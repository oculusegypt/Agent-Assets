#!/usr/bin/env python3
"""
ACIS Production Integration — FLUX.1 Image Generation via Replicate API
═══════════════════════════════════════════════════════════════════════════
STATUS: ✅ Ready to run (requires REPLICATE_API_TOKEN)
HONESTY: This code calls Replicate API. It costs ~$0.03/image. Not free.
         Free tier: ~500 images/month. After that: payment required.

Agent: Image Worker (FLUX pipeline)
Purpose: Generate cinematic keyframes from optimized prompts
"""

import os
import replicate
import requests
import json
import time
from pathlib import Path
from typing import Dict, List, Optional

# ─── CONFIGURATION ─────────────────────────────────────────────────────
REPLICATE_API_TOKEN = os.environ.get("REPLICATE_API_TOKEN", "")
OUTPUT_DIR = Path("/tmp/acis-output/images")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# FLUX model on Replicate
FLUX_MODEL = "black-forest-labs/flux-dev"
FLUX_SCHNELL = "black-forest-labs/flux-schnell"  # Faster, slightly lower quality

# ACIS default parameters for cinematic quality
CINEMATIC_DEFAULTS = {
    "aspect_ratio": "21:9",       # 2.39:1 cinemascope
    "output_format": "png",
    "output_quality": 100,
    "guidance_scale": 3.5,        # FLUX uses lower CFG
    "num_inference_steps": 50,    # 50 for quality, 28 for speed
    "prompt_upsampling": True,     # FLUX internal prompt enhancement
}


def generate_image(
    prompt: str,
    scene_id: str = "test",
    shot_id: str = "001",
    width: int = 3840,
    height: int = 1608,
    use_schnell: bool = False,     # True = faster/cheaper, False = quality
    retry_on_failure: bool = True,
    max_retries: int = 3,
) -> Dict:
    """
    Generate a single cinematic image using FLUX via Replicate.
    
    HONESTY CHECK:
    - This costs money per image (~$0.03 for FLUX-dev)
    - Requires REPLICATE_API_TOKEN (not free to obtain)
    - May take 5-15 seconds per image
    - Returns URL, not local file (must download separately)
    
    Args:
        prompt: Full cinematic prompt (already optimized by AI-Prompt-Director)
        scene_id: Scene identifier for file naming
        shot_id: Shot identifier for file naming
        width: Image width in pixels (default 3840 for 4K)
        height: Image height in pixels (default 1608 for 2.39:1)
        use_schnell: Use faster/cheaper FLUX-schnell variant
        
    Returns:
        Dict with: {
            "success": bool,
            "image_url": str,           # Replicate CDN URL
            "local_path": str,          # Downloaded file path (if success)
            "cost_usd": float,          # Approximate cost
            "generation_time_seconds": float,
            "model_used": str,
            "scene_id": str,
            "shot_id": str,
            "prompt_used": str,
            "error": str (if failed)
        }
    """
    
    if not REPLICATE_API_TOKEN:
        return {
            "success": False,
            "error": "CRITICAL: REPLICATE_API_TOKEN not set. Get one at https://replicate.com/account/api-tokens. This is NOT free — requires account creation.",
            "cost_usd": 0.0,
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
    
    model = FLUX_SCHNELL if use_schnell else FLUX_MODEL
    start_time = time.time()
    
    try:
        # Run FLUX generation
        output = replicate.run(
            model,
            input={
                "prompt": prompt,
                "aspect_ratio": CINEMATIC_DEFAULTS["aspect_ratio"],
                "output_format": CINEMATIC_DEFAULTS["output_format"],
                "output_quality": CINEMATIC_DEFAULTS["output_quality"],
                "guidance_scale": CINEMATIC_DEFAULTS["guidance_scale"],
                "num_inference_steps": 28 if use_schnell else CINEMATIC_DEFAULTS["num_inference_steps"],
                "prompt_upsampling": CINEMATIC_DEFAULTS["prompt_upsampling"],
                "width": width,
                "height": height,
            }
        )
        
        generation_time = time.time() - start_time
        
        # FLUX returns a list with one URL
        if isinstance(output, list) and len(output) > 0:
            image_url = output[0]
        else:
            image_url = str(output)
        
        # Download to local storage
        local_filename = f"{scene_id}_{shot_id}_{int(time.time())}.png"
        local_path = OUTPUT_DIR / local_filename
        
        img_response = requests.get(image_url, timeout=30)
        img_response.raise_for_status()
        
        with open(local_path, "wb") as f:
            f.write(img_response.content)
        
        # Estimate cost (FLUX-dev ~$0.03, FLUX-schnell ~$0.01)
        cost = 0.01 if use_schnell else 0.03
        
        return {
            "success": True,
            "image_url": image_url,
            "local_path": str(local_path),
            "cost_usd": cost,
            "generation_time_seconds": round(generation_time, 2),
            "model_used": model,
            "scene_id": scene_id,
            "shot_id": shot_id,
            "prompt_used": prompt[:200] + "..." if len(prompt) > 200 else prompt,
            "error": None,
        }
        
    except Exception as e:
        if retry_on_failure and max_retries > 0:
            time.sleep(2)
            return generate_image(
                prompt=prompt,
                scene_id=scene_id,
                shot_id=shot_id,
                width=width,
                height=height,
                use_schnell=use_schnell,
                retry_on_failure=True,
                max_retries=max_retries - 1,
            )
        
        return {
            "success": False,
            "error": f"Generation failed after {max_retries} retries: {str(e)}",
            "cost_usd": 0.0,
            "scene_id": scene_id,
            "shot_id": shot_id,
            "prompt_used": prompt[:200] + "..." if len(prompt) > 200 else prompt,
        }


def batch_generate_images(
    prompts: List[Dict],
    callback=None,
) -> List[Dict]:
    """
    Generate multiple images in sequence (not parallel — Replicate rate limits).
    
    HONESTY: Each image costs ~$0.03. 16 images = ~$0.48. Not free.
    
    Args:
        prompts: List of {"prompt": str, "scene_id": str, "shot_id": str}
        callback: Optional function(scene_id, shot_id, result) for progress updates
        
    Returns:
        List of result Dicts
    """
    results = []
    total_cost = 0.0
    
    for i, item in enumerate(prompts):
        result = generate_image(
            prompt=item["prompt"],
            scene_id=item.get("scene_id", f"scene_{i}"),
            shot_id=item.get("shot_id", f"shot_{i:03d}"),
        )
        results.append(result)
        
        if result["success"]:
            total_cost += result["cost_usd"]
        
        if callback:
            callback(item.get("scene_id"), item.get("shot_id"), result)
        
        # Rate limiting: wait between requests
        if i < len(prompts) - 1:
            time.sleep(1.5)
    
    # Summary
    successful = sum(1 for r in results if r["success"])
    print(f"\n{'═'*60}")
    print(f"BATCH GENERATION COMPLETE")
    print(f"{'═'*60}")
    print(f"Total images requested: {len(prompts)}")
    print(f"Successfully generated: {successful}")
    print(f"Failed: {len(prompts) - successful}")
    print(f"Total cost: ${total_cost:.2f} USD")
    print(f"Average time per image: {sum(r['generation_time_seconds'] for r in results if r['success']) / max(successful, 1):.1f}s")
    print(f"Output directory: {OUTPUT_DIR}")
    print(f"{'═'*60}\n")
    
    return results


# ─── EXAMPLE / TEST ──────────────────────────────────────────────────────
if __name__ == "__main__":
    
    # HONESTY: This test will FAIL without REPLICATE_API_TOKEN
    #          It will also COST ~$0.03 to run
    
    test_prompt = """
    Cinematic scene: A warm-lit study in ancient Baghdad, golden hour. 
    A young scholar (not old!) in flowing robes gazes at stars through an arched window. 
    Oil lamp glows amber. Deep midnight blue sky visible. Hand-painted animation style 
    like Disney/Pixar short film. Warm brushstrokes, painterly background. 
    2.39:1 aspect ratio, film grain, cinematic composition.
    """
    
    print("="*60)
    print("ACIS FLUX Image Generation Test")
    print("="*60)
    print(f"REPLICATE_API_TOKEN set: {'Yes' if REPLICATE_API_TOKEN else 'NO — WILL FAIL'}")
    print(f"Expected cost: $0.03 USD")
    print(f"Expected time: 5-15 seconds")
    print("="*60)
    
    result = generate_image(
        prompt=test_prompt,
        scene_id="test_scene",
        shot_id="001",
        use_schnell=False,  # Use full quality for test
    )
    
    print(f"\nResult:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
