#!/usr/bin/env python3
"""
ACIS Production Integration — ACE-Step Music Generation via HuggingFace or Local
═══════════════════════════════════════════════════════════════════════════════
STATUS: ⚠️ Partial — ACE-Step is not yet on HuggingFace Inference API
HONESTY: ACE-Step is a research model. Options:
         1. HuggingFace Inference API: NOT available (model not deployed)
         2. Self-host on GPU: Requires ~8GB VRAM, CUDA 12+, PyTorch 2.0+
         3. Alternative: MusicGen (available on HuggingFace, free tier)
         4. Alternative: Stable Audio Open (Replicate, ~$0.05/generation)
         5. Alternative: Suno API (paid, $10/month, commercial)

Agent: Music Worker (ACE-Step pipeline)
Purpose: Generate emotion-driven background scores and scene music
"""

import os
import requests
import json
import time
import base64
from pathlib import Path
from typing import Dict, List, Optional

# ─── CONFIGURATION ─────────────────────────────────────────────────────
HUGGINGFACE_TOKEN = os.environ.get("HUGGINGFACE_TOKEN", "")
REPLICATE_API_TOKEN = os.environ.get("REPLICATE_API_TOKEN", "")
OUTPUT_DIR = Path("/tmp/acis-output/music")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# HuggingFace endpoints
MUSICGEN_API_URL = "https://api-inference.huggingface.co/models/facebook/musicgen-small"
# MusicGen is available but quality is lower than ACE-Step

# Replicate alternatives
STABLE_AUDIO_URL = "https://api.replicate.com/v1/predictions"  # Via Replicate HTTP API

# ACE-Step local path (if self-hosted)
ACE_STEP_LOCAL_PATH = os.environ.get("ACE_STEP_LOCAL_PATH", "")


def generate_music_musicgen(
    prompt: str,                  # Text description of desired music
    scene_id: str = "test",
    shot_id: str = "001",
    duration_seconds: int = 10,    # MusicGen max ~30s
    guidance_scale: float = 3.0,
    max_retries: int = 3,
) -> Dict:
    """
    Generate music using MusicGen via HuggingFace Inference API.
    
    HONESTY CHECK — CRITICAL:
    - MusicGen is NOT ACE-Step. MusicGen generates short clips (10-30s).
    - ACE-Step is superior for structured musical composition but NOT available via API.
    - MusicGen free tier: ~1000 requests/month (shared across all HuggingFace APIs).
    - Quality: adequate for background ambience, NOT orchestral scoring.
    - For ACE-Step quality: must self-host on local GPU (8GB+ VRAM).
    - For production music: consider Suno API ($10/month) or commercial library.
    
    Args:
        prompt: Text description (e.g., "warm Arabic oud melody, cinematic, emotional, 60 BPM")
        scene_id: Scene identifier
        shot_id: Shot identifier
        duration_seconds: Length in seconds (max 30 for free tier)
        
    Returns:
        Dict with: {
            "success": bool,
            "music_path": str,
            "music_base64": str,
            "generation_time_seconds": float,
            "model_used": str,
            "duration_seconds": int,
            "quality_note": str,        # Honesty about MusicGen vs ACE-Step
            "scene_id": str,
            "shot_id": str,
            "error": str (if failed)
        }
    """
    
    if not HUGGINGFACE_TOKEN:
        return {
            "success": False,
            "error": "CRITICAL: HUGGINGFACE_TOKEN not set. MusicGen requires HuggingFace Inference API access. Free tier: ~1000 requests/month. Alternative: self-host ACE-Step on GPU (8GB+ VRAM) or use Suno API ($10/month).",
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
    
    # HONESTY: Warn that this is MusicGen, not ACE-Step
    quality_note = (
        "⚠️ Using MusicGen (HuggingFace) as ACE-Step fallback. "
        "MusicGen generates short clips with limited structure. "
        "For full orchestral scoring: self-host ACE-Step on GPU or use Suno API. "
        f"Duration requested: {duration_seconds}s (MusicGen works best 5-15s)."
    )
    
    print(f"\n{quality_note}\n")
    
    start_time = time.time()
    
    headers = {
        "Authorization": f"Bearer {HUGGINGFACE_TOKEN}",
        "Content-Type": "application/json",
    }
    
    payload = {
        "inputs": prompt,
        "parameters": {
            "guidance_scale": guidance_scale,
            "max_new_tokens": duration_seconds * 50,  # Approximate tokens per second
        }
    }
    
    try:
        response = requests.post(
            MUSICGEN_API_URL,
            headers=headers,
            json=payload,
            timeout=120,
        )
        
        if response.status_code == 503 and max_retries > 0:
            print(f"Model loading... waiting 15s")
            time.sleep(15)
            return generate_music_musicgen(
                prompt=prompt,
                scene_id=scene_id,
                shot_id=shot_id,
                duration_seconds=duration_seconds,
                guidance_scale=guidance_scale,
                max_retries=max_retries - 1,
            )
        
        response.raise_for_status()
        
        # Response is audio bytes
        audio_bytes = response.content
        generation_time = time.time() - start_time
        
        # Save
        local_filename = f"{scene_id}_{shot_id}_musicgen_{int(time.time())}.wav"
        local_path = OUTPUT_DIR / local_filename
        
        with open(local_path, "wb") as f:
            f.write(audio_bytes)
        
        audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
        
        return {
            "success": True,
            "music_path": str(local_path),
            "music_base64": audio_b64,
            "generation_time_seconds": round(generation_time, 2),
            "model_used": "facebook/musicgen-small (ACE-Step fallback)",
            "duration_seconds": duration_seconds,
            "quality_note": quality_note,
            "scene_id": scene_id,
            "shot_id": shot_id,
            "error": None,
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"Music generation failed: {str(e)}. MusicGen may be overloaded. For reliable music: self-host ACE-Step, use Stable Audio Open on Replicate (~$0.05/gen), or Suno API ($10/month).",
            "scene_id": scene_id,
            "shot_id": shot_id,
        }


def generate_music_stable_audio_replicate(
    prompt: str,
    scene_id: str = "test",
    shot_id: str = "001",
    duration_seconds: int = 10,
    negative_prompt: str = "",
    max_retries: int = 3,
) -> Dict:
    """
    Generate music using Stable Audio Open via Replicate.
    
    HONESTY: Stable Audio Open is higher quality than MusicGen for sound design.
    Cost: ~$0.05-0.10 per generation (varies by duration).
    Requires REPLICATE_API_TOKEN with paid credits.
    Duration: up to 47 seconds (model limit).
    """
    
    if not REPLICATE_API_TOKEN:
        return {
            "success": False,
            "error": "REPLICATE_API_TOKEN not set. Stable Audio Open requires paid Replicate credits (~$0.05-0.10/gen).",
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
    
    start_time = time.time()
    
    headers = {
        "Authorization": f"Token {REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
    }
    
    payload = {
        "version": "stability-ai/stable-audio-open-1.0",
        "input": {
            "prompt": prompt,
            "negative_prompt": negative_prompt or "low quality, distorted, noisy",
            "seconds": min(duration_seconds, 47),  # Model limit
            "steps": 100,
            "cfg_scale": 7.0,
        }
    }
    
    try:
        # Start prediction
        response = requests.post(
            STABLE_AUDIO_URL,
            headers=headers,
            json=payload,
            timeout=30,
        )
        response.raise_for_status()
        
        prediction = response.json()
        prediction_id = prediction["id"]
        
        # Poll for completion
        poll_url = f"https://api.replicate.com/v1/predictions/{prediction_id}"
        max_poll_time = 300  # 5 minutes
        poll_start = time.time()
        
        while time.time() - poll_start < max_poll_time:
            poll_response = requests.get(poll_url, headers=headers, timeout=30)
            poll_response.raise_for_status()
            status = poll_response.json()
            
            if status["status"] == "succeeded":
                output_url = status["output"]
                
                # Download
                audio_response = requests.get(output_url, timeout=60)
                audio_response.raise_for_status()
                audio_bytes = audio_response.content
                
                generation_time = time.time() - start_time
                
                local_filename = f"{scene_id}_{shot_id}_stableaudio_{int(time.time())}.wav"
                local_path = OUTPUT_DIR / local_filename
                
                with open(local_path, "wb") as f:
                    f.write(audio_bytes)
                
                audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
                
                return {
                    "success": True,
                    "music_path": str(local_path),
                    "music_base64": audio_b64,
                    "generation_time_seconds": round(generation_time, 2),
                    "model_used": "stability-ai/stable-audio-open-1.0",
                    "duration_seconds": min(duration_seconds, 47),
                    "quality_note": "Stable Audio Open — better quality than MusicGen, but not full ACE-Step orchestral. Cost: ~$0.05-0.10/gen.",
                    "scene_id": scene_id,
                    "shot_id": shot_id,
                    "error": None,
                }
                
            elif status["status"] == "failed":
                return {
                    "success": False,
                    "error": f"Stable Audio generation failed: {status.get('error', 'Unknown error')}",
                    "scene_id": scene_id,
                    "shot_id": shot_id,
                }
            
            time.sleep(5)
        
        return {
            "success": False,
            "error": "Polling timeout — Stable Audio generation took too long. Try again or use MusicGen fallback.",
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"Stable Audio API error: {str(e)}. Fallback: MusicGen (free tier) or self-host ACE-Step.",
            "scene_id": scene_id,
            "shot_id": shot_id,
        }


def generate_music(
    prompt: str,
    scene_id: str = "test",
    shot_id: str = "001",
    duration_seconds: int = 10,
    preferred_model: str = "auto",  # "auto", "musicgen", "stable_audio", "ace_step_local"
) -> Dict:
    """
    Smart wrapper: Try preferred model, fallback through chain.
    
    Priority: stable_audio (quality) → musicgen (free) → error with guidance
    """
    
    if preferred_model == "ace_step_local":
        # HONESTY: Not implemented — requires local GPU setup
        return {
            "success": False,
            "error": "ACE-Step local inference not implemented in this script. Requires: Python 3.10+, PyTorch 2.0+, CUDA 12+, 8GB+ VRAM. Install from https://github.com/ace-step/ace-step and run inference locally.",
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
    
    if preferred_model in ["auto", "stable_audio"] and REPLICATE_API_TOKEN:
        result = generate_music_stable_audio_replicate(
            prompt=prompt,
            scene_id=scene_id,
            shot_id=shot_id,
            duration_seconds=duration_seconds,
        )
        if result["success"]:
            return result
        print(f"Stable Audio failed, falling back to MusicGen...")
    
    if preferred_model in ["auto", "musicgen"] and HUGGINGFACE_TOKEN:
        return generate_music_musicgen(
            prompt=prompt,
            scene_id=scene_id,
            shot_id=shot_id,
            duration_seconds=duration_seconds,
        )
    
    return {
        "success": False,
        "error": "No music generation backend available. Options: (1) Set REPLICATE_API_TOKEN for Stable Audio (~$0.05/gen), (2) Set HUGGINGFACE_TOKEN for MusicGen (free tier, limited quality), (3) Self-host ACE-Step on GPU (best quality, requires 8GB VRAM).",
        "scene_id": scene_id,
        "shot_id": shot_id,
    }


# ─── EXAMPLE / TEST ──────────────────────────────────────────────────────
if __name__ == "__main__":
    
    print("="*60)
    print("ACIS Music Generation Test")
    print("="*60)
    print(f"HUGGINGFACE_TOKEN set: {'Yes' if HUGGINGFACE_TOKEN else 'NO'}")
    print(f"REPLICATE_API_TOKEN set: {'Yes' if REPLICATE_API_TOKEN else 'NO'}")
    print(f"ACE_STEP_LOCAL_PATH set: {'Yes' if ACE_STEP_LOCAL_PATH else 'NO'}")
    print("="*60)
    
    test_prompt = "Warm Arabic oud melody, cinematic emotional atmosphere, soft strings in background, 60 BPM, golden hour mood"
    
    print(f"\nGenerating: {test_prompt[:60]}...")
    print(f"Duration: 10 seconds")
    print(f"Model: auto (tries stable_audio → musicgen)")
    
    result = generate_music(
        prompt=test_prompt,
        scene_id="scene_01",
        shot_id="001",
        duration_seconds=10,
        preferred_model="auto",
    )
    
    print(f"\nResult:")
    print(json.dumps({
        "success": result.get("success"),
        "model": result.get("model_used"),
        "path": result.get("music_path"),
        "time": result.get("generation_time_seconds"),
        "quality_note": result.get("quality_note"),
        "error": result.get("error"),
    }, indent=2, ensure_ascii=False))
