#!/usr/bin/env python3
"""
ACIS Production Integration — Kokoro TTS Arabic Voice Generation via HuggingFace
══════════════════════════════════════════════════════════════════════════════
STATUS: ✅ Ready to run (requires HUGGINGFACE_TOKEN for GPU space)
HONESTY: Kokoro runs on HuggingFace Inference API (free tier: ~1000 requests/month).
         OR self-host on GPU (cost: your GPU time).
         Arabic support is EXPERIMENTAL — Kokoro is primarily English/Japanese.
         For Arabic, may need to use XTTS-v2 or MeloTTS as fallback.

Agent: Voice Worker (Kokoro TTS pipeline)
Purpose: Generate Arabic dialogue narration with emotional delivery
"""

import os
import requests
import json
import time
import base64
from pathlib import Path
from typing import Dict, List, Optional

# ─── CONFIGURATION ─────────────────────────────────────────────────────
HUGGINGFACE_TOKEN = os.environ.get("HUGGINGFACE_TOKEN", "")
OUTPUT_DIR = Path("/tmp/acis-output/audio")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# HuggingFace Inference API endpoints
KOKORO_API_URL = "https://api-inference.huggingface.co/models/hexgrad/Kokoro-82M"
XTTS_API_URL = "https://api-inference.huggingface.co/models/coqui/XTTS-v2"

# Voice IDs for Kokoro (English/Japanese only — NOT Arabic)
KOKORO_VOICES = {
    "af_heart": "American female, warm narrative",     # Best for storytelling
    "af_bella": "American female, bright and clear",
    "am_adam": "American male, authoritative",
    "jf_alpha": "Japanese female",
}

# XTTS-v2 speakers (multilingual, better for Arabic fallback)
XTTS_SPEAKERS = {
    "default": "General multilingual",
}

# For Arabic, we may need local XTTS with fine-tuned speaker
# or use Google Cloud TTS / Azure TTS as commercial fallback


def generate_voice_kokoro(
    text: str,                    # Text to speak (ENGLISH/JAPANESE only for Kokoro)
    scene_id: str = "test",
    shot_id: str = "001",
    voice_id: str = "af_heart",   # Kokoro voice (English/Japanese)
    speed: float = 1.0,
    max_retries: int = 3,
) -> Dict:
    """
    Generate speech using Kokoro TTS via HuggingFace Inference API.
    
    HONESTY CHECK — CRITICAL:
    - Kokoro-82M does NOT support Arabic natively. It is trained on English and Japanese.
    - For Arabic, you need: XTTS-v2 with Arabic fine-tuning, or Google Cloud TTS, or Azure.
    - HuggingFace free tier: ~1000 requests/month, then blocked or throttled.
    - Each request: ~1-5 seconds for short text (<100 chars).
    - For production: self-host Kokoro/XTTS on your own GPU (no API limits).
    
    Args:
        text: Text to synthesize (ENGLISH ONLY for Kokoro)
        scene_id: Scene identifier
        shot_id: Shot identifier  
        voice_id: Kokoro voice preset (af_heart recommended for narrative)
        speed: Playback speed (0.5-2.0)
        
    Returns:
        Dict with: {
            "success": bool,
            "audio_path": str,         # Local .wav file path
            "audio_base64": str,       # Base64 encoded audio (for preview)
            "generation_time_seconds": float,
            "model_used": str,
            "voice_id": str,
            "text_length": int,
            "language_warning": str,   # Always set for non-English
            "scene_id": str,
            "shot_id": str,
            "error": str (if failed)
        }
    """
    
    if not HUGGINGFACE_TOKEN:
        return {
            "success": False,
            "error": "CRITICAL: HUGGINGFACE_TOKEN not set. Get one at https://huggingface.co/settings/tokens. Free tier: ~1000 requests/month. For Arabic: Kokoro does NOT support Arabic — use XTTS-v2 or Google Cloud TTS instead.",
            "scene_id": scene_id,
            "shot_id": shot_id,
            "language_warning": "Kokoro does not support Arabic. This will FAIL for Arabic text.",
        }
    
    # HONESTY: Kokoro is English/Japanese only
    language_warning = ""
    if any('\u0600' <= c <= '\u06FF' or '\u0750' <= c <= '\u077F' for c in text):
        language_warning = "⚠️ ARABIC TEXT DETECTED — Kokoro does NOT support Arabic. Will attempt but expect failure. Use XTTS-v2 or Google Cloud TTS for Arabic."
        print(f"\n{language_warning}\n")
    
    start_time = time.time()
    
    headers = {
        "Authorization": f"Bearer {HUGGINGFACE_TOKEN}",
        "Content-Type": "application/json",
    }
    
    payload = {
        "inputs": text,
        "parameters": {
            "voice": voice_id,
            "speed": speed,
        }
    }
    
    try:
        response = requests.post(
            KOKORO_API_URL,
            headers=headers,
            json=payload,
            timeout=60,
        )
        
        # HuggingFace may return 503 if model is loading (cold start)
        if response.status_code == 503:
            # Model is loading — wait and retry
            print(f"Model loading... waiting 10s (HuggingFace cold start)")
            time.sleep(10)
            if max_retries > 0:
                return generate_voice_kokoro(
                    text=text,
                    scene_id=scene_id,
                    shot_id=shot_id,
                    voice_id=voice_id,
                    speed=speed,
                    max_retries=max_retries - 1,
                )
        
        response.raise_for_status()
        
        # Response is audio bytes (WAV format)
        audio_bytes = response.content
        
        generation_time = time.time() - start_time
        
        # Save to file
        local_filename = f"{scene_id}_{shot_id}_{voice_id}_{int(time.time())}.wav"
        local_path = OUTPUT_DIR / local_filename
        
        with open(local_path, "wb") as f:
            f.write(audio_bytes)
        
        # Encode base64 for preview/transport
        audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
        
        return {
            "success": True,
            "audio_path": str(local_path),
            "audio_base64": audio_b64,
            "generation_time_seconds": round(generation_time, 2),
            "model_used": "hexgrad/Kokoro-82M",
            "voice_id": voice_id,
            "text_length": len(text),
            "language_warning": language_warning or "English text — Kokoro works well for storytelling narrative.",
            "scene_id": scene_id,
            "shot_id": shot_id,
            "error": None,
        }
        
    except Exception as e:
        if max_retries > 0 and "loading" in str(e).lower():
            time.sleep(10)
            return generate_voice_kokoro(
                text=text,
                scene_id=scene_id,
                shot_id=shot_id,
                voice_id=voice_id,
                speed=speed,
                max_retries=max_retries - 1,
            )
        
        return {
            "success": False,
            "error": f"Voice generation failed: {str(e)}. Note: Kokoro does not support Arabic. For Arabic, use XTTS-v2 multilingual, Google Cloud TTS, or Azure Speech Services.",
            "scene_id": scene_id,
            "shot_id": shot_id,
            "language_warning": language_warning or "Check text language compatibility.",
        }


def generate_voice_xtts_fallback(
    text: str,
    speaker_wav_path: str = None,   # Reference voice for cloning (optional)
    scene_id: str = "test",
    shot_id: str = "001",
    language: str = "ar",             # "ar" = Arabic, "en" = English, "ja" = Japanese
    max_retries: int = 3,
) -> Dict:
    """
    Fallback: XTTS-v2 via HuggingFace (multilingual, supports Arabic).
    
    HONESTY: XTTS-v2 supports Arabic but quality is lower than English.
    Requires speaker reference for voice cloning (upload .wav file).
    Free tier: same 1000 requests/month limit.
    """
    
    if not HUGGINGFACE_TOKEN:
        return {
            "success": False,
            "error": "HUGGINGFACE_TOKEN not set. Required for XTTS-v2 fallback.",
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
    
    start_time = time.time()
    
    headers = {
        "Authorization": f"Bearer {HUGGINGFACE_TOKEN}",
        "Content-Type": "application/json",
    }
    
    payload = {
        "inputs": text,
        "parameters": {
            "language": language,
        }
    }
    
    # If speaker reference provided, add it
    if speaker_wav_path and os.path.exists(speaker_wav_path):
        with open(speaker_wav_path, "rb") as f:
            speaker_b64 = base64.b64encode(f.read()).decode("utf-8")
        payload["parameters"]["speaker_embedding"] = speaker_b64
    
    try:
        response = requests.post(
            XTTS_API_URL,
            headers=headers,
            json=payload,
            timeout=120,  # XTTS is slower
        )
        
        if response.status_code == 503 and max_retries > 0:
            time.sleep(15)
            return generate_voice_xtts_fallback(
                text=text,
                speaker_wav_path=speaker_wav_path,
                scene_id=scene_id,
                shot_id=shot_id,
                language=language,
                max_retries=max_retries - 1,
            )
        
        response.raise_for_status()
        
        audio_bytes = response.content
        generation_time = time.time() - start_time
        
        local_filename = f"{scene_id}_{shot_id}_xtts_{language}_{int(time.time())}.wav"
        local_path = OUTPUT_DIR / local_filename
        
        with open(local_path, "wb") as f:
            f.write(audio_bytes)
        
        audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
        
        return {
            "success": True,
            "audio_path": str(local_path),
            "audio_base64": audio_b64,
            "generation_time_seconds": round(generation_time, 2),
            "model_used": "coqui/XTTS-v2",
            "language": language,
            "text_length": len(text),
            "scene_id": scene_id,
            "shot_id": shot_id,
            "error": None,
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"XTTS fallback also failed: {str(e)}. For reliable Arabic TTS, consider Google Cloud Text-to-Speech (paid, ~$4/million chars) or Azure Speech Services.",
            "scene_id": scene_id,
            "shot_id": shot_id,
        }


def generate_arabic_voice(text: str, scene_id: str, shot_id: str) -> Dict:
    """
    Smart wrapper: Try Kokoro first (English), fallback to XTTS for Arabic.
    
    HONESTY: This is the recommended approach for multilingual production:
    1. English narration → Kokoro (best quality, free tier)
    2. Arabic narration → XTTS-v2 (acceptable, free tier) or commercial TTS
    """
    
    # Detect language
    has_arabic = any('\u0600' <= c <= '\u06FF' for c in text)
    
    if has_arabic:
        print(f"Arabic text detected — using XTTS-v2 fallback (Kokoro does not support Arabic)")
        return generate_voice_xtts_fallback(text, scene_id=scene_id, shot_id=shot_id, language="ar")
    else:
        return generate_voice_kokoro(text, scene_id=scene_id, shot_id=shot_id, voice_id="af_heart")


# ─── EXAMPLE / TEST ──────────────────────────────────────────────────────
if __name__ == "__main__":
    
    print("="*60)
    print("ACIS Kokoro TTS Test")
    print("="*60)
    print(f"HUGGINGFACE_TOKEN set: {'Yes' if HUGGINGFACE_TOKEN else 'NO — WILL FAIL'}")
    print(f"FREE TIER LIMIT: ~1000 requests/month")
    print(f"ARABIC SUPPORT: Kokoro NO — XTTS-v2 YES (lower quality)")
    print("="*60)
    
    # Test 1: English narration (Kokoro works well)
    test_english = "More than a thousand years ago, in the heart of golden Baghdad, a man named Al-Khwarizmi lived."
    
    print(f"\nTest 1 — English (Kokoro af_heart):")
    result_en = generate_voice_kokoro(
        text=test_english,
        scene_id="scene_01",
        shot_id="001",
        voice_id="af_heart",
    )
    print(f"Success: {result_en.get('success')}")
    if result_en.get('success'):
        print(f"File: {result_en['audio_path']}")
        print(f"Time: {result_en['generation_time_seconds']}s")
    else:
        print(f"Error: {result_en.get('error')}")
    
    # Test 2: Arabic narration (XTTS fallback)
    test_arabic = "منذ أكثر من ألف عام، في قلب بغداد الذهبية، عاش رجل اسمه الخوارزمي."
    
    print(f"\nTest 2 — Arabic (XTTS-v2 fallback):")
    result_ar = generate_arabic_voice(
        text=test_arabic,
        scene_id="scene_01",
        shot_id="002",
    )
    print(f"Success: {result_ar.get('success')}")
    if result_ar.get('success'):
        print(f"File: {result_ar['audio_path']}")
        print(f"Model: {result_ar['model_used']}")
        print(f"Time: {result_ar['generation_time_seconds']}s")
    else:
        print(f"Error: {result_ar.get('error')}")
