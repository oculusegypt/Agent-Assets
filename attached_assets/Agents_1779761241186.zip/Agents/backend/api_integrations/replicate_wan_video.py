#!/usr/bin/env python3
"""
ACIS Production Integration — WAN Video Generation via Replicate API
═══════════════════════════════════════════════════════════════════════════
STATUS: ✅ Ready to run (requires REPLICATE_API_TOKEN)
HONESTY: This code calls Replicate API. It costs ~$0.10-0.50 per video (5-10s).
         Not free. Requires paid Replicate account with sufficient credits.
         WAN Video I2V is GPU-intensive and relatively expensive.

Agent: Video Worker (WAN Video pipeline)
Purpose: Generate cinematic motion shots from keyframe images
"""

import os
import replicate
import requests
import json
import time
from pathlib import Path
from typing import Dict, List, Optional

# ─── CONFIGURATION ─────────────────────────────────────────────────────
REPLICATE_API_TOKEN = os.environ.get("REPLICATE_API_TOKEN", "")
OUTPUT_DIR = Path("/tmp/acis-output/videos")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# WAN Video models on Replicate
WAN_I2V = "wanchen7/wan-video-i2v-14b"          # Image-to-Video, 14B params
WAN_T2V = "wanchen7/wan-video-t2v-14b"          # Text-to-Video, 14B params
WAN_T2V_480P = "wanchen7/wan-video-t2v-1.3b-480p"  # Faster, lower quality


def generate_video_i2v(
    image_path: str,              # Local path to keyframe image
    prompt: str,                  # Motion description
    scene_id: str = "test",
    shot_id: str = "001",
    duration_seconds: int = 5,    # 5 or 10 seconds
    fps: int = 8,                 # 8 fps = smooth enough for animation
    guidance_scale: float = 5.0,
    max_retries: int = 3,
) -> Dict:
    """
    Generate video from image using WAN I2V via Replicate.
    
    HONESTY CHECK:
    - This costs $0.10-0.50 per video depending on duration and resolution
    - REPLICATE_API_TOKEN required (not free — needs paid account with credits)
    - 5s video at 8fps = 40 frames, ~$0.15
    - 10s video at 8fps = 80 frames, ~$0.30
    - May take 30-120 seconds per video (GPU queue + generation)
    - Image must be uploaded to accessible URL (Replicate can't access local files)
    
    Args:
        image_path: Path to source keyframe (will be uploaded to temp URL)
        prompt: Motion description (e.g., "camera slowly pans right, golden particles drift")
        scene_id: Scene identifier
        shot_id: Shot identifier
        duration_seconds: Video length (5 or 10 typical)
        fps: Frames per second (8 recommended for cost/speed balance)
        
    Returns:
        Dict with: {
            "success": bool,
            "video_url": str,
            "local_path": str,
            "cost_usd": float,
            "generation_time_seconds": float,
            "model_used": str,
            "frames": int,
            "resolution": str,
            "scene_id": str,
            "shot_id": str,
            "error": str (if failed)
        }
    """
    
    if not REPLICATE_API_TOKEN:
        return {
            "success": False,
            "error": "CRITICAL: REPLICATE_API_TOKEN not set. Get one at https://replicate.com/account/api-tokens. WAN Video requires PAID credits — ~$0.15-0.30 per 5-10s video.",
            "cost_usd": 0.0,
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
    
    # HONESTY: Image must be publicly accessible URL
    # Replicate can't read local files directly
    # We need to upload to a temporary public URL or data URI
    
    if not os.path.exists(image_path):
        return {
            "success": False,
            "error": f"Image file not found: {image_path}",
            "cost_usd": 0.0,
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
    
    start_time = time.time()
    
    try:
        # Convert image to base64 data URI (if small enough) or upload to temp storage
        # For production, use S3/MinIO pre-signed URLs
        
        # Read image and encode
        import base64
        with open(image_path, "rb") as f:
            image_data = f.read()
        
        # Check size — if > 2MB, need external upload
        if len(image_data) > 2 * 1024 * 1024:
            return {
                "success": False,
                "error": f"Image too large ({len(image_data)/1024/1024:.1f}MB). Max 2MB for base64. Upload to S3/MinIO and use URL instead.",
                "cost_usd": 0.0,
                "scene_id": scene_id,
                "shot_id": shot_id,
            }
        
        image_b64 = base64.b64encode(image_data).decode("utf-8")
        # Detect mime type from extension
        ext = Path(image_path).suffix.lower()
        mime = "image/png" if ext == ".png" else "image/jpeg" if ext in [".jpg", ".jpeg"] else "image/webp"
        image_url = f"data:{mime};base64,{image_b64}"
        
        # Run WAN I2V
        output = replicate.run(
            WAN_I2V,
            input={
                "image": image_url,
                "prompt": prompt,
                "max_area": "720x1280",        # Resolution: 720p vertical or custom
                "frame_rate": fps,
                "num_frames": duration_seconds * fps,  # Total frames
                "negative_prompt": "blurry, distorted, low quality, watermark, text overlay, bad anatomy",
                "guidance_scale": guidance_scale,
                "num_inference_steps": 40,       # 40 for quality, 20 for speed
            }
        )
        
        generation_time = time.time() - start_time
        
        # WAN returns video URL
        if isinstance(output, list) and len(output) > 0:
            video_url = output[0]
        else:
            video_url = str(output)
        
        # Download video
        local_filename = f"{scene_id}_{shot_id}_{int(time.time())}.mp4"
        local_path = OUTPUT_DIR / local_filename
        
        vid_response = requests.get(video_url, timeout=120)
        vid_response.raise_for_status()
        
        with open(local_path, "wb") as f:
            f.write(vid_response.content)
        
        # Estimate cost (WAN I2V 14B ~$0.15 for 5s at 720p)
        frames = duration_seconds * fps
        cost = (frames / 40) * 0.15  # Approximate: $0.15 per 40 frames
        
        return {
            "success": True,
            "video_url": video_url,
            "local_path": str(local_path),
            "cost_usd": round(cost, 2),
            "generation_time_seconds": round(generation_time, 2),
            "model_used": WAN_I2V,
            "frames": frames,
            "resolution": "720x1280",
            "scene_id": scene_id,
            "shot_id": shot_id,
            "prompt_used": prompt[:200] + "..." if len(prompt) > 200 else prompt,
            "error": None,
        }
        
    except Exception as e:
        if max_retries > 0:
            time.sleep(5)
            return generate_video_i2v(
                image_path=image_path,
                prompt=prompt,
                scene_id=scene_id,
                shot_id=shot_id,
                duration_seconds=duration_seconds,
                fps=fps,
                guidance_scale=guidance_scale,
                max_retries=max_retries - 1,
            )
        
        return {
            "success": False,
            "error": f"Video generation failed after retries: {str(e)}",
            "cost_usd": 0.0,
            "scene_id": scene_id,
            "shot_id": shot_id,
        }


def generate_video_t2v(
    prompt: str,
    scene_id: str = "test",
    shot_id: str = "001",
    duration_seconds: int = 5,
    fps: int = 8,
    max_retries: int = 3,
) -> Dict:
    """
    Generate video from text using WAN T2V (no image needed).
    
    HONESTY: Text-to-video is MORE EXPENSIVE than I2V. ~$0.30-0.50 for 5-10s.
    Lower quality than I2V (no reference image). Use I2V when keyframe exists.
    """
    
    if not REPLICATE_API_TOKEN:
        return {
            "success": False,
            "error": "CRITICAL: REPLICATE_API_TOKEN not set. WAN T2V requires PAID credits — ~$0.30-0.50 per 5-10s video.",
            "cost_usd": 0.0,
            "scene_id": scene_id,
            "shot_id": shot_id,
        }
    
    start_time = time.time()
    
    try:
        output = replicate.run(
            WAN_T2V,
            input={
                "prompt": prompt,
                "max_area": "720x1280",
                "frame_rate": fps,
                "num_frames": duration_seconds * fps,
                "negative_prompt": "blurry, distorted, low quality, watermark, text overlay",
                "guidance_scale": 5.0,
                "num_inference_steps": 40,
            }
        )
        
        generation_time = time.time() - start_time
        
        if isinstance(output, list) and len(output) > 0:
            video_url = output[0]
        else:
            video_url = str(output)
        
        local_filename = f"{scene_id}_{shot_id}_t2v_{int(time.time())}.mp4"
        local_path = OUTPUT_DIR / local_filename
        
        vid_response = requests.get(video_url, timeout=120)
        vid_response.raise_for_status()
        
        with open(local_path, "wb") as f:
            f.write(vid_response.content)
        
        frames = duration_seconds * fps
        cost = (frames / 40) * 0.30  # T2V is ~2x more expensive
        
        return {
            "success": True,
            "video_url": video_url,
            "local_path": str(local_path),
            "cost_usd": round(cost, 2),
            "generation_time_seconds": round(generation_time, 2),
            "model_used": WAN_T2V,
            "frames": frames,
            "resolution": "720x1280",
            "scene_id": scene_id,
            "shot_id": shot_id,
            "error": None,
        }
        
    except Exception as e:
        if max_retries > 0:
            time.sleep(5)
            return generate_video_t2v(
                prompt=prompt,
                scene_id=scene_id,
                shot_id=shot_id,
                duration_seconds=duration_seconds,
                fps=fps,
                max_retries=max_retries - 1,
            )
        
        return {
            "success": False,
            "error": f"T2V generation failed: {str(e)}",
            "cost_usd": 0.0,
            "scene_id": scene_id,
            "shot_id": shot_id,
        }


# ─── EXAMPLE / TEST ──────────────────────────────────────────────────────
if __name__ == "__main__":
    
    print("="*60)
    print("ACIS WAN Video Generation Test")
    print("="*60)
    print(f"REPLICATE_API_TOKEN set: {'Yes' if REPLICATE_API_TOKEN else 'NO — WILL FAIL'}")
    print(f"WARNING: Each video costs $0.15-0.50 USD. Not free.")
    print(f"WARNING: Requires paid Replicate account with sufficient credits.")
    print("="*60)
    
    # HONESTY: This test requires:
    # 1. REPLICATE_API_TOKEN with paid credits
    # 2. A keyframe image file to use as reference
    # 3. ~$0.15-0.30 per test run
    
    test_image = "/tmp/acis-output/images/test_keyframe.png"
    test_prompt = "Slow cinematic pan right, golden particles drift in warm lamplight, subtle breathing motion, painterly animation style"
    
    if not os.path.exists(test_image):
        print(f"\n⚠️  Test image not found: {test_image}")
        print("Generate an image first with replicate_flux.py, then run this test.")
    else:
        result = generate_video_i2v(
            image_path=test_image,
            prompt=test_prompt,
            scene_id="test",
            shot_id="001",
            duration_seconds=5,
            fps=8,
        )
        
        print(f"\nResult:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
