#!/bin/bash
# ACIS FFmpeg Setup Script for Ubuntu/Debian
# ════════════════════════════════════════════════════════════════════════════
# HONESTY: This installs FFmpeg BINARY (not source code).
#          'git clone' downloads source. 'apt install' gets the compiled binary.
#          If apt is unavailable, we compile from source (slower but works).

set -e

echo "======================================"
echo "ACIS FFmpeg Setup"
echo "======================================"

# Check if ffmpeg is already available
if command -v ffmpeg &> /dev/null; then
    echo "✅ ffmpeg already installed:"
    ffmpeg -version | head -1
    exit 0
fi

# Method 1: apt install (fastest, recommended)
echo ""
echo "Attempting apt install..."
if command -v apt &> /dev/null; then
    sudo apt-get update -qq
    sudo apt-get install -y ffmpeg
    
    if command -v ffmpeg &> /dev/null; then
        echo "✅ ffmpeg installed via apt"
        ffmpeg -version | head -1
        exit 0
    fi
fi

# Method 2: conda (if available)
if command -v conda &> /dev/null; then
    echo ""
    echo "Attempting conda install..."
    conda install -c conda-forge ffmpeg -y
    
    if command -v ffmpeg &> /dev/null; then
        echo "✅ ffmpeg installed via conda"
        ffmpeg -version | head -1
        exit 0
    fi
fi

# Method 3: Download static binary (no compile needed)
echo ""
echo "Downloading pre-built static binary..."
ARCH=$(uname -m)
if [ "$ARCH" = "x86_64" ]; then
    URL="https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-amd64-static.tar.xz"
else
    URL="https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-arm64-static.tar.xz"
fi

wget -q "$URL" -O /tmp/ffmpeg-static.tar.xz
tar -xf /tmp/ffmpeg-static.tar.xz -C /tmp/

# Find the extracted directory
FFMPEG_DIR=$(find /tmp -maxdepth 1 -name "ffmpeg-*-static" | head -1)
if [ -n "$FFMPEG_DIR" ]; then
    cp "$FFMPEG_DIR/ffmpeg" /usr/local/bin/ffmpeg 2>/dev/null || cp "$FFMPEG_DIR/ffmpeg" ~/bin/ffmpeg 2>/dev/null || echo "Cannot copy ffmpeg to PATH. Manual: cp $FFMPEG_DIR/ffmpeg ~/bin/ && export PATH=\$HOME/bin:\$PATH"
    cp "$FFMPEG_DIR/ffprobe" /usr/local/bin/ffprobe 2>/dev/null || true
fi

if command -v ffmpeg &> /dev/null; then
    echo "✅ ffmpeg installed via static binary"
    ffmpeg -version | head -1
    exit 0
fi

# Method 4: Compile from source (last resort, slow)
echo ""
echo "⚠️  All binary methods failed. Compiling from source..."
echo "WARNING: This takes 30-60 minutes and requires build tools."

sudo apt-get update -qq
sudo apt-get install -y \
    git \
    build-essential \
    yasm \
    cmake \
    libtool \
    libc6 \
    libc6-dev \
    unzip \
    wget \
    libnuma1 \
    libnuma-dev \
    pkg-config

# Clone and build
cd /tmp
git clone https://git.ffmpeg.org/ffmpeg.git ffmpeg
mkdir -p ffmpeg_build
cd ffmpeg

./configure \
    --prefix="/tmp/ffmpeg_build" \
    --enable-gpl \
    --enable-version3 \
    --disable-debug \
    --disable-doc \
    --enable-shared

make -j$(nproc)
make install

# Add to PATH
export PATH="/tmp/ffmpeg_build/bin:$PATH"
if ! grep -q "ffmpeg_build/bin" ~/.bashrc 2>/dev/null; then
    echo 'export PATH="/tmp/ffmpeg_build/bin:$PATH"' >> ~/.bashrc
fi

echo "✅ ffmpeg compiled from source"
/tmp/ffmpeg_build/bin/ffmpeg -version | head -1
echo ""
echo "⚠️  Compiled ffmpeg is in /tmp/ffmpeg_build/bin/"
echo "   Add to PATH: export PATH=\"/tmp/ffmpeg_build/bin:\$PATH\""
