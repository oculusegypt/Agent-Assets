# ACIS Production Runbook — Al-Khwarizmi Film
# ═══════════════════════════════════════════════════════════════════════════
# HONESTY: This is a step-by-step guide for YOU to run on YOUR computer.
#          I (the AI) cannot run these commands. You must run them yourself.
# ═══════════════════════════════════════════════════════════════════════════

## YOUR TOKENS (Keep Secret!)

```bash
export REPLICATE_API_TOKEN="r8_ZSv6z4B8mllrBiGx5FfDOk5y9L1vmPk49HPac"
export HUGGINGFACE_TOKEN="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"
export HUGGINGFACE_TOKEN_FINEGRAINED="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"
```

## STEP 1: Setup Environment (5 minutes)

```bash
# 1. Create project folder
mkdir ~/acis-al-khwarizmi && cd ~/acis-al-khwarizmi

# 2. Create Python virtual environment
python3 -m venv venv
source venv/bin/activate

# 3. Install dependencies
pip install replicate requests

# 4. Verify installations
python -c "import replicate; print('replicate OK')"
python -c "import requests; print('requests OK')"
```

## STEP 2: Save the Production Script

Save the file `acis_production_launcher.py` (copy from the code block below):

[See full script in /backend/acis_production_launcher.py]

## STEP 3: Run Image Generation (Replicate — Paid)

```bash
export REPLICATE_API_TOKEN="r8_ZSv6z4B8mllrBiGx5FfDOk5y9L1vmPk49HPac"
python acis_production_launcher.py
```

**Expected:**
- 3 images generated
- Cost: ~$0.09 USD
- Time: ~2-3 minutes total
- Output: `/tmp/acis-output/*.png`

## STEP 4: Generate More Images (Full Film — 16 images)

Edit the script and add 13 more prompts following the pattern. Cost: ~$0.48 total.

## STEP 5: Generate Video Clips (Replicate — Paid)

Use the prompts from `/Al_Khwarizmi_AI_Prompts_Ready_to_Run.md` Section "Sora / Veo / Runway / Kling — Video Prompts".

For WAN Video (best quality/price):
```python
import replicate
output = replicate.run(
    "wavespeedai/wan-2.1-i2v-480p",
    input={
        "image": open("scene01_baghdad_night.png", "rb"),
        "prompt": "slow gentle camera push forward through golden Baghdad night, warm lamplight flickering, stars twinkling, cinematic motion, 24fps",
        "num_frames": 81,  # ~3.4 seconds at 24fps
    }
)
```
Cost: ~$0.15-0.20 per 3-5 second clip. 8 clips = ~$1.50 total.

## STEP 6: Generate Voice (HuggingFace — Free Tier)

```python
import requests

headers = {"Authorization": f"Bearer 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"}
payload = {"inputs": "More than a thousand years ago, in the heart of golden Baghdad..."}

response = requests.post(
    "https://api-inference.huggingface.co/models/hexgrad/Kokoro-82M",
    headers=headers,
    json=payload,
)

with open("voice_narration.wav", "wb") as f:
    f.write(response.content)
```

**WARNING:** Kokoro only supports English/Japanese. For Arabic:
- Option A: Use XTTS-v2 (lower quality): `coqui/XTTS-v2`
- Option B: Use Google Cloud Text-to-Speech (~$0.20 for this film)
- Option C: Record manually (best quality for Arabic)

## STEP 7: Generate Music (HuggingFace — Free Tier)

```python
response = requests.post(
    "https://api-inference.huggingface.co/models/facebook/musicgen-small",
    headers=headers,
    json={"inputs": "warm Arabic oud melody, cinematic, emotional, soft strings, 60 BPM"},
)

with open("background_music.wav", "wb") as f:
    f.write(response.content)
```

**NOTE:** MusicGen produces short ambient clips (10-30s). For full orchestral score:
- Self-host ACE-Step on GPU (8GB+ VRAM)
- Or use Suno API ($10/month subscription)
- Or use royalty-free Arabic music library

## STEP 8: Assemble Final Film with FFmpeg

```bash
# Install FFmpeg first
sudo apt install ffmpeg  # Ubuntu
brew install ffmpeg     # Mac

# Create file list for concatenation
cat > files.txt << 'EOF'
file 'scene01_baghdad.mp4'
file 'scene03_khwarizmi.mp4'
file 'scene05_numbers.mp4'
# ... add all clips
EOF

# Concatenate with crossfade
ffmpeg -f concat -safe 0 -i files.txt -c copy temp.mp4

# Add narration audio
ffmpeg -i temp.mp4 -i voice_narration.wav -c:v copy -map 0:v:0 -map 1:a:0 -shortest film_with_voice.mp4

# Add background music (ducked under voice)
ffmpeg -i film_with_voice.mp4 -i background_music.wav -filter_complex "
  [0:a][1:a]amix=inputs=2:duration=first:weights='1 0.3'[outa]
" -map 0:v -map "[outa]" -c:v copy final_film.mp4

# Add title card
ffmpeg -i final_film.mp4 -vf "
  drawtext=text='الخوارزمي .. عبقري الأرقام':
  fontcolor=#FFD700:fontsize=72:x=(w-text_w)/2:y=(h-text_h)/2:
  enable='between(t,0,3)'
" -c:a copy -y al_khwarizmi_final.mp4
```

## STEP 9: View Your Film

```bash
vlc al_khwarizmi_final.mp4    # Linux
open al_khwarizmi_final.mp4   # Mac
start al_khwarizmi_final.mp4 # Windows
```

## 💰 Total Real Cost Summary

| Item | Quantity | Unit Cost | Total |
|------|----------|-----------|-------|
| FLUX Images (16) | 16 | $0.03 | $0.48 |
| WAN Video I2V (8 clips) | 8 | $0.18 | $1.44 |
| Voice (Kokoro English) | 8 | $0.00 | $0.00 |
| Music (MusicGen) | 4 | $0.00 | $0.00 |
| SFX (Stable Audio) | 6 | $0.05 | $0.30 |
| **TOTAL** | | | **~$2.22 USD** |

## ⚠️ Known Limitations (Honest)

1. **Arabic Voice**: Kokoro doesn't support Arabic. Options: XTTS-v2 (free, lower quality), Google Cloud TTS (paid, good quality), or manual recording (best).

2. **Music Quality**: MusicGen is ambient/short only. For orchestral score: self-host ACE-Step (needs GPU) or use Suno ($10/month).

3. **Video Motion**: WAN I2V creates motion from still images but isn't full animation. For Pixar-quality animation: needs custom trained models or manual animation.

4. **Image Consistency**: FLUX may generate slightly different character appearances across images. For consistency: use IP-Adapter or LoRA fine-tuning (advanced).

5. **Render Time**: 16 images + 8 videos = ~30-45 minutes total generation time.

## 📁 All Files You Need

Copy these from the workspace to your machine:
- `/backend/acis_production_launcher.py` — Main production script
- `/backend/api_integrations/replicate_flux.py` — Image generation module
- `/backend/api_integrations/replicate_wan_video.py` — Video generation module
- `/backend/api_integrations/huggingface_kokoro_tts.py` — Voice generation module
- `/backend/api_integrations/ace_step_music.py` — Music generation module
- `/backend/api_integrations/ffmpeg_assembler.py` — Film assembly module
- `/Al_Khwarizmi_AI_Prompts_Ready_to_Run.md` — All prompts ready to copy
- `/Al_Khwarizmi_Production_Master_Bible.md` — Complete production guide
- `/ACIS_RUNBOOK.md` — This file

## 🎯 What Success Looks Like

After running all steps, you will have:
- ✅ `al_khwarizmi_final.mp4` — Your 60-second film
- ✅ 16 cinematic keyframe images in `/tmp/acis-output/images/`
- ✅ 8 video clips in `/tmp/acis-output/videos/`
- ✅ Narration audio file
- ✅ Background music file
- ✅ Full production documentation

## 🆘 If Something Fails

| Problem | Solution |
|---------|----------|
| pip install fails | Check Python 3.10+ installed: `python3 --version` |
| Replicate API error | Check token valid: `curl -H "Authorization: Token $REPLICATE_API_TOKEN" https://api.replicate.com/v1/models` |
| HuggingFace 503 error | Model is loading — wait 15s and retry (cold start) |
| FFmpeg not found | Run `sudo apt install ffmpeg` or use setup script |
| Out of Replicate credits | Add $5-10 at replicate.com/account/billing |
| Arabic voice fails | Use Google Cloud TTS or record manually |

---

**HONESTY CONFIRMATION:** You are running these commands on YOUR computer.
I have provided the complete code, prompts, and instructions.
The APIs will charge YOUR account (Replicate, HuggingFace).
The files will be saved on YOUR machine.

**Ready? Start with Step 1 above. 🎬**
