# ACIS — Autonomous Cinematic Intelligence System

> **From Storyboard To Vision** → **ACIS v3.0** — A Complete Autonomous AI Film Production Operating System.  
> Powered by: **Free-First AI Model Stack** (FLUX, WAN Video, Kokoro TTS, ACE-Step) + **Gemini 2.5 Pro** Narrative Engine.

**Arabic**: "نظام الإنتاج السينمائي الذكي المستقل" — نظام تشغيل سينمائي بالذكاء الاصطناعي يُنتج أفلاماً كاملة تلقائياً من الفكرة إلى الفيلم النهائي.

**Arabic**: "استديو السينما الذكي المستقل" — نظام تشغيل سينمائي بالذكاء الاصطناعي يُخرج أفلاماً كاملة تلقائياً بذكاء هجين من موديلات متعددة.

---

## Vision

This is not an AI tool. This is an **Autonomous Cinematic Intelligence System (ACIS)** — a complete film production operating system.

When you type a single sentence, ACIS executes a full autonomous pipeline:

```
IDEA → HIERARCHICAL PLAN → SCENES → SHOTS → ASSETS → GENERATION → EVALUATION → OPTIMIZATION → TIMELINE → FINAL FILM
```

1. **Director Agent** classifies the idea, selects genre team, defines pipeline strategy
2. **Story Architect** writes the full screenplay (Gemini 2.5 Pro)
3. **Scene Breakdown** splits the story into autonomous production units
4. **Production Generation** creates prompts for all assets
5. **Model Orchestrator** routes to best free AI model (FLUX/WAN/Kokoro/ACE-Step)
6. **GPU Workers** generate real assets (images, videos, audio, music)
7. **Critic Agent** evaluates every asset (≥85 = accept, <85 = regenerate)
8. **Timeline Assembly** builds multi-track cinematic timeline (OTIO)
9. **Post Production** auto-grades, mixes, masters, and renders
10. **Export** delivers MP4 film + timeline project + asset library

**Every scene is an Autonomous Production Unit** with its own asset stack, model routing, quality scoring, and timeline injection.

**Output**: A complete cinematic film — not a plan, not a storyboard, a **real film**.

**Quality target**: Netflix internal pitch × Unreal Virtual Production × Hollywood Post House.

---

## Architecture

### ACIS System Architecture

ACIS is a **graph-based multi-agent film production system**. Every node is an agent, every edge is a workflow dependency, every run is a film production session.

```
┌──────────────┐
│  USER IDEA   │
└──────┬───────┘
       ↓
┌────────────────────┐
│  DIRECTOR AGENT     │  Genre classification, pipeline strategy, team selection
│  (Orchestrator LLM)  │
└────────┬───────────┘
         ↓
┌────────────────────────────┐
│  STORY ARCHITECT AGENT     │  Screenplay, characters, emotional arc (Gemini 2.5 Pro)
└────────┬───────────────────┘
         ↓
┌────────────────────────────┐
│  SCENE BREAKDOWN AGENT     │  Scenes with goals, emotions, visual style, duration
└────────┬───────────────────┘
         ↓
┌────────────────────────────┐
│ PRODUCTION GENERATION NODE │  Prompts for images, video, audio, music per scene
└────────┬───────────────────┘
         ↓
┌────────────────────────────┐
│ MODEL ORCHESTRATOR AGENT   │  FLUX/WAN/Kokoro/ACE-Step routing + fallback
└────────┬───────────────────┘
         ↓
┌────────────────────────────┐
│  CRITIC AGENT              │  Quality scoring ≥85 = accept, <85 = regenerate
└────────┬───────────────────┘
         ↓
┌────────────────────────────┐
│ GPU RENDER WORKERS (async) │  Redis queue → GPU nodes → Asset storage
└────────┬───────────────────┘
         ↓
┌────────────────────────────┐
│ TIMELINE ASSEMBLY ENGINE   │  Multi-track OTIO timeline (video/audio/music/sfx)
└────────┬───────────────────┘
         ↓
┌────────────────────────────┐
│ POST PRODUCTION AGENT      │  Color grade, audio mix, music master, transitions
└────────┬───────────────────┘
         ↓
┌────────────────────────────┐
│ INTERACTIVE EXPERIENCE     │  Control Room Dashboard (Unreal/Apple level UI)
└────────────────────────────┘
         ↓
    🎬 FINAL FILM EXPORT
       (MP4 + OTIO + Assets)
```

### 9-Agent Production Pipeline

| # | Agent | Role | Free AI Model | Output |
|---|-------|------|---------------|--------|
| 1 | **Director** | Orchestrator + Genre Team Selector | Gemini 2.5 Pro | Production strategy, genre team config |
| 2 | **Story Architect** | Screenplay writer | Gemini 2.5 Pro | Full screenplay, 3-act, character bible |
| 3 | **Scene Breakdown** | Scene splitter | Gemini 2.5 Pro | Scene cards with emotion, style, duration |
| 4 | **Production Generation** | Asset prompt engineer | Gemini 2.5 Pro | Image/video/audio/music prompts per scene |
| 5 | **Model Orchestrator** | AI model router | Custom logic | FLUX/WAN/Kokoro/ACE-Step assignment |
| 6 | **GPU Render Workers** | Asset generators | FLUX/WAN/Kokoro/ACE-Step | Real images, videos, audio, music files |
| 7 | **Critic Agent** | Quality gatekeeper | Gemini 2.5 Pro | Score 0-100, accept/regenerate decision |
| 8 | **Timeline Assembly** | Film editor | OpenTimelineIO + FFmpeg | Multi-track timeline, frame-accurate |
| 9 | **Post Production** | Color/sound/mix master | FFmpeg + custom | Graded film, mixed audio, mastered music |
| 10 | **Interactive Experience** | Dashboard builder | Gemini 2.5 Pro | Control Room HTML + real-time monitoring |

### Free-First AI Model Stack

| Asset Type | Primary | Fallback 1 | Fallback 2 |
|------------|---------|------------|------------|
| **Images** | FLUX.1 [pro/dev] | Juggernaut XL v9 | SDXL + LoRAs |
| **Video** | WAN Video I2V | Hunyuan Video | LTX Video / CogVideoX |
| **Voice/Dialogue** | Kokoro TTS | XTTS v2 | Gemini TTS |
| **Music** | ACE-Step | MusicGen | Stable Audio Open |
| **SFX** | Stable Audio Open | AudioCraft | — |

### Self-Evaluation Loop (CRITICAL)

Every asset passes through the **Critic Agent**:

```
GENERATE → CRITIC SCORE → DECISION
```

- **≥ 85** → ACCEPT → Inject into timeline
- **< 85** → REGENERATE → Improved prompt → Retry (max 3x)

The Critic evaluates:
- Image: composition, lighting, character consistency, cinematic quality
- Video: temporal coherence, motion quality, subject consistency, visual quality
- Audio: clarity, emotional delivery, Arabic quality, sync
- Music: emotional match, instrumentation, structure, quality
- SFX: realism, mix balance, spatial quality, clarity

---

## System State (LangGraph FilmState)

```python
class FilmState:
    idea: str                    # User's original idea
    story: dict                  # Full screenplay + characters
    scenes: list                 # Scene breakdown cards
    shots: list                  # Shot-level details
    assets: dict                 # images, videos, audio, music
    timeline: dict               # OTIO multi-track timeline
    model_plan: dict             # Which model for each asset
    quality_scores: dict         # Critic scores per asset
    final_render: str            # Path to final MP4
```

---

## Full System Pipeline

```
User Story Idea (1 sentence)
           │
           ▼
    ┌─────────────────────────┐
    │  DIRECTOR AGENT          │  Classify genre → Select team → Set strategy
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  STORY ARCHITECT         │  Write screenplay (Gemini 2.5 Pro)
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  SCENE BREAKDOWN         │  Split into autonomous production units
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  PRODUCTION GENERATION   │  Generate prompts for all asset types
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  MODEL ORCHESTRATOR      │  Route to FLUX/WAN/Kokoro/ACE-Step
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  GPU RENDER WORKERS      │  Async generation via Redis queue
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  CRITIC AGENT            │  Score ≥85? Accept : Regenerate
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  TIMELINE ASSEMBLY       │  Build multi-track OTIO timeline
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  POST PRODUCTION         │  Color grade, mix, master, transitions
    └─────────────────────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  🎬 FINAL FILM           │  MP4 + OTIO + Asset Library + Report
    └─────────────────────────┘
```

---

## Technology Stack (Free-First)

### AI Model Stack
| Asset Type | Primary | Fallback 1 | Fallback 2 | Fallback 3 |
|------------|---------|------------|------------|------------|
| **Images** | FLUX.1 [pro/dev] | Juggernaut XL v9 | RealVis XL | SDXL + LoRAs |
| **Video** | WAN Video I2V | Hunyuan Video | LTX Video | CogVideoX |
| **Voice/Dialogue** | Kokoro TTS | XTTS v2 | MeloTTS | Gemini TTS |
| **Music** | ACE-Step | MusicGen | Stable Audio Open | — |
| **SFX** | Stable Audio Open | AudioCraft | — | — |
| **Narrative/Reasoning** | Gemini 2.5 Pro | Claude 3.5 Sonnet | GPT-4o | — |

### Frontend
- **Next.js 15** — App Router, React Server Components
- **React 19**, TailwindCSS 4, Framer Motion, GSAP, Three.js, WebGPU
- **Shadcn UI**, Lucide React
- **Control Room Layout** (5 zones: Header, Scenes Panel, Live Preview, Timeline Engine, AI Logs + Export)
- **Real-time WebSocket** streaming for live generation status

### Backend
- **FastAPI** — API gateway with WebSocket endpoints
- **LangGraph** — Graph-based agent orchestration (FilmState)
- **Celery + Redis** — Async job queue for GPU workers
- **PostgreSQL** — Production data, model registry, quality scores
- **MinIO / S3** — Asset storage (`/films/{film_id}/scenes/images/videos/audio/music/`)
- **HashiCorp Vault** — Secrets management (API keys, model credentials)

### Rendering & Media
- **FFmpeg** — Video encoding, color grading, audio mixing
- **OpenTimelineIO** — Multi-track timeline assembly
- **Remotion / MoviePy** — Programmatic video composition
- **Whisper** — Audio alignment + subtitle generation

### Infrastructure
- **Docker** — All services containerized
- **Kubernetes** — GPU worker orchestration (A100/L4)
- **GPU Scheduler** — Smart allocation per scene complexity
- **Auto-scaling** — Scale workers up/down based on queue size
- **Prometheus + Grafana** — Monitoring & observability

### Deployment Options
- **Local Dev**: Docker Compose (backend + frontend + Redis + Postgres)
- **Production**: Kubernetes cluster with GPU nodes
- **Hybrid Free Mode**: Replicate API + HuggingFace endpoints + local CPU fallback

### Backend
- **FastAPI / Node.js** API Gateway
- **PostgreSQL** (production data, model registry, cost tracking)
- **Redis** (session cache, job queues, streaming buffers)
- **Qdrant** (vector DB for semantic memory)
- **HashiCorp Vault** (secrets management, key rotation)

### Infrastructure
- **Docker**, Kubernetes, Helm
- **GPU node pools** (NVIDIA A100) for Alibaba generation workers
- **WebSocket streaming** for live generation console
- **Prometheus + Grafana** monitoring
- **Distributed tracing** per generation task
- **Local LLMs** — Self-hosted options

### Deployment
- **Docker** — Containerization
- **Kubernetes** — Production orchestration
- **AWS / GCP / Azure** — Cloud infrastructure
- **CloudFront / CDN** — Static asset delivery
- **Prometheus + Grafana** — Monitoring & observability

---

## Project Structure (ACIS v3.0)

```
acis-studio/
├── agents/                          # Fleet LangGraph agent definitions
│   ├── director-agent/AGENTS.md     # Director Agent — Orchestrator + Genre Team Selector
│   ├── story-architect/AGENTS.md    # Story Architect — Screenplay (Gemini 2.5 Pro)
│   ├── scene-breakdown/AGENTS.md  # Scene Breakdown — Autonomous Production Units
│   ├── production-generation/       # Production Generation — Asset Prompts
│   ├── model-orchestrator/          # Model Orchestrator — FLUX/WAN/Kokoro/ACE-Step routing
│   ├── gpu-render-workers/          # GPU Workers — Async asset generation
│   ├── critic-agent/                # Critic Agent — Quality gatekeeper (score ≥85)
│   ├── timeline-assembly/           # Timeline Assembly — OTIO multi-track builder
│   ├── post-production/             # Post Production — Color/mix/master/transitions
│   └── interactive-experience/      # Interactive Experience — Control Room UI
│
├── backend/                         # FastAPI Core System
│   ├── main.py                      # Entry point
│   ├── api/
│   │   ├── routes_film.py          # /film/start, /film/{id}/status
│   │   ├── routes_assets.py        # /assets/{id}/download
│   │   └── routes_render.py        # /render/start, /render/{id}/progress
│   ├── core/
│   │   ├── orchestrator.py         # LangGraph runtime — FilmState
│   │   ├── state.py                # FilmState: idea, story, scenes, assets, timeline
│   │   ├── config.py               # Model registry, thresholds, secrets
│   │   └── vault.py                # HashiCorp Vault integration
│   ├── services/
│   │   ├── queue_service.py        # Redis job queue (Celery)
│   │   ├── model_router.py         # select_model(task, style) → free-first routing
│   │   ├── asset_service.py        # S3/MinIO upload/download
│   │   ├── critic_service.py        # evaluate_asset() → score 0-100
│   │   ├── flux_service.py         # FLUX.1 image generation
│   │   ├── wan_video_service.py    # WAN Video I2V generation
│   │   ├── kokoro_service.py       # Kokoro TTS Arabic voice
│   │   ├── ace_step_service.py     # ACE-Step music composition
│   │   ├── stable_audio_service.py # Stable Audio Open SFX
│   │   ├── otio_service.py         # OpenTimelineIO assembly
│   │   └── ffmpeg_service.py       # FFmpeg encode/mix/master
│   ├── workers/
│   │   ├── image_worker.py         # FLUX → Juggernaut → RealVis → SDXL
│   │   ├── video_worker.py         # WAN → Hunyuan → LTX → CogVideoX
│   │   ├── voice_worker.py         # Kokoro → XTTS → MeloTTS → Gemini
│   │   ├── music_worker.py         # ACE-Step → MusicGen → Stable Audio
│   │   ├── sfx_worker.py           # Stable Audio Open → AudioCraft
│   │   └── assembly_worker.py      # OTIO build + FFmpeg render
│   ├── db/                          # PostgreSQL schemas
│   └── Dockerfile
│
├── frontend/                        # Next.js 15 Control Room
│   ├── app/
│   │   ├── page.tsx                 # Control Room Layout (5 zones)
│   │   ├── components/
│   │   │   ├── FilmHeader.tsx       # Film name, progress, render status, GPU, cost
│   │   │   ├── ScenePanel.tsx       # Scene cards = Production Units (Produce/Preview/Logs)
│   │   │   ├── LivePreview.tsx      # Real-time video/image preview
│   │   │   ├── AssetLibrary.tsx     # Images grid + Video clips + Audio tracks
│   │   │   ├── TimelineEngine.tsx   # Multi-track: V1/V2/A1/A2/A3/A4/A5 + SMPTE ruler
│   │   │   ├── AIConsole.tsx        # Live prompts, model decisions, critic scores
│   │   │   ├── ModelRouterViewer.tsx # Model choices, fallback chain, cost vs quality
│   │   │   └── ExportPanel.tsx      # Export Final Film button + render queue
│   │   ├── hooks/
│   │   │   ├── useWebSocket.ts      # Real-time backend stream
│   │   │   └── useFilmState.ts      # Zustand film state management
│   │   └── types/
│   └── Dockerfile
│
├── workers/                         # GPU Worker Dockerfiles
│   ├── image_worker/
│   │   ├── Dockerfile               # FLUX + ComfyUI + Juggernaut
│   │   └── entrypoint.sh
│   ├── video_worker/
│   │   ├── Dockerfile               # WAN Video + Hunyuan + diffusers
│   │   └── entrypoint.sh
│   ├── voice_worker/
│   │   ├── Dockerfile               # Kokoro TTS + XTTS + MeloTTS
│   │   └── entrypoint.sh
│   ├── music_worker/
│   │   ├── Dockerfile               # ACE-Step + MusicGen
│   │   └── entrypoint.sh
│   └── sfx_worker/
│       ├── Dockerfile               # Stable Audio Open + AudioCraft
│       └── entrypoint.sh
│
├── docs/
│   ├── ACIS-MASTER-ARCHITECTURE.md  # Complete system v3.0 architecture
│   ├── ACIS-BACKEND-IMPLEMENTATION.md  # FastAPI + LangGraph + Workers
│   ├── ACIS-FRONTEND-IMPLEMENTATION.md   # Next.js 15 Control Room
│   ├── MODEL_ROUTING.md             # Model capability registry + routing algorithm
│   ├── PRODUCTION_GENERATION.md   # Asset pipelines (image/video/audio/music/sfx)
│   ├── TIMELINE_ENGINE.md           # OTIO + FFmpeg assembly specification
│   └── DEPLOYMENT.md                # Docker, K8s, GPU scaling, CI/CD
│
├── output/                          # Generated HTML dashboards
│   ├── acis-control-room.html       # ACIS v3.0 — 5-zone Control Room
│   ├── production-engine-dashboard.html  # v2.5 — Asset generation monitoring
│   ├── timeline-editor-dashboard.html    # v2.5 — Multi-track timeline
│   ├── ai-film-studio-dashboard.html     # v2.0 — Provider monitor
│   └── cinematic-production-dashboard.html # v1.0 — Storyboard + planning
│
├── docker-compose.yml               # Dev stack: backend + frontend + Redis + Postgres + MinIO
├── docker-compose.gpu.yml           # GPU workers overlay
├── k8s/                             # Kubernetes manifests
│   ├── backend-deployment.yaml
│   ├── frontend-deployment.yaml
│   ├── gpu-workers/                 # GPU node pool configs
│   └── redis-postgres/              # Stateful services
├── scripts/
│   ├── deploy.sh                    # Full deployment script
│   ├── start_workers.sh             # GPU worker launcher
│   └── setup_vault.sh               # Vault initialization
└── README.md                        # This file
```

---

## Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 20+, Python 3.11+
- NVIDIA GPU with CUDA 12+ (for local generation) OR cloud GPU account

### 1. Clone & Setup

```bash
git clone https://github.com/your-org/acis-studio.git
cd acis-studio

# Development — env file (NEVER commit to production)
cp .env.example .env
# Edit with your API keys and GPU settings
```

### 2. Start Full Stack (Development)

```bash
# Start all services: backend + frontend + Redis + Postgres + MinIO
docker-compose up -d

# In separate terminal, start GPU workers (if local GPU available)
docker-compose -f docker-compose.gpu.yml up -d
```

### 3. Access the Control Room

Navigate to [http://localhost:3000](http://localhost:3000)

---

## Usage — Creating a Film

### 1. Enter Your Idea

Type any idea in the input field:
> "A lonely lighthouse keeper discovers a message in a bottle that changes his understanding of time."

### 2. ACIS Takes Over — Full Autonomous Pipeline

| Step | What Happens | You See |
|------|-------------|---------|
| **Director Agent** | Classifies genre, selects team | Genre badge appears, team assigned |
| **Story Architect** | Writes full screenplay | Story tab populates with acts, characters |
| **Scene Breakdown** | Splits into production units | Scene cards appear (each = Autonomous Production Unit) |
| **Production Generation** | Creates prompts for all assets | Prompts tab fills with image/video/audio prompts |
| **Model Orchestrator** | Routes to best free model | Model routing bar shows FLUX/WAN/Kokoro assignments |
| **GPU Workers** | Generate real assets | Asset gallery populates with images, videos, audio |
| **Critic Agent** | Scores every asset (≥85=accept) | Quality scores appear, regeneration if needed |
| **Timeline Assembly** | Builds multi-track timeline | Timeline editor shows V1/A1/A2/A3/A4/A5 tracks |
| **Post Production** | Color grade, mix, master | Final film preview renders |

### 3. Interactive Control

- **🎬 Produce Scene** — Click any scene card to trigger full asset generation
- **🔁 Re-render** — Regenerate any asset with improved prompt
- **👁 Preview** — View generated assets before timeline injection
- **🧠 View AI Reasoning** — See why each model was chosen, quality scores
- **📊 Timeline Editor** — Drag/drop scenes, adjust timing, add transitions
- **🎬 Export Final Film** — One button renders complete MP4 + OTIO project

### 4. Every Scene = Autonomous Production Unit

Each scene contains:
- **Visual Layer**: Keyframes (FLUX), Motion shots (WAN), Camera logic, Lighting
- **Audio Layer**: Dialogue (Kokoro Arabic), Ambient, Foley
- **Music Layer**: Emotion-based scoring (ACE-Step), Scene themes
- **Editing Layer**: Shot timing, Transitions, Pacing curve

### 5. Export

Click **🎬 EXPORT FINAL FILM**:
- MP4 film (auto-assembled, color-graded, mixed)
- Full OTIO timeline project (editable in DaVinci Resolve / Premiere)
- Asset library (all images, videos, audio, music files)
- Scene breakdown report (JSON)
- AI reasoning log (model decisions, quality scores, costs)

---

## Model Orchestrator: Free-First Routing

### How It Works

```python
# Example: Scene 3 — "The Storm" (dark, high motion)
task = {
    media_type: "video",
    scene_emotion: "fear",
    motion_type: "high_motion",
    complexity: 8,
    style: "cinematic_dark"
}

# Model Orchestrator evaluates:
# ├─ WAN Video I2V: quality=0.92×40% + speed=0.85×20% + cost=1.0×15% + cinematic=0.94×15% = 0.906 ✓ PRIMARY
# ├─ Hunyuan Video: quality=0.88×40% + speed=0.80×20% + cost=0.95×15% + cinematic=0.90×15% = 0.857 ← FALLBACK 1
# ├─ LTX Video:     quality=0.85×40% + speed=0.95×20% + cost=1.0×15% + cinematic=0.87×15% = 0.847 ← FALLBACK 2
# └─ CogVideoX:     quality=0.82×40% + speed=0.90×20% + cost=1.0×15% + cinematic=0.84×15% = 0.822 ← FALLBACK 3

# Decision: WAN Video I2V (confidence: 0.906)
# Reason: Highest cinematic score for dark + high-motion scenes. FREE via HuggingFace/Replicate.
```

### Self-Evaluation Loop (≥85 Rule)

Every asset passes through **Critic Agent**:

```
GENERATE → CRITIC SCORE → DECISION
  Image: composition + lighting + consistency + cinematic = 0-100
  Video: temporal + motion + subject + quality = 0-100
  Audio: clarity + emotion + Arabic + sync = 0-100
  Music: emotional match + instrumentation + structure + quality = 0-100
  SFX: realism + mix balance + spatial + clarity = 0-100

  ≥ 85 → ACCEPT → Inject into timeline
  70-84 → CONDITIONAL ACCEPT → Flag, use if no time
  < 70 → REJECT → Regenerate with improved prompt (max 3 retries)
```

---

## Quality Standards (ACIS Certified)

Every film meets these autonomous quality gates:

| Layer | Standard | Model | Score Threshold |
|-------|----------|-------|-----------------|
| **Screenplay** | Three-act, character arcs, subtext | Gemini 2.5 Pro | ≥ 90 |
| **Images** | Composition, lighting, consistency | FLUX.1 | ≥ 85 |
| **Video** | Temporal coherence, cinematic motion | WAN Video I2V | ≥ 85 |
| **Voice** | Arabic clarity, emotional delivery | Kokoro TTS | ≥ 85 |
| **Music** | Emotional match, scene themes | ACE-Step | ≥ 85 |
| **SFX** | Realism, spatial quality | Stable Audio Open | ≥ 80 |
| **Timeline** | Frame-accurate, sync, transitions | OpenTimelineIO | ≥ 90 |
| **Post** | Color grade, audio mix, mastering | FFmpeg | ≥ 90 |

---

## Documentation

| Document | Content |
|----------|---------|
| [ACIS-MASTER-ARCHITECTURE.md](docs/ACIS-MASTER-ARCHITECTURE.md) | Complete v3.0 system architecture — all 5 steps |
| [ACIS-BACKEND-IMPLEMENTATION.md](docs/ACIS-BACKEND-IMPLEMENTATION.md) | FastAPI + LangGraph + Redis + GPU workers |
| [ACIS-FRONTEND-IMPLEMENTATION.md](docs/ACIS-FRONTEND-IMPLEMENTATION.md) | Next.js 15 Control Room + 5-zone layout |
| [MODEL_ROUTING.md](docs/MODEL_ROUTING.md) | Free-first model registry + routing algorithm |
| [PRODUCTION_GENERATION.md](docs/PRODUCTION_GENERATION.md) | Image/video/audio/music/SFX pipelines |
| [TIMELINE_ENGINE.md](docs/TIMELINE_ENGINE.md) | OTIO + FFmpeg assembly specification |
| [DEPLOYMENT.md](docs/DEPLOYMENT.md) | Docker, K8s GPU pools, Terraform, CI/CD |

---

## Roadmap

### Phase 1 — Core Engine ✅ (Current)
- [x] 9-agent LangGraph orchestration
- [x] Free-first model routing (FLUX, WAN, Kokoro, ACE-Step)
- [x] Critic Agent quality gate (≥85 rule)
- [x] Scene = Autonomous Production Unit
- [x] Self-improving loop (scene-to-scene learning)
- [x] Control Room dashboard (5-zone UI)
- [x] Timeline editor (multi-track, SMPTE ruler)
- [x] Export Final Film pipeline

### Phase 2 — Real Asset Generation (In Progress)
- [ ] FLUX.1 ComfyUI GPU worker integration
- [ ] WAN Video I2V GPU worker integration
- [ ] Kokoro TTS Arabic voice worker
- [ ] ACE-Step music composition worker
- [ ] OpenTimelineIO + FFmpeg render pipeline
- [ ] WebSocket real-time progress streaming

### Phase 3 — Production Polish
- [ ] LoRA character consistency training
- [ ] IP-Adapter face locking across scenes
- [ ] Automatic color grading (per genre team)
- [ ] Multi-language dialogue (Arabic, English, Spanish)
- [ ] Whisper subtitle auto-generation + sync
- [ ] Genre-specific agent fine-tuning

### Phase 3 — Studio Features
- [ ] Collaborative editing (multiple users)
- [ ] Version control for productions
- [ ] Asset library (characters, locations, props)
- [ ] Integration with real production tools (Celtx, Final Draft)
- [ ] Budget estimation module
- [ ] Casting character visualizations

### Phase 4 — Enterprise
- [ ] Custom AI model training per studio
- [ ] On-premise deployment option
- [ ] Advanced analytics and reporting
- [ ] Team management and permissions
- [ ] White-label option

---

## Contributing

We welcome contributions from filmmakers, cinematographers, storyboard artists, sound designers, and AI engineers.

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

### Contribution Areas
- **Screenwriting**: Improve story structure templates and beat sheets
- **Cinematography**: Add shot type libraries and director style references
- **Sound Design**: Expand audio cue templates and composer references
- **AI Prompts**: Optimize platform-specific prompt patterns
- **Frontend**: Build components, animations, interactions
- **Backend**: API endpoints, database optimizations, caching
- **DevOps**: Deployment automation, monitoring, security

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

## Acknowledgments

- Inspired by the storytelling mastery of Pixar, Studio Ghibli, and A24
- Cinematic techniques drawn from the work of Roger Deakins, Emmanuel Lubezki, and countless cinematographers
- AI research from OpenAI, Anthropic, Google DeepMind
- Open-source communities: LangChain, Next.js, TailwindCSS, Framer Motion

---

## Contact

**Project**: ACIS — Autonomous Cinematic Intelligence System  
**Creator**: Kills Online (kills.online@gmail.com)  
**Repository**: [github.com/your-org/acis-studio](https://github.com/your-org/acis-studio)

---

> " cinema is a matter of what's in the frame and what's out. "  
> — Martin Scorsese

> " Every story has a beginning, a middle, and an end. Not necessarily in that order. "  
> — Jean-Luc Godard

> " The idea is to write it so that people hear it and it slides through the brain and goes straight to the heart. "  
> — Maya Angelou

---

**🎬 ACIS — Where Ideas Become Films.**  
*Autonomous Cinematic Intelligence. Zero Manual Intervention. Full Production Power.*
