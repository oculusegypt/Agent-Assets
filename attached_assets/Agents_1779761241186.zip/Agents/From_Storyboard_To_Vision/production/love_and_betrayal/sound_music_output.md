# حب وخيانة (Love and Betrayal)
## Sound & Music Design Document
### Pipeline Stage: "From Storyboard To Vision" — Sound & Music Layer
**Date:** 2026-05-25
**Sound & Music Designer:** Sound & Music Agent
**Project:** The Garden of Broken Mirrors

---

## TABLE OF CONTENTS

1. [Musical Score Architecture](#1-musical-score-architecture)
2. [Sound Design Philosophy & Rules](#2-sound-design-philosophy--rules)
3. [Scene-by-Scene Audio Breakdown — 8 Key Scenes](#3-scene-by-scene-audio-breakdown--8-key-scenes)
4. [Diegetic vs. Non-Diegetic Music Map](#4-diegetic-vs-non-diegetic-music-map)
5. [Silence Design — The Emotional Weapon](#5-silence-design--the-emotional-weapon)
6. [Foley & Ambient Sound Design Per Act](#6-foley--ambient-sound-design-per-act)
7. [Music Licensing & Original Composition Notes](#7-music-licensing--original-composition-notes)
8. [Final Mix Philosophy](#8-final-mix-philosophy)
9. [Complete Audio Cue Sheet](#9-complete-audio-cue-sheet)
10. [Reference Scores & Composers](#10-reference-scores--composers)

---

# 1. MUSICAL SCORE ARCHITECTURE

## 1.1 The Maqam System — The Film's Emotional Spine

The film employs the Arabic **maqam** (modal) system as its fundamental musical architecture. Each act is anchored in a specific maqam that governs both diegetic and non-diegetic music, creating an emotional modal journey that parallels the narrative arc.

| Act | Title | Maqam | Emotional Character | Key / Tonic | Western Analog |
|-----|-------|-------|---------------------|-------------|----------------|
| Act I | The Surface | **Bayati** (بياتي) | Stable, warm, grounded, but without improvisational life (taqsim) | D (with neutral 3rd) | D minor with raised 4th — melancholic but stable |
| Act II-A | The Crack | **Hijaz** (حجاز) | Longing, beauty mixed with melancholy, the mode of yearning | E (with augmented 2nd) | Phrygian dominant — exotic, tense, passionate |
| Act II-B | The Abyss | **Rast** (راست) | Joy with underlying tension, the "master maqam" — authoritative but ambiguous | C (with neutral 3rd) | Major with microtonal tension — bright but unstable |
| Act III | The Reckoning | **Saba** (صبا) | Deep sorrow, rarely used in performance because "too painful" — used sparingly | D (descending, flat 2nd, flat 6th) | Descending chromatic sorrow — devastating |
| Act IV | The Collapse | **Saba** extended + silence | Devastation beyond music — music fails | — | — |
| Act V | The Ruins | **Nahawand** (نهوند) | Farewell, acceptance, gentle sadness, the mode of parting | C minor | Natural minor — dignified grief, moving toward peace |

### Maqam Implementation Rules
- **Bayati (Act I):** All non-diegetic score in Bayati uses authentic quarter-tone intonation (neutral 3rd between minor and major). Western instruments (strings, piano) must be performed with subtle pitch inflections. Oud and qanun provide authentic quarter-tone reference.
- **Hijaz (Act II-A):** The augmented 2nd (approximately 1.5 whole tones) creates the "longing interval." Violin and clarinet excel here. The interval should feel like a reach — something desired but not grasped.
- **Rast (Act II-B):** Rast is the maqam of beginnings and authority. Its neutral 3rd creates unresolved brightness — joy that knows it will end. Used ironically during the Raindrop Prelude scene: the piano plays Chopin in Db major while the non-diegetic score whispers Rast on oud and ney, suggesting the "joy" of Yasmin's performance is actually a prison.
- **Saba (Act III-IV):** Used only three times in the entire film. Saba is the "prohibited" maqam — its microtonal flat 2nd and flat 6th create a sound of irreparable loss. The first Saba cue enters when Yasmin destroys the piano. The second when she reads the file. The third in the final scene, beneath the unresolved note.
- **Nahawand (Act V):** Natural minor, but with Arabic phrasing — long ornamental lines, gradual resolution. The final unresolved note is a Nahawand tonic with a suspended 4th that never resolves. The audience hears "almost peace."

## 1.2 Character Leitmotifs

### YASMIN — "The Architect of Sound"
- **Primary instrument:** Solo piano (Steinway D concert grand for diegetic; felt-muted upright for non-diegetic)
- **Melodic signature:** A five-note descending figure: E — D — C — B — A (in whatever key the scene requires). This is the "Yasmin cell." It appears in every scene she occupies, transformed by context.
  - Act I: Played cleanly, evenly, in Bayati — the pianist who controls emotion through technique
  - Act II: Same cell, but with rubato (tempo fluctuation), hesitation on the third note — the control cracking
  - Act III: Cell fragmented, only first three notes, then silence — the identity shattering
  - Act IV: Cell played on detuned piano strings (prepared piano) — broken beauty
  - Act V: Cell transformed into ascending figure A — B — C — D — E — the inversion of self

- **Non-diegetic instrumentation:** Solo piano + chamber strings (8 players) + subtle oud. The piano always leads; strings enter only when Yasmin is observed by others.

### OMAR — "The Silence Between Notes"
- **Primary instrument:** Solo cello (dry recording, close-miked, no reverb)
- **Melodic signature:** A single sustained note (pedal tone) that shifts by microtones — the listener cannot identify when it changed, only that it is different. Represents Omar's undetectable transformation between selves.
  - When Omar is "husband": Pedal tone in the register of human speech (roughly 80–250 Hz), warm, comforting
  - When Omar is "operative": Same pitch, but timbre shifts — more bow pressure, more granular texture, less pitch stability
  - The transition between the two states happens over 4–6 seconds, undetectable unless the listener is actively monitoring

- **Non-diegetic rule:** Omar's cello is NEVER accompanied. When he is on screen with Yasmin, her piano motif and his cello pedal create a duet — but they are often in different keys, different tempos, different emotional registers. They play "together" but not "with each other." This is the sonic metaphor for their marriage.

### LAYLA (The Sister) — "The Dissonant Consonance"
- **Primary instrument:** Prepared piano (paperclips on strings, e-bow on bass strings) + field recordings
- **Melodic signature:** Two notes a half-step apart played simultaneously — a cluster that shouldn't exist in tonal music but does. Represents her journalistic instinct: seeing two truths at once.
- **Non-diegetic rule:** Layla's music is diegetic-first — she turns on music in her apartment, plays the radio, hums. Her non-diegetic presence is minimal. She is the "real world" character — her sound is always grounded, never scored.

### NOUR — "The Operational Mind"
- **Primary instrument:** Solo clarinet (bass clarinet in low register), processed through granular delay
- **Melodic signature:** A perfect fourth interval (C–F, or transposed) — the interval of stability, but played with "wrong" articulation: staccato in legato contexts, legato in staccato contexts. Nour's music obeys rules but subverts expectations.
- **Non-diegetic rule:** Nour's clarinet is always accompanied by a rhythmic pattern that sounds like Morse code, or heartbeats, or data transmission — never organic, always systematic.

### KHALID — "The Garden of Questions"
- **Primary instrument:** Solo ney (Arabic end-blown flute) + natural ambience (birds, wind in roses)
- **Melodic signature:** Free improvisation (taqsim) in the maqam of the scene, but played with "old man's breath" — audible air noise, slight pitch instability, notes that bend downward as if exhausted.
- **Non-diegetic rule:** Khalid is never scored with non-diegetic music. His garden IS the music. The sound design team must capture and shape the natural sounds of his space as his emotional voice.

## 1.3 The Chopin Architecture — Diegetic Spine

Chopin's music serves as the diegetic skeleton of the film. Three pieces anchor the narrative:

### Piece 1: Nocturne in C-sharp minor, Op. Posth. (0:00–3:00, 85:00–95:00)
- **Structural function:** Bookend. First performance = controlled perfection. Final duet = fragile, broken, possibly false.
- **Performance instruction:** The opening performance must be technically flawless but emotionally distant — a "beautiful recording" rather than a living interpretation. The final duet should have wrong notes, hesitations, tempo collapses. It is more honest because it is imperfect.
- **Non-diegetic integration:** During the opening, non-diegetic Bayati score enters between phrases — the Arabic maqam "commenting" on the Western classical piece. By the final duet, the non-diegetic score has consumed the Chopin; only fragments of the Nocturne remain, surrounded by Saba and Nahawand.

### Piece 2: Prelude in Db Major, Op. 28 No. 15 — "Raindrop Prelude" (60:00–68:00)
- **Structural function:** The invasion of the operational into the domestic. The persistent A-flat (repeated 61 times) = the inescapable doom / the surveillance that cannot be escaped.
- **Diegetic performance:** Yasmin plays this during the diplomatic meeting. The A-flat represents the "raindrop" of doom. As she hears her father's name, she misses a note — the Raindrop stutters.
- **Non-diegetic integration:** The non-diegetic score takes the A-flat and transforms it into an operational sound — a rhythmic pulse that becomes indistinguishable from a surveillance heartbeat, a coded transmission, a ticking clock. The audience should not know where the piano ends and the score begins.

### Piece 3: Unresolved Single Note (100:00–105:00)
- **Structural function:** The film's final sound. One note, held, unresolved.
- **Specification:** The note is a D in the 4th octave (D4 = 293.66 Hz). It is played on a Yamaha U1 upright piano (NOT the concert Steinway — this is a new, simpler instrument). The note is held with the sustain pedal, and the natural decay of the piano string is recorded for 30+ seconds.
- **The harmonic trick:** The note is the tonic of Bayati (Act I's maqam) and the final note of Nahawand (Act V's maqam). It is the same pitch that opened the film, but the context has transformed its meaning. The audience hears closure and opening simultaneously.
- **Final second:** In the last second of the film, as the note has decayed to near-inaudibility, a barely perceptible cello microtone (Omar's pedal) enters beneath it — suggesting he is still present, still unresolved, still part of her sonic world.

## 1.4 Instrumentation Palette

### Primary Ensemble (Non-Diegetic Score)
| Section | Instruments | Emotional Role |
|---------|-------------|----------------|
| **Strings** | 4 violins, 2 violas, 2 celli, 1 double bass | Yasmin's emotional world — warm but capable of shrill dissonance |
| **Piano** | Steinway D (close-miked) for diegetic; felt-muted upright for non-diegetic | The protagonist's voice — two instruments represent her two selves |
| **Arabic Core** | Oud, ney, qanun, riqq (tambourine) | Cultural grounding; maqam authenticity; the "truth beneath" |
| **Woodwinds** | Solo clarinet, solo bassoon | Nour and the operational world — systematic, cold, intellectual |
| **Electronic** | Subtle granular synthesis, spectral processing | The surveillance layer — sounds that might be music or might be technology |
| **Percussion** | Frame drum (daff), minimal orchestral percussion | Heartbeat, tension, the pulse of Cairo |

### Recording Philosophy
- **Non-diegetic score:** Recorded in a medium-sized concert hall (reverb time 1.8–2.2 seconds) with close-miking for intimacy, room mics for air.
- **Omar's cello:** Recorded in an anechoic chamber, then artificially placed in spaces. His sound has NO natural room — he has no "home."
- **Yasmin's piano:** Two recording approaches — (a) concert hall performance with audience presence (subtle breathing, chair creaks) for diegetic; (b) isolated studio, close-miked, mechanical noises (pedal, key strike) audible for non-diegetic.

---

# 2. SOUND DESIGN PHILOSOPHY & RULES

## 2.1 Core Philosophy: "The Architecture of Listening"

The sound design of "حب وخيانة" is built on a single principle:

> **Every sound is either a truth or a lie. The audience must not know which until the story reveals it.**

This means:
- Music that seems non-diegetic may be coming from a radio Yasmin hasn't noticed yet.
- Ambient sound that seems natural may be operational surveillance (a drone, a planted device).
- Silence that seems peaceful may be the absence of a sound that should be there (Omar's missing breathing, the stopped clock).
- A sound effect that seems exaggerated may be exactly what the character hears in a moment of emotional extremity (subjectively amplified).

## 2.2 The Five Sound Rules

### Rule 1: The Piano Is Always Present (Until It Isn't)
Until the destruction scene (68:00), some reference to piano — tuning, resonance, harmonic overtone, mechanical click — must be audible in every scene involving Yasmin. Even when she is not playing, the piano haunts her sonic world. After the destruction, the piano is replaced by: silence → prepared piano sounds → new piano (Act V).

### Rule 2: Omar Has Two Footsteps
Omar's Foley has two modes:
- **Husband mode:** Normal footsteps, leather shoes on tile/wood, confident but not hurried, weight distributed evenly.
- **Operative mode:** Softer footsteps, rubber-soled shoes, weight on the balls of the feet, shorter stride, occasional pauses (checking surroundings). The Foley team must record two complete footstep libraries for the actor.
The audience may not consciously notice the difference, but they will feel it. When Yasmin follows him to the café, his footsteps shift from husband to operative mid-scene.

### Rule 3: Cairo Is a Character
Cairo's ambient sound is not "background." It is an active force:
- **The Call to Prayer:** Occurs three times in the film — Act I (establishing, distant, beautiful), Act III (closer, more insistent, overlapping with operational tension), Act V (the final sound, close, enveloping, peaceful).
- **Traffic:** In Act I, traffic is distant, muffled, a lullaby. In Act II, traffic becomes foreground — honking, shouting, the chaos of the city reflecting internal chaos. In Act IV, traffic is absent — the city has abandoned them.
- **The Nile:** Water sounds appear in scenes of transition — when Yasmin crosses from one world to another, the river is audible, indifferent, eternal.

### Rule 4: Surveillance Has a Sound
Operational/surveillance moments have a subtle sonic signature:
- **The hum:** A barely perceptible 50Hz electrical hum (Egyptian power grid frequency) that enters in scenes where surveillance is present. The audience should not consciously hear it; it should register as "something is wrong here."
- **The click:** Occasional faint mechanical clicks (camera shutters, recording devices) that might be diegetic or might be the sound design suggesting surveillance. These are NEVER confirmed.
- **The compression:** When Yasmin discovers the safe house, the sound design should subtly compress dynamic range — louds become quieter, quiets become louder. The sonic world becomes "monitored," "recorded."

### Rule 5: Silence Is Never Empty
True silence in this film is rare and meaningful. When it occurs, it must be "active silence" — the sound of a room with no one speaking, where the audience can hear: breathing, fabric movement, the building settling, a distant dog, their own heartbeat.

## 2.3 Emotional Sound Design

### Sound Textures for Emotional States

| Emotional State | Sound Texture | Technical Implementation |
|-----------------|---------------|------------------------|
| **Controlled calm (Act I)** | Smooth, warm, minimal high frequencies | Low-pass filtering at 8kHz; gentle compression; reverb tails 2+ seconds |
| **Awakening suspicion (Act II-A)** | High-frequency detail emerges; subtle dissonance | High-shelf boost +3dB above 4kHz; introducing microtonal clashes |
| **Operational tension (Act II-B)** | Pulsing, rhythmic, constrained | Rhythmic pulses at 72–85 BPM (resting heart rate); sidechain compression creating "breathing" effect |
| **Rage (Act III)** | Overloaded, distorted, then sudden silence | Analog tape saturation on transients; sudden hard cut to silence |
| **Devastation (Act IV)** | Hollow, distant, underwater | Low-pass at 500Hz; exaggerated reverb (5+ seconds); reduced dynamic range |
| **Acceptance (Act V)** | Full frequency return, but softer, spacious | Natural room reverb; full frequency spectrum at lower overall volume |

---

# 3. SCENE-BY-SCENE AUDIO BREAKDOWN — 8 KEY SCENES

## SCENE 1: THE NOCTURNE (0:00–3:00)
### "Chopin Performance Duality"

**Diegetic Audio:**
- Chopin Nocturne in C-sharp minor, Op. Posth. — performed by Yasmin on Steinway D in concert hall
- Performance note: Technically flawless, emotionally restrained. The tempo is steady (quarter note = 60 BPM — one note per second, metronomic). No rubato. This is a "safe" performance — the performer hides behind the composer's notes.
- Audience presence: Subtle. Distant coughs, program rustling, a chair creak. These must be real recordings, not library effects.
- The wedding ring: When Yasmin's hand crosses the ring over the strings, there is a barely perceptible "tick" of metal on metal. This sound is isolated and will return as a motif throughout the film.

**Non-Diegetic Audio:**
- Bayati maqam score enters between phrases (2–3 seconds of musical "commentary" after each phrase ends). Instruments: solo oud + solo ney.
- The Bayati comments on the Chopin but does not compete. It is the "inner voice" — what Yasmin is not expressing in her performance.
- No other non-diegetic score in this scene.

**Sound Design:**
- Concert hall acoustics: Medium reverberation (RT60 = 2.0 seconds), warm, flattering.
- Transition to apartment: Hard cut from concert hall reverb to near-dry domestic space. The reverb tail of the final chord is abruptly truncated.
- Apartment ambience: Deep silence. Air conditioning hum. A clock ticking (the clock will stop in Act II — a sound design detail for attentive listeners).
- The refrigerator: When Yasmin opens it, the compressor hum changes pitch slightly. This is a "character" sound — the apartment is alive but indifferent.

**Audio Cue:**
| Cue # | Description | Type | In | Out | Notes |
|-------|-------------|------|-----|-----|-------|
| SM-001 | Chopin Nocturne — full performance | Diegetic | 0:00 | 2:45 | Flawless, controlled, emotionally distant |
| SM-002 | Bayati commentary between phrases | Non-diegetic | 0:12 | 2:45 | Solo oud + ney, entering in gaps |
| SM-003 | Concert hall audience ambience | Ambience | 0:00 | 2:45 | Subtle, real, non-intrusive |
| SM-004 | Apartment domestic ambience | Ambience | 2:46 | 3:00 | Refrigerator, silence, distant city |

**Emotional Purpose:** Establish the duality of Yasmin's life — public perfection, private emptiness. The Bayati maqam "knows" what the Chopin conceals.

---

## SCENE 2: THE DRAWER (8:00–12:00)
### "Second Phone Discovery — Silence, Then Ringing"

**Diegetic Audio:**
- Pre-scene: Yasmin reading. The sound of turning pages (Borges — "The Garden of Forking Paths").
- The drawer opening: The wooden slide sound must be specific — this drawer has been opened thousands of times. It should sound "lived-in."
- The phone vibration: This is the film's first sonic shock. The vibration is loud, unexpected, low-frequency (the phone is on wood, amplifying the buzz).
- The message notification sound: A generic "ding" — deliberately ordinary, which makes it more terrifying.
- Post-discovery: Yasmin plays the piano again. The Nocturne, but now it is different — wrong notes, accelerating tempo, frantic. The sound of her playing becomes the sound of her panic.
- The final dissonance: She slams both hands on the keyboard. The resulting cluster is NOT musical — it is noise, and the sound design should emphasize the mechanical violence (hammer strike, string collision, frame resonance).

**Non-Diegetic Audio:**
- None during the drawer sequence (8:00–8:45). The silence IS the score.
- After the phone discovery (8:45–9:30): A single sustained tone enters — the "Omar pedal" (cello, dry, close-miked). It is the note C, but it shifts microtonally, unstable. This is Omar's presence in the room even though he is not there.
- During the frantic piano playing (10:00–11:30): The Bayati score attempts to follow Yasmin's playing but cannot — she is too fast, too chaotic. The maqam breaks down. The oud player drops out. The ney plays a single piercing high note that sustains through the cacophony.
- The final slam (11:30): Everything cuts to silence. 5 seconds of absolute silence. Then: the sound of Yasmin's breathing, ragged, human.

**Sound Design:**
- The bedroom is sonically "close" — the microphones are near, the space is small. This is intimacy as claustrophobia.
- The phone vibration: Use a contact microphone recording of a phone on a wooden surface. The buzz should have both low-frequency rumble and high-frequency metallic rattle.
- The "ding": Recorded from an actual older Nokia/feature phone — the sound of a previous era, suggesting this phone has been used for a long time.

**Audio Cue:**
| Cue # | Description | Type | In | Out | Notes |
|-------|-------------|------|-----|-----|-------|
| SM-010 | Drawer opening, page turning | Foley | 8:00 | 8:30 | Domestic, lived-in sounds |
| SM-011 | Phone vibration on wood | SFX | 8:32 | 8:35 | Low-frequency shock — the first sonic terror |
| SM-012 | Message notification "ding" | SFX | 8:35 | 8:36 | Ordinary, which makes it horrifying |
| SM-013 | SILENCE — no music, no ambience | Design | 8:36 | 8:45 | Active silence — the room holds its breath |
| SM-014 | Omar cello pedal tone (microtonal C) | Non-diegetic | 8:45 | 9:30 | His presence in absence |
| SM-015 | Frantic Chopin Nocturne (diegetic) | Diegetic | 10:00 | 11:30 | Wrong notes, accelerating, breaking down |
| SM-016 | Bayati score breaking down | Non-diegetic | 10:00 | 11:30 | Attempts to follow, fails, collapses |
| SM-017 | Piano slam — full keyboard cluster | Diegetic/SFX | 11:30 | 11:32 | Mechanical violence, not music |
| SM-018 | Post-slam silence + breathing | Design | 11:32 | 12:00 | 5 sec absolute silence, then ragged breathing |

**Emotional Purpose:** The transition from domestic safety to operational threat happens in the sound before the image confirms it. The phone vibration is the film's first sonic betrayal.

---

## SCENE 3: THE FOLLOW (18:00–26:00)
### "Café Surveillance — Ambient Cairo, Tension Strings"

**Diegetic Audio:**
- The café in Zamalek: Real Cairo café ambience. Arabic conversation (background, indistinct), clinking glasses, espresso machine, traffic outside.
- Yasmin's footsteps: Following Omar. She is not trained — her footsteps are too loud, too regular. She does not know how to "ghost."
- Omar's footsteps: The transition from husband mode to operative mode. He walks differently in this scene. The Foley must reflect this.
- Nour's entrance: The café noise dips slightly (subjective perception — or is it the sound design?) when she enters. She brings a "field of quiet" with her.
- The envelope exchange: No sound. Their operation is silent. The sound design foregrounds the café ambience around them, making their silence more deafening.
- Yasmin's recording: The sound of her phone voice memo — lower fidelity, compressed, the microphone overloaded by café noise. When played back at home, the recording is grainy, hissy, terrifying in its banality.

**Non-Diegetic Audio:**
- Hijaz maqam score: Solo violin enters as Yasmin begins following Omar. The augmented 2nd interval creates immediate tension — this sound is "not from here."
- The score builds: As Yasmin gets closer to the café, strings add — first one, then two, then the full chamber group. But the dynamics are restrained — mezzo-forte at most. The tension is internal, not external.
- The "operational pulse": A subtle rhythmic element (frame drum, muffled) enters when Omar and Nour meet. It is 72 BPM — resting heart rate. The audience's heart may synchronize.
- When Yasmin plays the recording at home: The non-diegetic score drops out completely. Only the recording exists — grainy, hissy, real, devastating.

**Sound Design:**
- Cairo ambience must be authentic. Record on location in Zamalek cafés. The sounds must be specific: the particular espresso machine, the particular traffic pattern, the particular quality of Arabic conversation in that neighborhood.
- The "subjective dip": When Nour enters, the café ambience drops 3–4 dB for 2 seconds. This is NOT natural. It is the sound design reflecting Yasmin's perception — Nour's presence consumes sonic space.
- The apartment after the recording: The sound of the apartment changes. It is no longer safe. The same refrigerator hum now sounds threatening. The same traffic now sounds like surveillance. This is achieved through subtle EQ shifts (boosting 2–4kHz, the frequency range of human anxiety).

**Audio Cue:**
| Cue # | Description | Type | In | Out | Notes |
|-------|-------------|------|-----|-----|-------|
| SM-030 | Zamalek café ambience | Ambience | 18:00 | 22:00 | Authentic Cairo, specific location |
| SM-031 | Yasmin footsteps (untrained) | Foley | 18:30 | 19:15 | Too loud, too regular — following |
| SM-032 | Omar footsteps (operative mode) | Foley | 19:00 | 19:30 | Softer, shorter stride, checking |
| SM-033 | Hijaz violin entrance | Non-diegetic | 18:30 | 26:00 | Augmented 2nd — the sound of longing/suspicion |
| SM-034 | String ensemble build | Non-diegetic | 20:00 | 22:00 | Restrained, internal tension |
| SM-035 | Operational pulse (72 BPM) | Non-diegetic | 20:30 | 22:00 | Frame drum, heart-rate sync |
| SM-036 | Nour "subjective dip" ambience | Design | 20:45 | 20:47 | -3dB dip — her presence consumes space |
| SM-037 | Voice memo recording (low-fi) | Diegetic | 23:00 | 24:00 | Grainy, hissy, terrifyingly banal |
| SM-038 | Apartment "threatened" EQ shift | Design | 24:00 | 26:00 | Same room, now sonically hostile |

**Emotional Purpose:** The sound of following — the footsteps, the breathing, the café — creates tension without music. The music only enters when the emotional stakes are confirmed.

---

## SCENE 4: THE SAFE HOUSE (48:00–52:00)
### "Midpoint Twist — Diegetic Music Cuts Out"

**Diegetic Audio:**
- The safe house entrance: The sound of lock-picking (learned from Layla). Delicate, metallic, precise. This is the sound of Yasmin becoming operational.
- The apartment door opening: Hinge creak. The apartment is "dead" — no refrigerator hum, no traffic, no life. It is anechoic, artificial, terrifying.
- Yasmin's footsteps on the safe house floor: They echo more than they should. The space is sonically wrong.
- The photographs: The sound of Yasmin touching paper, shuffling photographs. This is intimate, private, violating.
- The discovery of the other woman: The sound of Yasmin's breathing changes. It becomes faster, shallower. This is subjective sound design — her physiology becomes the score.
- The escape: Footsteps accelerate. The window opens. Traffic from outside enters like a flood — the return of the world.

**Non-Diegetic Audio:**
- This is the MIDPOINT — the moment where the film's sonic architecture fundamentally shifts.
- **CRITICAL RULE:** From this point forward, diegetic music (Chopin, Yasmin's playing) becomes increasingly contaminated by non-diegetic score. The boundary between "what she plays" and "what she feels" dissolves.
- The safe house scene has NO non-diegetic score. Only sound design. The silence of the apartment IS the music.
- When Yasmin sees the photographs of the other woman: A single note from the Omar cello pedal enters. It is the lowest note on the instrument (C2, 65.41 Hz). It is felt more than heard. It is the sound of foundations shaking.

**Sound Design:**
- The safe house must be sonically "dead." Record in a space with minimal reverb, then further reduce ambience in post. The room should sound like no one has ever lived there — because no one has.
- The "footstep echo": Artificially extend the reverb of Yasmin's footsteps by 200%. The space should feel larger than it is, emptier than it is.
- The traffic "flood": When the window opens, the Cairo traffic enters as a full-frequency wall of sound. It is overwhelming, chaotic, and — after the dead apartment — deeply comforting. The city is indifferent, but it is ALIVE.

**Audio Cue:**
| Cue # | Description | Type | In | Out | Notes |
|-------|-------------|------|-----|-----|-------|
| SM-050 | Lock-picking sounds | Foley | 48:00 | 48:30 | Metallic, delicate — becoming operational |
| SM-051 | Safe house door hinge creak | SFX | 48:30 | 48:32 | The sound of entering the void |
| SM-052 | Dead apartment ambience | Ambience | 48:32 | 49:30 | Anechoic, artificial, no life |
| SM-053 | Exaggerated footstep reverb | Design | 48:40 | 49:30 | 200% reverb extension — space is wrong |
| SM-054 | Photograph paper sounds | Foley | 49:00 | 50:30 | Intimate, private, violating |
| SM-055 | Yasmin's breathing (subjective) | Design | 50:00 | 50:30 | Accelerated, shallow — her body is the score |
| SM-056 | Omar cello pedal (C2) | Non-diegetic | 50:15 | 51:00 | 65 Hz — felt, not heard — foundations shake |
| SM-057 | Window opens — traffic flood | SFX/Ambience | 51:30 | 51:35 | Full-frequency chaos — the return of life |
| SM-058 | Escape footsteps + city | Foley/Ambience | 51:35 | 52:00 | Running, breathing, Cairo reclaims her |

**Emotional Purpose:** The midpoint is where Yasmin crosses from civilian to operative. The sound design reflects this: the dead apartment is the operational world, and she learns to survive in it.

---

## SCENE 5: THE RAINDROP (60:00–68:00)
### "Operation Invades Home — Chopin Raindrop Prelude as Diegetic Music"

**Diegetic Audio:**
- Yasmin plays Chopin: Prelude in Db Major, Op. 28 No. 15 — "Raindrop Prelude."
- The persistent A-flat: This note appears 61 times in the piece. It is the "raindrop" — inescapable, monotonous, doomed. The sound design must ensure that by the 20th repetition, the audience is aware of it. By the 40th, it is maddening. By the 61st, it is devastating.
- The missed note: When Yasmin hears her father's name, she misses an A-flat. The raindrop STUTTERS. This wrong note is the most important piano note in the film. It must be precisely executed — a genuine performance mistake, not a composed effect. The actress/pianist must actually miss it in a way that sounds real.
- The modulation into minor: Yasmin modulates the piece into minor key. This is a spontaneous act of musical despair. The piano shifts from Db major to C# minor (the key of the opening Nocturne — the circle closes).
- The conversation behind her: Arabic, English, French — fragments. The sound design must make these words audible but indistinct. We hear the shape of language, not the content. Until: "El-Sayed connection." This name must cut through.

**Non-Diegetic Audio:**
- Rast maqam score: The non-diegetic score enters on oud and ney, playing in Rast (the maqam of joy-with-tension). It COMMENTS on the Chopin, creating an ironic duet. The Rast is "happy" — which makes the scene more horrifying.
- The A-flat transformation: The non-diegetic score takes the A-flat and transforms it into a rhythmic pulse. By the midpoint of the scene, the audience cannot distinguish between:
  - The Chopin A-flat (piano)
  - The Rast pulse (oud/ney)
  - A surveillance heartbeat (sound design)
  - The actual rain outside (if it is raining — the sound design should suggest this)
- The three layers merge into one sonic experience: the inescapable doom.

**Sound Design:**
- The apartment during the meeting: Different from the domestic apartment of Act I. The same space, but now it is "operational." The sound design achieves this through:
  - Reduced reverb (the room feels smaller, more contained)
  - Subtle 50Hz hum (surveillance presence)
  - The absence of domestic sounds (no refrigerator, no clock, no life — just the meeting)
- The "name cut-through": When "El-Sayed" is spoken, the sound design momentarily isolates this word. It is slightly louder, slightly drier, slightly more present than the surrounding conversation. It is the sonic equivalent of a knife.
- The rain outside: Whether or not it is actually raining, the sound design suggests rain. The A-flat becomes the raindrop. By the end of the scene, the audience should believe it is raining — even if the visuals do not confirm it.

**Audio Cue:**
| Cue # | Description | Type | In | Out | Notes |
|-------|-------------|------|-----|-----|-------|
| SM-070 | Chopin Raindrop Prelude — diegetic | Diegetic | 60:00 | 67:00 | 61 A-flats — the inescapable doom |
| SM-071 | Diplomat conversation (fragmented) | Diegetic | 61:00 | 66:00 | Arabic/English/French — audible but indistinct |
| SM-072 | "El-Sayed connection" — isolated | Design | 64:00 | 64:02 | The name cuts through — sonic knife |
| SM-073 | Rast maqam score (oud + ney) | Non-diegetic | 61:00 | 67:00 | Ironic joy — commenting on horror |
| SM-074 | A-flat pulse transformation | Design | 62:00 | 67:00 | Piano + oud + heartbeat merge |
| SM-075 | Rain suggestion (subtle) | Ambience | 63:00 | 67:00 | Rain outside — real or imagined? |
| SM-076 | Missed note — the A-flat stutters | Diegetic | 64:30 | 64:31 | Genuine performance mistake — devastating |
| SM-077 | Modulation to C# minor | Diegetic | 65:00 | 67:00 | Spontaneous despair — circle closes to opening |

**Emotional Purpose:** The Raindrop Prelude becomes the operational soundtrack. The music that was Yasmin's sanctuary is now her prison. The A-flat is no longer a musical note — it is surveillance, fate, her father's name.

---

## SCENE 6: THE DESTRUCTION (68:00–75:00)
### "Piano Smashed — Sound of Destruction, Music Dies"

**Diegetic Audio:**
- The argument: Voices raised, but not shouting. Omar and Yasmin are too controlled to shout. The argument is quiet, precise, devastating.
- The piano lid slam: The first violence. The sound of wood on wood, then the string resonance — a cluster of notes, dissonant, accidental.
- The candlestick on keys: The second violence. Wood and metal on ivory and steel. Keys break. Hammers strike strings they were not designed to strike. The piano SCREAMS.
- The frame resonance: When Yasmin destroys the piano, the entire instrument resonates — not musically, but structurally. The sound is of a wooden box being beaten. It is the sound of a coffin.
- Yasmin's breathing: After the destruction, she stands amid the wreckage. Her breathing is the only sound. Then: silence.

**Non-Diegetic Audio:**
- **THE SABA MAQAM ENTERS FOR THE FIRST TIME.**
- Saba is the maqam of deep sorrow — rarely used because it is "too painful." It enters here because this is the most painful moment in the film.
- The Saba is played on solo ney, but the player uses "old man's breath" — audible air noise, pitch instability, notes that bend downward. It is the sound of a voice that has given up.
- The ney plays the Yasmin cell (E–D–C–B–A) but in Saba — the notes are flattened, wrong, broken. The motif that represented her identity is now destroyed.
- A solo cello (Omar) enters beneath the ney — but it is not his usual pedal. It is a melody, for the first time. A simple, sad melody that he has never played before. He is trying to speak, but it is too late.
- The two instruments (ney and cello) play together for 30 seconds. They are in different keys. They do not harmonize. They are two people trying to communicate in languages the other does not understand.

**Sound Design:**
- The destruction of the piano must be recorded with multiple microphone perspectives:
  - Close-mics on the strings (to capture the metallic scream)
  - Close-mics on the frame (to capture the wooden thud)
  - Room mics (to capture the space's reaction)
  - Contact mics on the soundboard (to capture the structural resonance)
- The destruction is NOT scored with music. The destruction IS the music. No non-diegetic score during the actual smashing.
- Post-destruction: The room changes. The piano's resonance is gone. The apartment is now "dead" in a new way — not the anechoic dead of the safe house, but the dead of a home that has lost its voice.
- The silence after: 10 seconds of absolute silence. No breathing, no city, no life. Then: a single string, still vibrating, slowly dying. This is the piano's last breath.

**Audio Cue:**
| Cue # | Description | Type | In | Out | Notes |
|-------|-------------|------|-----|-----|-------|
| SM-080 | Argument — raised but controlled voices | Dialogue | 68:00 | 68:45 | Quiet precision, devastating |
| SM-081 | Piano lid slam — first violence | Diegetic/SFX | 68:45 | 68:47 | Wood on wood, string resonance, dissonance |
| SM-082 | Candlestick on keys — destruction | Diegetic/SFX | 68:50 | 69:15 | Piano screams — multi-mic recording |
| SM-083 | Frame resonance — structural death | SFX | 69:00 | 69:15 | The coffin sound |
| SM-084 | Post-destruction silence | Design | 69:15 | 69:25 | 10 sec absolute silence |
| SM-085 | Dying string — last breath | SFX | 69:25 | 69:35 | Single string, slowly dying |
| SM-086 | Saba maqam — ney (old man's breath) | Non-diegetic | 69:35 | 72:00 | First Saba — too painful for performance |
| SM-087 | Yasmin cell in Saba (broken) | Non-diegetic | 70:00 | 71:00 | Her identity motif, destroyed |
| SM-088 | Omar cello melody (first time) | Non-diegetic | 70:30 | 71:00 | He tries to speak — too late |
| SM-089 | Ney + cello — different keys | Non-diegetic | 70:45 | 71:15 | Two languages, no understanding |
| SM-090 | Dead apartment (new version) | Ambience | 71:15 | 75:00 | Home without its voice |

**Emotional Purpose:** The piano's destruction is the film's sonic climax. It is the death of Yasmin's identity, her art, her marriage, her self. The Saba maqam enters because only Saba can hold this much sorrow.

---

## SCENE 7: THE DUOLOGY (85:00–95:00)
### "Piano Duet as Battlefield — Dual Piano"

**Diegetic Audio:**
- Yasmin plays the Chopin Nocturne again — the same piece from the opening. But it is different now:
  - Slower (quarter note = 48 BPM — a breath, not a beat)
  - Fragile — wrong notes, hesitations, tempo collapses
  - More honest — the imperfection is the truth
- Omar places his hands above hers: He does not play. He rests his fingers on the keys. The sound is of four hands on the keyboard, but only two are sounding. The unsounded hands create mechanical noise — key depression without hammer strike. It is the sound of presence without voice.
- The silence after she stops: Absolute. The conservatory is empty. The city is distant. They are alone with the truth.

**Non-Diegetic Audio:**
- The non-diegetic score is now fully integrated with the diegetic. The audience should not be able to distinguish where the piano ends and the score begins.
- Saba and Nahawand alternate: Saba for the sorrow of what was lost; Nahawand for the acceptance of what cannot be changed.
- The Yasmin cell appears in its final transformation: ascending (A–B–C–D–E). It is the inversion of her identity — she is becoming something new.
- The Omar pedal enters: But now it is stable. For the first time in the film, his cello holds a single note WITHOUT microtonal drift. He is, finally, one person. But it is too late.
- The final chord: A cluster — Yasmin's piano (D major with suspended 4th) + Omar's cello (D natural minor) + Saba ney (D with flat 2nd and flat 6th) + Nahawand strings (D natural minor with major 7th). Four versions of D, all true, all incompatible. The chord is the marriage.

**Sound Design:**
- The conservatory acoustics: Large, resonant, beautiful. The sound of the space is the sound of Yasmin's world — music, art, culture. But it is empty. The emptiness makes it haunting.
- The mechanical noise of Omar's hands: Close-miked, the sound of keys depressing without sounding. It is intimate, tactile, sad.
- The silence after: 15 seconds. The longest silence in the film (except the final scene). Every sound system in every theater must be calibrated so that these 15 seconds are truly silent — no HVAC, no projector noise, no audience discomfort. The silence must be a gift, not a test.

**Audio Cue:**
| Cue # | Description | Type | In | Out | Notes |
|-------|-------------|------|-----|-----|-------|
| SM-100 | Chopin Nocturne — fragile, honest | Diegetic | 85:00 | 88:00 | Slower, wrong notes, tempo collapses |
| SM-101 | Omar's hands on keys (unsounded) | Diegetic/Foley | 87:00 | 88:00 | Mechanical intimacy — presence without voice |
| SM-102 | Saba + Nahawand alternating score | Non-diegetic | 85:30 | 88:00 | Sorrow and acceptance, intertwined |
| SM-103 | Yasmin cell — final transformation (ascending) | Non-diegetic | 86:30 | 87:30 | A–B–C–D–E — becoming something new |
| SM-104 | Omar cello pedal (stable, for the first time) | Non-diegetic | 87:00 | 88:00 | One person, finally — too late |
| SM-105 | Final chord — four versions of D | Diegetic + Non-diegetic | 88:00 | 88:10 | The marriage: four truths, incompatible |
| SM-106 | 15-second silence | Design | 88:10 | 88:25 | The longest silence — a gift |
| SM-107 | Post-silence breathing + city | Design | 88:25 | 95:00 | Return to the world, changed |

**Emotional Purpose:** The duet is the film's emotional climax. Not the plot climax — that is the operation, the file, the rooftop. The duet is where the marriage ends. The sound of four hands on two hands' worth of notes is the most devastating intimacy the film can offer.

---

## SCENE 8: THE UNRESOLVED NOTE (100:00–105:00)
### "One Note, Unresolved, Fade"

**Diegetic Audio:**
- The call to prayer: The final sound of Cairo. It begins as Yasmin stands at the window. It is close, enveloping, peaceful. It is the sound of the city that has witnessed a thousand such stories.
- Yasmin's breathing: The first unmeasured breath of the film. In Act I, her breathing was controlled, even. Here, it is natural — the breath of a person who is no longer performing.
- The piano note: D4, played on a Yamaha U1 upright (NOT the Steinway — she has a new, simpler life). The note is held with the sustain pedal. The natural decay is recorded for 30+ seconds.
- The note's decay: As the note fades, it becomes more complex, not less. The overtones become audible — the 5th, the octave, the 12th. The single note contains a world of harmonics. This is the film's final metaphor: one life, infinite resonance.

**Non-Diegetic Audio:**
- Saba maqam — FINAL appearance: The ney enters beneath the decaying piano note. It plays the Yasmin cell one last time — but now it is neither ascending nor descending. It is a single sustained D, with microtonal inflections. It is the sound of a question that does not want an answer.
- Omar's cello microtone: In the final second, as the piano note has decayed to near-inaudibility, the cello enters. A microtone below D — not quite D, not quite Db. It is Omar, unresolved, still present, still part of her harmonic world.
- The two notes (piano D and cello microtone) create a beating pattern — a subtle pulse of interference. It is the sound of two people who are not together but are not apart. The pulse is 7 Hz — below the threshold of pitch perception. It is felt, not heard. It is the heartbeat of the unresolved.

**Sound Design:**
- The call to prayer: Recorded from multiple minarets, creating a natural polyrhythm. The different muezzins start at slightly different times, creating a sonic tapestry. This is the sound of community, faith, continuity — the world that does not end when a marriage does.
- The piano recording: The Yamaha U1 must be recorded with the sustain pedal held, in a medium-sized room. The microphones must be placed to capture both the direct sound and the room resonance. The decay must be natural — no artificial reverb extension.
- The final second: The cello microtone must be precisely tuned. 7 Hz beating requires the cello to be approximately 7 cents below the piano D. This is a microtonal interval that creates physical sensation — the listener may feel it in their chest.
- The fade to black: The image fades before the sound. The sound continues for 3 seconds in darkness. Then: silence. But the silence is not empty — it contains the memory of the note. The audience hears the note in its absence.

**Audio Cue:**
| Cue # | Description | Type | In | Out | Notes |
|-------|-------------|------|-----|-----|-------|
| SM-120 | Call to prayer — multiple minarets | Diegetic/Ambience | 100:00 | 101:30 | Cairo's voice, enveloping, peaceful |
| SM-121 | Yasmin's unmeasured breathing | Diegetic | 101:00 | 101:30 | Natural, no longer performing |
| SM-122 | Piano note D4 — Yamaha U1 | Diegetic | 101:30 | 102:00 | Held, natural decay, 30+ seconds |
| SM-123 | Saba ney — final appearance | Non-diegetic | 101:45 | 102:15 | Yasmin cell as sustained question |
| SM-124 | Piano overtones during decay | Diegetic/Design | 101:45 | 102:15 | The 5th, octave, 12th — infinite resonance |
| SM-125 | Omar cello microtone (7 cents flat) | Non-diegetic | 102:14 | 102:15 | The unresolved presence |
| SM-126 | 7 Hz beating pattern | Design | 102:14 | 102:15 | Felt, not heard — the heartbeat of the unresolved |
| SM-127 | Fade to black — sound continues | Design | 102:10 | 102:15 | Image fades, sound holds |
| SM-128 | Final silence — memory of the note | Design | 102:15 | 105:00 | The note heard in its absence |

**Emotional Purpose:** The unresolved note is the film's thesis. Life does not resolve. Love does not resolve. Music does not resolve. But the absence of resolution is not emptiness — it is possibility. The audience leaves with a note ringing in their ears that does not end.

---

# 4. DIEGETIC VS. NON-DIEGETIC MUSIC MAP

## 4.1 The Blurring Principle

"حب وخيانة" does not respect the traditional boundary between diegetic and non-diegetic music. The boundary is intentionally blurred to reflect the film's themes:
- **Performance vs. Reality:** Yasmin's diegetic piano performances are always performances — even when she is alone.
- **The Operational World:** Omar's operational world contaminates everything. The non-diegetic score often sounds like surveillance technology.
- **Memory as Music:** Music that was diegetic in one scene returns as non-diegetic in another, becoming the character's memory.

## 4.2 Complete Map by Scene

| Scene | Time | Diegetic Music | Non-Diegetic Score | Blurring Moment |
|-------|------|----------------|-------------------|-----------------|
| 1. The Nocturne | 0:00–3:00 | Chopin Nocturne (concert) | Bayati commentary (oud+ney) | Bayati enters between phrases — "commenting" on the performance |
| 2. The Routine | 3:00–8:00 | None (Yasmin does not play at home) | Bayati solo piano (felt-muted) | The piano is heard but not seen — is she playing, or is it her thoughts? |
| 3. The Drawer | 8:00–12:00 | Frantic Chopin (post-discovery) | Omar cello pedal (microtonal C) | The cello represents Omar's absence — is it score or is it his ghost? |
| 4. The Sister | 12:00–18:00 | Layla's radio (Arabic pop) | None | Layla's music is always diegetic — she is the "real world" |
| 5. The Follow | 18:00–26:00 | None | Hijaz violin + strings | Pure non-diegetic — the score follows Yasmin's following |
| 6. The Confession | 26:00–32:00 | Yasmin touches keys, does not play | Bayati broken — piano + cello duet (different keys) | The duet represents their marriage: together but not aligned |
| 7. The New Rules | 32:00–40:00 | None | Hijaz + surveillance pulses | The score IS surveillance — rhythmic, systematic, cold |
| 8. The Journalist | 40:00–48:00 | None | Minimal — ambient only | Layla's world has no score — only reality |
| 9. The Handler | 48:00–52:00 | None | Clarinet + operational pulse | Nour's clarinet is her sonic signature |
| 10. The Safe House | 52:00–60:00 | None | NONE — only sound design | The midpoint: music abandons Yasmin |
| 11. The Meeting | 60:00–68:00 | Chopin Raindrop Prelude | Rast maqam (oud+ney) + A-flat pulse | The three layers merge — piano + maqam + surveillance become one |
| 12. The Raindrop | 60:00–75:00 | Chopin Raindrop (continues) | Rast + pulse (continues) | The merger continues — boundaries dissolve |
| 13. The Destruction | 68:00–75:00 | Piano destruction IS music | Saba ney + Omar cello melody | The destruction creates the score — Saba enters for the first time |
| 14. The Silence | 75:00–82:00 | None — Yasmin does not play | None | Absolute silence — grief beyond music |
| 15. The Package | 82:00–89:00 | None | Minimal — ambient + subtle pulse | The threat returns as sound design |
| 16. The Alliance | 89:00–94:00 | None | Clarinet + operational rhythm | Nour's world — systematic, musical but cold |
| 17. The Garden | 94:00–100:00 | None | None — only garden ambience | Khalid's garden IS the music — natural sound as score |
| 18. The File | 100:00–107:00 | None | Minimal Saba suggestion | The file is too terrible for music — only Saba can approach it |
| 19. The Duology | 107:00–117:00 | Chopin Nocturne (fragile) | Saba + Nahawand + four-version-D chord | Full integration — diegetic and non-diegetic are one |
| 20. The Silence After | 117:00–122:00 | None | None | 15-second silence — the longest in the film |
| 21. The News | 122:00–127:00 | None | Minimal pulse | Urgency returns — the world forces a decision |
| 22. The Offer | 127:00–132:00 | None | Nahawand cello + piano | Omar's offer — Nahawand, the maqam of farewell |
| 23. The Counter | 132:00–137:00 | None | Nahawand intensifying | Yasmin's counter — the farewell maqam becomes confrontation |
| 24. Three Months | 137:00–140:00 | Yasmin improvising | Nahawand + natural ambience | Her improvisation IS the score — she is composing her own life |
| 25. The Letter | 140:00–142:00 | None | Minimal — single piano notes | The letter's music is memory — fragmented |
| 26. The Unresolved Note | 142:00–145:00 | Piano D4 + call to prayer | Saba ney + cello microtone | The final merger — all boundaries dissolve |

## 4.3 The Boundary Dissolution

Three key moments where diegetic and non-diegetic become indistinguishable:

### Moment 1: The Raindrop (60:00–68:00)
The Chopin A-flat, the Rast oud pulse, the surveillance heartbeat, and the suggested rain merge into one sonic layer. The audience cannot — and should not try to — separate them.

### Moment 2: The Destruction (68:00–75:00)
The piano's destruction creates the Saba score. The violence IS the music. The non-diegetic ney and cello enter as a RESPONSE to the diegetic destruction — but they are so closely timed that they seem to be CAUSED by it.

### Moment 3: The Unresolved Note (100:00–105:00)
The piano note, the call to prayer, the ney, and the cello microtone are all playing the same pitch (D) with different inflections. They are four instruments, four traditions, four emotional states — but one note. The boundary between diegetic and non-diegetic, between East and West, between presence and absence, between Yasmin and Omar — all dissolve into the sustained D.

---

# 5. SILENCE DESIGN — THE EMOTIONAL WEAPON

## 5.1 The Philosophy of Silence

In "حب وخيانة," silence is not the absence of sound. It is the presence of something that cannot be spoken. The film's silence is:
- **Active:** The audience listens TO the silence, not THROUGH it.
- **Character-specific:** Each character's silence sounds different.
- **Progressive:** The silences grow longer, deeper, more meaningful as the film progresses.
- **Cultural:** Silence in Arabic emotional culture is not emptiness — it is density. The things not said are heavier than the things said.

## 5.2 The Seven Sacred Silences

### Silence 1: After the Phone Discovery (The Drawer, 8:00–12:00)
- **Duration:** 8 seconds (8:36–8:44)
- **Content:** Absolute silence after the phone "ding." No music, no ambience, no breathing.
- **Function:** The moment of recognition before reaction. The audience and Yasmin share the same silence — we are both processing the betrayal.
- **Technical note:** This silence must be true digital silence (–∞ dB). No room tone, no air. The audience should hear their own heartbeat.

### Silence 2: After the Confession (The Confession, 26:00–32:00)
- **Duration:** 12 seconds (30:00–30:12)
- **Content:** After Omar says "Silence. I've been silent so long I don't have a melody anymore." No music. Only the sound of the apartment — distant traffic, a refrigerator hum that now sounds threatening.
- **Function:** The marriage's truth is spoken. The silence after is the sound of that truth settling.
- **Technical note:** The silence contains "negative sound" — the absence of music is felt because music was expected. The refrigerator hum, previously unnoticed, becomes a character.

### Silence 3: In the Safe House (The Safe House, 52:00–60:00)
- **Duration:** 20 seconds (54:00–54:20)
- **Content:** After Yasmin sees the photographs of the other woman. The safe house is dead. No music. No ambience. Only her breathing.
- **Function:** The moment of absolute violation. Being seen without being known. The silence is the sound of identity being rewritten.
- **Technical note:** The silence is preceded by a 50Hz hum (surveillance) that drops out at the exact moment she sees the photographs. The absence of the hum is more terrifying than its presence.

### Silence 4: After the Destruction (The Destruction, 68:00–75:00)
- **Duration:** 10 seconds (69:15–69:25)
- **Content:** After Yasmin destroys the piano. Absolute silence. Then: a single dying string.
- **Function:** The funeral of her identity. The silence is the eulogy.
- **Technical note:** The 10 seconds must be calibrated per theater. In some spaces, 10 seconds of silence will cause audience discomfort. This is INTENTIONAL. The discomfort IS the emotion.

### Silence 5: After the Duology (The Duology, 85:00–95:00)
- **Duration:** 15 seconds (88:10–88:25)
- **Content:** After Yasmin stops playing and Omar removes his hands. The conservatory is empty. They are alone with the silence.
- **Function:** The end of the marriage. Not spoken. Not signed. Just: the absence of music where music once was.
- **Technical note:** The longest silence in the film. It must be earned — the audience must be so emotionally invested that they do not want the silence to end. If they do, the scene has failed.

### Silence 6: Three Days at Layla's (The Silence, 75:00–82:00)
- **Duration:** 30 seconds (distributed across the scene)
- **Content:** Yasmin does not speak for three days. The film does not score her silence. It simply shows it. The silence of the scene is the silence of a person who has lost language.
- **Function:** Grief beyond music, beyond words, beyond sound.
- **Technical note:** The scene contains three 10-second silences. Between them: the sound of Layla making tea, a distant car, a bird. The contrast makes the silences louder.

### Silence 7: The Unresolved Note (The Unresolved Note, 100:00–105:00)
- **Duration:** 30+ seconds (the decay of the piano note) + 3 seconds (post-black)
- **Content:** The piano note decays to near-inaudibility. The image fades to black. The sound continues for 3 seconds in darkness. Then: silence.
- **Function:** The film's final silence contains the memory of the note. The audience hears the note in its absence.
- **Technical note:** The 3 seconds of sound-in-darkness must be precisely calibrated. Too short, and the audience does not register it. Too long, and it becomes a gimmick. 3 seconds is the duration of a held breath.

## 5.3 Silence Rules

1. **Every act must contain at least 30 seconds of total non-diegetic silence.**
2. **Act IV (The Collapse) contains 90 seconds of silence — distributed across scenes.**
3. **Act V (The Ruins) contains 60 seconds of silence — but it is peaceful, not painful.**
4. **Silence must always be EARNED.** It cannot follow a loud scene just for contrast. It must follow an emotional revelation that makes sound impossible.
5. **Silence must always be BROKEN carefully.** The return of sound after silence is a musical event. It must be choreographed.
6. **Silence contains "negative sound."** The audience should notice the absence of expected sounds: no piano resonance, no traffic, no breathing, no life.

---

# 6. FOLEY & AMBIENT SOUND DESIGN PER ACT

## 6.1 Act I: The Surface (0:00–26:00)
### Sonic Character: Warm, Controlled, Seductive, False

**Ambient Design:**
- **Concert hall:** Rich, warm, reverberant. Audience presence subtle but real. The applause (if any) is polite, not passionate — Yasmin's performances are admired, not loved.
- **Apartment:** Domestic, cozy, but with subtle emptiness. The refrigerator hum is constant. The clock ticks (this clock will stop in Act II — a detail for repeat viewers). Traffic is distant, a lullaby.
- **Conservatory:** The sound of teaching — student pianos, scales, fragments of pieces. The conservatory is alive with music, but it is OTHER people's music. Yasmin is surrounded by music but alone.
- **Cafés:** Arabic conversation, clinking glasses, espresso machines. The sound of Cairo's social life — warm, inviting, deceptive.

**Foley Design:**
- **Yasmin's movements:** Precise, controlled. Her footsteps are even. Her hands on piano keys are deliberate. She does not rush. She does not hesitate. She is a person who has mastered her body.
- **Omar's movements (husband mode):** Normal, confident, warm. Footsteps on tile, wood, carpet. The sound of a man who is at home in his life.
- **The wedding ring:** A subtle "tick" sound whenever Yasmin's hand crosses a hard surface. This sound is isolated and will return as a motif.

**Signature Sounds:**
- The clock tick (which stops)
- The refrigerator hum (which becomes threatening in Act II)
- The wedding ring tick (which stops when she removes the ring)
- The concert hall applause (polite, controlled, sad)

## 6.2 Act II: The Crack (26:00–52:00)
### Sonic Character: Shifting, Unstable, Paranoid, Divided

**Ambient Design:**
- **Apartment (new version):** The same apartment, but now it sounds different. The refrigerator hum is louder, more insistent. The traffic is closer, more aggressive. Shadows have sounds — creaks, shifts, the building settling in new ways.
- **The city (following):** Zamalek café ambience, street sounds, car horns. The city is chaotic, alive, overwhelming. It reflects Yasmin's internal state.
- **The safe house:** Anechoic, dead, wrong. No life. No ambience. The space is a void.
- **Nour's restaurant:** Elegant, expensive, quiet — but with a subtle "operational hum" (50Hz) that suggests surveillance.

**Foley Design:**
- **Yasmin's movements:** More hesitant. Her footsteps are uneven. She checks behind her. She drops things. She is losing control.
- **Omar's movements:** The transition from husband mode to operative mode. The Foley must reflect this: softer shoes, shorter strides, weight on the balls of the feet.
- **Lock-picking:** The sound of Yasmin becoming operational. Metallic, delicate, precise.

**Signature Sounds:**
- The operational hum (50Hz surveillance)
- The two modes of Omar's footsteps
- The safe house void
- The click of the surveillance camera (suggested, never confirmed)

## 6.3 Act III: The Reckoning (52:00–78:00)
### Sonic Character: Tense, Pulsing, Invasive, Destructive

**Ambient Design:**
- **Apartment (operational):** The apartment during the diplomatic meeting. The domestic sounds are gone. The space is operational — contained, monitored, hostile.
- **The Raindrop scene:** The A-flat becomes the environment. Whether or not it is raining, the sound design suggests rain. The city becomes a storm.
- **The destruction aftermath:** The apartment is dead in a new way. The piano's resonance is gone. The space is hollow.
- **Layla's apartment:** Cluttered, alive, chaotic — the opposite of Yasmin's curated space. Books, coffee cups, a radio playing Arabic pop. Layla's world is messy but real.

**Foley Design:**
- **Piano destruction:** Multi-mic recording. The sound of wood on wood, metal on ivory, frame resonance. The piano screams.
- **Yasmin's post-destruction movements:** She moves differently. She is no longer a pianist. Her hands are weapons, then they are empty.
- **The package opening:** Brown paper, photographs, the sound of paper being violated.

**Signature Sounds:**
- The piano destruction (the film's most violent sound)
- The dying string (the piano's last breath)
- The operational A-flat pulse (surveillance as music)
- Layla's radio (the real world)

## 6.4 Act IV: The Collapse (78:00–100:00)
### Sonic Character: Hollow, Distant, Devastated, Silent

**Ambient Design:**
- **Khalid's garden:** Natural, gentle, alive — birds, wind in roses, distant Cairo. The garden is the first peaceful space in the film. But it is also terrifying — because peace, after so much destruction, feels like a trap.
- **The conservatory (final confrontation):** Large, resonant, empty. The sound of a space designed for music that now holds only silence.
- **The rooftop:** Wind, distant city, the sound of height. The space is vast, open, exposing.
- **Yasmin's new apartment:** Smaller, simpler, different. The sound of a new life — uncertain, fragile, real.

**Foley Design:**
- **Yasmin's movements:** Slower, more deliberate. She is no longer rushing. She is no longer performing. She is simply moving.
- **The file:** Manila envelope, paper, photographs, handwriting. The sound of total knowledge.
- **Omar's movements:** He is finally one person. His footsteps are consistent — neither husband nor operative, just a man.

**Signature Sounds:**
- Khalid's garden (natural sound as score)
- The Manila envelope (the sound of truth)
- The rooftop wind (exposure, height, decision)
- The new apartment (uncertainty, fragility, possibility)

## 6.5 Act V: The Ruins (100:00–105:00)
### Sonic Character: Spare, Open, Peaceful, Unresolved

**Ambient Design:**
- **The new apartment:** Quiet, simple, peaceful. The sound of a life that has been stripped to essentials.
- **The call to prayer:** Close, enveloping, beautiful. The sound of Cairo at peace.
- **The final window:** The city at dusk. Traffic is distant. The world is winding down.

**Foley Design:**
- **Yasmin's movements:** Natural, unmeasured. She is no longer a performer. She is a person.
- **The piano note:** One note, held, decaying. The sound of possibility.
- **The letter:** Envelope, paper, photograph. The sound of a message from another world.

**Signature Sounds:**
- The call to prayer (faith, continuity, peace)
- The unresolved piano note (possibility, openness, continuation)
- The cello microtone (Omar, still present, still unresolved)
- The 7 Hz beating (the heartbeat of the unresolved)

---

# 7. MUSIC LICENSING & ORIGINAL COMPOSITION NOTES

## 7.1 Licensed Works

### Chopin: Nocturne in C-sharp minor, Op. Posth.
- **Status:** Public domain (composer died 1849). No licensing required for the composition.
- **Recording license:** A new recording must be commissioned. The pianist (or actress, if she plays) must record two versions:
  - Version 1 (0:00–3:00): Controlled, perfect, emotionally distant. Tempo = 60 BPM. Metronomic.
  - Version 2 (85:00–95:00): Fragile, broken, honest. Tempo = 48 BPM. Rubato. Wrong notes. Hesitations.
- **Recording budget:** $15,000–25,000 for professional pianist + studio + Steinway D rental.
- **Note:** If the actress is not a professional pianist, a hand-double must be used for close-ups, and the recording must be synced carefully.

### Chopin: Prelude in Db Major, Op. 28 No. 15 — "Raindrop Prelude"
- **Status:** Public domain. No licensing required for composition.
- **Recording license:** New recording commissioned. Two versions:
  - Version 1 (60:00–68:00): Performed during the meeting. Must include the missed note (the A-flat stutter) and the modulation to C# minor.
  - Version 2 (non-diegetic fragments): Extracts of the A-flat for the sound design integration.
- **Recording budget:** $10,000–15,000.

### Arabic Pop/Radio Music (Layla's apartment)
- **Status:** Must be licensed. Suggest using contemporary Egyptian pop from independent artists (lower licensing fees, more authentic).
- **Budget:** $5,000–10,000 for 2–3 tracks.
- **Alternative:** Commission a brief original "radio pop" track from an Egyptian composer. Cheaper and more controllable.

## 7.2 Original Composition

### Scope of Original Score
- **Estimated number of cues:** 40–50 non-diegetic cues.
- **Total runtime of original score:** Approximately 45–55 minutes of a 105-minute film.
- **Composer requirement:** A composer fluent in both Western orchestral tradition and Arabic maqam system. Preferably of Middle Eastern origin or extensive study.

### Recommended Composers (Reference Tier)
1. **Gabriel Yared** (The English Patient, A Separation) — Emotional precision, modal sensitivity
2. **Ryuichi Sakamoto** (Merry Christmas Mr. Lawrence, The Revenant) — Spare devastation
3. **Jóhann Jóhannsson** (Arrival, Theory of Everything) — Mathematical beauty (posthumous reference for style)
4. **Hanan Townshend** (To the Wonder, The Better Angels) — Contemporary spiritual minimalism
5. **Tamer Abu Ghazaleh** (Arabic indie composer) — Authentic maqam + modern sensibility

### Original Score Budget Estimate
| Item | Cost (USD) |
|------|-----------|
| Composer fee (original score, 50 min) | $75,000–150,000 |
| Orchestration & copyist | $15,000–25,000 |
| Recording sessions (3 days, Cairo + European studio) | $40,000–60,000 |
| Soloist fees (oud, ney, qanun, riqq) | $8,000–12,000 |
| Mixing & mastering (5.1 + stereo) | $20,000–30,000 |
| **Total original score** | **$158,000–277,000** |

### Arabic Instrumentation Budget
| Instrument | Player | Sessions | Rate | Total |
|------------|--------|----------|------|-------|
| Oud | Master player | 3 days | $800/day | $2,400 |
| Ney | Master player | 3 days | $800/day | $2,400 |
| Qanun | Master player | 2 days | $800/day | $1,600 |
| Riqq/Daff | Master player | 2 days | $600/day | $1,200 |
| **Total Arabic soloists** | | | | **$7,600** |

## 7.3 Sound Design & Foley Budget Estimate
| Item | Cost (USD) |
|------|-----------|
| Sound design (supervisor + editor, 105 min) | $60,000–90,000 |
| Foley recording (3 days, Cairo + studio) | $25,000–40,000 |
| ADR (Arabic dialogue + additional recording) | $15,000–25,000 |
| Field recording (Cairo locations) | $8,000–12,000 |
| Sound effects libraries + custom recordings | $10,000–15,000 |
| Mixing (5.1 theatrical + stereo deliverables) | $40,000–60,000 |
| **Total sound design & mix** | **$158,000–242,000** |

## 7.4 Music Supervision & Licensing Budget
| Item | Cost (USD) |
|------|-----------|
| Music supervisor fee | $15,000–25,000 |
| Chopin recording commissions | $25,000–40,000 |
| Arabic pop/radio licensing | $5,000–10,000 |
| Music legal (clearance, contracts) | $5,000–8,000 |
| **Total music supervision** | **$50,000–83,000** |

## 7.5 Total Audio Budget
| Category | Low | High |
|----------|-----|------|
| Original score | $158,000 | $277,000 |
| Sound design & mix | $158,000 | $242,000 |
| Music supervision | $50,000 | $83,000 |
| **TOTAL AUDIO** | **$366,000** | **$602,000** |

**Recommended budget:** $450,000–500,000 for prestige arthouse production.

---

# 8. FINAL MIX PHILOSOPHY

## 8.1 The Mix as Emotional Architecture

The final mix of "حب وخيانة" is not a technical process — it is the final emotional layer of the film. The mix must:
1. **Preserve ambiguity:** The audience should not always know if a sound is diegetic or non-diegetic, music or sound design, real or imagined.
2. **Honor the maqam:** The quarter-tone inflections of the Arabic instruments must survive the mix. Western equalization habits (tuning to 12-tone equal temperament) must be avoided.
3. **Respect silence:** The silent moments must be truly silent. No leakage, no hum, no artifact.
4. **Create space for the piano:** The piano is the protagonist's voice. It must always have space — frequency space, dynamic space, emotional space.
5. **Integrate Cairo:** The city is not background. It is character. Its ambience must be present but never overwhelming.

## 8.2 Technical Specifications

### Theatrical Deliverables
- **5.1 surround mix:** Primary theatrical format.
  - L/R: Music score + principal dialogue
  - C: Dialogue (primary), solo piano (when featured)
  - Ls/Rs: Ambience, Cairo cityscape, reverb tails, surround score elements
  - LFE: Sub-bass for Omar's cello (low register), piano frame resonance, operational pulses
- **Stereo mix:** For festival screenings, streaming, international TV.
  - Must preserve all maqam quarter-tones and emotional dynamics.
  - Ambience must collapse gracefully without becoming congested.

### Mix Stages
1. **Dialogue premix:** Clean, intelligible, emotionally nuanced. Arabic dialogue must be clear to Arabic speakers AND emotionally comprehensible to non-Arabic speakers (through tone, rhythm, performance).
2. **Music premix:** Separate stems for:
   - Western orchestral (strings, piano, woodwinds)
   - Arabic ensemble (oud, ney, qanun, percussion)
   - Electronic/sound design layers
   - Each stem must be mixable independently for different territories (some territories may want more/less Arabic instrumentation).
3. **Sound effects premix:** Foley, ambience, SFX, operational sounds.
4. **Final mix:** Integration of all elements, creating the ambiguous sonic world.

### Critical Mix Decisions
- **The 50Hz operational hum:** Must be present but subliminal. In the theatrical mix, it should be routed to the LFE channel at very low level (-30 dBFS). Some listeners will feel it physically without hearing it.
- **The A-flat pulse (Raindrop scene):** Must merge seamlessly between diegetic piano, non-diegetic oud, and sound design pulse. The transition should be imperceptible.
- **The 7 Hz beating (final scene):** Must be calibrated per theater. In spaces with good LFE response, the audience will feel it. In spaces with limited bass, it will be inaudible — but the emotional impact must survive without it.
- **Silence calibration:** Each silent moment must be checked on multiple playback systems. True silence on a cinema system may reveal projector noise, HVAC, or auditorium ambience. The mix must account for real-world playback conditions.

## 8.3 Reference Mixes

The final mix should be referenced against:
1. **In the Mood for Love** (Wong Kar-wai, 2000) — The use of music as emotional memory, the blurred diegetic/non-diegetic boundary.
2. **Atonement** (Joe Wright, 2007) — The typewriter as percussion, the integration of diegetic piano with orchestral score.
3. **Tinker Tailor Soldier Spy** (Tomas Alfredson, 2011) — The paranoia density, the operational sound design, the restrained score.
4. **The Lives of Others** (Florian Henckel von Donnersmarck, 2006) — The surveillance as sonic presence, the piano as character.
5. **Cairo Time** (Ruba Nadda, 2009) — The Cairo ambience, the call to prayer as emotional anchor.

## 8.4 Mixing Team

**Recommended structure:**
- **Supervising Sound Editor:** 1 person, full film. Must be fluent in Arabic and Western musical traditions.
- **Re-recording Mixers:** 2 persons (dialogue/music + effects/ambience).
- **Mixing Stage:** Atmos-capable stage (for future-proofing), calibrated to dubbing stage standards.
- **Mix Duration:** 3–4 weeks minimum. This is an emotionally complex mix that cannot be rushed.

---

# 9. COMPLETE AUDIO CUE SHEET

## Legend
- **Type:** D = Diegetic, ND = Non-Diegetic, A = Ambience, F = Foley, S = SFX, DS = Design
- **Emotion:** The emotional purpose of the cue

## Master Cue List

| Cue # | Scene | Title | Type | In | Out | Duration | Description | Emotional Purpose |
|-------|-------|-------|------|-----|-----|----------|-------------|-------------------|
| SM-001 | 1 | Nocturne — Concert | D | 0:00 | 2:45 | 2:45 | Chopin Nocturne, flawless, controlled | Establish duality: perfection vs. emptiness |
| SM-002 | 1 | Bayati Commentary | ND | 0:12 | 2:45 | 2:33 | Solo oud + ney between phrases | The inner voice — what Yasmin conceals |
| SM-003 | 1 | Concert Audience | A | 0:00 | 2:45 | 2:45 | Subtle audience presence | The public performance — real but distant |
| SM-004 | 1 | Apartment Domestic | A | 2:46 | 3:00 | 0:14 | Refrigerator, silence, distant city | Private emptiness — the truth |
| SM-010 | 3 | Drawer Opening | F | 8:00 | 8:30 | 0:30 | Wood slide, lived-in sound | The ordinary action that reveals the extraordinary |
| SM-011 | 3 | Phone Vibration | S | 8:32 | 8:35 | 0:03 | Low-frequency shock on wood | The first sonic betrayal |
| SM-012 | 3 | Message Ding | S | 8:35 | 8:36 | 0:01 | Generic notification — terrifying in context | The ordinary made horrifying |
| SM-013 | 3 | Active Silence | DS | 8:36 | 8:45 | 0:09 | Absolute silence — the room holds its breath | Recognition before reaction |
| SM-014 | 3 | Omar Cello Pedal | ND | 8:45 | 9:30 | 0:45 | Microtonal C — his presence in absence | Omar's ghost haunts the silence |
| SM-015 | 3 | Frantic Chopin | D | 10:00 | 11:30 | 1:30 | Wrong notes, accelerating, breaking down | Panic as performance |
| SM-016 | 3 | Bayati Breakdown | ND | 10:00 | 11:30 | 1:30 | Maqam attempts to follow, fails | The inner voice cannot keep up |
| SM-017 | 3 | Piano Slam | D/S | 11:30 | 11:32 | 0:02 | Full keyboard cluster — mechanical violence | The breaking point |
| SM-018 | 3 | Post-Slam Silence | DS | 11:32 | 12:00 | 0:28 | 5 sec silence, then ragged breathing | The aftermath — sound of a person shattered |
| SM-030 | 5 | Zamalek Café | A | 18:00 | 22:00 | 4:00 | Authentic Cairo café ambience | The city as witness |
| SM-031 | 5 | Yasmin Footsteps | F | 18:30 | 19:15 | 0:45 | Untrained following — too loud, too regular | Her amateur surveillance |
| SM-032 | 5 | Omar Footsteps (Op) | F | 19:00 | 19:30 | 0:30 | Operative mode — softer, checking | The double life in sound |
| SM-033 | 5 | Hijaz Violin | ND | 18:30 | 26:00 | 7:30 | Augmented 2nd — longing/suspicion | The maqam of yearning |
| SM-034 | 5 | String Build | ND | 20:00 | 22:00 | 2:00 | Restrained ensemble — internal tension | Tension without release |
| SM-035 | 5 | Operational Pulse | ND | 20:30 | 22:00 | 1:30 | Frame drum at 72 BPM — heart-rate sync | The body responding to threat |
| SM-036 | 5 | Nour Dip | DS | 20:45 | 20:47 | 0:02 | -3dB ambience dip — her presence | She consumes sonic space |
| SM-037 | 5 | Voice Memo | D | 23:00 | 24:00 | 1:00 | Grainy, hissy, low-fi recording | The banality of betrayal |
| SM-038 | 5 | Threatened Apartment | DS | 24:00 | 26:00 | 2:00 | EQ shift — same room, now hostile | Home becomes prison |
| SM-050 | 10 | Lock-Picking | F | 48:00 | 48:30 | 0:30 | Metallic, delicate — becoming operational | Yasmin learns the operative's tools |
| SM-051 | 10 | Door Creak | S | 48:30 | 48:32 | 0:02 | Hinge creak — entering the void | The threshold |
| SM-052 | 10 | Dead Apartment | A | 48:32 | 49:30 | 0:58 | Anechoic, artificial, no life | The operational world — dead |
| SM-053 | 10 | Exaggerated Reverb | DS | 48:40 | 49:30 | 0:50 | 200% footstep extension | Space is wrong — she doesn't belong |
| SM-054 | 10 | Photographs | F | 49:00 | 50:30 | 1:30 | Paper shuffle, intimate, violating | Touching her own surveillance |
| SM-055 | 10 | Breathing (Subjective) | DS | 50:00 | 50:30 | 0:30 | Accelerated, shallow — her body is the score | Fear made audible |
| SM-056 | 10 | Omar Cello C2 | ND | 50:15 | 51:00 | 0:45 | 65 Hz — felt, not heard | Foundations shake |
| SM-057 | 10 | Traffic Flood | S/A | 51:30 | 51:35 | 0:05 | Full-frequency chaos — escape | The city reclaims her |
| SM-058 | 10 | Escape | F/A | 51:35 | 52:00 | 0:25 | Running, breathing, Cairo | She has become operational |
| SM-070 | 11-12 | Raindrop Prelude | D | 60:00 | 67:00 | 7:00 | Chopin — 61 A-flats, inescapable | The doom note — music as prison |
| SM-071 | 11-12 | Diplomat Conversation | D | 61:00 | 66:00 | 5:00 | Arabic/English/French fragments | Information she cannot have |
| SM-072 | 11-12 | "El-Sayed" Isolated | DS | 64:00 | 64:02 | 0:02 | The name cuts through — sonic knife | The father's name — identity shattered |
| SM-073 | 11-12 | Rast Maqam | ND | 61:00 | 67:00 | 6:00 | Ironic joy — commenting on horror | Joy with tension — the affair of the operational |
| SM-074 | 11-12 | A-flat Pulse | DS | 62:00 | 67:00 | 5:00 | Piano + oud + heartbeat merge | Inescapable — the three become one |
| SM-075 | 11-12 | Rain Suggestion | A | 63:00 | 67:00 | 4:00 | Suggested rain outside | Real or imagined? The A-flat becomes weather |
| SM-076 | 11-12 | Missed Note | D | 64:30 | 64:31 | 0:01 | The A-flat stutters — genuine mistake | The performance breaks — she breaks |
| SM-077 | 11-12 | C# Minor Modulation | D | 65:00 | 67:00 | 2:00 | Spontaneous despair — key of opening | The circle closes to the beginning |
| SM-080 | 13 | Argument | D | 68:00 | 68:45 | 0:45 | Raised but controlled voices | Quiet precision, devastating |
| SM-081 | 13 | Lid Slam | D/S | 68:45 | 68:47 | 0:02 | Wood on wood, string resonance | First violence — the piano screams |
| SM-082 | 13 | Candlestick Destruction | D/S | 68:50 | 69:15 | 0:25 | Multi-mic piano destruction | The piano dies — multi-perspective recording |
| SM-083 | 13 | Frame Resonance | S | 69:00 | 69:15 | 0:15 | Structural death — the coffin sound | The instrument's body breaking |
| SM-084 | 13 | Post-Destruction Silence | DS | 69:15 | 69:25 | 0:10 | 10 seconds absolute silence | The funeral — the eulogy is silence |
| SM-085 | 13 | Dying String | S | 69:25 | 69:35 | 0:10 | Single string, slowly dying | The piano's last breath |
| SM-086 | 13 | Saba Ney | ND | 69:35 | 72:00 | 2:25 | First Saba — old man's breath | Too painful for performance — now required |
| SM-087 | 13 | Yasmin Cell (Saba) | ND | 70:00 | 71:00 | 1:00 | Her identity motif, destroyed | The self in the mode of sorrow |
| SM-088 | 13 | Omar Cello Melody | ND | 70:30 | 71:00 | 0:30 | First melody — he tries to speak | Too late — but he tries |
| SM-089 | 13 | Ney + Cello | ND | 70:45 | 71:15 | 0:30 | Different keys — no understanding | Two languages, one marriage |
| SM-090 | 13 | Dead Apartment (New) | A | 71:15 | 75:00 | 3:45 | Home without its voice | The space mourns |
| SM-100 | 19 | Nocturne (Fragile) | D | 85:00 | 88:00 | 3:00 | Slower, wrong notes, honest | Imperfection as truth |
| SM-101 | 19 | Omar's Hands | D/F | 87:00 | 88:00 | 1:00 | Unsounded keys — presence without voice | Intimacy without sound |
| SM-102 | 19 | Saba + Nahawand | ND | 85:30 | 88:00 | 2:30 | Sorrow and acceptance | The two modes of grief |
| SM-103 | 19 | Yasmin Cell (Asc.) | ND | 86:30 | 87:30 | 1:00 | A–B–C–D–E — becoming new | The inversion of self |
| SM-104 | 19 | Stable Omar Pedal | ND | 87:00 | 88:00 | 1:00 | One person, finally — too late | Unity achieved — at the end |
| SM-105 | 19 | Four Versions of D | ND/D | 88:00 | 88:10 | 0:10 | The marriage chord — incompatible truths | Four Ds — the unresolvable |
| SM-106 | 19 | 15-Second Silence | DS | 88:10 | 88:25 | 0:15 | The longest silence — a gift | The end of the marriage — in silence |
| SM-107 | 19 | Post-Silence World | A | 88:25 | 95:00 | 6:35 | Breathing, city, return | Changed — everything changed |
| SM-120 | 26 | Call to Prayer | D/A | 100:00 | 101:30 | 1:30 | Multiple minarets — enveloping | Faith, continuity, peace |
| SM-121 | 26 | Unmeasured Breathing | D | 101:00 | 101:30 | 0:30 | Natural, no longer performing | The first unmeasured breath |
| SM-122 | 26 | Piano D4 | D | 101:30 | 102:00 | 0:30 | Yamaha U1 — held, decaying | One note, infinite resonance |
| SM-123 | 26 | Saba Ney (Final) | ND | 101:45 | 102:15 | 0:30 | Yasmin cell as sustained question | The question that needs no answer |
| SM-124 | 26 | Piano Overtones | D/DS | 101:45 | 102:15 | 0:30 | 5th, octave, 12th — the harmonics | One life, infinite resonance |
| SM-125 | 26 | Cello Microtone | ND | 102:14 | 102:15 | 0:01 | 7 cents flat — the unresolved | Omar, still present |
| SM-126 | 26 | 7 Hz Beating | DS | 102:14 | 102:15 | 0:01 | Felt, not heard | The heartbeat of the unresolved |
| SM-127 | 26 | Sound-in-Darkness | DS | 102:10 | 102:15 | 0:05 | Image fades, sound holds | The note outlives the image |
| SM-128 | 26 | Final Silence | DS | 102:15 | 105:00 | 2:45 | The note heard in its absence | Memory of sound — possibility |

---

# 10. REFERENCE SCORES & COMPOSERS

## 10.1 Primary References

### Gabriel Yared — *The English Patient* (1996), *A Separation* (2011)
- **What to learn:** Emotional precision without sentimentality. The ability to be devastating with minimal notes. Arabic modal sensitivity.
- **Application:** The Bayati and Nahawand cues should study Yared's string writing — warm but never cloying.

### Ryuichi Sakamoto — *Merry Christmas Mr. Lawrence* (1983), *The Revenant* (2015)
- **What to learn:** The power of spareness. A single note, held, can be more devastating than an orchestra.
- **Application:** The unresolved final note is Sakamoto's territory. Study his use of decay and silence.

### Jóhann Jóhannsson — *Arrival* (2016), *Theory of Everything* (2014)
- **What to learn:** Mathematical beauty. The score as architecture, not decoration.
- **Application:** The operational pulses, the surveillance sounds, the structural integration of music and sound design.

### Thomas Newman — *American Beauty* (1999), *Shawshank Redemption* (1994)
- **What to learn:** The piano as emotional voice. Newman's piano writing is never "movie music" — it is character.
- **Application:** Yasmin's piano motifs should aspire to Newman's level of pianistic authenticity.

### Hans Zimmer — *Inception* (2010), *Interstellar* (2014)
- **What to learn:** The sub-bass as emotional impact. The use of low frequencies to create physical sensation.
- **Application:** The 7 Hz beating, the Omar cello C2, the operational hum — Zimmer's sub-bass philosophy applied to intimate drama.

## 10.2 Arabic Musical References

### Marcel Khalife — *Oud Compositions*
- **What to learn:** The oud as a modern instrument, not a museum piece. Khalife's oud speaks contemporary emotional language.
- **Application:** The oud in the Bayati and Rast cues should aspire to Khalife's expressive freedom.

### Fairouz — *Classical Arabic Song*
- **What to learn:** The tarab tradition — musical ecstasy, emotional surrender, the voice as instrument.
- **Application:** The ney playing in Saba should evoke Fairouz's emotional directness — even without words.

### Abdel Wahab / Um Kulthum — *Arabic Classical*
- **What to learn:** The maqam as emotional architecture. The quarter-tone as expressive possibility.
- **Application:** All maqam-based cues must be performed by musicians who understand this tradition from the inside.

### Tamer Abu Ghazaleh — *Contemporary Arabic Indie*
- **What to learn:** The fusion of maqam and modern sensibility. Arabic tradition without nostalgia.
- **Application:** The score's most innovative moments — the merging of Chopin and maqam, the operational pulses — should reference Abu Ghazaleh's fearless hybridity.

## 10.3 Sound Design References

### *Tinker Tailor Soldier Spy* (2011) — Alberto Iglesias, sound design by Glenn Freemantle
- **What to learn:** Paranoia as sonic density. The operational world has a sound.
- **Application:** The surveillance hum, the operational pulses, the safe house void.

### *The Lives of Others* (2006) — Gabriel Yared, sound design
- **What to learn:** Surveillance and intimacy's collision. The sound of being listened to.
- **Application:** Yasmin's apartment in Act II — the feeling that every sound is being recorded.

### *In the Mood for Love* (2000) — Michael Galasso, sound design
- **What to learn:** Music as memory. The blurred boundary between diegetic and non-diegetic.
- **Application:** The recurring Nocturne, the transformation of diegetic to non-diegetic.

---

# APPENDIX: PRODUCTION NOTES

## A. Recording Priorities
1. **Chopin recordings:** Must be completed before principal photography (for playback on set during performance scenes).
2. **Cairo field recordings:** Should be completed during location scouting — capture the specific ambience of each location.
3. **Piano destruction:** Must be recorded with a real piano. No Foley, no library effects. Budget for a used upright piano ($2,000–5,000) to be destroyed.
4. **Arabic soloist sessions:** Should be recorded in Cairo with master players. Budget 3–4 days.
5. **Orchestral sessions:** Can be recorded in Eastern Europe (cost-effective) or Western Europe (prestige). Arabic soloists can be overdubbed.

## B. Technical Specifications
- **Sample rate:** 48 kHz / 24-bit minimum (96 kHz / 24-bit for archival).
- **Delivery format:** 5.1 WAV stems + stereo WAV mix + Dolby Atmos (future-proofing).
- **Dialogue language:** Arabic (Egyptian dialect). Subtitle languages: English (primary), French, Arabic standard (for non-Egyptian markets).
- **Music notation:** All original score must be notated in both Western staff notation and Arabic maqam analysis (for session musicians).

## C. Quality Control Checklist
- [ ] Every maqam cue has been checked by a qualified Arabic musicologist for authenticity.
- [ ] All quarter-tone inflections survive the mix (no Western temperament "correction").
- [ ] All silent moments have been checked on multiple playback systems for true silence.
- [ ] The 7 Hz beating in the final scene has been calibrated on cinema LFE systems.
- [ ] The A-flat pulse in the Raindrop scene has been tested for imperceptible merging of layers.
- [ ] All Foley footsteps (Omar's two modes) have been checked for consistency.
- [ ] The wedding ring tick has been placed consistently across all relevant scenes.
- [ ] The clock tick has been checked for stopping in Act II.
- [ ] The refrigerator hum has been checked for EQ shift between Acts I and II.
- [ ] The call to prayer has been checked for accurate timing and multiple-minaret polyphony.

---

**Document prepared by:** Sound & Music Agent
**Date:** 2026-05-25
**Status:** Design Complete — Ready for Production
**Next stage:** Cinematic Director (shot list and camera directions)

---

> *"I used to think music was the truest thing I knew. Now I know truth is just the lie that hasn't been exposed yet."*
> — Yasmin, Scene 19

> *"Silence. I've been silent so long I don't have a melody anymore."*
> — Omar, Scene 6

> *The final note does not resolve. It decays. It is felt in the body. It continues in memory. That is the sound of حب وخيانة.*
> — Sound & Music Design Philosophy
