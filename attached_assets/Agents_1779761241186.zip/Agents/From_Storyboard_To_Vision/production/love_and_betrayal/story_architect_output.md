# حب وخيانة — Love and Betrayal
## Story Architect Document
### Cinematic Production Pipeline: "From Storyboard To Vision"
### Agent: Story Architect
**Date:** 2026-05-25

---

# SECTION I: CONCEPT ANALYSIS

## Title
**Arabic:** حب وخيانة (Hub wa Khiyanah)
**English:** *Love and Betrayal*
**Working Title:** *The Garden of Broken Mirrors*

## Logline
A celebrated Cairo concert pianist discovers her husband of seven years is leading a double life as a covert operative — and when she is unwittingly drawn into his final mission, she must choose between the love she believed in and the truth that will destroy them both.

## Genre & Sub-Genre Classification
| Layer | Classification |
|-------|---------------|
| Primary | Romantic Psychological Drama |
| Secondary | Neo-Noir Romance |
| Tertiary | Espionage Thriller (domestic/personal scale) |
| Structural Model | Three-Act with Hero's Journey inflection (Inverted — descent rather than ascent) |

## Thematic Core

### Primary Theme: **The Architecture of Deception**
*Statement:* Intimacy cannot survive the absence of truth, yet truth often cannot survive the full light of intimacy. Every relationship is built on selective revelation — the question is who chooses what remains hidden, and at what cost.

### Secondary Theme: **Identity as Performance**
*Statement:* We are all actors in the lives of others, curating which selves we reveal. When the performance becomes indistinguishable from the self, authenticity collapses — leaving the performer uncertain whether they have deceived their audience or themselves.

### Tertiary Theme: **The Geometry of Betrayal and Self-Betrayal**
*Statement:* Betrayal is rarely a single act; it is a thousand small omissions, a architecture of silence. The deepest betrayal is often not against another — it is the self's surrender to the lie it tells itself to remain in love.

## Tone & Mood Profile

| Element | Descriptor |
|---------|-----------|
| Overall Tone | Intimate, claustrophobic, devastating |
| Visual Temperature | Warm amber interiors / Cold blue exterior nights |
| Emotional Register | Heartbreak → Suspicion → Terror → Devastation → Ambiguous Redemption |
| Sound Design Direction | Minimal dialogue in key scenes; piano as emotional voice; city ambient as suffocating presence |
| Pacing | Slow burn (Act I) → Accelerating tension (Act II-A) → Frantic compression (Act II-B) → Stillness (Act III) |
| Comparative Energy | *In the Mood for Love* (visual intimacy) + *Tinker Tailor Soldier Spy* (paranoia density) + *Atonement* (tragic consequence) |

## Target Audience
- **Primary:** Adults 25-55, emotionally mature viewers seeking cathartic drama
- **Secondary:** International arthouse audiences, festival circuits
- **Tertiary:** Arabic-speaking diaspora seeking culturally grounded prestige cinema

## Comparable Films (Comps)
1. *In the Mood for Love* (Wong Kar-wai, 2000) — Visual intimacy, unspoken longing, color-as-emotion
2. *Atonement* (Joe Wright, 2007) — Betrayal's irreversible consequences, period lushness translated to contemporary
3. *Tinker Tailor Soldier Spy* (Tomas Alfredson, 2011) — Paranoia in domestic spaces, information as weapon
4. *The Lives of Others* (Florian Henckel von Donnersmarck, 2006) — Surveillance and intimacy's collision
5. *Eternal Sunshine of the Spotless Mind* (Michel Gondry, 2004) — Memory, love, and the price of truth
6. *Cairo Time* (Ruba Nadda, 2009) — Cairo as romantic/liminal space

---

# SECTION II: DRAMATIC STRUCTURE

## Running Time Target: **105 minutes**
## Structure: Three-Act with Dual Timeline (Present Investigation / Past Revelation)

### ACT I: THE SURFACE — SETUP (0%–25% / 0:00–26:00)
> *"Every happy marriage is built on a secret someone is keeping."*

#### Beat 1: Opening Image (0:00–3:00)
- **Visual:** A woman's hands on piano keys. Extreme close-up. We see the hands, the sheet music, the wedding ring catching stage light.
- **Audio:** Chopin Nocturne in C-sharp minor. Flawless, controlled, emotionally restrained.
- **Cut to:** Empty apartment at 2:00 AM. The same hands make tea. The same wedding ring glints in refrigerator light.
- **Dramatic Function:** Establish duality — public perfection vs. private emptiness. Introduce YASMIN's emotional architecture.

#### Beat 2: The Ordinary World (3:00–8:00)
- **Sequence:** Yasmin's daily routine — Conservatory teaching, lunch with mother, evening practice, waiting for Omar's call.
- **Omar introduced:** Via phone call. He's "in Alexandria on business." The call is warm, routine, slightly rushed.
- **Visual Motif:** Mirrors — Yasmin sees herself reflected in windows, glasses, piano lid. Always alone in the reflection.
- **Dramatic Function:** Establish the pattern of absence that has become normalized. Make the audience complicit in accepting the lie.

#### Beat 3: The Inciting Incident (8:00–12:00)
- **Event:** Yasmin finds a second phone in Omar's nightstand drawer. It vibrates with a message: "Package ready. Garden entrance. Midnight."
- **Her reaction:** Not confrontation — confusion, then self-doubt. She puts it back. She practices piano for three hours without stopping.
- **Visual:** The music becomes increasingly frantic. Hands shaking.
- **Dramatic Question:** What will she do with this information?

#### Beat 4: The Debate / Refusal (12:00–18:00)
- **Yasmin investigates subtly:** Checks Omar's calendar. Cross-references "business trips" with publicly known events. They don't align.
- **She confides in LAYLA** (her younger sister, a journalist): "Do you think you can know someone completely?"
- **Layla's response:** "Nobody's completable, Yasso. That's the horror and the mercy."
- **Dramatic Function:** Yasmin's choice to investigate vs. choice to remain blind. The audience feels the weight of each path.

#### Beat 5: Crossing the First Threshold (18:00–26:00)
- **Event:** Yasmin follows Omar to a café in Zamalek. She watches him meet a woman — NOUR — who hands him an envelope. Their body language is not romantic. It is operational. Cold. Efficient.
- **The Break:** Yasmin returns home. When Omar arrives, she plays the recording she made of the café conversation. His face changes. The mask drops.
- **OMAR:** "You were never supposed to see this."
- **YASMIN:** "See what? That you're someone else? Or that I'm someone who doesn't know her own husband?"
- **Act I Climax:** Omar confesses: he works for an intelligence division so classified even his colleagues don't know its real purpose. Seven years of marriage — partially constructed, partially true. He doesn't know where the lie ends anymore.
- **Visual:** The camera circles them in their living room. The room becomes a stage set. The apartment they built together dissolves into a constructed fiction.

---

### ACT II-A: THE CRACK — CONFRONTATION RISING (25%–50% / 26:00–52:00)
> *"The truth doesn't set you free. It puts you in a room with the person you married and the stranger they are, and locks the door."*

#### Beat 6: Entering the Special World (26:00–32:00)
- **New Reality:** Omar brings Yasmin into limited awareness. He needs her to understand enough to stay safe, but not enough to be compromised.
- **The Rules:** No calls to his work number. No questions about "meetings." If anyone asks, she knows nothing — which, he notes with a bitter smile, is almost true.
- **Visual Shift:** Their apartment is now a potential surveillance zone. Yasmin begins seeing threats everywhere — the man reading a newspaper outside, the taxi that passes three times, the new neighbor.

#### Beat 7: Tests, Allies, Enemies (32:00–40:00)
- **Yasmin meets Nour:** Under the guise of a chance encounter. Nour is brilliant, brittle, professionally charming — and evaluating Yasmin in real-time.
- **NOUR:** "He told me you were beautiful. He didn't tell me you were perceptive. Those two qualities rarely coexist in our line of work."
- **Yasmin's test:** Can she play the role of unknowing wife in public while privately investigating her husband?
- **She discovers:** Omar has a second apartment. A safe house. She finds it by following the GPS history on the "secret phone" she photographed.

#### Beat 8: The Midpoint — False Victory / False Defeat (40:00–48:00)
- **The Safe House:** Yasmin enters. It is spare, anonymous — except for one wall. Hundreds of photographs. Her photographs. Concert programs. Restaurant receipts. Medical records. Her entire life, catalogued with operational precision.
- **The Twist:** Mixed with her surveillance file are photographs of another woman. Younger. Different city. Same time period. Same wedding ring on Omar's hand in the background.
- **Revelation:** Omar is not just an intelligence operative using his marriage as cover. He has another life. Another wife. Or — the photographs may be operational. The ambiguity is the weapon.
- **Yasmin's choice:** She doesn't confront him. She replaces the files exactly as found. She becomes the operative now. The surveilled becomes the surveillant.
- **Visual:** Yasmin's face in the safe house mirror. She doesn't recognize herself. Or she recognizes someone she never wanted to be.

#### Beat 9: Complications & Higher Stakes (48:00–52:00)
- **The Mission Intrudes:** Omar comes home shaken. His operation has been compromised. Someone inside his division is a leak. He needs to use their apartment for a meeting — "just once, and you'll be safe, you'll be protected, I promise."
- **Yasmin realizes:** She is now operational infrastructure. Her home. Her life. Her identity — all repurposed without consent.
- **She agrees** — but not for the reasons he thinks.

---

### ACT II-B: THE ABYSS — CONFRONTATION DESCENDING (50%–75% / 52:00–78:00)
> *"Love is the lie we tell ourselves so we can keep living with the truth."*

#### Beat 10: The Plan & The Descent (52:00–60:00)
- **The Meeting:** A foreign diplomat arrives at their apartment. Yasmin serves coffee. She plays piano while they talk in Arabic, English, French — languages she understands.
- **What she hears:** Omar is not national intelligence. He is selling information. Or he is entraping a seller. The ambiguity is structural — the scene is written so both interpretations are valid based on framing.
- **The piano:** Yasmin plays Chopin's "Raindrop Prelude." The repeated A-flat (representing the persistent rain/doom) underscores the conversation. She modulates into minor key when she hears a name she recognizes — her father's name, a former military officer who died under circumstances she never fully understood.

#### Beat 11: The Dark Night of the Soul (60:00–68:00)
- **Aftermath:** Yasmin confronts Omar not with anger — with cold operational precision. She has notes. Timelines. Evidence. She has become better at his work than he is.
- **YASMIN:** "You taught me without teaching me. Seven years of watching you disappear and return. Seven years of learning to read what isn't said. I didn't know I was studying for an exam."
- **OMAR:** "The exam was supposed to be me keeping you outside of it."
- **The Father Revelation:** Omar reveals — or claims — that her father's death was not an accident. That he was investigating the same network Omar has infiltrated. That their marriage may have been initiated as operational access, but —
- **YASMIN:** "But what? You fell in love with the daughter of the man you let die?"
- **Visual:** Yasmin destroys the piano — the instrument that has been her voice, her sanity, her identity. She smashes the lid. The strings scream.

#### Beat 12: The Lowest Point — Rock Bottom (68:00–75:00)
- **Separation:** Yasmin moves to Layla's apartment. She doesn't leave her sister's side for days. She doesn't speak. She doesn't play.
- **The Threat Escalates:** Yasmin receives a package — photographs of her and Omar from the early days of their marriage. Stamped with the same operational coding she saw in the safe house. A note: *"He was reporting on you before he loved you. The question is whether he ever stopped reporting."*
- **The Sender:** Unknown. The division investigating Omar? A rival network? Omar himself, testing her?
- **Yasmin's decision:** She will find the truth herself. Not as a wife. Not as a victim. As an architect of her own investigation.

#### Beat 13: The Resurrection of Agency (75:00–78:00)
- **Yasmin approaches Nour:** Not as a jealous wife. As a professional seeking professional assistance.
- **YASMIN:** "You said I was perceptive. Perception is only useful if it leads to action. I need to know who my husband is. Not who he was to me. Who he is to the world that made him."
- **Nour's response:** Respect. A grudging alliance. She provides access to a name: KHALIL, a retired handler who knows the architecture of Omar's division.
- **Act II-B Climax:** Yasmin is no longer the woman in the opening image. She has crossed into the world of operational ambiguity. The morality she believed in — honesty, transparency, loyalty — has been revealed as a luxury of the protected.

---

### ACT III: THE RECKONING — RESOLUTION (75%–100% / 78:00–105:00)
> *"There is no redemption without first accepting that some things cannot be redeemed."*

#### Beat 14: The Climax Setup (78:00–85:00)
- **Khalil:** An old man in a garden café in Maadi. He knew Yasmin's father. He confirms — Omar's story about her father is partially true. But Omar's version is the operational version. The truth is messier.
- **KHALIL:** "Your father wasn't investigating them. He was one of them. He tried to get out. They don't let you out. Omar was assigned to watch him. Instead, he tried to save him. Failed. Married you — some say as penance, some say because he genuinely —"
- **YASMIN:** "Genuinely what?"
- **KHALIL:** "That word doesn't survive in our vocabulary. We say 'operationally useful' or we say nothing."
- **The Choice:** Khalil offers her a file — the complete record of her relationship from Omar's operational perspective. Every report. Every assessment. Every note of doubt or affection, coded in operational language.
- **Yasmin takes it.**

#### Beat 15: The Final Confrontation — Climax (85:00–95:00)
- **Location:** The conservatory where Yasmin teaches. Empty at night. She has summoned Omar.
- **She reads from the file:** His initial assessment of her — "Subject is emotionally accessible, professionally isolated, family connection provides operational value. Recommend extended engagement."
- **She reads his later notes:** "Subject's musical intelligence translates to situational awareness. Unusually difficult to deceive. Risk: Subject may develop independent analytical capacity."
- **She reads the most recent:** "Subject has transitioned from operational context to liability. Recommend —" The recommendation is torn out.
- **OMAR:** "I tore that page out. The recommendation was extraction. From the operation. From me. I couldn't —"
- **YASMIN:** "Couldn't what? Continue lying, or couldn't bear to lose your asset?"
- **The Physical Climax:** Not violence — a duet. Yasmin sits at the piano. She plays the Chopin Nocturne from the opening. Omar stands behind her. He places his hands on the keys above hers — he doesn't play, just rests his fingers, a gesture from early in their courtship.
- **She stops playing.** The silence is devastating.
- **YASMIN:** "I used to think music was the truest thing I knew. Now I know truth is just the lie that hasn't been exposed yet."

#### Beat 16: The Choice (95:00–100:00)
- **The Operation Collapses:** News breaks — the network Omar infiltrated has been exposed. Arrests are made. Omar's role will be revealed, or buried, depending on which faction wins the internal power struggle.
- **Omar's offer:** "I can disappear. New identity. New country. You could come. We could try — not to fix it. Just to continue. Some people live entire lives in the middle of things, never at the beginning or end."
- **Yasmin's counter-offer:** "Or you could testify. Publicly. About everything. My father. The division. The other lives. The ones you built and the ones you destroyed. You could become visible."
- **OMAR:** "I would be dead in a month."
- **YASMIN:** "Yes. But you would be real for the first time."

#### Beat 17: The Resolution — Denouement (100:00–105:00)
- **Three months later.**
- **Visual:** A new apartment. Different neighborhood. Yasmin plays piano — not Chopin, but improvisation. Raw, unstructured, honest.
- **She receives a letter:** No return address. Inside, a single photograph — Omar, in a country she doesn't recognize, standing in a market. He looks older. He looks visible. He looks at the camera directly.
- **On the back:** *"I chose real. It doesn't forgive anything. But it's the only room I've ever lived in that doesn't have mirrors on every wall. Thank you for the architecture. — O."*
- **Final shot:** Yasmin at the window. Cairo at dusk. The call to prayer begins. She doesn't cry. She doesn't smile. She breathes — the first unmeasured breath of the film.
- **The piano:** One final note, unresolved. The film ends on harmonic tension. No resolution. Just the possibility of what comes after the story ends.

---

# SECTION III: CHARACTER BIBLE

## PROTAGONIST: YASMIN EL-SAYED

### Demographics
- **Age:** 34
- **Profession:** Concert pianist / Conservatory professor
- **Heritage:** Upper-middle-class Cairo family; father deceased (former military/intelligence), mother living, one younger sister
- **Economic status:** Comfortable but not wealthy; artistic rather than commercial
- **Religious/cultural identity:** Culturally Muslim, not practicing; values tradition as aesthetic rather than dogma

### External Arc
| Stage | State |
|-------|-------|
| Opening | Controlled, disciplined, emotionally contained — the perfect performer |
| Inciting Incident | Doubt enters through the second phone — first crack in the performance |
| Investigation | Transitions from passive victim to active investigator — developing operational instincts she didn't know she had |
| Revelation | Destroys piano (her identity vessel) — must rebuild self without her primary tool |
| Resolution | Improvises rather than performs — creates rather than interprets |

### Internal Arc: The Five Stages of Discovery
1. **Denial (Act I):** The second phone is a mistake. A misunderstanding. A work thing she doesn't need to understand.
2. **Investigation (Act II-A):** If she learns enough, she can control the narrative. Knowledge as power.
3. **Rage (Act II-B):** The piano destruction — her entire constructed identity shatters with the revelation about her father.
4. **Grief (Late Act II-B):** Silent days at Layla's. The non-playing. The non-being.
5. **Reconstruction (Act III):** Not forgiveness. Not resolution. Just forward motion without certainty.

### Core Flaw
**Emotional exceptionalism:** Yasmin believes that her capacity for feeling — her artistic sensitivity — makes her immune to the ordinary deceptions that trap others. She believes she "feels" Omar's truth, therefore it must be true. The film systematically destroys this belief, not to punish her sensitivity, but to prove that feeling and knowing are separate, overlapping but non-identical systems.

### Transformation
From performer (interpreter of others' compositions) to composer (creator of her own form). From believing in the transparency of love to accepting the opacity of all human connection — and choosing connection anyway, but on revised terms.

### Visual Design
- **Act I:** Tailored, neutral colors, structured silhouettes — clothing as armor for public performance
- **Act II:** Increasingly disheveled, colors darken, she stops wearing the wedding ring
- **Act III:** Simple, unstructured, individual — she wears Layla's borrowed clothes before finding her own new style
- **Symbolic color progression:** Ivory/black (piano keys) → Deep red (blood, rage, the destroyed piano) → Undefined warm tones (earth, possibility, ground)

### Piano as Character Extension
The piano is not a prop. It is a character relationship:
- **Act I:** Piano as faithful companion, voice, sanity
- **Act II-A:** Piano as possible surveillance device (is it bugged?), as performance that masks truth
- **Act II-B:** Piano as false god — destroyed when she realizes her artistic truth-seeking didn't protect her from emotional blindness
- **Act III:** Piano as reclaimed but revised instrument — she plays differently, she composes, she makes mistakes and keeps going

---

## ANTAGONIST / CO-PROTAGONIST: OMAR HASSAN

### Demographics
- **Age:** 38
- **Profession:** Covert intelligence operative (claims to be management consultant)
- **Heritage:** Lower-middle-class Alexandria; self-made, recruited young, no family contact
- **Economic status:** Appears comfortable; actual finances opaque
- **Religious/cultural identity:** Non-practicing; uses cultural knowledge as operational tool

### The Antagonist Function
Omar is not a villain. He is the structural antagonist — the force that prevents Yasmin from maintaining her comfortable illusion. But he is also a protagonist in his own tragedy. The film's moral architecture requires the audience to shift their allegiance multiple times:
- **First:** Omar is the lying husband — conventional villain
- **Then:** Omar is a professional forced into impossible choices — sympathetic prisoner of the system
- **Then:** Omar may have initiated the marriage as operational strategy — villainy restored
- **Then:** Omar may have genuinely loved her within the operational frame — tragedy, not villainy
- **Finally:** Omar is simply a man who chose opacity as survival strategy and lost the capacity to distinguish performance from self

### Omar's Philosophy
"Every relationship is operational. Parents operate on children. Lovers operate on each other. Nations operate on citizens. The only question is whether you're conscious of your operations. I was conscious. That doesn't make me better. It makes me more alone."

### Core Wound
Orphaned by choice — he severed his original identity so completely that he has no "true self" to return to. Yasmin's discovery threatens not just his operation but the only identity he has managed to construct and sustain: the man who loves her. Even if that love began as operational, its duration and depth may have made it real — but he has no language for that transition, no permission to claim it.

### The Ambiguity Engine
Omar is written so that multiple interpretations remain valid until the final scene:
- Did he marry Yasmin for access to her father? (Khalil suggests yes)
- Did he try to save her father? (Omar claims yes)
- Does the missing page of the file recommend extraction or elimination? (We never know for certain)
- Is the final photograph really Omar, or another operative continuing a deception? (Designed to remain uncertain)

This ambiguity is not narrative cowardice. It is thematic necessity: the film argues that in relationships built on fundamental information asymmetry, certainty is impossible. We choose our interpretations, and our choices reveal us.

---

## SUPPORTING CHARACTER: LAYLA EL-SAYED

### Demographics
- **Age:** 29
- **Profession:** Investigative journalist (freelance, struggling)
- **Function in story:** Yasmin's mirror — the sister who chose transparency and pays for it with professional marginalization; the one who asks questions for a living, contrasted with Yasmin who performs answers

### Arc
- **Opening:** Frustrated by her own inability to break big stories; slightly envious of Yasmin's "perfect" marriage
- **Middle:** Becomes Yasmin's operational ally without knowing the full scope; provides journalist skills (research, surveillance techniques, contact networks)
- **Crisis:** Discovers that Yasmin's father was involved in intelligence work — forces her to confront that her own investigative certainty was built on family secrets she never questioned
- **Resolution:** Begins investigating her father's death story in parallel; the film implies but doesn't show her future trajectory

### Key Dialogue
"I spent my career exposing other people's lies. I never thought to check if my own family was the first draft."

---

## SUPPORTING CHARACTER: NOUR AMIR

### Demographics
- **Age:** 42
- **Profession:** Senior intelligence operative; Omar's handler or colleague (ambiguous)
- **Function:** The professional woman who has fully integrated operational identity; she represents the road not taken — or the road Yasmin might travel

### Character Design
Nour is warm, witty, terrifyingly competent. She likes Yasmin. She would kill Yasmin without hesitation if operational necessity required it. She doesn't see these as contradictory. She has solved the problem of moral compartmentalization that Omar still struggles with.

### Key Scene
When Yasmin asks if Nour has ever loved anyone operationally:
"Three times. The first, I told him everything. He died. The second, I told him nothing. He lived, but the marriage was a fiction that happened to share a bed. The third — I don't know what I told him. I've forgotten which parts were cover story and which were me. That's the most honest relationship I've ever had. The one where even I don't know the truth."

---

## SUPPORTING CHARACTER: KHALID RASHID

### Demographics
- **Age:** 71
- **Profession:** Retired intelligence handler; garden enthusiast
- **Function:** The truth-teller who is himself unreliable; he knows too much to be fully believed, too little to be dismissed

### Character Design
Khalid represents the cost of long-term operational life: he is gentle, observant, resigned. He grows roses because "roses don't require cover stories." He provides information but never resolution. His final gift to Yasmin — the complete file — is also his final cruelty, because complete information does not provide peace.

### Key Dialogue
"Your generation thinks truth is a destination. We knew it was just a direction. You walk toward it, but you never arrive. If you did, you'd have nothing left to walk for."

---

# SECTION IV: SCENE BREAKDOWN (26 Scenes)

| # | Title | Location | Time | Duration | Purpose | Characters | Emotional Beat | Dramatic Question |
|---|-------|----------|------|----------|---------|------------|----------------|-----------------|
| 1 | The Nocturne | Concert hall / Home | Night | 3:00 | Establish duality; introduce Yasmin | Yasmin | Controlled loneliness | Who is this woman when no one watches? |
| 2 | The Routine | Conservatory / Café / Home | Day | 5:00 | Establish patterns of absence | Yasmin, Omar (voice) | Habit as comfort | How long has this absence been normalized? |
| 3 | The Drawer | Bedroom | Night | 4:00 | Inciting incident | Yasmin | Suspicion → self-doubt | Will she investigate or suppress? |
| 4 | The Sister | Layla's apartment | Day | 6:00 | Debate; ally introduced | Yasmin, Layla | Uncertainty seeking anchor | Is it better to know or to believe? |
| 5 | The Follow | Zamalek café | Day | 8:00 | First threshold; Omar revealed | Yasmin, Omar, Nour | Betrayal's first shape | What has she actually seen? |
| 6 | The Confession | Living room | Night | 8:00 | Act I climax; new rules | Yasmin, Omar | Devastation → numbness | Can this marriage survive knowing? |
| 7 | The New Rules | Home / City | Day | 6:00 | Enter special world; paranoia | Yasmin, Omar | Anxiety → hypervigilance | What does "safe" mean now? |
| 8 | The Journalist | Newspaper office | Day | 8:00 | Tests; skills development | Yasmin, Layla | Determination | Can she learn what she needs? |
| 9 | The Handler | Restaurant | Night | 8:00 | Nour as mirror; warning | Yasmin, Nour | Professional respect; personal fear | Is Nour friend, enemy, or neither? |
| 10 | The Safe House | Anonymous apartment | Night | 8:00 | Midpoint; the double life | Yasmin | Horror → cold resolve | Who is the other woman? Who is Yasmin becoming? |
| 11 | The Meeting | Home | Night | 8:00 | Operation invades domestic space | Yasmin, Omar, Diplomat | Performance under duress | What is Omar really doing? |
| 12 | The Raindrop | Home | Night | 8:00 | Information acquisition; father's name | Yasmin, Omar | Terror → rage | What did her father have to do with this? |
| 13 | The Destruction | Living room | Night | 8:00 | Dark night; identity shatter | Yasmin, Omar | Rage → emptiness | Who is she without the piano? Without the marriage? |
| 14 | The Silence | Layla's apartment | Day | 7:00 | Grief; non-being | Yasmin, Layla | Numbness → slow awakening | Will she survive this? |
| 15 | The Package | Layla's apartment | Day | 5:00 | Threat escalation; new mystery | Yasmin | Paranoia → determination | Who is manipulating her now? |
| 16 | The Alliance | Nour's office | Day | 6:00 | New alliance; professional Yasmin | Yasmin, Nour | Grudging respect | Can she trust anyone? |
| 17 | The Garden | Maadi café | Day | 7:00 | Truth-seeking; father's story | Yasmin, Khalid | Grief → confrontation with history | Is Khalid telling the truth? Any truth? |
| 18 | The File | Khalid's garden | Day | 5:00 | The choice to know everything | Yasmin, Khalid | Fear → resolve | Will complete knowledge destroy her? |
| 19 | The Duology | Conservatory | Night | 10:00 | Climax confrontation; piano as battlefield | Yasmin, Omar | Grief → power | Can she control the ending? |
| 20 | The Silence After | Conservatory | Night | 5:00 | Post-climax; choice presented | Yasmin, Omar | Exhaustion → clarity | What does she actually want? |
| 21 | The News | Layla's apartment | Day | 5:00 | External world intrudes; stakes peak | Yasmin, Layla | Urgency | What will happen to Omar? |
| 22 | The Offer | Rooftop | Night | 5:00 | Omar's proposal: disappear | Yasmin, Omar | Longing → rejection | Can she choose the past? |
| 23 | The Counter | Rooftop | Night | 5:00 | Yasmin's proposal: testify | Yasmin, Omar | Fear → courage | Can she choose the truth? |
| 24 | Three Months | New apartment | Day | 3:00 | Time passage; new life | Yasmin | Uncertain peace | Has she healed? |
| 25 | The Letter | New apartment | Day | 2:00 | Omar's choice revealed | Yasmin | Complex grief | Is the letter real? Does it matter? |
| 26 | The Unresolved Note | Window | Dusk | 3:00 | Final image; thematic resolution | Yasmin | Acceptance without closure | What comes after the story ends? |

---

# SECTION V: FULL SCREENPLAY TREATMENT

## TREATMENT: SCENE-BY-SCENE PROSE

### PROLOGUE: THE PERFORMANCE (Minutes 0:00–3:00)

FADE IN:

EXTREME CLOSE-UP — HANDS on piano keys. The hands are elegant, controlled. A wedding ring catches the amber stage light. We hear CHOPIN: Nocturne in C-sharp minor, Op. Posth.

The camera pulls back slowly. We see YASMIN EL-SAYED (34) at a Steinway grand. The concert hall is full. She doesn't look at the audience. She looks at the keys, the sheet music, somewhere internal.

The music is technically perfect. Emotionally, something is held back. We feel it before we understand it.

CUT TO:

INT. YASMIN AND OMAR'S APARTMENT — KITCHEN — 2:17 AM

The same hands. The same wedding ring. Now making tea in a dark kitchen, illuminated only by refrigerator light.

Yasmin stands at the window. Cairo sprawls below, awake, indifferent. She drinks her tea. She waits.

The clock ticks to 3:00 AM.

She goes to bed alone.

TITLE CARD: *"Every happy marriage is built on a secret someone is keeping."*

---

### ACT I: THE SURFACE

#### SCENE 1: THE NOCTURNE (0:00–3:00)
*[See Prologue above]*

**Visual Direction:** The film's color palette is established — warm golds and ambers in performance spaces, cold blues and grays in domestic spaces. The wedding ring is the visual anchor, appearing in nearly every scene until it is removed in Act II-B.

**Emotional Beat:** Controlled loneliness. The performance is flawless because it is a performance. The apartment is empty because that is the truth.

---

#### SCENE 2: THE ROUTINE (3:00–8:00)

MONTAGE — YASMIN'S DAY

- 7:00 AM: Alarm. She doesn't hit snooze. Discipline.
- 8:30 AM: Conservatory. Teaching advanced students. Patient, precise, slightly distant.
- 1:00 PM: Lunch with her mother, SAMIRA (60s), at a hotel café.
  - SAMIRA: "Omar is still in Alexandria?"
  - YASMIN: "Business."
  - SAMIRA: "He has a lot of business."
  - Yasmin doesn't respond. The silence is practiced.
- 3:00 PM: Practice. Three hours. She doesn't stop for water.
- 7:00 PM: Home. She calls Omar. The phone rings three times.
  - OMAR (V.O., warm, slightly echoey): "Yasso. I'm just leaving the meeting."
  - YASMIN: "Don't rush. I'll be practicing."
  - OMAR: "Don't wait up."
  - YASMIN: "I wasn't planning to."
  The routine is comforting. The routine is a trap.

**Visual Motif:** MIRRORS. Yasmin's reflection in the piano lid, the café window, her phone screen. She is always looking at herself alone.

**Emotional Beat:** Habit as comfort. The absence has been so normalized that its presence would be disruptive.

---

#### SCENE 3: THE DRAWER (8:00–12:00)

INT. BEDROOM — 11:47 PM

Yasmin can't sleep. She doesn't take pills — another discipline. She reads (Borges — "The Garden of Forking Paths" — foreshadowing the labyrinthine structure of truth).

She reaches for Omar's nightstand drawer looking for a bookmark. Her hand finds something else. A second phone. Older model. Nondescript.

It vibrates. A message glows:

> "Package ready. Garden entrance. Midnight."

Yasmin stares at the phone. Her breathing changes. Not panic — something worse. Recognition.

She puts the phone back. Closes the drawer. Goes to the piano.

She plays the Nocturne again. But now the tempo accelerates. Wrong notes appear. She doesn't stop. She plays through the mistakes, faster, more frantic, until —

She slams her hands down on the keys. The dissonance echoes.

She looks at her hands. They are shaking.

**Emotional Beat:** Suspicion colliding with self-doubt. She has spent her life interpreting complex compositions. Now she must interpret a three-word text message, and her interpretive confidence fails her.

---

#### SCENE 4: THE SISTER (12:00–18:00)

INT. LAYLA'S APARTMENT — DAY

Layla's apartment is cluttered, alive, chaotic — the opposite of Yasmin's curated space. Books everywhere. Coffee cups. A whiteboard with story diagrams.

LAYLA (29) makes terrible coffee with great enthusiasm.

LAYLA: "So what's the crisis? You only visit when you're composing or catastrophe-ing."

YASMIN: "Do you think you can ever completely know someone?"

LAYLA: (freezes) "Oh. This is the marriage one."

YASMIN: "I'm not saying there's —"

LAYLA: "Yasso. I am an investigative journalist. I know what 'do you think you can know someone' means. It means you found something."

Yasmin tells her about the phone. Not the message. Just the existence.

LAYLA: "A work phone. Probably."

YASMIN: "He never mentioned it."

LAYLA: "Men don't mention things. That's not intelligence work, that's just being a man."

YASMIN: "He mentions everything else. His meetings. His flights. His headaches. His favorite new restaurant. He narrates his life to me. Except this."

LAYLA: (quieter) "Then it's not nothing."

YASMIN: "But what if it is? What if I destroy seven years because I'm paranoid?"

LAYLA: "What if you preserve seven years of something that isn't real because you're afraid?"

The sisters look at each other. They are both right. That is the horror.

**Emotional Beat:** Uncertainty seeking anchor. Layla provides intellectual clarity but no emotional comfort, because none exists.

---

#### SCENE 5: THE FOLLOW (18:00–26:00)

INT./EXT. ZAMALEK CAFÉ — DAY

Yasmin has never followed anyone. She is terrible at it. She stands too close. She checks her phone too obviously. A man in a nearby seat watches her with mild curiosity.

Omar arrives. He is different here — not the warm husband, not the tired businessman. He is precise. Controlled. Scanning the room before sitting.

NOUR (42) arrives. She is striking — silver-streaked hair, tailored clothes, the confidence of someone who has never asked permission.

Their conversation is not romantic. It is operational. We don't hear the words. We see the body language — Nour slides an envelope across the table. Omar doesn't open it. He nods. They don't touch. They don't smile.

They stand to leave. Yasmin ducks behind a menu. She is not made for this world.

But she has seen enough.

INT. LIVING ROOM — NIGHT

Yasmin sits in the dark. She has a recording — her phone, voice memo, hidden in her bag. She plays it.

Static. Arabic fragments. A name: "The Lebanese route." A date. "She can't know." A laugh — Omar's laugh, but different. Professional. Empty.

The door opens. Omar enters. He sees her in the dark. He sees the phone. His face — the face she has loved for seven years — undergoes a transformation. The mask doesn't drop. It shifts. Reveals another mask beneath.

OMAR: "You were never supposed to see this."

YASMIN: "See what? That you're someone else? Or that I'm someone who doesn't know her own husband?"

The camera begins its slow circle. The living room becomes a stage. The apartment becomes a set.

OMAR: "I work for a division that doesn't exist in any directory. My colleagues don't know what I actually do. My family — if I had one — wouldn't know. I thought... I thought if I kept you outside, you'd be safe."

YASMIN: "Safe from what?"

OMAR: "From this. From me. From what I have to become to do what I do."

YASMIN: "And what do you become?"

OMAR: (long pause) "I don't know anymore. I used to know where the operation ended and I began. Now I look for the line and I can't find it."

**Emotional Beat:** Devastation that mutates into numbness. She has suspected; now she knows. Knowing is not better.

**Act I Climax:** The marriage enters a new phase — not honest, but differently dishonest. Omar brings her into partial awareness. The question is no longer "what is he hiding?" but "what will she do with partial knowledge?"

---

### ACT II-A: THE CRACK

#### SCENE 6: THE CONFESSION (26:00–32:00)
*[Overlaps with Scene 5 conclusion]*

The conversation continues. Omar explains the rules. The compartmentalization. The necessity of her knowing nothing to everyone they meet.

YASMIN: "So I'm an accessory to your lie."

OMAR: "You're the reason I still need there to be a truth."

This line hangs between them. Is it manipulation? Sincerity? Both?

Yasmin stands. She walks to the piano. She touches the keys. She doesn't play.

YASMIN: "I have spent my life interpreting other people's compositions. Trying to understand what they felt when they wrote these notes. I thought — I believed — that if I could understand the music, I could understand the musician."

She turns to him.

YASMIN: "What is your music, Omar? What would I hear if I could play you?"

OMAR: "Silence. I've been silent so long I don't have a melody anymore."

**Emotional Beat:** The first genuine moment of the film — or the most sophisticated manipulation. The audience cannot know. Yasmin cannot know. That uncertainty is the film's engine.

---

#### SCENE 7: THE NEW RULES (32:00–40:00)

MONTAGE — THE NEW NORMAL

Yasmin sees threats everywhere. The man reading a newspaper outside her building — is he watching? The taxi that passes three times — coincidence? The new neighbor who introduced himself too warmly — operative?

She teaches piano. But now she watches the door. She watches the students' bags. Could they be carrying something? Could they be someone?

Omar comes home. They eat dinner in near-silence. He asks about her day. She gives minimal answers. He looks hurt. Is the hurt real? Is he performing hurt because she expects it?

The apartment that was her sanctuary is now potentially hostile territory. Every object could be a bug. Every affectionate gesture could be operational maintenance.

**Visual Shift:** The warm ambers of Act I are replaced by harsher fluorescents. Shadows are deeper. The camera moves more — handheld creeping in, destabilizing the previously steady frame.

---

#### SCENE 8: THE JOURNALIST (40:00–48:00)

INT. LAYLA'S NEWSPAPER OFFICE — DAY

Layla has agreed to help investigate — but within limits. She won't use her professional resources for personal matters. But she teaches Yasmin what she knows.

LAYLA: "Surveillance is about pattern recognition. You already do this — you listen for patterns in music. Same skill, different instrument."

She shows Yasmin how to check for GPS tracking, how to photograph documents without being obvious, how to use the internet to cross-reference public records.

YASMIN: "You've done this before."

LAYLA: "I do this every day. Just usually with politicians, not pianists."

YASMIN: "What's the difference?"

LAYLA: (pause) "Usually the pianist is more honest about being a performer."

**Emotional Beat:** Determination. Yasmin is becoming competent. The skills she develops here will be used against Omar later — a structural irony the film does not underline but allows the audience to feel.

---

#### SCENE 9: THE HANDLER (48:00–52:00)

INT. RESTAURANT — NIGHT

Yasmin "accidentally" encounters Nour. It is transparently staged on both sides. They are both performing.

NOUR: "He told me you were beautiful. He didn't tell me you were perceptive. Those two qualities rarely coexist in our line of work."

YASMIN: "What line is that?"

NOUR: "The line between what we show and what we are. You're a pianist — you understand. The performance and the performer. The score and the interpretation."

YASMIN: "Are you his colleague? His handler? His —"

NOUR: "I'm the person who reminds him that everyone is a resource, including himself. Especially himself."

She studies Yasmin with professional assessment.

NOUR: "You're adapting faster than expected. Most civilians collapse or flee by now."

YASMIN: "I'm not most civilians."

NOUR: "No. You're not. That's what concerns me."

**Emotional Beat:** Professional respect mixed with personal fear. Nour sees Yasmin's potential — and potential is threat.

---

#### SCENE 10: THE SAFE HOUSE — MIDPOINT (52:00–60:00)

INT. ANONYMOUS APARTMENT — NIGHT

Yasmin has found the safe house by following GPS history. She picks the lock — Layla taught her. She enters.

It is spare. Anonymous. A bed. A desk. A mini-fridge. The apartment of someone who doesn't exist.

Except one wall. Covered in photographs, documents, maps. Operational materials.

And photographs of her. Hundreds. Concert programs with dates noted. Restaurant receipts. Medical records from her appendectomy two years ago. Her entire life, catalogued.

She touches the photographs. Her own face stares back. She has never felt so seen. She has never felt so violated.

Then — mixed with her file — photographs of another woman. Younger. Different city. Alexandria, according to a handwritten note. Same time period.

In the background of some photographs: Omar. His hand. His wedding ring.

Yasmin's breathing changes. The violation deepens. It is not just that she was watched. It is that she may have been one of several. That the marriage may have been one of several. That she may be interchangeable.

She hears a sound. Footsteps in the hall.

She moves with sudden operational precision — replaces everything exactly, retreats to the bathroom, flushes the toilet as cover, exits through the window and down the fire escape.

She is shaking. But she is also exhilarated. She has become someone who escapes through windows.

**Emotional Beat:** Horror that transforms into cold resolve. The woman who smashed her piano in rage doesn't exist yet. This Yasmin is calculating. Dangerous. New.

**Midpoint Shift:** Yasmin is no longer investigating to save the marriage. She is investigating to understand the scope of the deception — and to decide whether to destroy Omar or become him.

---

### ACT II-B: THE ABYSS

#### SCENE 11: THE MEETING (60:00–68:00)

INT. YASMIN AND OMAR'S APARTMENT — NIGHT

Omar has asked to use the apartment for a meeting. "Just once. You'll be safe. Protected."

Yasmin agrees. But she has a plan.

She prepares the space as if for a concert — every detail considered. She wears a dress Omar loves. She plays piano as the DIPLOMAT (50s, European, expensive suit) arrives.

The conversation happens in multiple languages. Yasmin plays Chopin's "Raindrop Prelude" — the persistent A-flat representing doom, the repeated note that cannot be escaped.

She hears fragments:
- "The Lebanese route is compromised."
- "Your source inside the ministry —"
- "The El-Sayed connection —"

She misses a note. The Raindrop stutters. She recovers. No one notices — or at least, no one reacts.

The A-flat continues. She modulates into minor key. The music darkens. The conversation continues in shadows she cannot fully penetrate.

**Visual:** Yasmin at the piano, framed between the two men. She is literally and figuratively between them, providing the emotional soundtrack to their operational conversation. The piano is her weapon and her prison.

---

#### SCENE 12: THE RAINDROP (68:00–75:00)

*[Overlaps with Scene 11]*

The diplomat leaves. Omar is shaken — more than Yasmin has ever seen.

OMAR: "You heard."

YASMIN: "I heard my father's name. I heard 'El-Sayed connection.' I heard you discuss my family like a logistics problem."

OMAR: "It's not what you —"

YASMIN: "Don't. Don't tell me what it is or isn't. I've spent weeks learning your language. The language of omission and implication. I understand you now better than I ever did when I believed you."

OMAR: (defeated) "Your father. He wasn't what you think. He wasn't what I told you."

YASMIN: "What was he?"

OMAR: "He was one of us. Before us. Before my division. He tried to get out. They don't let you out. I was assigned to — to observe him. I tried to warn him. I failed. And then I met you, and I thought — I thought if I could protect you, it would be —"

YASMIN: "Penance? You married me as penance?"

OMAR: "I don't know why I married you. I've asked myself every day for seven years. Was it guilt? Was it love? Was it operational? I don't know. I don't know anymore."

Yasmin walks to the piano. She looks at it. Her companion. Her voice. Her lie.

She lifts the lid. She looks at the strings, the hammers, the beautiful engineering of controlled vibration.

She slams the lid down. The strings scream in dissonance. She slams it again. And again.

OMAR: "Yasmin —"

She picks up a candlestick. She smashes the keyboard. Keys fly. Hammers break. The piano — her identity, her sanity, her carefully constructed self — dies in a cacophony of destruction.

She stands amid the wreckage. Breathing hard. Not crying.

YASMIN: "You killed everything I was. The least you can do is watch the funeral."

**Emotional Beat:** Rage that transforms into emptiness. The piano's destruction is the film's most violent moment, and it is violence against herself. She has destroyed her own identity vessel because she cannot yet touch Omar.

---

#### SCENE 13: THE DESTRUCTION (75:00–82:00)
*[Overlaps with Scene 12 conclusion]*

The aftermath. Yasmin sits amid piano wreckage. Omar stands at the door, afraid to enter, afraid to leave.

She speaks without looking at him:

YASMIN: "You asked if I could play you. What I would hear. I know now. I would hear a man who built a life out of silence and called it protection. Who built a marriage out of omission and called it love. Who is so lost inside his own operations that he can't find the door to his own heart."

OMAR: "If there's a door, you're the only one who ever knocked."

YASMIN: "Then you're more alone than I thought. Because I wasn't knocking on your door, Omar. I was knocking on a wall I thought was a door."

She leaves. She doesn't pack. She just walks out.

**Emotional Beat:** The end of the marriage as it existed. Not a divorce — a disappearance. Yasmin vanishes into her sister's world, leaving her constructed identity in pieces.

---

#### SCENE 14: THE SILENCE (82:00–89:00)

INT. LAYLA'S APARTMENT — DAY (THREE DAYS LATER)

Yasmin hasn't spoken in three days. She sits by the window. She doesn't play piano — there is no piano here. She doesn't read. She barely eats.

Layla moves around her like she is a fragile object. She brings tea Yasmin doesn't drink. She talks about work Yasmin doesn't respond to.

On the third day, Layla sits across from her.

LAYLA: "I started investigating Dad."

Yasmin's eyes move. First response.

LAYLA: "I found things. Not everything. But enough to know that Omar's story — at least the part about Dad being intelligence — that's true. I don't know about the rest. But Dad wasn't just a military officer who died in an accident. There's a file. It's classified, but I found references."

YASMIN: (first words in three days) "References to what?"

LAYLA: "References to 'El-Sayed, K.' Being 'transitioned to external capacity.' To 'deep cover.' To — Yasmin, I think Dad was doing exactly what Omar does. I think — I think we grew up in a house that was also a safe house."

Yasmin processes this. The horror deepens. Her entire childhood may have been operational theater.

YASMIN: "Did Mom know?"

LAYLA: "I don't know. I haven't asked her. I'm afraid to."

The sisters sit in silence. They are both orphans now — not of death, but of narrative. The story of their family is being rewritten in real-time.

**Emotional Beat:** Numbness slowly cracking. The revelation about her father doesn't heal Yasmin — it complicates her. She cannot be simply a victim of Omar's deception if she was born inside a larger deception.

---

#### SCENE 15: THE PACKAGE (89:00–94:00)

INT. LAYLA'S APARTMENT — DAY

A package arrives. No return address. Plain brown paper.

Inside: photographs. Yasmin and Omar, early in their relationship. Walking by the Nile. At a concert. In a restaurant. The photographs are beautiful. Intimate.

Stamped on each photograph: operational coding. The same alphanumeric system she saw in the safe house.

A note, typed:

> "He was reporting on you before he loved you. The question is whether he ever stopped reporting. Every affection you remember was documented. Every word transcribed. Every gift logged as 'relationship maintenance.' He is not the man you loved. He is the man who played the man you loved. And the performance was flawless. — A Friend"

Yasmin reads it three times. She hands it to Layla.

LAYLA: "'A Friend.' Who?"

YASMIN: "Someone who wants me to destroy him. Or someone who wants him to lose me. Or —"

LAYLA: "Or?"

YASMIN: "Or Omar himself. Testing whether I can be controlled. Whether I can be managed. Whether I'm still operational."

She stands. She is different now.

YASMIN: "I'm done being someone's operation."

**Emotional Beat:** Paranoia crystallizing into determination. The package could be from anyone, and that uncertainty is the point. Yasmin stops trying to determine who to trust and starts acting as if no one can be trusted.

---

#### SCENE 16: THE ALLIANCE (94:00–100:00)

INT. NOUR'S OFFICE — DAY

Yasmin doesn't call Nour. She arrives. Unannounced. Professional. Cold.

YASMIN: "You said I was perceptive. Perception is only useful if it leads to action. I need to know who my husband is. Not who he was to me. Who he is to the world that made him."

Nour studies her. There is respect in her eyes. Perhaps recognition.

NOUR: "You've crossed a line. Most people don't. They stay in the world of feelings — betrayal, anger, forgiveness. You've entered the world of information."

YASMIN: "Is that better?"

NOUR: "It's more honest. Feelings are infinite. Information is finite. You can finish with information."

She provides a name: Khalid Rashid. Retired handler. Maadi. Garden café.

NOUR: "He knew your father. He knows Omar's architecture. But understand — Khalid doesn't give answers. He gives more questions. That's his gift and his cruelty."

**Emotional Beat:** Grudging respect between two women who have learned the same brutal lesson: love is an operation, and the only question is who controls the narrative.

---

### ACT III: THE RECKONING

#### SCENE 17: THE GARDEN (100:00–107:00)

EXT. MAADI GARDEN CAFÉ — DAY

KHALID RASHID (71) tends roses while he talks. He wears gardening gloves. He is gentle. He is terrifying.

KHALID: "Your father. Khaled El-Sayed. Brilliant man. Terrible operative. Too feeling. The feeling ones burn out or get burned."

YASMIN: "Omar said he was trying to save him."

KHALID: "Omar says many things. Some true. Some operationally true — true enough to serve a purpose. Some he believes because believing serves his survival."

YASMIN: "What actually happened?"

KHALID: "Your father was not investigating a network. He was part of one. A different one. A predecessor to Omar's division. He wanted out — he had met your mother, he wanted a real life. They don't let you out. Omar was assigned to monitor him. Instead, Omar tried to extract him. Failed. Your father died — accident, they said. But accidents in our world are usually communications."

YASMIN: "And Omar married me because —"

KHALID: "That is the question, isn't it? I watched Omar for years. I never saw him uncertain until he met you. That uncertainty — in our world, that's the closest thing to love. Or the closest thing to danger. The two are often identical."

**Emotional Beat:** Grief complicated by competing narratives. Khalid provides information that validates some of Omar's story while undermining its completeness.

---

#### SCENE 18: THE FILE (107:00–112:00)

EXT. KHALID'S GARDEN — DAY

Khalid offers a Manila envelope. Thick.

KHALID: "The complete file. Every report Omar filed on you. Every assessment. Every coded note of — whatever it was. Information doesn't provide peace, Yasmin. It provides accuracy. Those are different currencies."

YASMIN: "I need to know."

KHALID: "Yes. You do. That's your nature. It's why Omar was drawn to you — you both need to know, and you both destroy yourselves with what you find."

She takes the file.

KHALID: "One more thing. The torn page in Omar's current file. The recommendation. I don't know what it said. But I know who wrote it. Nour. Ask her what she recommended. Ask her what Omar refused."

**Emotional Beat:** Fear hardening into resolve. The file represents total knowledge — and total knowledge is the film's final test. Will it destroy her or free her?

---

#### SCENE 19: THE DUOLOGY (112:00–122:00)

INT. CONSERVATORY — NIGHT

Yasmin has summoned Omar. The space is empty, lit only by emergency lights and the glow from the street.

She sits at a different piano — not her destroyed one, but the conservatory's practice instrument. Lesser quality. Appropriate.

She doesn't look at him when he enters.

YASMIN: "I read the file. All of it."

OMAR: (barely audible) "And?"

YASMIN: "Your first assessment. 'Subject is emotionally accessible, professionally isolated, family connection provides operational value. Recommend extended engagement.'"

She turns to face him.

YASMIN: "Extended engagement. Is that what I am? A long meeting?"

OMAR: "Yasmin —"

YASMIN: "Your second assessment. Six months in. 'Subject's musical intelligence translates to situational awareness. Unusually difficult to deceive. Risk: Subject may develop independent analytical capacity. Recommendation: Maintain proximity, manage information flow.'"

She stands. She walks toward him.

YASMIN: "You didn't love me. You managed me. Like an asset. Like a —"

OMAR: "Like a woman I was terrified of losing!"

Silence. The first raw emotion from Omar in the entire film.

OMAR: "Yes, I assessed you. Yes, I reported. Yes, I did things — I am things — that have no forgiveness. But the terror in those reports, Yasmin. The terror was real. I was terrified of you because I was falling in love with you while I was lying to you, and I didn't know which was the operation and which was me, and I still don't, and I have spent seven years in that not-knowing, and it has been the most real thing I have ever —"

He stops. He is shaking.

Yasmin walks back to the piano. She sits. She begins to play — the Chopin Nocturne from the opening. The same piece. But now it is different. Slower. More fragile. More honest.

Omar stands behind her. After a moment, he places his hands on the keys above hers. He doesn't play. He just rests his fingers there — a gesture from early in their courtship, when he would "play" silently while she performed, a private joke between them.

The gesture is devastating. It recalls love. It recalls performance. It recalls everything that is ambiguous between them.

She stops playing. The silence is absolute.

YASMIN: "I used to think music was the truest thing I knew. Now I know truth is just the lie that hasn't been exposed yet."

She stands. She faces him.

YASMIN: "I don't know if I can forgive you. I don't know if forgiveness is even the right word for what would need to happen. But I know that I can't live in your world of managed truths and operational emotions. I need — I need to know what is real, even if it's terrible. Especially if it's terrible."

**Emotional Beat:** The film's emotional climax — not resolution, but the moment of maximum tension. The piano duet is the most intimate and most false moment between them, and the ambiguity is unbearable.

---

#### SCENE 20: THE SILENCE AFTER (122:00–127:00)

*[Overlaps with Scene 19]*

They stand in the empty conservatory. Two people who have shared everything and nothing.

OMAR: "What do you want?"

YASMIN: "I want to not be an operation. I want to be a person who is seen without being assessed. I want —"

She stops. She doesn't know what she wants. That is the honesty.

YASMIN: "I want to wake up and know that my life is mine. Not my father's legacy. Not your cover story. Not my own performance of the perfect pianist. Just — mine. Even if it's empty. Even if it's terrifying."

OMAR: "I don't know if I can give you that. I don't know if I have anything to give that isn't contaminated by —"

YASMIN: "Then we have nothing. And nothing is honest. And honesty is the only room I can breathe in anymore."

She leaves. He doesn't follow.

**Emotional Beat:** Exhaustion giving way to clarity. Not happy clarity. Just the clarity of having stated the unspeakable.

---

#### SCENE 21: THE NEWS (127:00–132:00)

INT. LAYLA'S APARTMENT — DAY

Yasmin is packing. Not to return to Omar — just to move forward. She doesn't know where yet.

Layla bursts in.

LAYLA: "It's on the news. The network — the one Omar was involved with. Mass arrests. International. It's huge."

YASMIN: "What about Omar?"

LAYLA: "They haven't named him. But — Yasmin, if he was connected to this, and it's going public, his division will be —"

YASMIN: "They'll bury him. Or expose him. Depending on who wins."

LAYLA: "What are you going to do?"

Yasmin sits. She thinks.

YASMIN: "I don't know. For the first time in months, I genuinely don't know. And that's — that's almost relief."

**Emotional Beat:** Urgency injected into exhaustion. The external world forces a decision she wasn't ready to make.

---

#### SCENE 22: THE OFFER (132:00–137:00)

EXT. ROOFTOP — NIGHT

Yasmin has summoned Omar. They haven't spoken since the conservatory.

The Cairo skyline sprawls around them. The city is indifferent to their drama.

OMAR: "I can disappear. New identity. New country. I've done it before — not like this, but I know the architecture. You could come. We could — not fix it. Not pretend. Just continue. Some people live entire lives in the middle of things, never at the beginning or end."

YASMIN: "You want me to disappear with you. Into another lie."

OMAR: "Into a life. Any life. I'm offering you the only thing I have — the ability to keep existing. Together. Imperfectly. Invisibly."

YASMIN: "And if I say no?"

OMAR: "Then I disappear alone. And you stay here. And we become stories we tell ourselves to explain what happened."

**Emotional Beat:** Longing for the possibility of escape, immediately recognized as another form of imprisonment.

---

#### SCENE 23: THE COUNTER (137:00–142:00)

*[Overlaps with Scene 22]*

YASMIN: "Or you could testify. Publicly. About everything. My father. The division. The other lives. The ones you built and the ones you destroyed. You could become visible."

OMAR: "I would be dead in a month."

YASMIN: "Yes. But you would be real for the first time."

OMAR: "Real and dead. That's not a choice. That's a sentence."

YASMIN: "It's the only choice that isn't another operation. testify, tell everything, and accept the consequences. Or disappear, and keep being what you've always been — a fiction that happens to have a heartbeat."

Omar looks at her. For a moment, the mask is completely gone. He is just a man. Tired. Afraid. Possibly capable of love, possibly not.

OMAR: "When I married you — whatever the reason was, whatever it became — there was a moment, early on, when I woke up and saw you sleeping and thought: this is what peace feels like. I hadn't felt peace in fifteen years. I haven't felt it since. I've been chasing that moment."

YASMIN: "Through more lies?"

OMAR: "Through the only methods I know."

**Emotional Beat:** Fear confronting courage. Omar's offer and Yasmin's counter-offer are both forms of death — one physical, one existential.

---

#### SCENE 24: THREE MONTHS (142:00–145:00)

TITLE CARD: "Three months later"

INT. NEW APARTMENT — DAY

Different neighborhood. Smaller. Simpler. Yasmin's hands on different piano keys.

But she is not playing Chopin. She is improvising. Raw. Unstructured. Making mistakes and continuing through them. The music is not beautiful in a conventional sense. It is alive.

She wears simple clothes. No ring. Her hair is different — less controlled.

She teaches at a different conservatory. Smaller. Less prestigious. She doesn't perform publicly anymore.

She is not happy. She is not unhappy. She is — becoming.

**Visual Shift:** The palette has warmed again, but differently. Not the amber of performance but the earth tones of ground, of planting, of beginnings.

---

#### SCENE 25: THE LETTER (145:00–147:00)

INT. NEW APARTMENT — DAY

The mail arrives. Among bills and flyers: an envelope. No return address. Foreign stamps.

Inside: a single photograph.

Omar. In a market. A country she doesn't recognize — possibly Southeast Asia, possibly Latin America. He looks older. Thinner. He is looking directly at the camera. Visible.

On the back, handwritten:

> "I chose real. It doesn't forgive anything. But it's the only room I've ever lived in that doesn't have mirrors on every wall. Thank you for the architecture. — O."

Yasmin holds the photograph. She doesn't cry. She studies it. She studies his face — the face of a man who may be telling the truth for the first time, or may be performing visibility as expertly as he performed invisibility.

She doesn't know. She will never know. That is the truth she has learned to live with.

**Emotional Beat:** Complex grief — not closure, but a door opening onto another room.

---

#### SCENE 26: THE UNRESOLVED NOTE (147:00–150:00)

INT./EXT. NEW APARTMENT — WINDOW — DUSK

Yasmin stands at the window. Cairo at dusk. The city that contains infinite stories, infinite deceptions, infinite possibilities for reinvention.

The call to prayer begins. The sound rises from a hundred minarets.

She doesn't cry. She doesn't smile. She breathes — a deep, unmeasured breath. The first unmeasured breath of the film.

She turns from the window. She walks to the piano. She places her hands on the keys.

She plays one note. Then another. Not a composition. Just notes. Searching for what comes next.

The camera holds on her face. The note hangs in the air, unresolved.

FADE TO BLACK.

The sound of the unresolved note continues for three seconds after the image is gone.

Then silence.

THE END

**Emotional Beat:** Acceptance without closure. The film's final gift to the audience is the understanding that resolution is not the same as redemption, and that living with uncertainty is its own form of courage.

---

# SECTION VI: THEME MATRIX

## PRIMARY THEME: The Architecture of Deception

### Statement
Intimacy cannot survive the absence of truth, yet truth often cannot survive the full light of intimacy. Every relationship is built on selective revelation — the question is who chooses what remains hidden, and at what cost.

### Development Through Structure
| Act | Integration |
|-----|------------|
| Act I | The deception is revealed to the audience before the protagonist fully accepts it — creating dramatic irony and audience complicity |
| Act II-A | Yasmin learns the skills of deception — she becomes what she investigates, raising the question: is all intimacy operational? |
| Act II-B | The revelation that her father was also an operative reframes deception as generational, structural, inescapable |
| Act III | The choice between disappearance (continued deception) and testimony (destructive truth) forces the theme into literal decision |

### Symbolic Motifs
- **Mirrors:** Represent self-perception and the infinite regress of performed identity. Yasmin is always seeing herself alone, until she stops looking.
- **The Piano:** Initially a vessel of authentic expression, revealed as potentially surveilled; destroyed; rebuilt as improvisation — the film's metaphor for moving from interpretation to creation, from performing others' truths to composing one's own
- **The Wedding Ring:** Visual anchor of the marriage's authenticity. Its removal marks transition. Its absence in the final scenes marks neither divorce nor widowhood, but something more ambiguous.

## SECONDARY THEME: Identity as Performance

### Integration Points
- **Omar:** The professional performer who has lost track of the original self
- **Yasmin:** The artistic performer who discovers her entire life may have been audience to someone else's show
- **Nour:** The performer who has integrated performance so completely that authenticity is no longer a relevant category
- **Khalid:** The retired performer who grows roses because they require no cover story — his only authentic space

## TERTIARY THEME: The Geometry of Betrayal and Self-Betrayal

### Integration Points
- Yasmin's self-betrayal: her choice to not investigate sooner, to accept the comfortable lie
- Omar's self-betrayal: his continued operation even as he developed genuine feelings
- The father's self-betrayal: choosing operational life over family, then trying to reverse the choice
- The system's betrayal: consuming individuals as resources, then discarding them

### Thematic Resolution
The film does not resolve its themes in the conventional sense. It arrives at a position of sustained ambiguity:
- Yasmin does not forgive Omar. She does not not-forgive him. She lives with the unresolved chord.
- Omar may be telling the truth in his final letter. He may be performing truth. The film refuses to resolve this.
- The audience is left with the question: Is a life built on necessary uncertainty preferable to a life built on comfortable false certainty?

This ambiguity is not narrative weakness. It is thematic integrity. The film's argument is that relationships built on information asymmetry cannot be "solved" — they can only be navigated, continued, or ended. Yasmin chooses navigation, which is the only honest choice available.

---

# SECTION VII: PRODUCTION NOTES

## Visual Style Direction

### Color Architecture
| Phase | Dominant Palette | Emotional Register |
|-------|-----------------|-------------------|
| Act I | Warm amber + cold blue-gray | Performance warmth vs. domestic cold |
| Act II-A | Desaturated, increasing green-yellow | Paranoia, illness of the marriage |
| Act II-B | Deep red + black | Rage, blood, destruction |
| Act III | Earth tones + undefined warmth | Ground, growth, uncertain possibility |

### Camera Language
- **Act I:** Steady, composed, classical framing — Yasmin's world is ordered
- **Act II-A:** Increasing handheld, longer lenses, shallow focus — destabilization
- **Act II-B:** Extreme close-ups mixed with wide emptiness — isolation within space
- **Act III:** Return to steadiness, but looser — not composed, just present

### Key Visual Sequences
1. **The Mirror Motif:** Yasmin's reflection in every possible surface, gradually diminishing until she stops seeing herself entirely — then, in Act III, she sees herself in a window and pauses, not recognizing but accepting
2. **The Piano Destruction:** Shot in a single take, or designed to appear so. The violence is against wood and wire, but the emotion is murderous
3. **The Final Note:** Extreme close-up on Yasmin's face as the unresolved note hangs. The camera imperceptibly zooms in for 30 seconds. No cut.

## Sound Design Direction

### Musical Architecture
- **Chopin Nocturne in C-sharp minor:** Opening, recurring, destroyed, possibly referenced in final scene
- **Chopin "Raindrop" Prelude:** The operational meeting scene — the persistent A-flat as doom motif
- **Original composition:** Yasmin's improvisation in Act III — the film's only "original" music, representing her transition from interpreter to creator

### Ambient Sound
- Cairo as character: call to prayer, traffic, construction, crowds — initially comforting, increasingly oppressive, finally neutral
- Silence: used as weapon and healing — the three days of silence at Layla's is the film's quietest sequence

## Casting Considerations

### Yasmin
Requires an actress capable of:
- Musical credibility (or ability to fake it convincingly)
- Emotional restraint that reads as strength, not coldness
- Transformation from controlled performer to raw improviser
- Carrying long scenes with minimal dialogue

**Reference energy:** Juliette Binoche (*Three Colors: Blue*), Tang Wei (*Lust, Caution*), Hiam Abbass

### Omar
Requires an actor capable of:
- Generating ambiguity in every scene — is he sincere or performing?
- Physical transformation between "husband" and "operative" modes
- Vulnerability that could be manipulation
- Chemistry with Yasmin that persists even when the relationship is revealed as constructed

**Reference energy:** Tony Leung (*In the Mood for Love*), Rami Malek, Tahar Rahim

### Nour
Requires an actress capable of:
- Professional warmth that masks absolute ruthlessness
- Being the road not taken — showing Yasmin what she could become
- Comedy in darkness

**Reference energy:** Tilda Swinton, Lubna Azabal

### Khalid
Requires an actor capable of:
- Gentle authority
- Speaking exposition as poetry
- Making unreliability feel like wisdom

**Reference energy:** Omar Sharif archetype, Jonathan Pryce

## Production Challenges

1. **Cairo filming:** Requires navigating local production infrastructure; consider co-production with Egyptian studio
2. **Piano performance:** Either cast musically capable actors or use hand doubles with seamless editing
3. **Ambiguity maintenance:** The script must be shot and edited to preserve multiple interpretations of Omar's sincerity; this requires precise control of performance direction and editorial framing
4. **The unresolved ending:** Festival and commercial audiences may resist; prepare for test screening debates

## Festival & Distribution Strategy

- **Primary target:** Venice, Cannes, Toronto — prestige drama with international relevance
- **Secondary target:** Cairo International Film Festival — local resonance, regional star power
- **Distribution:** Arthouse theatrical with streaming partnership; target adults 25-55
- **Marketing angle:** "The most devastating love story since *In the Mood for Love*" — position as emotional experience, not plot-driven thriller

---

# APPENDIX: ARABIC DIALOGUE EXCERPTS

For scenes requiring Arabic authenticity, key lines are provided in Arabic with English translation:

**Scene 19 — The Duology:**

YASMIN (Arabic):
> "كنت أفكر أن الموسيقى هي أصدق شيء أعرفه. الآن أعرف أن الحقيقة هي مجرد كذبة لم تُكشف بعد."

*"I used to think music was the truest thing I knew. Now I know truth is just the lie that hasn't been exposed yet."*

**Scene 5 — The Follow:**

YASMIN (Arabic):
> "أرى ماذا؟ أنك شخص آخر؟ أم أنني شخص لا يعرف زوجها؟"

*"See what? That you're someone else? Or that I'm someone who doesn't know her own husband?"*

**Scene 23 — The Counter:**

YASMIN (Arabic):
> "أو يمكنك أن تشهد. علناً. عن كل شيء."

*"Or you could testify. Publicly. About everything."*

OMAR (Arabic):
> "سأكون ميتاً خلال شهر."

*"I would be dead in a month."*

YASMIN (Arabic):
> "نعم. لكنك ستكون حقيقياً للمرة الأولى."

*"Yes. But you would be real for the first time."*

---

# DOCUMENT METADATA

- **Agent:** Story Architect ("From Storyboard To Vision" pipeline)
- **Concept:** حب وخيانة — Love and Betrayal
- **Genre:** Romantic Psychological Drama / Neo-Noir Romance
- **Target Runtime:** 105 minutes
- **Structure:** Three-Act with 26 scenes
- **Tone:** Intimate, tension-filled, emotionally devastating, visually lush
- **Emotional Target:** Heartbreak, longing, moral ambiguity, redemption struggle
- **Comparables:** *In the Mood for Love*, *Atonement*, *Tinker Tailor Soldier Spy*, *The Lives of Others*
- **Status:** Ready for Vision Director and Screenwriter Agent handoff

---

*"Every story is a lie that tells a truth. This one tells several, and leaves the audience to decide which ones they believe."*

— Story Architect, 2026-05-25
