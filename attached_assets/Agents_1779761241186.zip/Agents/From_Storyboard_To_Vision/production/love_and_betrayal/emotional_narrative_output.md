# حب وخيانة (Love and Betrayal)
## Emotional Narrative Design Document

**Prepared by:** Emotional Narrative Designer  
**Pipeline Stage:** From Storyboard To Vision — Emotional Narrative Layer  
**Date:** 2026-05-25  
**Language:** Arabic/English Bilingual Design  

---

## Table of Contents
1. [Story Philosophy & Emotional Thesis](#1-story-philosophy--emotional-thesis)
2. [Character Emotional Arcs](#2-character-emotional-arcs)
3. [Audience Emotional Journey Map](#3-audience-emotional-journey-map)
4. [Emotional Color Palette by Act](#4-emotional-color-palette-by-act)
5. [Tension / Release Rhythm Design](#5-tension--release-rhythm-design)
6. [Catharsis Moment Engineering](#6-catharsis-moment-engineering)
7. [Music-Emotion Correspondence](#7-music-emotion-correspondence)
8. [Scene-by-Scene Emotional Beat Sheet](#8-scene-by-scene-emotional-beat-sheet)
9. [Subtext & Emotional Layering Guide](#9-subtext--emotional-layering-guide)

---

## 1. Story Philosophy & Emotional Thesis

### Core Emotional Thesis
> **"We do not betray those we never truly saw. Betrayal is born from the silence between two people who once knew each other's language."**

### Narrative Heart
"حب وخيانة" is not a story about a physical affair. It is a story about **emotional disappearance**. Yousef and Layla are two people who built a cathedral together, then forgot to keep lighting the candles inside it. The betrayal is not merely Layla's — it is the betrayal of time, of routine, of the unspoken contract that love sustains itself without nourishment.

Karim does not seduce Layla with promises. He seduces her with **presence** — with the terrible, beautiful gift of being *seen*. The tragedy is that Yousef, who loves her more deeply than Karim ever could, has forgotten how to make her feel visible.

### Audience Emotional Contract
We ask the audience to feel:
- **Complicity** — to understand that they too have silences in their own relationships
- **Judgment and Forgiveness simultaneously** — to condemn and then absolve every character
- **The ache of beauty** — every scene must carry aesthetic beauty that contrasts with emotional pain
- **Cultural specificity and universal resonance** — the story is rooted in Middle Eastern emotional vocabulary (honor, shame, family, silence, *‘ar* / عار) while speaking to universal human longing

### Reference Emotional DNA
- **Krzysztof Kieślowski** — emotional precision, color as emotion (Double Life of Véronique, Three Colors)
- **Asghar Farhadi** — moral complexity, no villains, the weight of unspoken truths (A Separation)
- **Studio Ghibli** — visual beauty as emotional language, the poignancy of ordinary moments
- **Pixar** — earned emotional beats, setup and payoff across the entire narrative (Up, Inside Out)
- **Nawal El Saadawi** — female interiority, the body as emotional landscape
- **Abdulrahman Munif** — the architecture of place as emotional architecture

---

## 2. Character Emotional Arcs

### 2.1 YOUSEF — The Architect (Protagonist)

**Core Emotional DNA:** Control as love. Fear of chaos. Believes that if he builds things perfectly enough, they will never break.

| Phase | Emotional State | Internal Conflict | External Expression | Emotional Score |
|-------|-----------------|-------------------|---------------------|-----------------|
| **Act I** | Contentment veiling complacency | "If I don't look at the cracks, they don't exist" | Calm, measured, affectionate but mechanical | +4 |
| **Act I-II Turn** | Unease | "Something is different, but I don't want to know what" | Subtle probing, forced normalcy | +2 |
| **Act II** | Suspicion | "Am I losing her, or did I already lose her years ago?" | Watchful, quieter, overcompensating | -1 |
| **Act II-III** | Denial → Fear | "If I confront it, it becomes real" | Hyper-rationalization, avoidance | -3 |
| **Act III** | Anguish | "I built everything for her — why wasn't that enough?" | Withdrawal, coldness masking hurt | -6 |
| **Act III-IV** | Rage | "I want to destroy what I built" | Explosive confrontation with Karim | -8 |
| **Act IV** | Grief | "The house was empty before he ever entered it" | Silent devastation, physical collapse | -9 |
| **Act IV-V** | Truth | "I stopped seeing her. I stopped being seen." | Vulnerability, confession | -7 → -4 |
| **Act V** | Rebirth | "Ruins can be gardens too" | Quiet strength, rebuilding alone | -2 → +1 |

**Key Emotional Triggers:**
- **Vulnerability moments:** Discovering Layla's old composition notebooks, reading what she felt but never played
- **Strength moments:** His final act — completing a building he designed for her, then giving it away
- **Emotional blind spot:** He believes love is demonstrated through provision, not presence

**Transformation Stages:**
1. **Architect** → builds structures to contain emotion
2. **Guardian** → becomes watchful, controlling
3. **Wounded Animal** → lashes out, destroys
4. **Ruin** → sits in the wreckage, finally feels
5. **Gardener** → learns that love grows, is not built

---

### 2.2 LAYLA — The Musician (Co-Protagonist)

**Core Emotional DNA:** Sensitivity as both gift and curse. Feels everything, but has been taught to suppress the inconvenient feelings.

| Phase | Emotional State | Internal Conflict | External Expression | Emotional Score |
|-------|-----------------|-------------------|---------------------|-----------------|
| **Act I** | Numb contentment | "I have everything I should want" | Warm but distant, plays mechanically | +3 |
| **Act I-II Turn** | Awakening | "When did I stop feeling the music?" | Restless, starts playing old compositions | +5 |
| **Act II** | Aliveness | "I forgot what it feels like to be seen" | Glowing, nervous, guilty joy | +6 |
| **Act II-III** | Euphoria / Guilt | "This is wrong but I have never felt more alive" | Radiant but withdrawn from Yousef | +4 → +1 |
| **Act III** | Shame | "I am destroying the only person who ever truly loved me" | Desperate attempts at normalcy with Yousef | -2 |
| **Act III-IV** | Self-loathing | "I am the villain of my own life" | Confession, self-destructive honesty | -5 |
| **Act IV** | Devastation | "I wanted to feel alive and now I feel everything" | Grief, loss of music, silence | -8 |
| **Act IV-V** | Acceptance | "I cannot undo it, but I can stop lying" | Fragile honesty, facing consequences | -6 → -3 |
| **Act V** | Solitude as truth | "I need to find my music alone" | Composes again — not for Yousef, not for Karim, for herself | -2 → +3 |

**Key Emotional Triggers:**
- **Vulnerability moments:** Her hands hovering over piano keys, unable to play the piece she composed for Yousef when they first met
- **Strength moments:** The confession — choosing truth over comfort
- **Emotional blind spot:** Believes her need for emotional aliveness justifies any cost

**Transformation Stages:**
1. **Sleeping Beauty** → numb in the castle of marriage
2. **Awakened** → feels the sun for the first time in years
3. **Adulteress** (emotional) → crosses a line she cannot uncross
4. **Penitent** → cannot forgive herself, seeks punishment
5. **Soloist** → rediscovers music as self, not as relationship

---

### 2.3 KARIM — The Witness (Catalyst / Antagonist)

**Core Emotional DNA:** Trauma as charisma. Has seen too much destruction to believe in building. Sees beauty in ruins because he feels at home in them.

| Phase | Emotional State | Internal Conflict | External Expression | Emotional Score |
|-------|-----------------|-------------------|---------------------|-----------------|
| **Act I-II** | Charm / Detachment | "I don't get involved — I just document" | Magnetic, funny, self-deprecating, dangerous | +3 |
| **Act II** | Seduction (unconscious) | "She reminds me of what I lost" | Intense listening, mirroring her emotions | +5 |
| **Act II-III** | Desire | "I want to be the one who makes her feel alive" | Pursuit, rationalization of harm | +6 |
| **Act III** | Complicity | "I am becoming what I photograph — destruction" | Passion, jealousy, possessiveness | +4 |
| **Act III-IV** | Self-disgust | "I came to document ruins and I became one" | Withdrawal, confession to Yousef | -4 |
| **Act IV** | Destruction | "I destroy everything I touch" | Leaves, returns to war zones | -6 |
| **Act V** | Redemption through absence | "The best thing I can do is disappear" | Sends the photographs he took of them — unposed, real moments — as a gift of truth | -3 |

**Key Emotional Triggers:**
- **Vulnerability moments:** His nightmares, the photographs he cannot look at, the one of a child playing in rubble
- **Strength moments:** Telling Yousef the truth face-to-face, knowing he'll be hit
- **Emotional blind spot:** Believes he is merely a witness, not a participant in destruction

**Transformation Stages:**
1. **Ghost** → detached observer, professional distance
2. **Mirror** → reflects back to Layla what she wants to see
3. **Arsonist** → doesn't mean to burn, but carries fire everywhere
4. **Confessor** → cannot live with the lie
5. **Penitent Ghost** → leaves, but leaves truth behind

---

### 2.4 AMAL — The Seer (Supporting)

**Core Emotional DNA:** Practical love. Sees clearly because she is not inside the storm.

| Phase | Emotional State | Role in Emotional Architecture |
|-------|-----------------|--------------------------------|
| **Act I-II** | Concern | First person to notice Layla's change — tries to warn gently |
| **Act II-III** | Confirmation | Sees the truth, confronts Layla — "You're not the first woman to confuse being seen with being loved" |
| **Act III-IV** | Intervention | Tells Yousef what she sees — becomes the bridge of truth |
| **Act IV-V** | Grief / Solidarity | Supports both of them separately — refuses to choose sides |

**Emotional Function:** Amal is the audience's proxy — she sees what we see, feels what we feel, and voices the moral complexity we struggle with.

---

### 2.5 HASSAN — The Monument (Supporting)

**Core Emotional DNA:** Shame as inheritance. Represents the older generation's way of handling betrayal — silence, endurance, pride.

| Phase | Emotional State | Role in Emotional Architecture |
|-------|-----------------|--------------------------------|
| **Act I** | Pride | "Yousef built what I never could" — validation through son's marriage |
| **Act II-III** | Warning | "Don't ask questions you don't want answered" — teaches silence |
| **Act IV** | Shame | "This is 'air (عار) — this is our shame" — externalizes the cultural weight |
| **Act V** | Acceptance | "I endured for forty years. Maybe I should have spoken." — generational reckoning |

**Emotional Function:** Hassan embodies the cultural pressure that makes betrayal not just personal but communal. His final confession — that he too endured a hollow marriage — reframes the entire film's emotional context.

---

## 3. Audience Emotional Journey Map

### 3.1 Overall Emotional Arc (Graph Description)

```
Emotional Score (+10 to -10)

+10 |                                    ★ (Hope at end — small, earned)
 +8 |              ★ (Beauty of awakening)
 +6 |         ★ (Playful tension)    
 +4 |    ★ (Warmth)              
 +2 | ★ (Opening calm)                       
  0 |________________________________________
 -2 |                                    ★ (Act V — bittersweet)
 -4 |                              ★ (Amal's intervention)
 -6 |                        ★ (Crisis point)
 -8 |                   ★ (Confrontation)
-10 |              ★ (Absolute bottom — revelation scene)
```

**Shape:** A "descending staircase with a gentle ramp up" — the fall is sharp and broken into stages; the recovery is slow, uncertain, and ultimately incomplete but honest. The audience does not get a "happy ending" — they get a *true* ending.

### 3.2 Act-by-Act Emotional Progression

| Act | Audience Should Feel | Primary Emotion | Secondary Emotion | Intensity | Duration |
|-----|----------------------|-----------------|-------------------|-----------|----------|
| **I** | Warm recognition, quiet longing | Nostalgia | Peace with unease | 3/10 | 20 min |
| **II** | Increasing alertness, forbidden excitement | Tension | Beauty / Desire | 5/10 | 25 min |
| **III** | Dread, complicity, moral confusion | Anxiety | Compassion | 7/10 | 25 min |
| **IV** | Devastation, cathartic grief, truth | Anguish | Relief (of truth) | 9/10 | 20 min |
| **V** | Bittersweet acceptance, fragile hope | Melancholy | Peace | 4/10 | 15 min |

### 3.3 Scene-by-Scene Emotional Scores

#### ACT I: THE EDIFICE (Scenes 1-8)

| Scene | Description | Audience Emotion | Score | Notes |
|-------|-------------|------------------|-------|-------|
| 1 | Morning routine — Yousef and Layla, silent choreography | Recognizable comfort, subtle unease | +2 | We feel the beauty and the hollowness simultaneously |
| 2 | Yousef at work — designing a concert hall | Admiration, ambition | +4 | The building is for music — irony planted |
| 3 | Layla at piano — plays mechanically, stops | Quiet sorrow, recognition | +1 | "She used to compose" — Amal's line plants longing |
| 4 | Dinner with Hassan — generational tension | Cultural weight, humor | +2 | Warm but constrained |
| 5 | Yousef and Layla in bed — backs to each other | Deep recognition for couples | 0 | The most important non-scene in the film |
| 6 | Karim introduced — photography exhibition | Intrigue, charisma | +3 | He photographs destroyed buildings — visual metaphor |
| 7 | Layla sees Karim's work — connection | Awakening, danger | +5 | First time she truly *looks* at something in months |
| 8 | Yousef mentions concert hall project — "I want you to play there" | Hope, irony | +4 | Beautiful setup for future devastation |

**Act I Emotional Pivot:** Scene 7 — the moment Layla feels alive. The audience must feel both thrilled for her and terrified of what it means.

---

#### ACT II: THE CRACK (Scenes 9-18)

| Scene | Description | Audience Emotion | Score | Notes |
|-------|-------------|------------------|-------|-------|
| 9 | Karim visits their home — dinner | Tension, social pleasure | +3 | Yousef is oblivious; audience is hyper-aware |
| 10 | Karim and Layla discuss music alone | Intimacy, transgression | +5 | Not sexual — emotional. More dangerous |
| 11 | Yousef notices Layla's changed energy | Unease, empathy | +2 | He notices but misinterprets as happiness |
| 12 | Layla plays again — real music for the first time | Beauty, joy, guilt | +6 | The music is the affair |
| 13 | Amal sees the change — warning conversation | Concern, foreboding | +1 | "You're glowing, and it's not from Yousef" |
| 14 | Yousef finds Karim's photography book in Layla's studio | Suspicion, fear | -1 | The crack becomes visible |
| 15 | Karim takes Layla to photograph the sea | Freedom, danger | +5 | She is alive, and the audience is complicit |
| 16 | Yousef works late, alone in the unbuilt concert hall | Loneliness, ambition as armor | -2 | He builds what he cannot feel |
| 17 | Layla and Karim — the first emotional betrayal | Desire, guilt, inevitability | +4 | They kiss. The audience has been dreading and wanting this |
| 18 | Yousef comes home to find Layla glowing — she lies about her day | Dread, helplessness | -2 | The lie is louder than any confession |

**Act II Emotional Pivot:** Scene 17 — the kiss. The audience must feel both the triumph of desire and the tragedy of transgression simultaneously. This is the "complicity peak" — we wanted this for her, and now we are implicated.

---

#### ACT III: THE SPIRAL (Scenes 19-28)

| Scene | Description | Audience Emotion | Score | Notes |
|-------|-------------|------------------|-------|-------|
| 19 | Yousef senses the distance — tries to reconnect | Pathos, frustration | -1 | His attempts are mechanical, heartbreaking |
| 20 | Layla tries to end it with Karim — fails | Tragedy, inevitability | 0 | "I can't. Not yet." |
| 21 | Karim shows Layla photographs of war children | Cathartic pain, bonding | +2 | Shared trauma as intimacy |
| 22 | Yousef discovers a text message — not explicit, but enough | Dread, confirmation | -3 | The moment the husband knows |
| 23 | Yousef confronts Layla indirectly — "Are you happy?" | Devastating delicacy | -4 | She says yes. They both know it's a lie |
| 24 | Layla plays at a small concert — her best performance | Pride, sorrow, triumph | +3 | She is a genius. Yousef watches from the back |
| 25 | After the concert — Karim is there, Yousef sees them | Jealousy, rage, helplessness | -5 | The triangle becomes visible to all |
| 26 | Yousef drives home alone — breakdown in car | Grief, privacy of pain | -6 | He screams. No one hears |
| 27 | Layla comes home — Yousef is eerily calm | Terror, suspense | -5 | The calm is more frightening than rage |
| 28 | Amal tells Yousef the truth | Shock, relief, devastation | -6 | The truth enters through a third party |

**Act III Emotional Pivot:** Scene 26 — Yousef's car breakdown. This is the audience's first true catharsis. We have been holding tension with him; his scream is our release. But it's not the final catharsis — it's the first real drop into the abyss.

---

#### ACT IV: THE COLLAPSE (Scenes 29-36)

| Scene | Description | Audience Emotion | Score | Notes |
|-------|-------------|------------------|-------|-------|
| 29 | Yousef doesn't confront Layla — becomes cold, mechanical | Dread, helplessness | -6 | He is building a wall even as he falls apart |
| 30 | Layla feels his withdrawal — tries to reach him | Guilt, desperation | -4 | "Talk to me." "About what?" |
| 31 | Karim comes to the house — Yousef finds them talking | Rage, humiliation | -8 | The confrontation is inevitable |
| 32 | Yousef attacks Karim — physical fight | Cathartic violence, shame | -7 | Not triumphant — pathetic and devastating |
| 33 | Layla confesses everything — the full truth | Horror, relief, grief | -9 | The absolute bottom. Everything is ruined |
| 34 | Yousef leaves — drives to the unbuilt concert hall | Desolation, emptiness | -9 | The architecture of his love — unfinished |
| 35 | Hassan finds Yousef — reveals his own marriage was a lie | Generational sorrow, reframing | -7 | "I endured. I don't know if that was strength or cowardice" |
| 36 | Layla alone in the house — plays the piano, but nothing comes | Grief as silence | -8 | The music has left her too |

**Act IV Emotional Pivot:** Scene 33 — the confession. This is the film's **Primary Catharsis**. Every scene before has been building to this. The audience must feel:
- Relief that the lie is over
- Horror at the destruction
- A strange, terrible beauty in the honesty
- That this is simultaneously the worst and most necessary moment of the film

---

#### ACT V: THE RUINS (Scenes 37-45)

| Scene | Description | Audience Emotion | Score | Notes |
|-------|-------------|------------------|-------|-------|
| 37 | Weeks later — Yousef and Layla in the same room, silent | Desolation, familiar sorrow | -5 | They have not spoken of divorce |
| 38 | Yousef goes to the concert hall — completes it alone | Bitter triumph, emptiness | -3 | He finishes what he started, but not for her |
| 39 | Layla moves to a small apartment — starts composing again | Fragile hope, solitude | -2 | Music returns, but it is different — solo, not duet |
| 40 | Yousef gives the concert hall to the city — does not invite Layla | Bittersweet closure | -2 | The gift that becomes a relinquishment |
| 41 | Karim sends photographs — unposed moments of Yousef and Layla from the early days | Nostalgia, grief, beauty | -1 | He documents what they had before he destroyed it |
| 42 | Yousef sees the photographs — first smile in the film's second half | Melancholy peace | 0 | Memory as bittersweet medicine |
| 43 | Layla performs her new composition — solo, in a small venue | Pride, sorrow, beauty | +1 | The music is about loss, but also about self |
| 44 | Yousef is in the audience — they see each other | Recognition, unresolved | 0 | No reunion. Just seeing. That is enough |
| 45 | Final shot — the concert hall, filled with music and people. Yousef and Layla are both there, separately. | Fragile hope, continuity | +1 | Love failed, but beauty continues. That is the film's thesis |

**Act V Emotional Pivot:** Scene 44 — the mutual recognition. The audience wants them to reunite. They do not. But they *see* each other, and that seeing is more honest than any reunion could be. This is the **Secondary Catharsis** — acceptance without resolution.

---

## 4. Emotional Color Palette by Act

### Color as Emotional Language
Following Kieślowski's *Three Colors* and the emotional vocabulary of Middle Eastern visual tradition, each act has a dominant color that shifts as emotions evolve.

---

### ACT I: THE EDIFICE — **Amber / Gold / Warm Sand**

| Element | Color | Emotional Function |
|---------|-------|-------------------|
| **Dominant** | Warm amber (#D4A574) | Nostalgia, the golden light of memory, the illusion of permanence |
| **Accent** | Cream white (#F5F5DC) | Purity, the surface of the marriage, untested |
| **Shadow** | Deep brown (#5C4033) | What lies beneath — warmth that can become suffocation |
| **Light sources** | Golden hour, lamps, candlelight | Time suspended, the "magic hour" of their life together |
| **Architecture** | Warm stone, wood, brass | Materials that age well — the promise of endurance |
| **Wardrobe — Yousef** | Beige, sand, camel | Blends into his own architecture — becoming invisible |
| **Wardrobe — Layla** | Muted gold, cream | Beautiful but not vibrant — sleeping beauty's colors |

**Color Arc within Act I:** The act begins in rich golden light (scenes 1-3), gradually introducing cooler undertones in the shadows (scenes 4-6), and ends with Layla bathed in a single amber spotlight at the piano — a warm but solitary light.

---

### ACT II: THE CRACK — **Cyan / Teal / Sea Glass**

| Element | Color | Emotional Function |
|---------|-------|-------------------|
| **Dominant** | Sea cyan (#4A9B9B) | Awakening, cool aliveness, the color of Karim's world |
| **Accent** | Coral / warm pink (#F08080) | The heat beneath the cool — desire emerging |
| **Shadow** | Deep navy (#1A3A5C) | The depth of what is being hidden |
| **Light sources** | Overcast natural light, blue hour, moonlight | Transition time — neither day nor night |
| **Nature** | The sea, open sky, rain | Elements that cannot be controlled — what Layla craves |
| **Wardrobe — Layla** | Soft blues, teals, whites | Cool colors = awakening from the warm sleep of Act I |
| **Wardrobe — Karim** | Denim, faded blue, grey | The color of distance and documentation |
| **Wardrobe — Yousef** | Stays in warm tones | He is still in the old world, unaware it has changed temperature |

**Color Arc within Act II:** The act begins with Layla in her cream/gold wardrobe (Act I residue), but as she spends time with Karim, she gradually appears in blues and teals. The contrast between her and Yousef in their scenes together becomes visually painful — warm and cool in the same frame, incompatible temperatures.

---

### ACT III: THE SPIRAL — **Muted Violet / Dusty Rose / Bruised Purple**

| Element | Color | Emotional Function |
|---------|-------|-------------------|
| **Dominant** | Dusty violet (#7B6B8D) | Moral confusion, the color of twilight — neither day nor night, neither right nor wrong |
| **Accent** | Bruised rose (#9B6B7B) | The physicality of emotional pain — the color of a healing wound |
| **Shadow** | Deep plum (#4A2C3A) | The darkness of guilt, shame, the unspoken |
| **Light sources** | Fluorescent, streetlight, screen glow | Artificial, harsh, exposing |
| **Interior** | Layla's studio, nighttime rooms | Spaces that feel both intimate and imprisoning |
| **Wardrobe — All characters** | Colors become muted, desaturated | The world is losing its vibrancy as the lie consumes everything |

**Color Arc within Act III:** The most desaturated act of the film. Colors do not pop — they bleed into each other. Yousef's warm tones become brown-grey. Layla's blues become muddy. Karim's world loses its cool clarity. The act ends in near-monochrome — the color has been drained by the lie.

---

### ACT IV: THE COLLAPSE — **Slate Grey / Storm Blue / Ash**

| Element | Color | Emotional Function |
|---------|-------|-------------------|
| **Dominant** | Slate grey (#708090) | Devastation, the color of ruins, of unfinished buildings |
| **Accent** | Storm blue (#4A6B8D) | Cold grief, the color of Yousef's emotional state |
| **Emergency color** | Blood red (#8B0000) | Rage, the fight scene, the moment violence enters |
| **Shadow** | Charcoal black (#36454F) | The void, the unbuilt concert hall at night |
| **Light sources** | Neon, emergency lights, darkness | The world has become hostile, exposing, unbearable |
| **Wardrobe — Yousef** | Dark grey, black, concrete colors | He has become the ruin he feared |
| **Wardrobe — Layla** | Pale, almost colorless | Guilt has bleached her |

**Color Arc within Act IV:** This act begins in muted purples (transition from Act III) and rapidly descends into grey. The fight scene introduces blood red — the only vivid color in the act, and it is violent. The confession scene is nearly black-and-white. The concert hall at night is a cathedral of grey shadows.

---

### ACT V: THE RUINS — **Pale Green / Dawn Grey / Soft Silver**

| Element | Color | Emotional Function |
|---------|-------|-------------------|
| **Dominant** | Pale sage (#9DC183) | New growth in ruins, the first color of recovery, fragile |
| **Accent** | Dawn grey (#B0B8B4) | The grey is not the dark grey of Act IV — it is the grey of dawn, not dusk |
| **Warm return** | Soft gold (#D4C4A8) | Memory as gentle, not painful — Yousef's smile scene |
| **Light sources** | Morning light, overcast but bright | The world is not sunny, but it is visible again |
| **Nature** | Green plants in Layla's apartment, rain on windows | Life continues, grows, even in isolation |
| **Wardrobe — Yousef** | Softer greys, a touch of earth tone | He is not warm yet, but he is no longer cold |
| **Wardrobe — Layla** | White, soft green | Clean, self-determined, new |

**Color Arc within Act V:** The act begins in pale tones — almost colorless. Gradually, soft greens and gentle golds emerge. The final shot of the concert hall is bathed in a silver-grey light that contains all colors — a prism, not a void. The emotional palette suggests that the characters have learned to hold all emotions simultaneously, rather than being defined by one.

---

## 5. Tension / Release Rhythm Design

### 5.1 The Heartbeat of the Film

The film's emotional rhythm follows a modified **cardiac pattern** — tension builds like a heartbeat accelerating, then releases. But unlike a regular heartbeat, the intervals become shorter and the peaks higher as the film progresses, until the heart is racing (Act IV), then gradually slows (Act V) — not to normal, but to a new, slower rhythm of recovery.

### 5.2 Tension/Release Per Act

#### ACT I: Slow Heartbeat (60 BPM)
- **Pattern:** Tension 2 min / Release 3 min
- **Rhythm:** Leisurely, observational, hypnotic
- **Pacing:** Long takes, minimal cuts, the camera lingers like memory
- **Key Technique:** The release is beautiful but slightly unsettling — we enjoy the warmth but feel something missing

#### ACT II: Accelerating (80 BPM)
- **Pattern:** Tension 3 min / Release 2 min
- **Rhythm:** The release periods become shorter; tension periods lengthen
- **Pacing:** Shorter scenes, cross-cutting between Yousef/Layla and Layla/Karim
- **Key Technique:** The "beautiful moments" with Karim are releases, but they carry tension because we know they are transgressive

#### ACT III: Racing (100 BPM)
- **Pattern:** Tension 4 min / Release 1 min
- **Rhythm:** Breathless. The release moments are brief and tinged with dread
- **Pacing:** Rapid cross-cutting, parallel actions building to collision
- **Key Technique:** Scene 26 (Yousef's car breakdown) is a forced release — a scream that briefly drops the tension before it builds again

#### ACT IV: Tachycardia (120 BPM) — then Cardiac Arrest
- **Pattern:** Tension 5 min / Release 30 sec / Catastrophic release (Act IV catharsis)
- **Rhythm:** Unsustainable intensity, then a flatline moment after the confession
- **Pacing:** The confrontation scenes are fast; the aftermath is slow, almost frozen
- **Key Technique:** After Scene 33 (confession), the film enters a "flatline" — 5 minutes of near-static, minimal dialogue, long takes. The audience needs to process.

#### ACT V: Recovery Rhythm (50 BPM)
- **Pattern:** Tension 1 min / Release 4 min
- **Rhythm:** Slow, spacious, generous with time
- **Pacing:** Long takes return, but they are not hypnotic like Act I — they are contemplative, awake
- **Key Technique:** The final 10 minutes have almost no tension. The audience is allowed to simply be with the characters.

### 5.3 Scene-by-Scene Tension/Release Map

```
Tension Level (0-10)

10 |                                              ██
 9 |                                       ██ ██ ██
 8 |                                  ██ ██ ██ ██ ██
 7 |                             ██ ██ ██ ██ ██ ██ ██
 6 |                        ██ ██ ██ ██ ██ ██ ██ ██
 5 |                   ██ ██ ██ ██ ██ ██ ██ ██ ██ ██
 4 |              ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██
 3 |         ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██
 2 |    ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██
 1 | ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██ ██
 0 |___________________________________________________
       Act I      Act II      Act III     Act IV    Act V
```

### 5.4 Micro-Rhythm Within Scenes

#### Pattern A: The Slow Burn (Used in Act I, early Act II)
- Open with wide shot (30 sec) — environment, context
- Move to medium shot (1 min) — character interaction
- Tighten to close-up (30 sec) — emotional detail
- Cut to reaction (15 sec) — internal response
- Release with wide shot or cut away (15 sec)

#### Pattern B: The Cross-Cut Tightening (Used in Act II-III)
- Scene A begins (30 sec)
- Cut to Scene B, same emotional beat (20 sec)
- Return to Scene A, closer (25 sec)
- Return to Scene B, closer (20 sec)
- Cut to third location or close-up reaction (15 sec)
- The scenes are getting shorter and tighter — the net is closing

#### Pattern C: The Claustrophobic Hold (Used in Act III-IV)
- Scene opens in close-up already (no establishing shot)
- The camera stays close, refusing to give space
- Even when characters move apart, the lens keeps them visually close — the frame is suffocating
- Only breaks with a violent cut to extreme wide shot — the world is vast and they are alone

#### Pattern D: The Spacious Contemplation (Used in Act V)
- Wide establishing shot (45 sec) — the world is large, they are small
- Character enters, but camera does not rush to them
- They exist within the frame, not dominating it
- This communicates: the world continues. They are part of it, not its center.

### 5.5 Breathing Room Placement

| Location | Scene | Duration | Function |
|----------|-------|----------|----------|
| After Scene 5 (bed scene) | Yousef watches Layla sleep | 20 sec | Let the silence resonate |
| After Scene 12 (Layla plays) | Hold on her hands after the last note | 15 sec | Beauty needs space |
| After Scene 17 (the kiss) | Fade to black, 3 seconds | 3 sec | The audience needs to exhale |
| After Scene 26 (car breakdown) | Silence, empty street | 30 sec | Cathartic release |
| After Scene 33 (confession) | Static shot of empty room | 45 sec | The void after truth |
| After Scene 38 (concert hall completion) | Wide shot of empty building | 20 sec | Monument to absence |
| Final scene | Hold on concert hall, people entering | 30 sec | Life continues |

---

## 6. Catharsis Moment Engineering

### 6.1 Definition of Catharsis in This Film

Catharsis in "حب وخيانة" is not "feeling better." It is **"feeling fully."** The audience must not leave relieved. They must leave *emptied* — as if they have lived an entire emotional life in two hours, and the space where that life was is now clean, clear, and strangely peaceful.

### 6.2 Primary Catharsis: Scene 33 — THE CONFESSION

**Setup (Scenes 1-32):**
- Every scene before this has been a brick in a wall of lies
- The audience knows the truth, Yousef suspects it, Layla carries it
- The tension has become unbearable — not just for the characters, but for the audience
- We have been *waiting* for this moment, both dreading it and needing it

**The Cathartic Moment:**
- Yousef does not ask. Layla does not wait to be asked.
- She says: "I did not sleep with him. But I betrayed you more than if I had."
- The confession is not about sex. It is about emotional abandonment.
- Yousef does not scream. He goes very still.
- The camera holds on his face for 45 seconds. We watch him feel everything.
- Then he says: "When did you stop playing the piano?" — not an accusation, but a recognition that he noticed but did not act.

**Why This Is Cathartic:**
- **Recognition:** We have all had truths we knew but avoided
- **Relief:** The lie is over. The worst has happened. We can stop fearing it.
- **Beauty in destruction:** There is a terrible beauty in total honesty
- **Empathy:** We feel for both of them simultaneously — there is no winner

**Pacing:**
- The scene is 7 minutes long — the longest in the film
- It uses Pattern C (claustrophobic hold) for 5 minutes, then Pattern D (spacious contemplation) for the final 2 minutes as Yousef leaves the house

---

### 6.3 Secondary Catharsis: Scene 26 — THE SCREAM

**Setup:**
- Yousef has been holding everything together
- He has been the rational architect, the controlled man
- The audience has been feeling his suppression as physical tension

**The Cathartic Moment:**
- In his car, alone, at night, in the parking lot of the unfinished concert hall
- He screams. Not a movie scream — a human scream. Ugly, broken, animal.
- The camera stays outside the car. We see him through glass, distorted.
- The scream lasts 10 seconds. Then silence.
- He sits there for 2 minutes. We sit with him.

**Why This Is Cathartic:**
- **Vicarious release:** The audience's tension is released through his
- **Permission:** It gives the audience permission to feel their own suppressed grief
- **Honesty:** It is not cinematic or beautiful. It is raw. That makes it more cathartic.

---

### 6.4 Tertiary Catharsis: Scene 44 — THE MUTUAL RECOGNITION

**Setup:**
- The entire film has been about seeing and not seeing
- Yousef did not see Layla's emptiness. Layla did not see Yousef's fear. Karim saw everything but did not understand it.
- The audience has wanted them to reunite, to fix it, to go back.

**The Cathartic Moment:**
- Layla is performing. Yousef is in the audience.
- She looks up and sees him. He does not look away.
- They look at each other for 5 seconds.
- Then she returns to her music. He stays. The concert continues.

**Why This Is Cathartic:**
- **Acceptance without resolution:** They do not reunite. They simply *see* each other. That is enough.
- **Growth:** Both have become people who can be seen and who can see
- **Hope without fantasy:** It suggests a future, but does not promise one
- **Audience gift:** The audience gets what they need (hope) without being lied to (reunion)

---

### 6.5 Micro-Catharses (Emotional Echoes)

Throughout the film, smaller cathartic moments prepare the audience for the major ones:

| Scene | Moment | Type | Function |
|-------|--------|------|----------|
| 3 | Layla stops playing, silence | Mini-release | Establishes that her music is emotional truth |
| 12 | Layla plays real music again | Joy-catharsis | The audience feels her liberation |
| 15 | Layla by the sea, laughing | Freedom-catharsis | Brief, guilty joy |
| 24 | Concert performance success | Triumph-catharsis | Pride mixed with sorrow |
| 35 | Hassan's confession to Yousef | Generational catharsis | Reframing — betrayal is inherited |
| 41 | Karim's photographs arrive | Memory-catharsis | The past becomes beautiful again |

---

## 7. Music-Emotion Correspondence

### 7.1 Musical Architecture

The film's score operates on **three layers**:
1. **Layla's diegetic music** — what she plays, composes, stops playing
2. **The emotional score** — composed for the film, reflecting interior states
3. **The silence** — the absence of music is as important as its presence

**Reference Composers:**
- **Gabriel Yared** (The English Patient, A Separation) — emotional precision, Middle Eastern modal influences
- **Jóhann Jóhannsson** (Arrival, Theory of Everything) — mathematical beauty, architecture as music
- **Ryuichi Sakamoto** (Merry Christmas Mr. Lawrence, The Revenant) — spare, devastating emotional clarity
- **Fairouz / Marcel Khalife** — Arabic musical emotional vocabulary, the maqam system
- **Abdel Wahab / Um Kulthum** — the tarab tradition of musical ecstasy and emotional surrender

---

### 7.2 Diegetic Music: Layla's Piano

**Act I — Mechanical Music:**
- Layla plays scales, exercises, familiar pieces
- The music is technically perfect but emotionally absent
- **Maqam:** Bayati — traditional, stable, but without improvisation (taqsim) that would make it alive
- **Audience emotion:** Recognition of beauty that has lost its soul

**Act II — Reawakening:**
- Layla begins playing old compositions, fragments
- The music is hesitant, then more confident
- **Maqam:** Hijaz — the mode of longing, beauty mixed with melancholy
- **Audience emotion:** Joy mixed with dread — we know this happiness is borrowed

**Act III — The Affair as Music:**
- Layla composes a new piece — passionate, complex, alive
- She plays it for Karim. It is the most beautiful music in the film.
- **Maqam:** Rast — the mode of joy, but with an underlying tension (the "quarter-tone" that never fully resolves)
- **Audience emotion:** Ecstasy and guilt — the music is the affair, and it is gorgeous

**Act IV — Silence:**
- Layla sits at the piano. Her hands hover. Nothing comes.
- When she tries to play, it is discordant, wrong.
- **Maqam:** None. Silence. Or Saba — the mode of deep sorrow, rarely used because it is too painful
- **Audience emotion:** The loss of music is the loss of self

**Act V — Solo Music:**
- Layla composes a new piece — not for Yousef, not for Karim, for herself
- It is simpler than her Act III composition. But it is true.
- **Maqam:** Nahawand — the mode of farewell, of acceptance, of gentle sadness
- **Audience emotion:** Peace, not happiness. The music has become honest.

---

### 7.3 Emotional Score: Film Music

**Act I Theme — "The Edifice"**
- Instrumentation: Solo piano + strings + subtle oud
- Rhythm: Steady, measured, like architectural plans
- Emotional function: The beauty of order, the sadness of rigidity
- **Key moments:** Opening credits, Yousef at work, the concert hall design

**Act II Theme — "The Awakening"**
- Instrumentation: Solo violin (Karim's theme) + piano (Layla) intertwining
- Rhythm: Irregular, improvisational, breathing
- Emotional function: The pull of desire, the danger of aliveness
- **Key moments:** Layla and Karim by the sea, the first kiss, Layla's changed energy

**Karim's Theme — "The Witness"**
- Instrumentation: Solo cello, dry recording, no reverb
- Rhythm: Sparse, unpredictable — like a shutter clicking
- Emotional function: The beauty of ruins, the charisma of destruction
- **Key moments:** Karim's photographs, his nightmares, his confession

**Act III Theme — "The Spiral"**
- Instrumentation: Full orchestra, but discordant — strings fighting each other
- Rhythm: Accelerating, then stopping abruptly
- Emotional function: The lie consuming everything, the anxiety of complicity
- **Key moments:** Yousef's suspicion, the parallel lives, the concert performance

**Act IV Theme — "The Collapse"**
- Instrumentation: Solo piano, but damaged — detuned slightly, with pedal held too long
- Rhythm: Chaotic, then a single sustained note
- Emotional function: The end of everything built
- **Key moments:** The confession, Yousef's car scream, the empty concert hall

**Act V Theme — "The Ruins"**
- Instrumentation: Solo piano + ambient natural sounds (rain, wind, distant traffic)
- Rhythm: Slow, spacious, with long rests between phrases
- Emotional function: Recovery, not resolution. Life in the aftermath.
- **Key moments:** Layla in her apartment, Yousef giving away the concert hall, the final scene

---

### 7.4 Silence as Music

| Location | Duration | Function |
|----------|----------|----------|
| After Scene 5 (bed, backs to each other) | 10 sec | The silence of the marriage |
| After Scene 17 (the kiss) | 5 sec | The silence of transgression |
| Scene 33, before the confession | 15 sec | The silence before truth |
| After Yousef's scream (Scene 26) | 30 sec | The silence after catharsis |
| Scene 36 (Layla at piano, nothing comes) | 20 sec | The silence of lost art |
| Scene 44 (mutual recognition) | 5 sec | The silence of understanding |
| Final shot | 10 sec | The silence of continuation |

**Musical Rule:** Every act of the film must contain at least 30 seconds of total silence (non-diegetic). Act IV contains 90 seconds. Act V contains 60 seconds.

---

### 7.5 Music-Color Correspondence

| Act | Dominant Color | Musical Key/Maqam | Emotional Synthesis |
|-----|---------------|-------------------|---------------------|
| I | Amber/Gold | Bayati (stable, warm) | Warmth with hidden rigidity |
| II | Cyan/Teal | Hijaz (longing, beauty) | The cool blue of awakening desire |
| III | Violet/Rose | Rast (joy with tension) | The confused beauty of the affair |
| IV | Slate Grey | Saba (deep sorrow) | The monochrome of devastation |
| V | Pale Green | Nahawand (gentle farewell) | The fragile green of new growth |

---

## 8. Scene-by-Scene Emotional Beat Sheet

### BEAT LEGEND
- **Beat Type:** Hope (H), Fear (F), Love (L), Loss (Ls), Triumph (T), Despair (D), Guilt (G), Truth (Tr)
- **Intensity:** 1-10 scale
- **Setup/Payoff:** S = setup, P = payoff, E = echo
- **Color coding is implicit in the scene design**

---

### ACT I: THE EDIFICE

| # | Scene | Beat Type | Intensity | Setup/Payoff | Notes |
|---|-------|-----------|-----------|--------------|-------|
| 1 | Morning routine | H/Ls | 3 | S: The marriage S: The silence | Beautiful but hollow. We feel the absence of what was |
| 2 | Yousef at work | T | 3 | S: The concert hall S: Yousef's control | Architecture as emotional metaphor |
| 3 | Layla at piano | Ls | 4 | S: The lost music P (echo later): Act V music | Most important setup in the film |
| 4 | Dinner with Hassan | H | 2 | S: Generational pattern S: Cultural pressure | Warmth masking rigidity |
| 5 | Bed scene, backs to each other | Ls | 5 | S: The physical distance P (Act IV): Separation | The marriage's ghost |
| 6 | Karim exhibition | F/H | 3 | S: Karim S: Photography as truth | Intrigue, charisma of danger |
| 7 | Layla sees Karim's work | L | 5 | S: The awakening P (Act III): The affair | First emotional pivot |
| 8 | Yousef offers concert hall | H | 4 | P (Act IV): The unbuilt building S: The gift | Irony: he gives her what she needs, but not how she needs it |

**Act I Emotional Summary:**
- Total beats: 8
- Hope: 3 | Fear: 1 | Love: 1 | Loss: 2 | Triumph: 1
- Average intensity: 3.4
- Setup beats: 6 | Payoff beats: 0 (all setup)

---

### ACT II: THE CRACK

| # | Scene | Beat Type | Intensity | Setup/Payoff | Notes |
|---|-------|-----------|-----------|--------------|-------|
| 9 | Dinner with Karim | H/F | 4 | S: The triangle P (Act III): The affair | Social pleasure masking danger |
| 10 | Karim and Layla discuss music | L | 6 | S: Emotional intimacy | Not sexual — deeper |
| 11 | Yousef notices change | F | 4 | P (Act I): The routine changed | He is happy she's happy — the tragedy |
| 12 | Layla plays real music | T/L | 7 | P (Act I): The lost music S: The composition | The most beautiful moment so far |
| 13 | Amal warns Layla | F | 5 | S: The witness S: Moral voice | The audience's surrogate speaks |
| 14 | Yousef finds the book | F | 5 | P (Act II): Karim's presence S: Suspicion | The crack becomes visible |
| 15 | Karim and Layla at sea | L/H | 6 | S: The freedom S: The transgression | Water = uncontrollable emotion |
| 16 | Yousef alone in concert hall | Ls | 4 | P (Act I): The concert hall S: Loneliness | Building what he cannot feel |
| 17 | The first kiss | L/G | 7 | P (Act II): The tension S: The betrayal | Complicity peak |
| 18 | Layla lies to Yousef | G/F | 5 | S: The lie P (Act III): The spiral | The lie is the real betrayal |

**Act II Emotional Summary:**
- Total beats: 10
- Hope: 1 | Fear: 4 | Love: 3 | Loss: 1 | Triumph: 1 | Guilt: 2
- Average intensity: 5.1
- Setup beats: 5 | Payoff beats: 3 | Echo beats: 0

---

### ACT III: THE SPIRAL

| # | Scene | Beat Type | Intensity | Setup/Payoff | Notes |
|---|-------|-----------|-----------|--------------|-------|
| 19 | Yousef tries to reconnect | Ls | 4 | P (Act II): The distance S: Failed reconnection | His attempts are mechanical |
| 20 | Layla tries to end it | F/G | 5 | P (Act II): The affair S: Inability to stop | "I can't. Not yet." |
| 21 | Karim shows war photographs | Ls/L | 4 | S: Shared trauma | Bonding through pain |
| 22 | Yousef discovers text | F | 6 | P (Act II): Suspicion S: Confirmation | The moment of knowing |
| 23 | Yousef asks "Are you happy?" | F/Ls | 7 | P (Act I): The marriage S: The indirect confrontation | Devastating delicacy |
| 24 | Layla's concert | T/G | 6 | P (Act I): The music P (Act II): The playing | Genius mixed with guilt |
| 25 | Yousef sees them together | F/D | 7 | P (Act II): The affair S: The visible triangle | Jealousy, rage, helplessness |
| 26 | Yousef's car breakdown | D | 9 | P (All Acts): Suppression P: The scream | Secondary catharsis |
| 27 | Yousef eerily calm | F | 6 | S: The before-storm | More frightening than rage |
| 28 | Amal tells Yousef | Tr/F | 7 | P (Act II): Amal's warning S: The truth enters | The truth through a third party |

**Act III Emotional Summary:**
- Total beats: 10
- Hope: 0 | Fear: 5 | Love: 1 | Loss: 2 | Triumph: 1 | Despair: 1 | Guilt: 2 | Truth: 1
- Average intensity: 6.2
- Setup beats: 3 | Payoff beats: 5 | Echo beats: 0

---

### ACT IV: THE COLLAPSE

| # | Scene | Beat Type | Intensity | Setup/Payoff | Notes |
|---|-------|-----------|-----------|--------------|-------|
| 29 | Yousef becomes cold | F | 6 | P (Act III): The confirmation S: The wall | Building emotional walls |
| 30 | Layla tries to reach him | G/Ls | 5 | P (Act III): The withdrawal | "Talk to me." "About what?" |
| 31 | Karim comes to house | F/D | 8 | P (Act II): The affair S: The confrontation | Inevitable collision |
| 32 | Physical fight | D/G | 8 | P (All Acts): Rage P: Violence | Not triumphant — pathetic |
| 33 | THE CONFESSION | Tr/D | 10 | P (All Acts): The lie P: Primary catharsis | THE CATHARSIS |
| 34 | Yousef leaves for concert hall | D | 9 | P (Act I): The concert hall | The unbuilt building |
| 35 | Hassan's confession | Tr/Ls | 7 | P (Act I): Generational pattern P: Reframing | "I endured. I don't know if that was strength." |
| 36 | Layla, piano, silence | Ls | 8 | P (Act I): The music P (Act III): The playing | The music has left |

**Act IV Emotional Summary:**
- Total beats: 8
- Hope: 0 | Fear: 2 | Love: 0 | Loss: 3 | Triumph: 0 | Despair: 3 | Guilt: 1 | Truth: 2
- Average intensity: 7.6
- Setup beats: 1 | Payoff beats: 7 | Echo beats: 0

---

### ACT V: THE RUINS

| # | Scene | Beat Type | Intensity | Setup/Payoff | Notes |
|---|-------|-----------|-----------|--------------|-------|
| 37 | Weeks later, same room, silence | Ls | 5 | P (Act IV): The aftermath | Not divorced. Not together. |
| 38 | Yousef completes concert hall | T/Ls | 5 | P (Act I): The building S: Completion | Finishing for himself, not her |
| 39 | Layla composes alone | H | 4 | P (Act IV): The silence P: The solo music | Music returns, transformed |
| 40 | Yousef gives hall away | Tr | 4 | P (Act I): The gift S: Relinquishment | The gift becomes release |
| 41 | Karim's photographs arrive | Ls/H | 3 | P (Act I): The exhibition S: Memory | He documents what they lost |
| 42 | Yousef smiles | H | 2 | P (All Acts): The grief | First smile in the second half |
| 43 | Layla performs new composition | T | 5 | P (Act I): The music P (Act IV): The silence | The music is about self |
| 44 | Mutual recognition | Tr/H | 4 | P (All Acts): The seeing | Secondary catharsis |
| 45 | Final shot — concert hall, filled, separately | H/Ls | 3 | P (All Acts): The story | Life continues. Beauty endures. |

**Act V Emotional Summary:**
- Total beats: 9
- Hope: 4 | Fear: 0 | Love: 0 | Loss: 3 | Triumph: 2 | Despair: 0 | Truth: 1
- Average intensity: 3.8
- Setup beats: 1 | Payoff beats: 7 | Echo beats: 1

---

### COMPLETE FILM BEAT STATISTICS

| Category | Count | % of Total |
|----------|-------|------------|
| **Hope** | 9 | 22% |
| **Fear** | 12 | 29% |
| **Love** | 4 | 10% |
| **Loss** | 11 | 27% |
| **Triumph** | 5 | 12% |
| **Despair** | 4 | 10% |
| **Guilt** | 5 | 12% |
| **Truth** | 5 | 12% |
| **Total Beats** | 45 | 100% |

*(Note: Beats can carry multiple emotions; percentages reflect primary classification)*

---

## 9. Subtext & Emotional Layering Guide

### 9.1 Unspoken Emotions in Dialogue

The dialogue in "حب وخيانة" operates on three levels:

**Level 1: The Literal**
- What the characters say
- Example: "Did you have a good day?" — Yousef, Scene 23

**Level 2: The Emotional Truth**
- What the characters mean
- Example: "Did you have a good day?" = "Are you with him? Do I still matter?"

**Level 3: The Universal**
- What the audience feels
- Example: "Did you have a good day?" = "I too have asked this question knowing I didn't want the answer."

### 9.2 Key Subtext Moments

| Scene | Spoken | Unspoken | Audience Layer |
|-------|--------|----------|----------------|
| 3 | "I'm practicing" (Layla) | "I have nothing to say through music anymore" | The death of art in a dying relationship |
| 8 | "I want you to play there" (Yousef) | "I want to give you what you need without understanding what you need" | Gifts as substitutes for presence |
| 10 | "You compose?" (Karim) | "You are more than what your marriage allows you to be" | Recognition as seduction |
| 14 | "Where did you get this?" (Yousef, finding the book) | "I know something is wrong and I am afraid to know more" | The terror of confirmation |
| 23 | "Are you happy?" (Yousef) | "I know you're not. I know I'm not. Can we admit it?" | The question that contains the answer |
| 30 | "Talk to me" (Layla) | "I have destroyed us and I don't know how to fix it" | The helplessness after confession |
| 33 | "When did you stop playing the piano?" (Yousef) | "I noticed. I noticed everything. I just didn't know what to do." | The tragedy of observation without action |
| 35 | "I endured" (Hassan) | "I made the same mistake. Silence is not strength." | Generational inheritance of emotional failure |
| 40 | "It's for the city" (Yousef, giving away the hall) | "I built this for love, but love failed. So I give it to strangers." | The transformation of private grief into public gift |
| 44 | [No dialogue — mutual look] | "I see you. I am seen. That is enough." | The final truth: being seen is the fundamental need |

### 9.3 Visual Emotional Cues

| Visual Element | Emotional Function | Key Scenes |
|----------------|-------------------|------------|
| **Yousef's hands** | Control vs. breakdown | Calm and precise in Act I; trembling in Act III; empty, open in Act V |
| **Layla's hands on piano** | Emotional truth | Mechanical (Act I) → Alive (Act II) → Flying (Act III) → Frozen (Act IV) → Sure (Act V) |
| **Doorways** | Thresholds of truth | Characters stand in doorways before crossing emotional thresholds |
| **Mirrors / reflections** | Self-knowledge | Characters see themselves distorted before moments of realization |
| **Water** | Uncontrollable emotion | Sea (Act II), rain (Act III), bath (Act IV), dew (Act V) |
| **Unfinished building** | Incomplete love | The concert hall grows through the film; completed but given away |
| **Empty chairs** | Absence | A chair left empty becomes a character in the frame |

### 9.4 Pacing Emotional Manipulation

| Technique | Function | Used In |
|-----------|----------|---------|
| **Slow motion** | Time dilating around emotional peaks | The kiss (Scene 17), the confession (Scene 33) |
| **Freeze frame** | The photograph as truth | Karim's photographs punctuate the film as emotional stillness |
| **Long take** | Refusal to let the audience escape the emotion | Yousef's face during confession (45 seconds) |
| **Jump cut** | Emotional whiplash | Yousef's memory of happy moments cuts to present devastation |
| **Frame within frame** | Confinement | Characters seen through windows, doorways, mirrors — trapped |
| **Overhead shot** | The god's-eye view of human folly | Used twice: the kiss (moral judgment) and the final scene (continuity) |

### 9.5 Foreshadowing of Emotional Moments

| Setup (Early) | Payoff (Late) | Emotional Effect |
|---------------|---------------|------------------|
| Scene 3: Layla stops playing | Scene 36: Layla cannot play | The music was the marriage; when the marriage dies, so does the music |
| Scene 5: Backs to each other in bed | Scene 37: Separate in same room | The physical distance was always there; it just became visible |
| Scene 6: Karim photographs ruins | Scene 34: Yousef in the unbuilt hall | Karim's art form becomes Yousef's reality |
| Scene 8: "I want you to play there" | Scene 40: Yousef gives hall away | The gift built for love becomes a gift of letting go |
| Scene 12: Layla's first real music | Scene 43: Layla's solo composition | The music returns, but it is no longer a duet |
| Scene 21: Karim's war photographs | Scene 41: Karim's photographs of Yousef and Layla | The witness becomes a mirror; he documents what they lost |

---

## APPENDIX A: Emotional Resonance Targets

### Target Audience Emotional States (Post-Viewing)

| Timeframe | Target Emotional State | Measurement |
|-----------|----------------------|-------------|
| Immediately after | Emptied, quiet, contemplative | Audience sits through credits in silence |
| 1 hour after | Processing, discussing | Audience wants to talk, not immediately judge |
| 1 day after | Recognition | Audience applies film to their own relationships |
| 1 week after | Integration | Film becomes reference point for emotional honesty |
| Long-term | Cathartic memory | Film recalled as "the one that made me feel everything" |

### Cultural Emotional Specificity

| Arabic Emotional Concept | Film Expression | Universal Equivalent |
|--------------------------|-----------------|----------------------|
| **Hob (حب)** | The original marriage, the lost connection | Love as presence |
| **Gharam (غرام)** | Layla's awakening with Karim | Passion as recognition |
| **Khiana (خيانة)** | Not just the affair, but the years of silence | Betrayal as emotional abandonment |
| **‘Ar (عار)** | Hassan's shame, the community weight | Shame as inherited silence |
| **Waja‘ (وجع)** | Yousef's scream, Layla's silent piano | Grief as physical sensation |
| **Sabr (صبر)** | Hassan's forty years of endurance | Endurance as moral ambiguity |
| **Tarab (طرب)** | Layla's music in Act III | Ecstasy as danger |
| **Wisal (وصال)** | The mutual recognition in Scene 44 | Union through seeing, not possessing |

---

## APPENDIX B: Emotional Pacing Checkpoints

### Before Each Act Transition, Audience Should Feel:

| Transition | Checkpoint | If Missing, Fix |
|------------|-----------|-----------------|
| I → II | "Something is about to change" | Increase subtext in final Scene I scene |
| II → III | "This cannot continue, and it will" | Heighten the moral tension in Scene 18 |
| III → IV | "I cannot bear the tension anymore" | Ensure Scene 26 delivers cathartic release |
| IV → V | "Everything is ruined. What now?" | Allow flatline time after confession |

### Emotional Milestones (Audience must feel by this point)

| Milestone | Scene | Expected Audience State |
|-----------|-------|------------------------|
| Investment | Scene 3 | "I care about these people" |
| Complicity | Scene 17 | "I understand why this is happening, even though I know it's wrong" |
| Fear | Scene 25 | "I am afraid of what will happen when he finds out" |
| Catharsis | Scene 33 | "I needed this. It hurts, but I needed it." |
| Hope | Scene 44 | "I don't need them to reunite. I just need them to be okay." |
| Peace | Scene 45 | "Life continues. That is enough." |

---

**Document Status:** COMPLETE  
**Prepared for:** Director, Cinematographer, Composer, Production Designer, Actors  
**Next Pipeline Stage:** Visual Storyboard Integration (Color + Camera + Emotional Beats)  

---

> *"الحب ليس قلعة نبنيها مرة واحدة. الحب حديقة نسقيها كل يوم، أو نتركها تموت."*
> 
> *("Love is not a castle we build once. Love is a garden we water every day, or we let it die.")*
> 
> — The emotional thesis of **حب وخيانة**
