# حب وخيانة — Love and Betrayal
## Cinematic Direction Document
### Cinematic Director — "From Storyboard To Vision" Production Pipeline
**Date:** 2026-05-25
**Project:** The Garden of Broken Mirrors
**Runtime Target:** 105 minutes
**Format:** Romantic Psychological Drama / Neo-Noir Romance / Espionage Thriller

---

## TABLE OF CONTENTS

1. [Visual Style Guide](#1-visual-style-guide)
2. [Camera Philosophy & Visual Language](#2-camera-philosophy--visual-language)
3. [Composition Rules & Aspect Ratio](#3-composition-rules--aspect-ratio)
4. [Shot-by-Shot Design — 8 Key Scenes](#4-shot-by-shot-design--8-key-scenes)
5. [Lighting Design Per Scene](#5-lighting-design-per-scene)
6. [Transition Design & Editorial Philosophy](#6-transition-design--editorial-philosophy)
7. [Pacing & Visual Rhythm Analysis](#7-pacing--visual-rhythm-analysis)
8. [Lens Language Guide](#8-lens-language-guide)
9. [Visual References & Cinematic Comps](#9-visual-references--cinematic-comps)

---

## 1. VISUAL STYLE GUIDE

### 1.1 Aspect Ratio & Frame Philosophy

**Primary Aspect Ratio: 2.39:1 (Anamorphic Widescreen)**

**Justification:** The widescreen frame serves dual emotional functions in this film. First, the horizontal expanse creates a sense of *distance* even in intimate domestic spaces — Yasmin and Omar can sit in the same room and the frame emphasizes the gulf between them. Second, the anamorphic format's characteristic lens flares, oval bokeh, and subtle barrel distortion create a "soft surveillance" aesthetic — the world always feels slightly observed, slightly distorted, as if viewed through a long lens or a two-way mirror.

**Reference Precedents:**
- Wong Kar-wai's *In the Mood for Love* (2.39:1) — intimacy within widescreen frames
- Roger Deakins on *Sicario* (2.39:1 anamorphic) — moral ambiguity through frame width
- Bradford Young on *Arrival* (2.39:1) — emotional isolation in vast frames

**Secondary Aspect Ratio: 4:3 ( Academy Ratio)**

**Usage:** Only for the surveillance footage Yasmin discovers — her own file, the photographs, any archival or "recorded" material. The abrupt shift to 4:3 signals "documentary truth" invading the narrative. The boxed-in frame suggests entrapment, the past as prison.

### 1.2 Frame Rate & Motion Style

**Base Frame Rate: 24fps** — Cinematic standard. The slight stutter of 24fps creates an unconscious "memory" quality.

**Slow Motion: 48fps played at 24fps (2×)**
- The moment Yasmin discovers the second phone — time stretches as her reality fractures
- The piano destruction scene — each shard of wood and wire suspended in air
- The final unresolved note — Yasmin's finger hovering, the note ringing past its natural decay

**Undercranked: 12fps played at 24fps (2× fast)**
- Brief passages of surveillance montage — the cold efficiency of operational life
- The drive to the safe house — Yasmin's heartbeat accelerating the world

### 1.3 Color Palette (Hex-Coded, Act-by-Act)

The palette follows the Emotional Narrative Design exactly, with cinematic translation:

#### ACT I: THE SURFACE (0:00–26:00)
| Role | Color | Hex | Application |
|------|-------|-----|-------------|
| **Dominant** | Warm Amber | `#D4A574` | Interiors, skin tones, lamplight, golden hour exteriors |
| **Secondary** | Cream White | `#F5F5DC` | Wardrobe, walls, piano keys — the surface of perfection |
| **Shadow** | Deep Brown | `#5C4033` | Deep shadows, wood grain, leather — warmth with suffocation |
| **Accent** | Brass Gold | `#B5A642` | Wedding ring, piano hardware, watch, doorknobs — the lie that glitters |

**Grade Direction:** Warm highlights (3200K feel), lifted blacks with brown undertone, gentle roll-off in highlights. Shot on film or emulated with Arri Alexa 35 with custom LUT "Amber Cairo." Reference: *Cairo Time* (Ruba Nadda, 2009) meets *The Immigrant* (James Gray, 2013).

#### ACT II-A: THE CRACK (26:00–52:00)
| Role | Color | Hex | Application |
|------|-------|-----|-------------|
| **Dominant** | Sea Cyan | `#4A9B9B` | Night exteriors, Zamalek café, moonlight, Nour's wardrobe |
| **Secondary** | Coral Pink | `#F08080` | Desire emerging — lipstick, neon, wine, blush on skin |
| **Shadow** | Deep Navy | `#1A3A5C` | The depth of what hides — suit jackets, night sky, deep water |
| **Transition** | Muted Amber→Cyan | Gradient | When Yasmin moves from home to outside world, the grade shifts mid-scene |

**Grade Direction:** Cooler key light (5600K), cyan push in shadows, skin tones slightly desaturated. Reference: *Tinker Tailor Soldier Spy* (Hoyte van Hoytema) — the cold paranoia of operational spaces.

#### ACT II-B: THE ABYSS (52:00–78:00)
| Role | Color | Hex | Application |
|------|-------|-----|-------------|
| **Dominant** | Dusty Violet | `#7B6B8D` | Moral twilight — walls, wardrobe, light through curtains |
| **Secondary** | Bruised Rose | `#9B6B7B` | Physical pain of emotion — skin under harsh light, wine, bloodless lips |
| **Shadow** | Deep Plum | `#4A2C3A` | Guilt, shame, the unspoken — corners, doorways, what lies beyond |
| **Warning** | Emergency Red | `#8B0000` | Rare, bleeding in at edges — danger, the mission intruding |

**Grade Direction:** Desaturated 30% from Act I. Violet push in mid-tones. Shadows go plum rather than neutral. Skin tones lose warmth — characters look slightly ill, bruised. Reference: *Three Colors: Blue* (Sławomir Idziak) — grief as color subtraction.

#### ACT III: THE RECKONING (78:00–105:00)
| Role | Color | Hex | Application |
|------|-------|-----|-------------|
| **Dominant** | Slate Grey | `#708090` | Ruins, devastation, unbuilt concert hall, rain, fog |
| **Secondary** | Storm Blue | `#4A6B8D` | Cold grief — morning light, Yasmin's new apartment, Conservatory at night |
| **Hope** | Pale Sage | `#9DC183` | New growth — plants, first natural light in new apartment, dawn |
| **Memory** | Soft Gold | `#D4C4A8` | The photograph Omar sends — a single warm intrusion into cold reality |

**Grade Direction:** Initially monochrome-leaning (Act IV energy), with gradual reintroduction of muted color. By the final scene, full color returns but at 70% saturation — the world is visible again but never as vivid as before the truth. Reference: *Atonement* (Seamus McGarvey) — the long take on Dunkirk beach as color-of-trauma.

### 1.4 Visual Texture

**Primary Texture: Fine Film Grain**
- Kodak Vision3 500T 5219 emulation for night/interior scenes
- Kodak Vision3 250D 5207 emulation for day/exterior scenes
- Grain increases with emotional distress: Act I is clean, Act II-B is grainy (anxiety as texture), Act III returns to clean but different — the clarity of aftermath

**Secondary Texture: Clean Digital**
- Only for surveillance footage and 4:3 inserts — clinical, sharp, "true" in its artificiality

### 1.5 Overall Look Reference

> *"The film should feel like a memory that is slowly realizing it was a lie. The warmth of the opening is not nostalgic — it is the golden hour of a world that is about to end. Every frame should contain beauty and threat simultaneously."*

---

## 2. CAMERA PHILOSOPHY & VISUAL LANGUAGE

### 2.1 Core Philosophy: The Surveillance of Love

Every relationship is an act of watching. In *حب وخيانة*, the camera literalizes this. The film operates in three visual modes:

**MODE A: THE OBSERVED LIFE (Act I)**
- Camera is steady, respectful, loving
- Long takes, gentle movement, the camera "lingers" like a spouse who enjoys watching their partner
- We are complicit in the illusion — the camera doesn't interrogate, it adores

**MODE B: THE INVESTIGATING EYE (Act II-A)**
- Camera becomes suspicious
- More cuts, more reframing, the camera "checks" things — a face, a phone, a shadow
- Surveillance grammar enters: distant long lenses, partial obstruction (through doorways, across streets), the frame as interrogation

**MODE C: THE BROKEN MIRROR (Act II-B & III)**
- Camera becomes unstable, emotional, subjective
- Handheld enters for the first time — not documentary-style but *expressive* handheld (like Emmanuel Lubezki in *Children of Men* — emotional, not shaky)
- The camera can no longer hold the frame steady because Yasmin's reality cannot be held steady
- Dutch angles for moments of vertigo (the safe house discovery, the piano destruction)

### 2.2 Camera as Character

The camera has a secret: it knows Omar's truth before Yasmin does. In Act I, watch how the camera sometimes *chooses* not to follow Yasmin's eyeline, instead lingering on Omar's face a beat too long, or catching a reflection that reveals something he didn't mean to show. The camera is the first betrayer.

### 2.3 Movement Motivation Rule

**Every camera movement must answer: Who is watching, and what do they want to see?**

- **Static / Locked-off:** Acceptance, routine, the comfort of the known. The life Yasmin believes in.
- **Slow dolly/pan:** Curiosity, dawning awareness, the mind turning toward a question.
- **Handheld:** Emotional truth breaking through control. The body knows before the mind.
- **Crane / Steadicam:** The operational eye — above, detached, calculating. Omar's professional vision. Also: transcendence, the emotional overview that comes too late.
- **Surveillance movement (distant, motorized):** The cold watch of institutions. The marriage as file.

---

## 3. COMPOSITION RULES & ASPECT RATIO

### 3.1 The Frame as Architecture

Given the film's thematic obsession with architecture (Omar's constructed lives, Yasmin's father's profession, the concert hall as emotional monument), composition follows architectural principles:

**PRIMARY: Symmetry & Central Framing (Act I)**
- Yasmin in doorways, centered, the home as balanced space
- Piano lid creating horizontal symmetry — the world in harmony
- Reflections doubling the frame: mirrors, windows, polished surfaces
- Reference: Wes Anderson's centered framing but without his irony — *earnest* symmetry, the sincerity of the illusion

**SECONDARY: The Off-Balance Frame (Act II)**
- Yasmin pushed to frame edges as her world destabilizes
- Leading lines that lead nowhere — corridors ending in darkness, streets that curve away
- The rule of thirds becomes a rule of fifths — characters clinging to the edge of their own lives
- Reference: *Tinker Tailor Soldier Spy* — information framed at the margins

**TERTIARY: The Fragmented Frame (Act III)**
- Reflections that don't align — mirror images showing different angles of truth
- Over-the-shoulder shots where the shoulder dominates and the face is small, distant
- Frames within frames: doorways, windows, the proscenium arch of the concert hall
- Reference: *The Conformist* (Vittorio Storaro) — fascist architecture as psychological fracture

### 3.2 Aspect Ratio Shifts (Narrative Function)

| Moment | Ratio | Duration | Function |
|--------|-------|----------|----------|
| Film body | 2.39:1 | 100 min | The marriage as cinematic illusion |
| Surveillance footage | 4:3 | 30–90 sec inserts | Truth as prison, the file as identity |
| The piano destruction | 2.39:1 → 1.85:1 → 2.39:1 | 10 sec squeeze | The world compressing, then releasing |
| Final note | 2.39:1 → slowly narrowing to 1.85:1 | 15 sec | The aperture closing on possibility |

### 3.3 Mirror & Reflection Grammar

Mirrors are not decorative in this film — they are narrative devices:

- **Act I:** Reflections are clean, complete, comforting. Yasmin sees herself whole.
- **Act II:** Reflections show what the character doesn't see — Omar's face in a mirror while Yasmin faces away.
- **Act III:** Reflections fracture, multiply, or show the wrong angle. The safe house mirror: Yasmin's face reflected in a cabinet of her own surveillance photographs. She sees herself as file.

**Technical note:** All mirror shots will be practical (not VFX) where possible, using precise camera angles to capture both subject and reflection in emotional register.

---

## 4. SHOT-BY-SHOT DESIGN — 8 KEY SCENES

---

### SCENE 1: THE NOCTURNE (0:00–3:00)
**Beat 1 — Opening Image: Chopin Performance Duality**

**Scene Description:** Yasmin performs Chopin Nocturne in C-sharp minor at the Cairo Opera House. Cut to: the same hands, same ring, making tea in an empty apartment at 2 AM. The duality of public perfection and private emptiness.

**Shot List:**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 1.1 | NOCTURNE_01 | Extreme Close-Up | Eye-level, slightly low | Static | 100mm Macro | Razor-thin (f/2.0) | Centered on hands, ring catches stage light | 15s | Establish the instrument as voice, the ring as symbol |
| 1.2 | NOCTURNE_02 | Close-Up | Slightly high (gods-eye) | Slow tilt down | 85mm | Shallow (f/2.8) | Eyes closed, sweat on temple, rapturous but controlled | 10s | The performance face — mask of perfection |
| 1.3 | NOCTURNE_03 | Wide | Low angle from orchestra pit | Slow crane rise | 35mm | Deep (f/5.6) | Yasmin centered in concert hall grandeur, tiny against the architecture | 12s | The public self — celebrated, visible, alone |
| 1.4 | NOCTURNE_04 | Extreme Close-Up | Eye-level | Static | 135mm | Razor-thin (f/1.8) | Single piano string vibrating — the note she just played | 5s | Transition device: the note travels from public to private |
| 1.5 | NOCTURNE_05 | Medium Close-Up | Eye-level | Slow dolly in | 50mm | Shallow (f/2.0) | Yasmin in kitchen, same hands making tea, same ring in refrigerator light. Eyes: empty, exhausted | 20s | The private self — the performance has ended, the woman remains |
| 1.6 | NOCTURNE_06 | Wide | High angle (crane down) | Static | 24mm | Deep (f/4.0) | Empty apartment. Yasmin small at kitchen counter. The space swallows her. | 15s | Loneliness as architecture — the home as stage set |
| 1.7 | NOCTURNE_07 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/2.0) | Tea surface — a ripple. The last note of the Nocturne plays over. | 8s | Sound-image fusion: music becomes domestic texture |

**Camera Philosophy Notes:**
- The first four shots are "operational" — the camera is audience, admirer, spectator
- The cut to the apartment is not a match cut but a *rupture* — same hands, same ring, different universe
- Shot 1.5's slow dolly in is the first movement of emotional approach in the film. The camera wants to get closer to her emptiness.

---

### SCENE 2: THE DRAWER (8:00–12:00)
**Beat 3 — Inciting Incident: Second Phone Discovery**

**Scene Description:** Yasmin finds a second phone in Omar's nightstand. It vibrates: "Package ready. Garden entrance. Midnight." She puts it back. Practices piano for three hours. The world fractures.

**Shot List:**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 2.1 | DRAWER_01 | Medium | Eye-level, over-shoulder | Static | 35mm | Deep (f/4.0) | Yasmin putting away Omar's socks. Domestic choreography, familiar | 8s | Routine — the comfort of the known |
| 2.2 | DRAWER_02 | Close-Up | Eye-level | Static | 50mm | Shallow (f/2.8) | Her hand hesitates. The drawer doesn't close smoothly. Something blocks it. | 5s | The first wrong note — physical resistance |
| 2.3 | DRAWER_03 | Extreme Close-Up | Low angle (from inside drawer) | Static | 14mm | Deep (f/8 — wide) | The second phone, black, anonymous, wedged in the back. Alien object. | 6s | The intrusion — domestic space violated by operational object |
| 2.4 | DRAWER_04 | Close-Up | Eye-level | Static → slow zoom in | 85mm | Shallow (f/2.0) | Yasmin's face. She doesn't open it. She stares. Her breathing changes. | 12s | The moment before knowledge — the choice not yet made |
| 2.5 | DRAWER_05 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/2.0) | Her thumb hovering over the power button. Wedding ring in frame. | 8s | The marriage ring and the secret phone — same hand, different lives |
| 2.6 | DRAWER_06 | Insert (handheld) | Eye-level | Slight drift | 50mm | Shallow (f/2.8) | Screen lights up: "Package ready. Garden entrance. Midnight." | 4s | The message — operational language invading domestic space |
| 2.7 | DRAWER_07 | Close-Up | Slightly low | Slow tilt up | 85mm | Shallow (f/2.0) | Yasmin's face. No tears. A kind of terrible stillness. She puts the phone back. | 15s | The decision to not-know-yet — self-preservation as deferral |
| 2.8 | DRAWER_08 | Wide | High angle | Static | 24mm | Deep (f/4.0) | Yasmin at piano. She begins to play. The camera holds. | 45s | The piano as sanctuary, as denial, as the only true thing |
| 2.9 | DRAWER_09 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/1.8) | Hands. Faster. Harder. A wrong note. She doesn't stop. She plays through it. | 20s | Fracture beneath the surface — the perfection cracking |
| 2.10 | DRAWER_10 | Close-Up | Eye-level | Slow dolly back | 50mm | Shallow (f/2.0) | Yasmin's face. Tears now. Still playing. The performance continues. | 15s | The private performance — crying while the hands continue their lie |

**Camera Philosophy Notes:**
- This is the last scene where the camera is entirely "loving" — it doesn't push, doesn't interrogate
- The drawer POV shot (2.3) is the film's first use of a "non-human" angle — the object perspective
- The 45-second wide hold (2.8) establishes a rhythm of endurance: the camera, like Yasmin, will not look away
- The progression from static to slight handheld (2.6) to dolly back (2.10) mirrors Yasmin's emotional trajectory: stillness → shock → retreat

---

### SCENE 3: THE FOLLOW (18:00–26:00)
**Beat 5 — Act I Climax: Café Surveillance & Confession**

**Scene Description:** Yasmin follows Omar to a Zamalek café. Watches him meet Nour. Returns home. Plays the recording. Omar confesses: "You were never supposed to see this."

**Shot List — Part A: The Follow**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 3.1 | FOLLOW_01 | Wide | High angle (balcony) | Static | 135mm | Shallow (f/2.8) | Yasmin from above, walking through Zamalek streets. Distant, observable. | 10s | The surveilled becomes surveillant — the watcher is watched |
| 3.2 | FOLLOW_02 | POV (Yasmin) | Eye-level | Slight handheld sway | 85mm | Shallow (f/2.0) | Omar's back through café window. He enters. The glass distorts him. | 8s | POV introduces subjectivity — we see through her eyes, through glass |
| 3.3 | FOLLOW_03 | Over-shoulder | Eye-level | Static | 50mm | Deep (f/4.0) | Yasmin at a neighboring table. Her coffee untouched. She holds a phone — recording. | 15s | The operational turn — she becomes what he is |
| 3.4 | FOLLOW_04 | Two-shot | Eye-level | Slow zoom out | 85mm | Shallow (f/2.8) | Omar and Nour. Body language: cold, operational. Not lovers. Worse. | 20s | The ambiguity of their relationship — it's not sex, it's something she doesn't understand |
| 3.5 | FOLLOW_05 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/2.0) | Yasmin's thumb pressing "record." Her nail polish (from Act I — gold, now chipped). | 5s | The active choice to gather evidence — the wife becomes operative |
| 3.6 | FOLLOW_06 | Wide | Through café window | Static | 24mm | Deep (f/5.6) | The café as aquarium — warm interior, cold exterior, Yasmin outside the glass | 12s | Separation — she is outside the world he inhabits |
| 3.7 | FOLLOW_07 | Close-Up | Low angle (worm's eye) | Slow push in | 35mm | Shallow (f/2.0) | Yasmin's eyes. Reflected in the coffee surface: the café ceiling, distorted. | 8s | Reflection grammar — she sees her world upside-down |

**Shot List — Part B: The Confession**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 3.8 | CONFESS_01 | Wide | Eye-level, 360° orbit | Slow circular dolly | 35mm | Deep (f/4.0) | Yasmin plays the recording. Omar stands frozen. The camera orbits them — the room becomes a stage set | 45s | The marriage as performance — the 360° reveals the apartment as constructed fiction |
| 3.9 | CONFESS_02 | Two-shot | Eye-level | Static | 50mm | Deep (f/4.0) | Yasmin seated, Omar standing. Power shift — she is grounded, he is unmoored | 20s | Composition as power — his height now reads as vulnerability |
| 3.10 | CONFESS_03 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | Omar's face. The mask drops. Seven years of performance erased in one frame. | 15s | The reveal — what does he look like when no one is watching? |
| 3.11 | CONFESS_04 | Close-Up | Slightly low | Slow dolly in | 50mm | Shallow (f/2.0) | Yasmin: "Or that I'm someone who doesn't know her own husband?" | 12s | The reversal — she has been watching him without his knowledge |
| 3.12 | CONFESS_05 | Wide | High angle | Static → slow crane down | 24mm | Deep (f/4.0) | The living room. Two people. The space between them is a chasm. | 18s | The emotional geography — architecture of separation |

**Camera Philosophy Notes:**
- The 360° orbit (3.8) is the film's most complex camera movement. It should take 45 seconds — almost painfully slow. The living room must be dressed for all angles. The orbit reveals: the piano, the wedding photograph, the bookshelf, the window. Each object becomes evidence.
- The shift from telephoto surveillance (135mm) in the café to wide intimacy (24mm–50mm) at home mirrors Yasmin's shift from watcher to participant.

---

### SCENE 4: THE SAFE HOUSE (48:00–52:00)
**Beat 8 — Midpoint Twist: Surveillance File & Other Woman**

**Scene Description:** Yasmin enters Omar's safe house. Finds hundreds of photographs — her life, catalogued. Mixed with them: another woman. Same time period. Same wedding ring on Omar's hand. The surveilled becomes the surveillant. She doesn't recognize herself in the mirror.

**Shot List:**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 4.1 | SAFE_01 | Wide | Low angle | Static | 24mm | Deep (f/5.6) | The safe house door. Yasmin inserts key. The door opens into darkness. | 10s | Threshold — entering the secret world |
| 4.2 | SAFE_02 | POV (Yasmin) | Eye-level | Slow walk-through | 35mm | Deep (f/4.0) | The apartment: bare, anonymous, operational. A bed. A desk. A wall. | 15s | The anti-home — no warmth, no personality, yet his |
| 4.3 | SAFE_03 | Wide | Eye-level | Static | 50mm | Deep (f/4.0) | The wall. Hundreds of photographs. Maps. Timelines. Her life as case file. | 12s | The revelation — her identity as operational object |
| 4.4 | SAFE_04 | Extreme Close-Up | Eye-level | Slow dolly across | 100mm Macro | Razor-thin (f/2.0) | Photograph after photograph — Yasmin at the market, at the conservatory, sleeping (taken from outside window) | 20s | The violation — she was watched in her most private moments |
| 4.5 | SAFE_05 | Insert | Eye-level | Static | 50mm | Deep (f/4.0) | A photograph of another woman. Younger. Different city. Omar's hand with wedding ring in background. | 8s | The double betrayal — not just spy, but potentially another life |
| 4.6 | SAFE_06 | Close-Up | Slightly high | Static → Dutch tilt | 85mm | Shallow (f/2.0) | Yasmin's face. The world tilts. She doesn't blink. | 15s | The floor drops out — Dutch angle as emotional vertigo |
| 4.7 | SAFE_07 | Medium | Eye-level, through doorway | Static | 50mm | Deep (f/4.0) | Yasmin in the safe house mirror. Behind her: the wall of photographs. She sees herself among her own surveillance. | 20s | The most important shot of Act II — she cannot recognize herself |
| 4.8 | SAFE_08 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/2.0) | Her hands. She replaces the files exactly as found. The precision of the operative. | 15s | The transformation — she becomes what he made her |
| 4.9 | SAFE_09 | Wide | High angle | Static | 24mm | Deep (f/4.0) | Yasmin exits. She closes the door. She does not look back. | 10s | Resolution of the scene — she leaves the evidence behind but carries the knowledge |

**Camera Philosophy Notes:**
- The safe house is lit with practical fluorescence — flat, institutional, emotionally dead. This is the first space without warmth.
- Shot 4.7 is the midpoint's visual thesis: Yasmin's reflection surrounded by her own file. She is both the subject and the object of surveillance.
- The macro dolly across photographs (4.4) requires practical photographs, carefully selected to show the progression from "target" to "wife" — when did the operational become personal? The photographs should ask this question visually.

---

### SCENE 5: THE RAINDROP (60:00–68:00)
**Beat 10–11 — Operation Invades Home; Yasmin Plays While Omar Conducts Espionage**

**Scene Description:** A foreign diplomat arrives. Yasmin serves coffee. She plays Chopin's "Raindrop Prelude" while Omar and the diplomat talk in multiple languages. She modulates into minor key when she hears her father's name. Aftermath: she confronts him with operational precision.

**Shot List:**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 5.1 | RAIN_01 | Wide | Eye-level, through doorway | Static | 35mm | Deep (f/4.0) | The apartment transformed — diplomatic meeting in their living room. Yasmin enters with coffee tray. | 12s | The home as operational theater — domesticity repurposed |
| 5.2 | RAIN_02 | Two-shot | Eye-level | Slow zoom in | 50mm | Deep (f/4.0) | Omar and the diplomat. Their conversation in Arabic, English, French. Subtitles shift languages. | 18s | The multilingual scene — she understands what they think she doesn't |
| 5.3 | RAIN_03 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | Yasmin's face as she serves. She smiles. She hears everything. | 10s | The performance of the unknowing wife — her smile is a mask |
| 5.4 | RAIN_04 | Wide | Low angle from piano bench | Static | 24mm | Deep (f/4.0) | Yasmin at piano. The Raindrop Prelude. The repeated A-flat. She plays flawlessly. | 25s | The piano as weapon — she plays while the operation unfolds |
| 5.5 | RAIN_05 | Over-shoulder (piano) | Eye-level | Static | 50mm | Deep (f/4.0) | From behind Yasmin: Omar and diplomat in background, blurred. Conversation continues. | 20s | The depth of field as emotional layering — her focus (sharp) vs. their world (blurred) |
| 5.6 | RAIN_06 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/2.0) | Yasmin's hands. The A-flat (repeated note representing doom). She begins to modulate. | 15s | The musical shift — she changes the piece in response to what she hears |
| 5.7 | RAIN_07 | Close-Up | Slightly low | Static | 85mm | Shallow (f/2.0) | Yasmin's face. She hears her father's name. Her hands do not stop. Her eyes change. | 12s | The revelation within the performance — the personal invading the musical |
| 5.8 | RAIN_08 | Wide | High angle | Slow crane down | 24mm | Deep (f/4.0) | The room from above. Three bodies. Three agendas. The music binds them. | 20s | The scene as choreographed triangle — music as the fourth character |
| 5.9 | RAIN_09 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | The diplomat leaves. Yasmin continues playing. Omar watches her. He knows she knows. | 15s | The mutual recognition — the performance continues because the truth is too dangerous to speak |
| 5.10 | RAIN_10 | Two-shot | Eye-level | Static | 50mm | Deep (f/4.0) | Aftermath. Yasmin and Omar. She has notes. Timelines. Evidence. She is better at his work than he is. | 25s | The power reversal — the wife as the superior operative |

**Camera Philosophy Notes:**
- This scene is the film's most complex orchestration of sound and image. The camera must serve the music — the Raindrop Prelude's structure (repetition, variation, storm) mirrors the scene's tension.
- The shift to minor key (5.6) should be captured in a single shot — no cut, just the hands changing harmony while the face remains serene. The contradiction is the point.
- The high-angle crane (5.8) reveals the apartment as chessboard — three figures in strategic positions. Reference: *The Servant* (Joseph Losey, 1963) — class and power as spatial geometry.

---

### SCENE 6: THE DESTRUCTION (68:00–75:00)
**Beat 11 — Piano Smashed: The Film's Most Violent Emotional Beat**

**Scene Description:** After the father revelation, Yasmin destroys the piano. The instrument that has been her voice, her sanity, her identity — smashed. The strings scream.

**Shot List:**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 6.1 | DESTROY_01 | Wide | Eye-level | Static | 24mm | Deep (f/4.0) | Yasmin standing at the piano. Omar in background. She is terrifyingly still. | 15s | The stillness before — the violence of control about to break |
| 6.2 | DESTROY_02 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | Yasmin's face. No tears. A decision. | 10s | The emotional architecture — she has chosen destruction over speech |
| 6.3 | DESTROY_03 | Medium | Low angle | Fast whip pan to | 35mm | Deep (f/4.0) | Her hands lift the piano lid. The sound is wrong — too loud, too final. | 5s | The first act of violence — the instrument exposed |
| 6.4 | DESTROY_04 | Wide | High angle | Slow-motion capture (48fps) | 24mm | Deep (f/5.6) | Yasmin smashes the lid down. In slow motion: wood splinters, wire screams, dust erupts. | 12s (plays as 24s) | The destruction as ballet — beauty in annihilation |
| 6.5 | DESTROY_05 | Extreme Close-Up | Eye-level | Slow-motion (48fps) | 100mm Macro | Deep (f/5.6) | Piano string vibrating, then snapping. The metal whipping through air. | 8s (plays as 16s) | The string as nerve — the instrument's pain made visible |
| 6.6 | DESTROY_06 | Handheld Close-Up | Eye-level, unstable | Handheld, erratic | 35mm | Shallow (f/2.8) | Yasmin's face. Hair falling. Eyes wild. She doesn't stop. She hits again. | 15s | The loss of control — handheld enters the film for the first time as her violence |
| 6.7 | DESTROY_07 | Wide | Low angle | Static | 24mm | Deep (f/4.0) | The destroyed piano. Yasmin on her knees among the wreckage. Omar has not moved. | 20s | The aftermath — the ruin as landscape, she as inhabitant |
| 6.8 | DESTROY_08 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/2.0) | Yasmin's hand. Bleeding from a string cut. She looks at the blood. She laughs — a terrible sound. | 12s | The wound — the body marks what the soul cannot express |
| 6.9 | DESTROY_09 | Wide | Through doorway | Static | 50mm | Deep (f/4.0) | The room from outside. Yasmin in the wreckage. The frame is a doorway — we are not allowed in. | 15s | The voyeur's position — the audience is witness to a private apocalypse |
| 6.10 | DESTROY_10 | Close-Up | Eye-level | Slow dolly back | 85mm | Shallow (f/2.0) | Yasmin. The rage drains. Grief enters. She is empty. | 20s | The emotional truth beneath the violence — destruction as failed communication |

**Camera Philosophy Notes:**
- This is the first scene where the camera becomes unstable — handheld enters not as documentary style but as *emergency*. The camera cannot hold steady because the world cannot be held steady.
- The slow-motion destruction (6.4, 6.5) is the film's most overtly "beautiful" violence. Reference: *The Strange Love of Martha Ivers* (Lewis Milestone) — destruction as aesthetic release. But the beauty must feel wrong — we should be horrified by how beautiful it is.
- The aspect ratio squeeze (2.39:1 → 1.85:1 → 2.39:1) occurs during the slow-motion smash — the world literally compresses around the violence, then releases.
- The doorway frame (6.9) is the last composition of the scene — we are excluded from her grief. The camera, like Omar, does not know how to enter.

---

### SCENE 7: THE DUOLOGY (85:00–95:00)
**Beat 15 — Climax Confrontation: Piano Duet as Battlefield**

**Scene Description:** Empty conservatory at night. Yasmin reads from Omar's operational file. His assessment of her as "subject." She plays the opening Nocturne. Omar stands behind her, places hands on keys above hers — their courtship gesture. She stops. Devastating silence.

**Shot List:**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 7.1 | DUET_01 | Wide | High angle, from balcony | Static | 24mm | Deep (f/5.6) | Empty conservatory. Yasmin at the piano. Single spotlight. The hall is a cathedral of wood and shadow. | 15s | The space as tribunal — she has summoned him to judgment |
| 7.2 | DUET_02 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | Yasmin reads from the file: "Subject is emotionally accessible, professionally isolated..." Her voice is clinical. Her hands shake. | 25s | The operational language applied to love — the file as love letter, inverted |
| 7.3 | DUET_03 | Over-shoulder (Omar) | Eye-level | Static | 50mm | Deep (f/4.0) | From behind Omar: Yasmin at piano, reading. He is out of focus. The file is sharp. | 15s | The shallow depth as narrative — the file is the truth, he is the blur |
| 7.4 | DUET_04 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | Yasmin: "Recommend extended engagement." She laughs, a broken sound. | 10s | The cruelty of operational euphemism — "engagement" as marriage, as espionage |
| 7.5 | DUET_05 | Two-shot | Eye-level, profile | Static | 50mm | Deep (f/4.0) | Yasmin begins playing the Nocturne from Scene 1. Omar enters frame. He stands behind her. | 20s | The return of the opening — the same music, the same gesture, destroyed context |
| 7.6 | DUET_06 | Close-Up | Overhead, from above | Static | 50mm | Deep (f/4.0) | Yasmin's hands on keys. Omar's hands hover above. The courtship gesture — hands not touching, but aligned. | 15s | The physical memory of love — the body remembers what the mind has poisoned |
| 7.7 | DUET_07 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | Omar's face. He does not play. He rests his fingers on hers. He is crying. | 12s | The first true tears in the film — the operative cannot perform anymore |
| 7.8 | DUET_08 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | Yasmin. She stops playing. The silence is the most devastating sound in the film. | 15s | The refusal to continue the duet — music cannot contain this truth |
| 7.9 | DUET_09 | Wide | Low angle from floor | Static | 24mm | Deep (f/4.0) | The conservatory. Two figures at the piano. The hall is empty. The music has died. | 25s | The emptiness — the space that music filled, now void |
| 7.10 | DUET_10 | Extreme Close-Up | Eye-level | Slow dolly in | 100mm Macro | Razor-thin (f/2.0) | Yasmin: "I used to think music was the truest thing I knew. Now I know truth is just the lie that hasn't been exposed yet." | 20s | The thesis statement — the collapse of art as refuge |

**Camera Philosophy Notes:**
- The conservatory must be shot at night with only practical moonlight and the single piano spotlight. The space should feel both sacred and abandoned.
- The overhead shot (7.6) is the climax's visual anchor — hands aligned but not touching. The geometry of almost-contact. Reference: *The Piano* (Jane Campion) — touch as language.
- The silence after she stops playing (7.8) must be held for at least 15 seconds. No music, no dialogue, just the ambient hum of the empty hall. The audience must feel the absence of music as physical pressure.
- The return to the opening Nocturne is not nostalgic — it is forensic. She is using the music as evidence against him, against herself, against the lie they built.

---

### SCENE 8: THE UNRESOLVED NOTE (100:00–105:00)
**Beat 17 — Final Scene: One Note, Unresolved, Film Fades on Harmonic Tension**

**Scene Description:** Three months later. New apartment. Different neighborhood. Yasmin improvises — raw, unstructured, honest. She receives Omar's letter and photograph. Final shot: Yasmin at window, Cairo at dusk, call to prayer. One note, unresolved. Fade on harmonic tension.

**Shot List:**

| # | Shot ID | Type | Angle | Movement | Lens | Depth | Comp | Dur | Purpose |
|---|---------|------|-------|----------|------|-------|------|-----|---------|
| 8.1 | NOTE_01 | Wide | Eye-level | Static | 35mm | Deep (f/4.0) | New apartment. Plants. Morning light. Yasmin at a different piano — smaller, older, real. | 15s | The new world — smaller, but honest. Green plants = life continuing |
| 8.2 | NOTE_02 | Medium | Eye-level | Slow dolly in | 50mm | Shallow (f/2.0) | Yasmin improvising. No sheet music. Her face: concentrated, alive, sad, present. | 25s | The music of the self — not Chopin, not performance, just being |
| 8.3 | NOTE_03 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/2.0) | Her hands. Different rhythm. Searching, finding, losing, finding again. | 20s | The hands have learned a new language — improvisation as emotional truth |
| 8.4 | NOTE_04 | Wide | Through window | Static | 24mm | Deep (f/4.0) | Cairo street below. Life continues. Children. Vendors. The city indifferent to her story. | 15s | The world beyond — the film's scope widening to the universal |
| 8.5 | NOTE_05 | Insert | Eye-level | Static | 50mm | Deep (f/4.0) | The letter. Omar's handwriting. "Thank you for the architecture. — O." | 10s | The last word — "architecture" as their shared language, now relinquished |
| 8.6 | NOTE_06 | Close-Up | Eye-level | Static | 85mm | Shallow (f/2.0) | Yasmin reads. She does not cry. She breathes. The first unmeasured breath of the film. | 20s | The breath as resolution — she is alive, present, no longer performing |
| 8.7 | NOTE_07 | Wide | Eye-level | Static | 35mm | Deep (f/4.0) | Yasmin at the window. Cairo at dusk. The call to prayer begins. She listens. | 25s | The spiritual dimension — the azan as Cairo's voice, indifferent, eternal |
| 8.8 | NOTE_08 | Close-Up | Eye-level | Slow zoom out | 85mm → 50mm | Shallow (f/2.0) | Yasmin's face. She doesn't smile. She doesn't cry. She is present. | 20s | The face as final landscape — all emotions held simultaneously |
| 8.9 | NOTE_09 | Extreme Close-Up | Eye-level | Static | 100mm Macro | Razor-thin (f/2.0) | Her finger. One key. One note. She holds it. The note sustains... | 15s | The unresolved note — harmonic tension as emotional truth |
| 8.10 | NOTE_10 | Wide | Through window, exterior | Static | 24mm | Deep (f/5.6) | Cairo at dusk. The note continues over. Buildings, sky, the city breathing. | 20s | The city as the note's resonance — the personal becoming universal |

**Camera Philosophy Notes:**
- The final scene is the film's most spacious. After 100 minutes of claustrophobia — apartments, cafés, safe houses, cars — the final frames open to the city. Cairo is not a backdrop; it is the witness that outlives all private tragedies.
- The call to prayer (8.7) is not religious commentary — it is *temporal* commentary. The azan has sounded five times a day through all of Yasmin's marriage, her betrayal, her destruction, her recovery. It will sound after the film ends. The city endures.
- The unresolved note (8.9) must be held until the audience becomes aware of the silence that will follow. Then, as the note finally decays, the image fades — not to black, but to a very dark grey (#1A1A1A), leaving the screen "almost" dark. The harmonic tension continues in the audience's ear.
- The aspect ratio slowly narrows from 2.39:1 to 1.85:1 during the final 15 seconds — the aperture closing, the story ending, but the possibility of what comes after remaining.

---

## 5. LIGHTING DESIGN PER SCENE

### 5.1 Lighting Philosophy: Truth as Exposure

The film's lighting follows a simple principle: the more truth is revealed, the harsher the light becomes. Act I is warm, soft, forgiving — the light of love's blindness. Act III is cool, sharp, exposing — the light that shows everything.

**Lighting Instruments:**
- **Tungsten practicals:** Home interiors, warmth, the lie that comforts
- **HMI daylight:** Exteriors, operational spaces, the truth that exposes
- **LED panels:** Safe house, surveillance, institutional coldness
- **Candle/Practical only:** Piano scenes — the oldest light, the most honest

### SCENE 1: THE NOCTURNE — Lighting Plan

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Key** | Stage overhead, soft box | 2× 2K Fresnel through 8×8 silk | T8 (stage appropriate) | 3200K | Performance lighting | Glamorous, public, exposing |
| **Fill** | Orchestra pit bounce | Bounce off white floor | T4 | 3200K | Natural stage fill | Soft, flattering, artificial perfection |
| **Practical** | Piano lamp | Practical tungsten bulb | T4 | 2800K | Real source — the piano's own light | Intimate, warm, the instrument's soul |
| **Accent** | Follow spot | Leko 750W | Variable | 3000K | The celebrated performer | Isolation — she is alone even in the light |
| **CUT TO APARTMENT** |||||||
| **Key** | Kitchen overhead | Practical fluorescent | T2 | 4100K (cool) | Refrigerator light, institutional | Cold, empty, the truth of 2 AM |
| **Fill** | Bounce off refrigerator | Natural bounce | T1 | 4100K | Cool spill | None — she is barely visible |
| **Practical** | Refrigerator interior | Practical LED | T4 | 4500K | The only "warm" source — and it is cold | Isolation, the domestic as prison |

**Note:** The 900K temperature shift from stage (3200K) to kitchen (4100K) is the film's first emotional temperature change — warmth to cold, performance to reality.

### SCENE 2: THE DRAWER — Lighting Plan

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Key** | Bedroom window (night) | 1K HMI through muslin | T4 | 5600K (moonlight) | Night exterior, "natural" | Cool, suspicious, the wrong temperature for a bedroom |
| **Fill** | Bounce off ceiling | Bounce card | T2 | Mixed | Ambient fill | Soft, uncertain |
| **Practical** | Bedside lamp | Practical tungsten 60W | T3 | 2800K | The only warm source — and she turns away from it | The warmth is behind her; she faces the cold |
| **Accent** | Drawer interior | Small LED panel | T2 | 4500K | Phone screen glow | The digital intrusion — cold, blue, operational |
| **Piano sequence** |||||||
| **Key** | Practical piano lamp | 40W tungsten | T2 | 2800K | The only source — no other lights on | The piano as sanctuary, the warm light of art |
| **Fill** | None | — | — | — | — | Deep shadow — she plays in darkness, the only light is the music |

**Note:** The drawer scene uses mixed color temperature as emotional conflict: the warm bedside lamp (2800K) vs. the cool moonlight (5600K) vs. the phone's digital glow (4500K). Yasmin moves from warm to cold as she investigates.

### SCENE 3: THE FOLLOW — Lighting Plan

**Part A: The Follow (Zamalek Café, Night)**

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Key** | Café interior | Practical tungsten fixtures | T5 | 2800K | Warm café interior — inviting, dangerous | The warmth of public space vs. Yasmin's cold exterior |
| **Fill** | Street lamps | Practical sodium vapor | T3 | 2200K (orange) | Cairo street lighting — real, distinctive | The orange of Cairo night — she is outside, in the city's glow |
| **Accent** | Phone screen | Practical | T2 | 6500K | Recording screen — cold intrusion | The operational device — blue light in orange world |
| **Yasmin exterior** |||||||
| **Key** | Street lamp above | Sodium vapor practical | T2 | 2200K | Real Cairo night | Observable, exposed — she is under a streetlight, visible |
| **Fill** | Café spill | Tungsten spill through window | T1 | 2800K | The warmth she cannot enter | The café as aquarium — warm inside, cold out |

**Part B: The Confession (Apartment)**

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Key** | Living room overhead | Tungsten practical chandelier (dimmed) | T3 | 2800K | The home's own light, but dimmed — something is wrong | Familiar source, unfamiliar intensity — the home is sick |
| **Fill** | Bounce off walls | Natural bounce | T1 | 2800K | Ambient | Almost none — shadows are long, the room is swallowing them |
| **Practical** | Table lamp | Tungsten 40W | T2 | 2800K | The only pool of warmth — and it is small | The light shrinks as the confession expands |
| **Accent** | Window (night) | HMI through curtains | T1 | 5600K | Moonlight — cool, distant, indifferent | The world outside continues; their world is ending |

**Note:** The 360° orbit during the confession requires continuous lighting — no shadows from the camera. Use a circular rig of small tungsten fixtures, dimmed to create "sourceless" warmth that follows the camera.

### SCENE 4: THE SAFE HOUSE — Lighting Plan

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Key** | Overhead fluorescent | Practical fluorescent tubes | T4 | 4100K | Institutional, operational | Cold, flat, emotionally dead — the anti-home |
| **Fill** | Bounce off white walls | Natural | T2 | 4100K | The flatness of institutional space | No shadow, no secret — everything is exposed |
| **Practical** | Desk lamp | Small LED | T2 | 5000K | Work light — clinical | The light of investigation, not of living |
| **Accent** | Flashlight (Yasmin's phone) | Practical LED | T3 | 6500K | She uses phone to examine files | The blue-white of digital truth — harsh, exposing |
| **Mirror shot** |||||||
| **Key** | Bathroom fluorescent | Practical | T4 | 4100K | Institutional mirror light | The worst light for a woman — every flaw exposed |
| **Fill** | None | — | — | — | — | Harsh shadow under eyes, nose — she looks like a file photograph |

**Note:** The safe house has no tungsten. No warmth. No home. The 4100K–5000K range is deliberately "office" — this is where he works, not where he lives. The contrast with their apartment (2800K) is the contrast between the lie and the truth.

### SCENE 5: THE RAINDROP — Lighting Plan

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Key** | Living room | Tungsten practicals + 2K Fresnel through window | T5 | 2800K (warm interior) | Evening at home — or so it appears | The warmth of the trap — she has set the light for them |
| **Fill** | Bounce off walls | Natural | T2 | 2800K | Warm ambient | The familiar made strange — the home as operational theater |
| **Practical** | Table lamps | Multiple tungsten | T3 | 2600K | Layered warmth — and layered deception | The light of hospitality, weaponized |
| **Piano area** |||||||
| **Key** | Piano lamp | Practical tungsten | T2 | 2800K | The piano's own light — warm, isolated | The island of music in the sea of operation |
| **Fill** | None | — | — | — | — | Her face half-lit, half-shadow — she is both performer and spy |
| **Diplomat / Omar area** |||||||
| **Key** | Sofa area | 1K tungsten Fresnel | T4 | 3200K | Brighter than piano — the operation demands visibility | The men are well-lit; she is in shadow — power as illumination |
| **Accent** | Window (rain) | HMI with rain bars | T2 | 5600K | The raindrop prelude — water on glass | The natural world reflecting the musical structure |

**Note:** The rain is practical — rain bars outside the window, backlit by HMI. The water on glass creates moving texture that echoes the piano's repeated note. The warm interior (2800K) vs. cool rain (5600K) creates the scene's color conflict: the trap is warm, the world is cold.

### SCENE 6: THE DESTRUCTION — Lighting Plan

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Pre-destruction** |||||||
| **Key** | Living room | Tungsten practicals (full) | T6 | 2800K | The brightest the apartment has been — the truth is fully exposed | Blinding warmth — too much, too late |
| **Fill** | Bounce | Natural | T3 | 2800K | Bright fill — no shadows to hide in | Exposure as violence — she is fully seen |
| **Destruction sequence** |||||||
| **Key** | Overhead | 2K Fresnel hard | T8 | 3200K | Hard, direct, unforgiving | The light of interrogation — no softness |
| **Fill** | None | — | — | — | — | Black shadows — the void opening |
| **Practical** | Piano lamp (swinging) | Practical tungsten | Variable | 2800K | The piano's own light, now unstable — swinging with impact | The music's light dying |
| **Aftermath** |||||||
| **Key** | Broken piano lamp | Practical, flickering | T1–T2 flicker | 2800K | The dying light — electrical short from destruction | The world reduced to a failing bulb |
| **Fill** | Window moonlight | HMI | T1 | 5600K | Cool, distant, indifferent | The moon watched everything |
| **Accent** | Dust in air | Backlit by failing lamp | T1 | 2800K | Particles suspended — the destruction made visible | Beauty in the ruin — dust as stars |

**Note:** The destruction scene begins with the apartment's brightest lighting (everything exposed) and ends with its darkest (one failing bulb). The light dies with the piano. The dust particles backlit by the failing lamp (6.9) create an unexpected beauty — destruction as constellation.

### SCENE 7: THE DUOLOGY — Lighting Plan

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Key** | Piano spotlight | 750W Leko, tight spot | T6 | 3000K (warm) | The performer illuminated — the stage as tribunal | Warm but isolating — the spotlight is a prison |
| **Fill** | Hall ambient | Bounce off wood paneling | T1 | 2800K | The hall's warmth — but distant | The space is too large for one person — loneliness as architecture |
| **Practical** | Exit signs, hall lights | Practical LEDs | T1 | 5000K | Green exit signs — cold, institutional | The hall's own voice — "exit" as subliminal message |
| **Omar area** |||||||
| **Key** | Piano spill | Spill from spotlight | T2 | 3000K | He is in her light — dependent, exposed | He enters her light; he cannot bring his own |
| **Fill** | None | — | — | — | — | His face half-lit from piano spill — he is incomplete |
| **Moonlight** | High windows | HMI through windows | T1 | 5600K | Night exterior — cool, distant | The world outside is cold; the tribunal inside is warm |
| **The Silence** |||||||
| **Key** | Spot fades | Leko dimming | T6→T1 | 3000K | The light follows the music — as she stops, the light dies | Darkness as the music's absence |
| **Fill** | None | — | — | — | — | Complete shadow — the void where music was |

**Note:** The spotlight is the only key source. As Yasmin stops playing (7.8), the spot slowly dims — not a cut to black, but a fade to near-darkness over 15 seconds. The light obeys the music. When the music dies, the light mourns.

### SCENE 8: THE UNRESOLVED NOTE — Lighting Plan

| Light | Position | Instrument | Intensity | Color Temp | Motivation | Mood |
|-------|----------|------------|-----------|------------|------------|------|
| **Morning sequence** |||||||
| **Key** | Window | Natural daylight through muslin | T4 | 5600K (diffused) | Morning light — new, honest, unperformed | Cool but bright — the clarity of new beginnings |
| **Fill** | Bounce off walls | Natural | T2 | 5600K | Soft, diffused | The apartment breathes — air, light, life |
| **Practical** | No artificial lights on | — | — | — | — | Only natural light — she no longer needs artificial warmth |
| **Piano sequence** |||||||
| **Key** | Window | Natural daylight | T3 | 5600K | Daylight on piano — no lamp | The piano in natural light — no performance, just being |
| **Fill** | Bounce | Natural | T1 | 5600K | Soft | Her face in natural light — every line visible, every line accepted |
| **Dusk sequence** |||||||
| **Key** | Window (dusk) | Natural magic hour | T4 | 4500K→3500K (shifting) | The only scene with true magic hour — the world forgiving | The transition from day to night — the liminal moment of peace |
| **Fill** | Bounce off interior | Natural | T1 | Shifting | The apartment in twilight | Interior warmth (2800K practicals) mixing with exterior dusk — synthesis |
| **Practical** | No lights turned on | — | — | — | — | She doesn't need to turn on the light — the world provides enough |
| **Final note** |||||||
| **Key** | Window (last light) | Natural, dying | T2→T1 | 3500K→3000K | The last light of the day — reluctant, gentle | The light is leaving, but it is not cruel — it is natural |
| **Fill** | None | — | — | — | — | Shadow enters the frame — the darkness is not threat, it is rest |

**Note:** The final scene uses no artificial key light. Only natural light, from morning to dusk. This is the first scene where Yasmin does not perform under a spotlight, a lamp, or a stage. She is lit by the world. The 5600K morning → 3000K dusk arc mirrors her emotional arc: cool clarity → warm acceptance. The unresolved note is played in the last 3000K light of day — not warm, not cold, just the world's own color.

---

## 6. TRANSITION DESIGN & EDITORIAL PHILOSOPHY

### 6.1 Transition Grammar

The film uses six transition types, each with narrative function:

| Transition | Usage | Emotional Function | Frequency |
|------------|-------|---------------------|-----------|
| **Hard Cut** | Standard scene-to-scene | The truth is abrupt — one world ends, another begins | 70% |
| **Match Cut** | Performance-to-domestic, past-to-present | The continuity of illusion — the same gesture masks different truths | 10% |
| **Dissolve (slow)** | Time passing, memory intruding | The softness of nostalgia — the past bleeding into present | 8% |
| **Fade to Black** | Act breaks, emotional deaths | The end of a way of seeing — the darkness of transition | 3% |
| **Fade from Black** | New beginnings, awakenings | The slow emergence from ignorance — birth of awareness | 3% |
| **Sound Bridge** | Overlapping scenes | The persistence of music/memory across time and space | 6% |

### 6.2 Key Transitions by Scene

**Scene 1 (The Nocturne): Match Cut — Piano String → Tea Ripple**
- The vibrating piano string (shot 1.4) cuts to the ripple in the tea (shot 1.7)
- The same note travels from public to private — the match cut implies the music *caused* the ripple
- Sound bridge: the Nocturne continues across the cut, but shifts from concert hall acoustics to apartment echo

**Scene 1→2 (Nocturne → Drawer): Hard Cut**
- The final shot of empty apartment (1.6) cuts hard to morning bedroom (2.1)
- No dissolve — time has passed, but the emptiness continues
- The hard cut preserves the emotional jolt: the performance ends, the marriage continues its routine

**Scene 2→3 (Drawer → Follow): Dissolve**
- Yasmin's hands on piano, playing through the wrong note (2.10) dissolves to her hands holding coffee cup in café (3.3)
- The dissolve implies the piano practice continued for hours, bleeding into the next day
- The music fades, replaced by café ambience

**Scene 3→4 (Follow → Safe House): Fade to Black → Fade from Black**
- The confession ends in darkness (3.12) — fade to black
- Hold black for 3 seconds (the audience breathes)
- Fade from black into safe house door (4.1) — a new kind of darkness
- Only act break that uses fade-to-black — the midpoint demands it

**Scene 4→5 (Safe House → Raindrop): Sound Bridge**
- Yasmin closes safe house door (4.9) — the door slam echoes
- The echo transforms into the first note of the Raindrop Prelude (5.4)
- Sound bridge: door → piano note → rain begins

**Scene 5→6 (Raindrop → Destruction): Hard Cut**
- Yasmin's operational confrontation (5.10) cuts hard to pre-destruction stillness (6.1)
- The cut is violent in its silence — no sound bridge, no dissolve
- The audience is thrown from precision to chaos

**Scene 6→7 (Destruction → Duology): Fade to Black (long)**
- Yasmin empty after destruction (6.10) — fade to black
- Hold black for 5 seconds (the longest fade in the film)
- The audience must sit in the aftermath
- Fade from black into empty conservatory (7.1) — the void before judgment

**Scene 7→8 (Duology → Unresolved Note): Dissolve (very slow — 4 seconds)**
- The unresolved silence after the duet (7.9) dissolves into morning light of new apartment (8.1)
- The dissolve implies three months in a single breath
- The silence of the conservatory becomes the morning sounds of a new neighborhood

### 6.3 Editorial Rhythm by Act

**Act I (0:00–26:00): The Long Gaze**
- Average shot length: 12–18 seconds
- Longest shot: 45 seconds (Yasmin playing piano after drawer discovery)
- Cut frequency: Low. The camera, like Yasmin, is not looking for problems.
- The rhythm is hypnotic — we are lulled into the marriage's routine.

**Act II-A (26:00–52:00): The Accelerating Eye**
- Average shot length: 6–10 seconds
- Cut frequency: Moderate, increasing
- The rhythm accelerates as Yasmin investigates — the cuts mirror her gathering momentum
- The surveillance montage uses faster cutting (2–3 seconds per shot)

**Act II-B (52:00–78:00): The Fracture**
- Average shot length: 4–8 seconds
- Cut frequency: High
- The rhythm becomes staccato — the marriage's music is breaking into fragments
- The piano destruction scene uses both the slowest (slow-motion) and fastest (handheld) cutting in the film

**Act III (78:00–105:00): The Stillness**
- Average shot length: 15–25 seconds (return to long takes)
- Cut frequency: Low
- But the long takes are different from Act I — they are not comfortable, they are *exhausted*
- The camera holds because the characters have nothing left to perform
- Final scene average shot length: 20 seconds — the longest sustained quiet in the film

---

## 7. PACING & VISUAL RHYTHM ANALYSIS

### 7.1 The Cardiac Rhythm Map

Following the Emotional Narrative's cardiac pattern, the film's visual rhythm maps to emotional BPM:

```
Visual Rhythm BPM Map

Act I:    60 BPM  ▓▓▓▓░░░░░░  Slow, observational, hypnotic
Act II-A: 72 BPM  ▓▓▓▓▓▓░░░░  Accelerating, curious, suspicious  
Act II-B: 100 BPM ▓▓▓▓▓▓▓▓▓░  Frantic, compressed, breaking
Act III:  48 BPM  ▓▓▓░░░░░░░  Slow, exhausted, still
Final:    36 BPM  ▓▓░░░░░░░░  Near-stillness, the breath after crying
```

### 7.2 Pacing Zones by Key Scene

| Scene | Time | Rhythm Zone | Camera Energy | Cut Frequency | Emotional Function |
|-------|------|-------------|---------------|---------------|-------------------|
| The Nocturne | 0:00–3:00 | Slow Burn | Static, gentle | Very Low | Lull the audience into the illusion |
| The Drawer | 8:00–12:00 | Slow Burn → Stutter | Mostly static, one handheld insert | Low → one spike | The first wrong note — routine disrupted |
| The Follow | 18:00–26:00 | Accelerating | Surveillance grammar, handheld, 360° orbit | Moderate | Investigation as acceleration |
| The Safe House | 48:00–52:00 | Fracture | Walk-through, Dutch angle, static terror | Moderate-High | The midpoint — the floor drops out |
| The Raindrop | 60:00–68:00 | Polyrhythm | Multiple simultaneous rhythms (piano, conversation, rain) | Moderate | Complexity — she is playing three roles at once |
| The Destruction | 68:00–75:00 | Crescendo → Silence | Slow-motion, handheld, static aftermath | Very High → Zero | The explosion, then the void |
| The Duology | 85:00–95:00 | Sustained Note | Static, locked-off, minimal | Very Low | The climax as held breath |
| The Unresolved Note | 100:00–105:00 | Decay | Static, gentle, open | Very Low | The final breath — let go |

### 7.3 Breathing Moments vs. Intense Sequences

**BREATHING MOMENTS (Audience Rest):**
- Scene 1: The 45-second wide shot of empty apartment — the audience breathes in the space
- Scene 4: The mirror shot in the safe house — the audience breathes in the horror
- Scene 7: The 15-second silence after she stops playing — the audience breathes in the absence
- Scene 8: The 20-second dusk window shot — the audience breathes in the possibility

**INTENSE SEQUENCES (Audience Stress):**
- Scene 2: The phone discovery — 8 shots in 90 seconds, each one a step closer to truth
- Scene 3: The café surveillance — cross-cutting between Yasmin's POV and Omar's operational coldness
- Scene 6: The destruction — the most visually intense sequence, rhythmically complex (slow-motion + handheld + static)

### 7.4 Montage and Sequence Design

**The Investigation Montage (Act II-A, ~35:00–40:00)**
- Cross-cutting between: Yasmin at Omar's computer, Yasmin following GPS, Yasmin photographing documents, Yasmin practicing piano (frantically)
- The montage rhythm: piano practice → investigation → piano practice → investigation
- The piano becomes the metronome of her investigation — music and espionage share a rhythm
- Cut duration: 2–3 seconds per shot, accelerating to 1 second as she nears the safe house

**The Three Months Later Transition (Act III opening, ~100:00)**
- Single dissolve: the destroyed piano → the new apartment's plants
- The dissolve lasts 4 seconds — the longest in the film
- No montage — the film refuses to show recovery as a series of events
- Recovery is a single breath, a single dissolve, a single morning

---

## 8. LENS LANGUAGE GUIDE

### 8.1 Lens Philosophy

The film's lens selection follows emotional, not merely practical, logic. Each focal length carries thematic weight.

#### Wide Lenses (14mm–24mm): Environment, Isolation, Architecture

**14mm (Ultra-Wide):**
- Used: Safe house discovery (4.1), Destruction aftermath (6.7)
- Effect: Distortion at edges — the world bends. Architecture looms. The human is small.
- Emotional function: The individual overwhelmed by structure — marriage, surveillance, Cairo itself.
- Reference: Emmanuel Lubezki on *The Revenant* — nature as oppressive architecture.

**24mm (Wide):**
- Used: Empty apartment shots, conservatory wides, Cairo exteriors
- Effect: Environment readable, human present but contextualized
- Emotional function: The person in their world — Yasmin in Cairo, Omar in his operations, the city indifferent
- Reference: Roger Deakins on *Sicario* — the wide frame as moral geography.

#### Standard Lenses (35mm–50mm): Natural, Human, Documentary

**35mm (Standard-Wide):**
- Used: Two-shots, walk-throughs, doorways
- Effect: Natural perspective, slight environment, human-scale
- Emotional function: The "normal" world — conversations, meals, routine. The lens of the marriage that was.
- Reference: Asghar Farhadi's films — domestic spaces shot at 35mm for naturalistic imprisonment.

**50mm (Standard):**
- Used: Medium close-ups, over-shoulders, profile two-shots
- Effect: Human eye perspective — what we see when we look at someone we love
- Emotional function: Intimacy without distortion. The honest gaze. The lens of Act I's love.
- Reference: *In the Mood for Love* — Christopher Doyle's 50mm close-ups as emotional penetration.

#### Telephoto Lenses (85mm–135mm): Compression, Intimacy, Surveillance

**85mm (Portrait):**
- Used: Emotional close-ups, the "mask drop" moments
- Effect: Compression of background — the world falls away, only the face remains
- Emotional function: The moment when all context disappears and only the person remains — love, betrayal, recognition
- Reference: *Atonement* — 85mm for the intimate scenes that become evidence.

**100mm Macro (Special):**
- Used: Hands, rings, piano strings, tea ripples, text messages
- Effect: The world at micro-scale — detail as symbol
- Emotional function: The small things that contain the largest meanings. The ring. The string. The ripple.
- Reference: *Eternal Sunshine of the Spotless Mind* — macro as memory archaeology.

**135mm (Telephoto):**
- Used: Surveillance shots, distant observation, across-street café shots
- Effect: Compression — distant elements feel close, flat, observable
- Emotional function: The watcher's perspective. The removal of the watcher from the watched. The emotional distance of espionage.
- Reference: *The Lives of Others* — telephoto as the gaze of the surveillance state.

### 8.2 Lens Progression Across Emotional Beats

| Beat | Primary Lens | Secondary Lens | Rationale |
|------|------------|----------------|-----------|
| Act I — Domestic love | 50mm | 35mm | Natural, human, comfortable |
| Act I — Performance | 85mm | 100mm Macro | Public face, detail as symbol |
| Act II-A — Surveillance | 135mm | 85mm | Distance, compression, watching |
| Act II-A — Confession | 35mm | 50mm | The return to domestic space, but wider — more revealed |
| Act II-B — Safe house | 24mm | 14mm | Architecture as prison, space as threat |
| Act II-B — Destruction | 24mm / 100mm Macro | 35mm (handheld) | From wide chaos to micro-detail, then handheld instability |
| Act III — Duology | 50mm / 85mm | 35mm | Return to intimacy, but now sharp, precise, judicial |
| Act III — Final note | 50mm → 85mm | 24mm (wide) | From intimate to expansive — the personal becomes universal |

---

## 9. VISUAL REFERENCES & CINEMATIC COMPS

### 9.1 Reference Directors & Cinematographers

| Director / Cinematographer | Reference Work | Element Borrowed | Application in حب وخيانة |
|---------------------------|----------------|------------------|--------------------------|
| **Wong Kar-wai / Christopher Doyle** | *In the Mood for Love* (2000) | Widescreen intimacy, color-as-emotion, unspoken longing, frame-within-frame | Yasmin and Omar's domestic spaces; the duet scene; the use of doorways as emotional thresholds |
| **Tomas Alfredson / Hoyte van Hoytema** | *Tinker Tailor Soldier Spy* (2011) | Cold paranoia in warm spaces, information density, the watcher as protagonist | The café surveillance; the safe house; the operational aesthetic |
| **Joe Wright / Seamus McGarvey** | *Atonement* (2007) | The long take as emotional overwhelming, color as period and trauma, the irrevocable moment | The 360° orbit during confession; the destruction scene; the Dunkirk-beach emotional logic translated to Cairo |
| **Krzysztof Kieślowski / Sławomir Idziak** | *Three Colors: Blue* (1993) | Color as emotional state, grief as color subtraction, the macro of memory | The color palette progression; the use of blue in Act II-A; the piano as memory instrument |
| **Asghar Farhadi / Mahmoud Kalari** | *A Separation* (2011) | Domestic space as moral arena, no villains, the weight of unspoken truths | The apartment as battleground; the moral complexity of framing; the Cairo specificity |
| **Denis Villeneuve / Roger Deakins** | *Sicario* (2015) | Widescreen moral ambiguity, twilight as liminal space, the landscape as character | Cairo at night; the wide frames that contain intimate horror; the dusk light |
| **Ruba Nadda / Luc Montpellier** | *Cairo Time* (2009) | Cairo as romantic/liminal space, the city's architecture as emotional architecture | Cairo exteriors; the call to prayer as temporal marker; the city's indifference to private drama |
| **Jane Campion / Stuart Dryburgh** | *The Piano* (1993) | The instrument as emotional voice, touch as language, the female gaze | The piano destruction; the duet scene; Yasmin's hands as emotional narrative |
| **Alfonso Cuarón / Emmanuel Lubezki** | *Children of Men* (2006) | Expressive handheld, long takes with embedded complexity, the world continuing around private tragedy | The destruction aftermath handheld; the final scene's wide held shot; the city breathing around Yasmin |

### 9.2 Specific Shot References

**The 360° Orbit (Scene 3, shot 3.8)**
- Reference: *The Innocents* (Jack Clayton, 1961) — the circular dolly as encroaching dread
- Reference: *Atonement* — the continuous shot as the impossibility of looking away
- Execution: 45-second orbit on a 12-foot circular dolly track. Lighting must be continuous — practical tungsten chandelier + motivated fill from window. The orbit reveals the room's objects in sequence: piano, photograph, bookshelf, window. Each object is a piece of evidence.

**The Mirror Shot (Scene 4, shot 4.7)**
- Reference: *The Lady from Shanghai* (Orson Welles, 1947) — mirror as fractured truth
- Reference: *Black Swan* (Matthew Libatique, 2010) — the mirror as identity dissolution
- Execution: Practical mirror. Yasmin stands before it. Behind her (reflected in the mirror): the wall of photographs. She sees her face among her own file. The shot is a single 20-second hold. Her expression changes from recognition to non-recognition — she sees a stranger who looks like her.

**The Slow-Motion Destruction (Scene 6, shots 6.4–6.5)**
- Reference: *Zabriskie Point* (Michelangelo Antonioni, 1970) — destruction as aesthetic release
- Reference: *The Conformist* — the violence as choreographed beauty
- Execution: 48fps capture, played at 24fps. Multiple angles: wide (24mm), macro (100mm), profile (50mm). The piano must be a practical instrument — no CGI destruction. The strings snap, the wood splinters, the dust rises. The beauty must feel wrong.

**The Unresolved Note (Scene 8, shot 8.9)**
- Reference: *Three Colors: Blue* — the final note as emotional suspension
- Reference: *In the Mood for Love* — the final shot as possibility, not resolution
- Execution: Macro on the finger. The key depressed. The note rings. Hold for 15 seconds. The note decays but does not resolve. Fade begins while the note is still audible. The screen fades to near-black (#1A1A1A), not pure black. The harmonic tension continues in the audience's ear after the image is gone.

### 9.3 Cairo-Specific Visual Vocabulary

The film is set in Cairo, and the city is not backdrop — it is witness, participant, and ultimately the only entity that survives the story.

**Visual Elements to Capture:**
- **The call to prayer (azan):** Not religious symbolism but *temporal* — the city marking time five times daily, indifferent to private drama. Must be recorded at actual mosques, multi-layered (near and distant), authentic.
- **The Nile at night:** Black water reflecting city lights — the surface as mirror, the depth as hidden. Zamalek island as liminal space — between east and west Cairo, between truth and lie.
- **Dust and light:** Cairo's particular quality — dust in sunbeams, the golden haze of late afternoon, the way light becomes visible because the air is not clean. The dust as the city's breath.
- **Islamic geometry:** The patterns of mashrabiya screens, mosque domes, tilework — patterns that contain infinite complexity within rigid structure. Omar's operational mind as geometric; Yasmin's music as fluid.
- **The Opera House:** A colonial building repurposed — the performance space as inherited architecture. Yasmin performs European classical music in a building that embodies Egypt's colonial and postcolonial complexity.

---

## APPENDIX A: TECHNICAL SPECIFICATIONS SUMMARY

### Camera & Format
| Parameter | Specification |
|-----------|-------------|
| Primary Camera | Arri Alexa 35 (4.6K) |
| Surveillance inserts | Arri Alexa Mini (4:3 extraction) |
| Anamorphic lenses | Cooke Anamorphic/i SF (Special Flare) — 32mm, 50mm, 75mm, 100mm |
| Spherical lenses | Arri Signature Prime — 14mm, 24mm, 35mm, 47mm, 58mm, 85mm, 125mm |
| Macro | Arri Signature 100mm Macro |
| Recording format | ProRes 4444 XQ, 4.6K |
| Frame rate base | 24fps |
| Slow motion | 48fps (played at 24fps) |

### Aspect Ratio & Exhibition
| Format | Ratio | Usage |
|--------|-------|-------|
| Primary | 2.39:1 | 100 minutes (film body) |
| Surveillance | 4:3 | 30–90 second inserts |
| Destruction squeeze | 2.39:1 → 1.85:1 → 2.39:1 | 10 seconds |
| Final fade | 2.39:1 → 1.85:1 | 15 seconds |

### Color & Texture
| Element | Specification |
|---------|-------------|
| LUT (Act I) | "Amber Cairo" — warm highlights, lifted brown blacks, gentle highlight roll-off |
| LUT (Act II-A) | "Cyan Night" — cool shadows, desaturated skin, cyan push |
| LUT (Act II-B) | "Violet Grief" — violet mid-tones, plum shadows, 30% desaturation |
| LUT (Act III) | "Slate Recovery" — near-monochrome opening, gradual color return to 70% saturation |
| Grain | Kodak Vision3 5219 (500T) emulation for nights; 5207 (250D) for days |
| VFX | Minimal — practical effects preferred. Only VFX: surveillance photo inserts, Cairo skyline extensions |

### Lighting Package
| Scene type | Key instruments |
|------------|----------------|
| Domestic warm | 2K–5K tungsten Fresnel, china balls, practical bulbs (2800K–3200K) |
| Night exterior | 1K–4K HMI, sodium vapor practicals, LED panels (5600K–6500K) |
| Stage/performance | Leko 750W spots, 2K Fresnel through silk (3000K–3200K) |
| Safe house/institutional | Practical fluorescent, LED panels (4100K–5000K) |
| Rain | Rain bars + HMI backlights (5600K) |
| Magic hour | Natural only — no artificial sources (3500K–4500K shifting) |

---

## APPENDIX B: SHOT COUNT SUMMARY

| Scene | Shots | Avg Duration | Key Movement | Most Complex Shot |
|-------|-------|------------|--------------|-------------------|
| The Nocturne | 7 | 15s | Match cut string→ripple | Macro string vibration |
| The Drawer | 10 | 12s | Static → one handheld insert | Drawer POV (14mm) |
| The Follow | 12 | 14s | 360° orbit, surveillance grammar | 45-second circular dolly |
| The Safe House | 9 | 12s | Walk-through, Dutch angle | Mirror shot (practical) |
| The Raindrop | 10 | 18s | Piano + conversation + rain | Overhead two-shot |
| The Destruction | 10 | 12s | Slow-motion + handheld + static | Slow-motion piano smash |
| The Duology | 10 | 18s | Static, locked-off | 15-second silence hold |
| The Unresolved Note | 10 | 18s | Natural light progression | Final note + aspect ratio squeeze |
| **TOTAL** | **78** | **~15s avg** | — | — |

---

## DIRECTOR'S FINAL NOTE

> *"Every frame of this film is a choice between looking and looking away. The camera must be complicit in the opening illusion, suspicious in the investigation, broken in the destruction, and finally — in the last scene — simply present. Not judging. Not forgiving. Just present."
>
> *"The unresolved note at the end is not ambiguity for ambiguity's sake. It is the truth of every life that continues after the story ends. We do not get resolution. We get continuation. The note does not resolve because Yasmin has learned that resolution is a performance, and she no longer performs."
>
> *"Cairo is the only character that does not lie. The city endures. The call to prayer continues. The Nile flows. The dust rises and falls. Yasmin's tragedy is private. Cairo's indifference is the film's final mercy — the reminder that the world is larger than any heartbreak, and that morning comes even after the darkest night."*

---

**Document prepared by Cinematic Director Agent**
**Pipeline: From Storyboard To Vision**
**Project: حب وخيانة / The Garden of Broken Mirrors**
**Date: 2026-05-25**

**Next Pipeline Stage:** Production Designer (Set & Location Design) — to receive this document for spatial realization of the 8 key scenes.
