# 🎬 حب وخيانة — The Garden of Broken Mirrors
## Complete Cinematic Production Package

**Project ID:** L&B-2026-05  
**Genre:** Romantic Psychological Drama / Neo-Noir Romance with Espionage Thriller Layer  
**Runtime:** 105 Minutes  
**Aspect Ratio:** 2.39:1 Anamorphic Widescreen (4:3 for surveillance footage)  
**Status:** Pre-Production Package — Ready for Pitch

---

## 📖 LOGLINE

A celebrated Cairo concert pianist discovers her husband of seven years is leading a double life as a covert operative — and when she is unwittingly drawn into his final mission, she must choose between the love she believed in and the truth that will destroy them both.

---

## 🏛️ THREE-ACT STRUCTURE

### Act I: The Surface (0:00–26:00)
- The Nocturne — Chopin performance duality (public perfection / private emptiness)
- The Drawer — Second phone discovery — inciting incident
- The Follow — Café surveillance — Act I climax, Omar confesses

### Act II-A: The Crack (26:00–52:00)
- New rules of paranoia
- The Safe House — Midpoint twist: Yasmin discovers her own surveillance file + another woman's photographs
- Learning operational skills

### Act II-B: The Abyss (52:00–78:00)
- Operation invades home
- The Raindrop — Yasmin plays Chopin while Omar conducts espionage
- The Destruction — Piano smashed — the film's most violent emotional beat
- Father's secret revealed
- Yasmin becomes investigator

### Act III: The Reckoning (78:00–105:00)
- Khalid's truth
- The Duology — Conservatory confrontation — piano duet as battlefield of love and lies
- Omar's choice: disappear or testify
- 3-month later resolution
- The Unresolved Note — Final scene — Yasmin improvises one note, unresolved, film fades on harmonic tension

---

## 👤 CHARACTER BIBLE

| Character | Arc | Casting Energy |
|-----------|-----|---------------|
| **Yasmin El-Sayed** (Protagonist) | Controlled performer → Devastated wife → Operational investigator → Composer of her own uncertain future | Tang Wei / Juliette Binoche |
| **Omar Hassan** (Antagonist/Co-Protagonist) | Masked operative → Partially revealed man → Tragic ambiguity engine | Tony Leung / Rami Malek |
| **Layla El-Sayed** (Supporting) | Envious sister → Operational ally → Parallel investigator of her own father's secrets | — |
| **Nour Amir** (Supporting) | Professional handler → Grudging mirror to Yasmin's potential dark future | Tilda Swinton |
| **Khalid Rashid** (Supporting) | Truth-teller/gardener who gives knowledge without peace | — |

---

## 🎨 COLOR PALETTE BY ACT

| Act | Dominant Color | Emotional Function | Hex |
|-----|---------------|-------------------|-----|
| **I** | Amber / Gold / Warm Sand | Nostalgia, the golden illusion of permanence | `#D4A574` |
| **II-A** | Cyan / Teal / Sea Glass | Awakening, cool aliveness, uncontrollable desire | `#4A9B9B` |
| **II-B** | Dusty Violet / Bruised Rose | Moral confusion, twilight — neither right nor wrong | `#7B6B8D` |
| **III** | Slate Grey / Storm Blue / Ash + Emergency Red | Devastation, the color of ruins | `#708090` / `#8B0000` |
| **Resolution** | Pale Sage / Dawn Grey / Soft Silver | New growth in ruins, fragile recovery | `#9DC183` |

---

## 🎵 MUSICAL SCORE ARCHITECTURE

| Act | Maqam | Emotional Quality |
|-----|-------|-------------------|
| I | **Bayati** | Stable, warm, but without improvisational life |
| II | **Hijaz** | Longing, beauty mixed with melancholy |
| III | **Rast** | Joy with underlying tension — the quarter-tone that never resolves |
| IV | **Saba** | Deep sorrow — rarely used because too painful |
| V | **Nahawand** | Farewell, acceptance, gentle sadness |

**Character Themes:**
- **Yasmin:** Descending five-note piano cell that inverts to ascending in Act V
- **Omar:** Microtonal cello pedal tone that shifts between "husband mode" and "operative mode"
- **Layla:** Dissonant piano cluster (two half-step notes)
- **Nour:** Clarinet perfect fourth with "wrong" articulation
- **Khalid:** Ney taqsim with "old man's breath"

---

## 🎬 KEY SCENE BREAKDOWN (8 Critical Scenes)

| # | Timecode | Scene | Camera Signature | Color | Music |
|---|----------|-------|-----------------|-------|-------|
| 1 | 0:00–3:00 | The Nocturne | Match cut: vibrating piano string → tea ripple | Amber/Gold | Chopin Nocturne + Bayati oud/ney |
| 2 | 8:00–12:00 | The Drawer | 14mm drawer POV — secret phone as alien object | Fading Amber → Dusty Violet | Phone vibration as sonic shock |
| 3 | 18:00–26:00 | The Follow | 360° circular dolly during confession | Cyan/Teal | Hijaz violin + 72 BPM operational pulse |
| 4 | 48:00–52:00 | The Safe House | Mirror shot: Yasmin sees face in surveillance photos | Dusty Violet/Bruised Rose | Anechoic dead space |
| 5 | 60:00–68:00 | The Raindrop | Overhead two-shot: her hands on keys, his hovering | Slate Grey/Storm Blue | Chopin A-flat merges with Rast oud pulse |
| 6 | 68:00–75:00 | The Destruction | 48fps slow-motion piano smash + handheld rage | Emergency Red/Ash | First Saba entrance — violence IS the music |
| 7 | 85:00–95:00 | The Duology | Four hands on keyboard as chessboard | Slate → Pale Sage transition | Four-version D chord (major, minor, Saba, Nahawand) |
| 8 | 100:00–105:00 | The Unresolved Note | Pull back from two figures to city to river to world | Pale Sage/Dawn Grey | D4 decay + 7 Hz beating pattern |

---

## 📐 CINEMATIC PHILOSOPHY

> "The camera knows Omar's truth before Yasmin does. It is the first betrayer."

**Camera Modes:**
1. **THE OBSERVED LIFE (Act I):** Static, loving, complicit in the illusion. Long takes (avg 15s). The camera adores.
2. **THE INVESTIGATING EYE (Act II-A):** Suspicious, reframing, "checking" faces and phones. Surveillance grammar — 135mm telephoto.
3. **THE BROKEN MIRROR (Act II-B & III):** Handheld enters — expressive handheld (Lubezki-style). Dutch angles for vertigo. The camera can no longer hold steady because Yasmin's reality cannot be held steady.

**Lens Language:**
- 14mm — Architecture overwhelms the human
- 24mm — Person in their world
- 35mm — The "normal" marriage
- 50mm — Intimacy without distortion
- 85mm — The mask drops
- 100mm Macro — The small things that contain the largest meanings
- 135mm — The watcher's perspective

---

## 🔊 THE SEVEN SACRED SILENCES

| Silence | Duration | Scene | Function |
|---------|----------|-------|----------|
| After phone discovery | 8 sec | The Drawer | Recognition before reaction |
| After Omar's confession | 12 sec | The Follow | Truth settling |
| In the safe house | 20 sec | The Safe House | Identity being rewritten |
| After piano destruction | 10 sec | The Destruction | The funeral of identity |
| After the duet | **15 sec** | The Duology | The end of the marriage |
| Three days at Layla's | 30 sec (distributed) | — | Grief beyond language |
| The unresolved note | 30+ sec decay + 3 sec darkness | Unresolved Note | Possibility in absence |

---

## 🎮 PRODUCTION DELIVERABLES

| Document | File Path |
|----------|-----------|
| Story Structure & Screenplay Treatment | `/memories/production/love_and_betrayal/story_architect_output.md` |
| Emotional Arcs & Music-Emotion Map | `/memories/production/love_and_betrayal/emotional_narrative_output.md` |
| Cinematic Direction & Shot Design | `/memories/production/love_and_betrayal/cinematic_director_output.md` |
| Visual Storyboard (68 Frames) | `/memories/production/love_and_betrayal/visual_storyboard_output.md` |
| Sound & Music Design | `/memories/production/love_and_betrayal/sound_music_output.md` |
| AI Video Generation Prompts (263+ prompts) | `/memories/production/love_and_betrayal/ai_prompt_director_output.md` |
| Interactive HTML Experience | `/memories/production/love_and_betrayal/interactive_experience.html` |
| Master Production Package (This Document) | `/memories/production/love_and_betrayal/PRODUCTION_PACKAGE.md` |

---

## 🏆 FESTIVAL STRATEGY

- **Primary:** Venice / Cannes / Toronto — prestige arthouse positioning
- **Comps:** *In the Mood for Love* + *Atonement* + *Tinker Tailor Soldier Spy* + *The Lives of Others*
- **Genre Positioning:** Romantic Psychological Drama with espionage-noir visual language

---

## 💰 ESTIMATED BUDGET NOTES

- **Audio Budget:** $450,000–500,000 (original score + Chopin recordings + licensing)
- **Visual Effects:** Minimal — practical effects preferred, anamorphic in-camera
- **Locations:** Cairo Opera House, Zamalek apartment, European café, decayed safe house, Nile corniche
- **Recommended Composer:** Gabriel Yared / Ryuichi Sakamoto / Jóhann Jóhannsson energy

---

*"Every frame of this film is a choice between looking and looking away."*

*"The unresolved note does not resolve because Yasmin has learned that resolution is a performance, and she no longer performs."*

*"الحب ليس قلعة نبنيها مرة واحدة. الحب حديقة نسقيها كل يوم، أو نتركها تموت."*
*("Love is not a castle we build once. Love is a garden we water every day, or we let it die.")*
