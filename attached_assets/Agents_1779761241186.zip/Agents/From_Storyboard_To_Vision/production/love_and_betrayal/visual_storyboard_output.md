# حب وخيانة — LOVE AND BETRAYAL
## Visual Storyboard Document
### Produced by Visual Storyboard Agent — "From Storyboard To Vision" Pipeline

---

## OVERALL VISUAL ARC SUMMARY

The film's visual journey mirrors Yasmin's emotional descent from golden, perfumed warmth into the bruised violet of revelation, through the storm-grey violence of invasion, and finally to the pale sage of unresolved possibility. The piano — first as a luminous altar of art, then as shattered wreckage, finally as a site of duet confrontation — serves as the visual spine. Omar is visually split across the entire film: warm and present in Act I, then increasingly cyan/teal (operational), dusty violet (compromised), and finally washed in slate grey as his double identity collapses.

**Key Visual Motifs:**
1. **Mirrors & Reflections** — Repeated throughout; Yasmin sees fragments of truth in mirrored surfaces before she can face them directly
2. **The Piano Keyboard** — Horizontal lines of black and white that become bars, then broken teeth
3. **Hands in Close-Up** — Yasmin's pianist hands versus Omar's operative hands; hands touching versus hands weaponized
4. **Cairo's Dual Architecture** — Belle époque concert halls (warm gold) versus concrete safe houses (cold cyan)
5. **Water & Glass** — Rain, coffee cups, shattered mirror glass, each refracting a splintered truth
6. **Doors & Thresholds** — Every scene of revelation framed through doorways; thresholds Omar crosses that Yasmin cannot follow

---

## COLOR ACT MAP

| Act | Timecode | Emotional Palette | Key Visual Shift |
|-----|----------|-------------------|------------------|
| Act I | 0:00–26:00 | Amber/Gold/Warm Sand | Concert hall warmth dissolving into domestic amber |
| Act II-A | 26:00–52:00 | Cyan/Teal/Sea Glass | Surveillance coolness; Omar's operational world bleeds in |
| Act II-B | 52:00–68:00 | Dusty Violet/Bruised Rose | The lie exposed; bruised domesticity |
| Act III | 68:00–95:00 | Slate Grey/Storm Blue/Ash + Emergency Red | Violence, destruction, confrontation |
| Resolution | 95:00–105:00 | Pale Sage/Dawn Grey/Soft Silver | Ambiguous peace; the unresolved note hangs in air |

---

## SCENE 1: THE NOCTURNE (0:00–3:00)
### "Chopin Performance Duality"
**Location:** Cairo Opera House — Main Concert Hall + Backstage + Car Interior
**Palette:** Amber / Gold / Warm Sand → Fading to Night Blue
**Emotional Beat:** Ecstasy / Intimacy / The First Hairline Crack
**Total Frames:** 8

---

### Frame SC-01-SH-01
**Shot Type:** Extreme Wide — Establishing
**Aspect Ratio:** 2.39:1 (Scope)
**Camera:** Low angle from orchestra pit, tilted slightly upward toward the stage
**Duration:** 8 seconds

**Visual Composition:**
The Cairo Opera House main hall fills the frame in majestic scope. Rows of velvet seats descend in golden tiers. The hall's Belle époque architecture glows under amber house lights. Chandeliers cast warm pools. In the deep background, center stage: a single Steinway concert grand gleams under a focused warm spotlight. The piano is a tiny, luminous island in an ocean of velvet and gold. Audience silhouettes fill the foreground, out of focus — bokeh circles of light.

**Subject Placement:**
Yasmin is not yet visible. The empty piano bench waits center stage. The composition creates anticipation — the instrument as shrine before the priestess arrives.

**Lighting:**
Warm tungsten (3200K) from house lights. Single follow-spot on piano (hard, warm, 2800K). The contrast between the lit stage and the shadowed audience creates a natural vignette effect.

**Color:** Amber Gold dominant. Warm sand in the woodwork. Deep burgundy in the velvet seats.

**Mood:** Sacred. Anticipatory. The hush before revelation.

**Props & Set:** Steinway Model D concert grand (black, lacquered, mirror-bright). Crystal chandelier. Gilded balcony railings. Fresh white lilies in a slim vase on the piano's far corner.

**Wardrobe & Makeup:** Yasmin not yet visible.

**Emotional Beat:** The calm before the voice. The audience holds its breath. We hold ours.

---

### Frame SC-01-SH-02
**Shot Type:** Medium Wide — Performance
**Aspect Ratio:** 2.39:1 (Scope)
**Camera:** Stage right, slightly low, looking across the keyboard toward Yasmin's profile
**Duration:** 6 seconds

**Visual Composition:**
Yasmin enters from stage left, walking with measured grace. She wears a flowing amber-gold gown that catches the follow-spot and seems to radiate light. The gown's silk catches micro-highlights as she moves. She pauses at the piano, bows her head briefly — a private ritual — then sits. The camera holds as she lifts her hands above the keys. Her hands hover, angel-like, catching the spotlight. Her face is three-quarter view: serene, eyes half-closed, already somewhere else.

**Subject Placement:**
Yasmin positioned slightly left of center, following rule of thirds. The piano keyboard leads the eye diagonally from bottom-right to center. The white lilies frame her from the right edge. Her hands are the brightest point in frame.

**Lighting:**
Single hard follow-spot from above and slightly stage-front (2800K, 3200K mixed). Soft bounce fill from the piano lid reflecting upward onto her face. No other light sources visible. The world outside the spotlight does not exist.

**Color:** Amber gold gown against black piano. Warm skin tones. The white lilies provide the only cool note — a whisper of the cold world outside.

**Mood:** Transcendent. Devotional. The artist as conduit.

**Props & Set:** The Steinway lid is fully open, creating a reflective sail that bounces light. A slim silver watch on Yasmin's left wrist glints.

**Wardrobe & Makeup:** Yasmin — amber-gold silk gown (backless, flowing sleeves, vintage 1930s-inspired but modern cut). Hair in a loose, elegant chignon with a few escaped strands that catch light. Minimal makeup — luminous skin, dark eyes, nude lip. A single antique gold earring visible (Omar's gift). Omar — not present.

**Emotional Beat:** Yasmin at the height of her power. The world she has built. The self she believes herself to be.

---

### Frame SC-01-SH-03
**Shot Type:** Extreme Close-Up — Hands on Keys
**Aspect Ratio:** 2.39:1 (Scope)
**Camera:** Directly above keyboard, looking straight down
**Duration:** 4 seconds

**Visual Composition:**
The black-and-white keys fill the entire frame in abstract geometry. Yasmin's hands enter from top and bottom of frame — elegant, long-fingered, strong. She plays a Chopin Nocturne passage. The fingers press, release, glide. The contrast between her warm skin and the cold ivory is stark. Shadows from her fingers stretch across the white keys like dark fingers reaching. Motion blur on the fastest passages.

**Subject Placement:**
Hands positioned center-frame, creating symmetry. The keyboard's repeating pattern creates visual rhythm that echoes the music.

**Lighting:**
Hard spotlight from directly above — the hands cast long, dramatic shadows across the keys. High contrast. The black keys absorb light; the white keys reflect it. Chiaroscuro on a miniature scale.

**Color:** Monochromatic with warm skin intrusion. The amber of the spotlight warms the ivory to cream. The black keys are true black — void-like.

**Mood:** Hypnotic. The marriage of flesh and machine. Beauty as precision.

**Props & Set:** Only the keyboard exists. The world has been reduced to touch and sound.

**Wardrobe & Makeup:** Only hands visible — the silver watch glints at wrist edge. No nail polish. Clean, practical, beautiful.

**Emotional Beat:** The pure language of music. Before words. Before doubt.

---

### Frame SC-01-SH-04
**Shot Type:** Medium Close-Up — Two-Shot (Yasmin + Omar in audience)
**Aspect Ratio:** 2.39:1 (Scope)
**Camera:** From stage, looking into the audience, long lens compressing depth
**Duration:** 5 seconds

**Visual Composition:**
A racked-focus shift from Yasmin (blurred in background) to Omar (sharp in midground). Omar sits in the fourth row, center. He wears a charcoal suit, white shirt open at collar. He is perfectly still, watching Yasmin with an expression that reads as adoration — but his eyes are too focused, too controlled. Around him, audience members are blurred into soft shapes. A woman to his left wipes a tear. Omar does not blink. In the foreground, out of focus: the edge of the stage, a microphone stand.

**Subject Placement:**
Omar positioned right of center, seated. The composition uses the blurred audience members as framing elements on left and right. Yasmin is a golden blur in the deep background — she is the light he watches.

**Lighting:**
Available house light on audience (warm, dim). Omar's face catches a spill of stage light from the follow-spot — half his face is warmer than the other half. The asymmetry is subtle but present. One eye catches gold; the other remains in cooler shadow.

**Color:** Charcoal suit against warm amber background. The split lighting creates a visual schism — warm/cool on the same face.

**Mood:** Adoration with a hairline fracture. The perfect husband, watching too perfectly.

**Props & Set:** Theater seat, program in Omar's lap (unopened). A glass of water on the floor beside his seat.

**Wardrobe & Makeup:** Omar — charcoal slim-fit suit, no tie, white shirt with top button open. Clean-shaven. Hair neatly styled. A watch that is not the same one he will wear in operational mode (this one is elegant, thin, gold). Yasmin — golden blur, still radiant.

**Emotional Beat:** The audience's love for Yasmin. Omar's love — or is it surveillance? The first visual doubt.

---

### Frame SC-01-SH-05
**Shot Type:** Close-Up — Yasmin's Face (Performance Ecstasy)
**Aspect Ratio:** 2.39:1 (Scope)
**Camera:** Slightly below eye level, looking up
**Duration:** 4 seconds

**Visual Composition:**
Yasmin's face fills the frame in rapture. Eyes closed, head tilted slightly back, lips parted. A single tear traces down her right cheek — not of sadness, but of transcendent connection to the music. The tear catches the spotlight and becomes a streak of liquid gold. Her skin glows. She is beautiful and unreachable. Behind her, the theater's ornate ceiling is visible but out of focus — a baroque heaven.

**Subject Placement:**
Face centered, slightly favoring the right third. The tear draws the eye down her cheek. The background architecture provides depth without distraction.

**Lighting:**
Warm key from above and front (follow-spot). Soft fill from piano lid reflection. The tear becomes its own light source — a micro-highlight. Skin rendered in warm honey tones.

**Color:** Gold skin, gold light, gold tear. The world is amber. She is the sun.

**Mood:** Transcendence. The highest point of the film's warmth. Never this innocent again.

**Props & Set:** Only the suggestion of the theater ceiling — gilded angels, painted clouds, Belle époque splendor.

**Wardrobe & Makeup:** Escaped hair strands stick to the tear track. The antique gold earring catches light. Skin dewy with the heat of performance.

**Emotional Beat:** The last moment of pure, unfractured joy in the film.

---

### Frame SC-01-SH-06
**Shot Type:** Wide — Backstage Corridor
**Aspect Ratio:** 2.39:1 (Scope)
**Camera:** Tracking, following Yasmin from behind as she walks down a narrow corridor
**Duration:** 6 seconds

**Visual Composition:**
Yasmin walks away from the camera down a narrow backstage corridor. The amber-gold gown trails behind her. The corridor is concrete and utilitarian — a harsh contrast to the gilded hall. Fluorescent lights overhead cast a greenish-white pallor. At the far end of the corridor, a door opens into a warm room — her dressing room, golden light spilling out. She walks toward that warmth. But the corridor itself is cold, industrial, unforgiving. The transition from public goddess to private woman is visualized in the architecture.

**Subject Placement:**
Yasmin is small in frame, center, walking away. The corridor walls create converging lines that pull the eye toward the golden door. She is a golden figure in a grey tunnel.

**Lighting:**
Overhead fluorescents (cool, clinical, 5600K) in the corridor. Warm tungsten (3200K) spilling from the open dressing room door. The contrast between the two light sources creates a visual threshold — crossing from one world to another.

**Color:** Cool grey-green corridor. Amber gown creating a trail of warmth that diminishes as she moves away. The golden door at the end is a beacon.

**Mood:** The return to earth. The goddess becomes mortal again. The corridor is liminal space.

**Props & Set:** Concrete walls with exposed wiring. A fire extinguisher. A mop and bucket. Stage equipment stacked haphazardly. A poster of last month's opera production, peeling at corners.

**Wardrobe & Makeup:** The amber gown drags slightly on the concrete floor, picking up dust at the hem — the first visual diminishment.

**Emotional Beat:** The descent from art to life. The warmth is ahead, but the path is cold.

---

### Frame SC-01-SH-07
**Shot Type:** Medium — Dressing Room
**Aspect Ratio:** 2.39:1 (Scope)
**Camera:** Through the doorway, looking in
**Duration:** 5 seconds

**Visual Composition:**
Yasmin sits at her dressing room mirror, removing the antique gold earring. The room is small, warm, cluttered with flowers. The mirror is framed with light bulbs — classic theater dressing room. In the mirror's reflection, we see Yasmin's face and, behind her, the door. Omar enters the frame from behind, closing the door. His reflection appears in the mirror before his physical presence is felt. He comes up behind her, places his hands on her shoulders. Their eyes meet in the mirror.

**Subject Placement:**
Yasmin seated center, facing mirror (away from camera). Omar enters from deep background. The mirror dominates the composition. We see Yasmin's front through the mirror; we see her back in reality. The duality is immediate.

**Lighting:**
Warm tungsten bulbs around the mirror (2800K). Soft overhead room light. The mirror bulbs create a halo effect around Yasmin's reflected face. Omar, entering from the darker area behind her, is partially in shadow until he steps into the mirror's glow.

**Color:** Warm gold dressing room. White and pink flowers everywhere. Yasmin's skin golden in the mirror light. Omar's charcoal suit absorbs light — he is a dark figure in the golden room.

**Mood:** Intimacy. The private world. But the mirror introduces doubt — which is the real image?

**Props & Set:** Dressing room mirror with light bulbs. Makeup scattered on table — Chanel powder, Egyptian kohl pencil, roses in vases, congratulatory telegrams pinned to walls. A framed photo of Yasmin and Omar at Luxor (happy, sun-drenched). A bottle of perfume. The antique earring box.

**Wardrobe & Makeup:** Yasmin — gown loosened at back, makeup slightly worn from performance heat, the tear track still faintly visible. Omar — charcoal suit, now with a loosened collar, more relaxed than in the theater.

**Emotional Beat:** The reunion. The beloved arrives. But he arrives in the mirror first — a visual whisper of the duality to come.

---

### Frame SC-01-SH-08
**Shot Type:** Close-Up — Car Interior, Night
**Aspect Ratio:** 2.39:1 (Scope)
**Camera:** From back seat, between Omar and Yasmin, looking forward through windshield
**Duration:** 7 seconds

**Visual Composition:**
Yasmin and Omar in the back of a car at night. Cairo streams past the windows — blurred neon, streetlights, the Nile's dark ribbon. Yasmin rests her head on Omar's shoulder, eyes closed, content. Omar looks forward, not at her. His face is half-illuminated by passing streetlights — each light briefly revealing his expression, then plunging it into shadow. In one flash of light, his jaw is tight. In the next shadow, we cannot read him. The windshield shows the road ahead and, superimposed, faint reflections of the dashboard lights — green, red — like operational readouts.

**Subject Placement:**
Yasmin on the left, nestled in. Omar on the right, rigid. The composition creates a diagonal — her softness against his tension. The windshield fills the upper third with the streaming city.

**Lighting:**
Available light only — passing streetlights (mixed tungsten and sodium vapor), dashboard glow (green, cyan). No movie light. The intermittent illumination creates a strobe effect on Omar's face. Yasmin remains mostly in shadow, nestled against him, peaceful.

**Color:** Warm amber from Yasmin's gown (still visible at edge of frame). Cool cyan and green from dashboard. The exterior world is sodium orange and neon pink. The palette is already splitting.

**Mood:** Peace interrupted by subliminal unease. The city rushes past. Omar is somewhere else even as Yasmin sleeps against him.

**Props & Set:** Car interior — leather seats, wood trim. The driver's head visible as a dark silhouette. A second phone, barely visible in Omar's jacket pocket — a darker rectangle against dark fabric. The Cairo skyline visible in flashes: minarets, high-rises, the Corniche.

**Wardrobe & Makeup:** Yasmin — exhausted, peaceful, still in the gown but wrapped in Omar's jacket. Omar — the charcoal suit, now with a second phone visible as a bulge in the interior pocket. His watch, in this light, looks different — thicker, more tactical.

**Emotional Beat:** The last frame of Act I warmth. The audience has seen the second phone. Yasmin has not. The duality is planted.

---

## TRANSITION: SC-01 → SC-02
**Frame T-01-02**
**Shot Type:** Abstract — Macro
**Aspect Ratio:** 2.39:1
**Camera:** Extreme close-up of Yasmin's hand on a drawer handle
**Duration:** 3 seconds

**Visual Composition:**
Yasmin's hand reaches for a polished mahogany drawer handle. The wood grain is visible in extreme detail. Her fingers — those same fingers that played Chopin — now grip the handle. The lighting is morning daylight, cool and honest. The warmth of Act I is gone. The image is a direct visual bridge: the hand that created beauty now seeks something hidden.

**Color:** Warm wood against cool morning light. The amber is fading.

**Mood:** The passage of time. The transition from public performance to private search.

---

## SCENE 2: THE DRAWER (8:00–12:00)
### "Second Phone Discovery"
**Location:** Yasmin & Omar's Apartment — Master Bedroom / Dressing Area
**Palette:** Fading Amber → Dusty Violet (First intrusion of betrayal color)
**Emotional Beat:** Curiosity / Discovery / Fracture
**Total Frames:** 7

---

### Frame SC-02-SH-01
**Shot Type:** Wide — Bedroom Morning
**Aspect Ratio:** 2.39:1
**Camera:** From doorway, looking in
**Duration:** 5 seconds

**Visual Composition:**
The master bedroom in morning light. Dust motes dance in sunbeams through sheer curtains. The bed is unmade — Omar's side empty, already left for work. Yasmin's side shows the impression of her body, the sheets still warm. The room is tasteful, cultured: books in Arabic and French, a small writing desk, framed photos. But the camera holds on the dressing table — a Victorian piece Omar restored for her. Its drawers are closed. The room is quiet. Too quiet.

**Subject Placement:**
Yasmin is not yet in frame. The empty bed dominates center. The dressing table waits in the right third. The doorway creates a natural frame-within-frame.

**Lighting:**
Natural morning light (5600K but warmed by the amber curtains to approximately 4800K). Soft, directional from window left. Long shadows. The light is beautiful but reveals too much — every dust mote, every wrinkle in the sheets.

**Color:** Fading amber. The gold of the curtains is washed out by daylight. The room feels less warm than the concert hall. A palette in transition.

**Mood:** Domestic tranquility with an undertone of absence. Omar is gone. Where?

**Props & Set:** King bed with white linens and amber throw. Bookshelves. Writing desk with fountain pen and unfinished letter. Framed wedding photo (Yasmin and Omar, happier, younger). The Victorian dressing table with its multiple drawers. A vase of dried roses — past their prime.

**Wardrobe & Makeup:** Yasmin not visible yet.

**Emotional Beat:** The empty space where love should be. The question not yet asked.

---

### Frame SC-02-SH-02
**Shot Type:** Medium — Yasmin at Dressing Table
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, Yasmin's profile
**Duration:** 4 seconds

**Visual Composition:**
Yasmin in a cream silk robe, hair down, no makeup. She sits at the dressing table brushing her hair. The brush strokes are slow, meditative. Her expression is neutral, almost blank — morning mind, not yet fully awake. In the mirror, we see her face and, behind her, the room. The room is normal. She is normal. But her eyes, in the mirror, drift to the drawers. Something is on her mind. The brushing continues, but the rhythm is disturbed — she pauses, mid-stroke.

**Subject Placement:**
Yasmin seated left of center. The mirror creates a second plane of visual information. The drawers are visible in the lower right of frame.

**Lighting:**
Natural morning light from window, soft on her face. The mirror reflects the window light, creating a secondary brightness. The dressing table bulbs are off — they belong to night, to performance. This is morning. This is real.

**Color:** Cream robe against warm wood. Skin without makeup — paler, more vulnerable. The color palette is muted, honest. The amber is residual, not dominant.

**Mood:** The ordinary morning. The mind wandering to places it shouldn't. The first unconscious suspicion.

**Props & Set:** Silver hairbrush (antique, Omar's grandmother's). Perfume bottles. The antique earring box from the concert, now open and empty. A calendar showing the day's date circled in red — concert date. A cup of cold coffee.

**Wardrobe & Makeup:** Yasmin — cream silk robe, loosely belted. Hair unbrushed, wild, beautiful. No makeup. Face younger without the stage paint. More vulnerable.

**Emotional Beat:** The private self. The woman behind the artist. Something is wrong but she doesn't know what.

---

### Frame SC-02-SH-03
**Shot Type:** Close-Up — Hand Opening Drawer
**Aspect Ratio:** 2.39:1
**Camera:** Direct side angle, at drawer height
**Duration:** 3 seconds

**Visual Composition:**
Yasmin's hand — the same hands we saw on the piano keys — now pulls open the middle drawer of the dressing table. The drawer slides smoothly on well-oiled runners. Inside: the usual debris of a shared life. Hair ties. A watch battery. Ticket stubs. A folded letter. And beneath these, something that doesn't belong: the corner of a black object, matte, rectangular. A phone. Not Omar's usual phone — she knows his phone. This is different.

**Subject Placement:**
The hand dominates left frame. The drawer's interior fills center and right. The phone's edge is visible in the lower right quadrant — a dark intruder in the domestic clutter.

**Lighting:**
Morning light from above and left. The drawer's interior is in shadow, making the black phone even darker — a void in the warm clutter.

**Color:** Warm wood interior. Colorful clutter (pink hair ties, blue ticket stubs). The black phone is colorless — a monochrome intrusion.

**Mood:** Curiosity becoming unease. The ordinary made strange by one wrong object.

**Props & Set:** Drawer contents detailed: hair ties, cinema tickets (French film, last month), a dried flower, a handwritten note in Omar's script ("Pick up milk"), the black phone with its matte finish, no visible branding.

**Wardrobe & Makeup:** Only hand and forearm visible. Cream silk sleeve.

**Emotional Beat:** The discovery. The first physical evidence of the double life.

---

### Frame SC-02-SH-04
**Shot Type:** Medium Close-Up — Yasmin Holding the Phone
**Aspect Ratio:** 2.39:1
**Camera:** Slightly low, looking up at Yasmin's face
**Duration:** 6 seconds

**Visual Composition:**
Yasmin holds the black phone in both hands, staring at it as if it were a dead thing. Her face transforms in slow motion: confusion, then dawning realization, then something like fear. She turns the phone over. It is heavier than a normal phone. Thicker. No brand markings. A single LED blinks amber — slow, regular, like a heartbeat. She presses a button. The screen lights up with a lock screen: a photo of her. Taken without her knowledge. She is on stage, playing, unaware. The photo is beautiful but the violation is visceral.

**Subject Placement:**
Yasmin center frame. The phone held at chest level, screen angled slightly toward camera so we glimpse the image. Her face is the dominant visual element — the shift from woman to someone recognizing danger.

**Lighting:**
Morning light now feels harsher. It falls across her face without mercy. The phone screen casts a blue-white glow upward onto her chin and lips — an unnatural light source in the warm room.

**Color:** The first dusty violet intrusion. The phone's blue-white screen light clashes with the amber morning. Her skin tone shifts — the warmth is leaving her face.

**Mood:** Betrayal as physical sensation. The room is unchanged but the world has tilted.

**Props & Set:** The black phone — matte finish, thick, a single amber LED, a small port unlike standard charging ports. The screen image: Yasmin at the piano, shot from audience, long lens, her face in performance rapture. Metadata visible: date, three months ago. The lock screen shows no carrier name, no standard UI — a custom operating system.

**Wardrobe & Makeup:** Yasmin's hands tremble. The cream robe slips from one shoulder, unnoticed. Her face drains of color. The morning-after vulnerability becomes something else — the vulnerability of someone realizing they're watched.

**Emotional Beat:** The fracture. The moment the marriage becomes a question.

---

### Frame SC-02-SH-05
**Shot Type:** Overhead — Phone Screen and Hands
**Aspect Ratio:** 2.39:1
**Camera:** Directly above, looking down
**Duration:** 4 seconds

**Visual Composition:**
Yasmin's hands on the dressing table, the phone between them. She swipes through screens — not her world, not any world she recognizes. Encrypted messaging apps with codenames. A map with pins. Photos of people she doesn't know in places she doesn't recognize. A photo of Omar in a café she doesn't know, with a woman she doesn't know. Her finger hovers over that photo. The screen's blue glow illuminates her hands from below, making them look like someone else's hands.

**Subject Placement:**
Hands and phone fill center frame. The dressing table surface provides texture — wood grain, a small scratch, the ring from a coffee cup.

**Lighting:**
Screen light dominates. Blue-white (6500K) from below. The natural morning light is still present but now feels like a memory.

**Color:** The dusty violet takes hold. Blue screen against warm wood. The clash of temperatures is visual dissonance. The amber is being defeated.

**Mood:** The violation of privacy as visceral experience. The phone is a portal to another life.

**Props & Set:** Phone screen contents: encrypted chat (codename: "AL-MOZAINI" — Omar's operational alias), geolocation pins across Cairo, Alexandria, Sinai. Photos of meeting locations. A single photo of Yasmin labeled "ASSET/COVER." The phone interface is military-grade, utilitarian, terrifying in its efficiency.

**Wardrobe & Makeup:** Hands only — trembling. The left hand's silver watch (the concert watch) catches the screen light.

**Emotional Beat:** The evidence mounts. The double life is not suspicion — it is fact.

---

### Frame SC-02-SH-06
**Shot Type:** Medium — Yasmin and Mirror
**Aspect Ratio:** 2.39:1
**Camera:** From behind Yasmin, looking at her reflection
**Duration:** 5 seconds

**Visual Composition:**
Yasmin stands abruptly. The chair scrapes backward. She looks at herself in the dressing mirror — but does not recognize herself. Her hand reaches out to touch the mirror's surface, as if checking whether it is real. In the reflection, behind her, the bedroom door is visible. It is closed. She is alone with what she knows. Her face in the mirror shows a woman at the edge of something — she does not yet know what. The reflection is clearer than the reality. The mirror that showed Omar entering now shows only her own fear.

**Subject Placement:**
Yasmin's back fills left frame. Her reflection dominates center-right. The mirror's light bulbs create a halo that now looks like an interrogation light.

**Lighting:**
Mixed — morning window light plus the mirror bulbs. But the balance has shifted. The bulbs seem harsher. The morning light seems to be fading, though it is only mid-morning.

**Color:** The dusty violet is now the dominant emotional tone. Her skin looks grey-violet in the mirror. The cream robe looks stained, though it is not. Color as emotional state.

**Mood:** The self unrecognizable. The private world invaded. The mirror as witness.

**Props & Set:** The mirror. The dressing table. The reflection of the bed behind her — still unmade, still empty on his side.

**Wardrobe & Makeup:** Yasmin — robe slipping further, hair now wilder, face pale with shock. She looks younger and older simultaneously.

**Emotional Beat:** The confrontation with the self. Who am I if this is true? Who was I before I knew?

---

### Frame SC-02-SH-07
**Shot Type:** Close-Up — Phone Returned to Drawer
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, drawer level
**Duration:** 4 seconds

**Visual Composition:**
Yasmin's hand places the phone back in the drawer. She covers it with the ticket stubs, the hair ties, the mundane debris of their life. She closes the drawer. The click of the drawer closing is the sound of a door closing on her old life. Her hand rests on the drawer front for a moment. Then she stands, smooths her robe, and turns away. The decision not to confront — yet. The decision to watch.

**Subject Placement:**
Hand and drawer dominate. The action is simple but loaded with meaning.

**Lighting:**
The morning light is now fully cool. The warmth has left the room.

**Color:** Dusty violet dominant. The amber is a memory.

**Mood:** The secret kept. The watcher becomes the watched. The transformation begins.

**Props & Set:** The drawer closes. The dressing table returns to normal. But nothing is normal.

**Wardrobe & Makeup:** Yasmin's hand is steady now. The tremor has become resolve.

**Emotional Beat:** The decision to investigate rather than confront. Yasmin enters the world of suspicion. The drawer is closed but the marriage is opened.

---

## TRANSITION: SC-02 → SC-03
**Frame T-02-03**
**Shot Type:** Abstract — Time-lapse
**Aspect Ratio:** 2.39:1
**Camera:** Fixed on the apartment window, day becoming night
**Duration:** 3 seconds

**Visual Composition:**
The apartment window. Daylight fades. The Cairo skyline transitions from gold to sodium orange to deep blue. Cars pass in streaks. Time is passing. Yasmin is waiting, watching, planning. The window glass reflects the room behind — a figure (Yasmin) standing in darkness, watching the city. The transition from day to night mirrors the transition from trust to surveillance.

**Color:** Amber → Cyan. The palette shift is complete.

**Mood:** The passage of waiting time. The watcher in the dark.

---

## SCENE 3: THE FOLLOW (18:00–26:00)
### "Café Surveillance"
**Location:** Downtown Cairo — European-style café + Surrounding streets
**Palette:** Cyan / Teal / Sea Glass (Operational coolness invades)
**Emotional Beat:** Suspicion / Confirmation / The Other Woman (is not what she seems)
**Total Frames:** 8

---

### Frame SC-03-SH-01
**Shot Type:** Wide — Cairo Street, Late Afternoon
**Aspect Ratio:** 2.39:1
**Camera:** From inside a café, looking out through glass doors
**Duration:** 5 seconds

**Visual Composition:**
The café interior is cool, teal-toned — marble floors, chrome fixtures, potted palms. Through the glass doors, the Cairo street is dusty, warm, chaotic. Yasmin sits at a corner table, alone, wearing sunglasses and a headscarf — an attempt at anonymity that makes her more conspicuous. She holds an espresso she hasn't touched. Her eyes, behind the sunglasses, watch the street. A reflection in the glass doors shows the café interior behind her — other patrons, waiters, the normal world continuing. She is outside the normal world now.

**Subject Placement:**
Yasmin in the left third, seated. The glass doors fill center and right, creating a plane of reflection and transparency. The street beyond is visible through the glass. Reflections overlap: interior patrons reflected on the glass, superimposed over the exterior street.

**Lighting:**
Late afternoon sun (warm, 4500K) from the street side. The café interior is lit by cool LED panels (5600K). The contrast between warm exterior and cool interior is stark — she has entered a colder world.

**Color:** Cyan/teal café interior against warm amber street. Yasmin's clothing is neutral — beige trench coat, dark headscarf — she is trying to disappear. The palette is split: warm world outside, cool world inside. She is in the cool world now.

**Mood:** Surveillance as isolation. The watcher is always alone. The sunglasses hide her but also trap her.

**Props & Set:** Marble-topped café table. Untouched espresso in a white cup. A newspaper (Al-Ahram) open but unread. Sunglasses (large, dark). The headscarf (silk, charcoal). Chrome café chairs. Potted palms. The street outside: vendors, traffic, a donkey cart, Cairo's endless motion.

**Wardrobe & Makeup:** Yasmin — beige trench coat over dark clothing, charcoal silk headscarf (unfamiliar, a disguise), large sunglasses that obscure half her face. No jewelry. No watch. She has stripped herself of identity to watch.

**Emotional Beat:** The transformation into watcher. The concert pianist is gone. This is someone else.

---

### Frame SC-03-SH-02
**Shot Type:** Long Lens — Omar Across Street
**Aspect Ratio:** 2.39:1
**Camera:** From Yasmin's POV, extreme telephoto compression
**Duration:** 4 seconds

**Visual Composition:**
Omar across the street, entering a building. The telephoto compression makes the distance between them feel both immense and flattened — he is close enough to see but unreachable behind the glass. He wears a different suit than his usual charcoal — this one is navy, more anonymous. He checks his phone as he walks. His gait is different — more purposeful, less relaxed. He does not look around. He is not worried about being followed. This is his operational mode. The building he enters is unmarked, concrete, unremarkable — but his entry is swift, coded, habitual.

**Subject Placement:**
Omar center frame, small due to distance. The street traffic creates a moving foreground that partially obscures him — cars, pedestrians, a cart. He is both visible and hidden by the city.

**Lighting:**
Natural late afternoon. Harsh sunlight from the west. Omar's face is half-lit, half-shadowed. The building entrance is in shadow — he moves from light to dark.

**Color:** Warm exterior palette still. Omar is in the warm world while Yasmin watches from the cool café. The split is maintained.

**Mood:** The husband as stranger. The familiar body with unfamiliar purpose.

**Props & Set:** The unmarked building — concrete, no signage, a metal door with a buzzer. Omar's navy suit. His phone — the operational phone, matte black, visible in his hand. The Cairo street: taxis, a fruit vendor, a billboard for a mobile phone company.

**Wardrobe & Makeup:** Omar — navy suit (operational, not his usual charcoal), white shirt, no tie. Sunglasses (different pair than usual — aviator style, more tactical). His hair is slightly different — combed flatter, less styled. He is a version of himself.

**Emotional Beat:** Confirmation. He is not who he pretends to be. The building is not what it seems.

---

### Frame SC-03-SH-03
**Shot Type:** Medium — Yasmin Removing Sunglasses
**Aspect Ratio:** 2.39:1
**Camera:** Café interior, close on Yasmin's face
**Duration:** 3 seconds

**Visual Composition:**
Yasmin removes her sunglasses. Her eyes are red-rimmed, exhausted. She has been watching for hours. She looks at the espresso — cold now, with a thin film on top. She does not drink it. Her hand trembles slightly as she sets the sunglasses down. The café around her continues — a couple laughs at the next table, a businessman talks loudly on his phone, a waiter passes with a tray. None of them see her. She is invisible in her pain.

**Subject Placement:**
Yasmin center frame. The café background is slightly out of focus but active — movement, life, color. She is still in the center of a world that has forgotten her.

**Lighting:**
Cool café light from above. Her face is lit by the café's teal-toned LEDs. The sunglasses, removed, reflect the ceiling lights — two small circles of cool white.

**Color:** Cyan/teal dominant. Yasmin's skin looks pale, cool, unhealthy. The beige trench coat looks grey in this light. The espresso is black.

**Mood:** Exhaustion. The weight of knowing without understanding.

**Props & Set:** The cold espresso. The sunglasses (designer, Omar's gift — a cruel irony). The unread newspaper. A napkin with a phone number scrawled on it — a waiter, or something else.

**Wardrobe & Makeup:** Yasmin — without sunglasses, her eyes are the focus. Dark circles. The headscarf has slipped, revealing hair. She looks like she has been crying, though she hasn't — not yet.

**Emotional Beat:** The human cost of surveillance. She is becoming someone who watches instead of lives.

---

### Frame SC-03-SH-04
**Shot Type:** Wide — Nour Enters Frame
**Aspect Ratio:** 2.39:1
**Camera:** From behind Yasmin, over her shoulder
**Duration:** 5 seconds

**Visual Composition:**
A woman enters the café and walks directly to Yasmin's table. This is Nour — Omar's handler, though Yasmin does not know this yet. Nour is in her forties, elegant, severe. She wears a tailored teal blazer over black — the color of the operational world. She sits without asking. Yasmin looks up, startled. The café around them continues its bustle, but a bubble of silence forms around their table. Nour places a file on the table — a thin manila folder. She does not open it. She looks at Yasmin with an expression that is not quite pity, not quite warning.

**Subject Placement:**
Yasmin in foreground left, her shoulder and back visible. Nour enters from deep background right, walks to center, sits. The file is placed on the table between them — a barrier and a bridge.

**Lighting:**
Cool café light. Nour's face is sharper, more angular in this light than Yasmin's. The contrast between them is visual: softness versus hardness, artist versus operative.

**Color:** Teal dominates. Nour's blazer matches the café's color scheme — she belongs to this world. Yasmin's beige looks out of place, a refugee from the warm world.

**Mood:** The operational world makes contact. The surveillance is mutual.

**Props & Set:** The manila file. Nour's leather bag (expensive, utilitarian). Her phone — standard consumer model, a deliberate disguise. The cold espressos. The café's marble table now holds a conversation that could change everything.

**Wardrobe & Makeup:** Nour — teal blazer, black silk shirt, no jewelry, minimal makeup (defined brows, nude lip, severe). Hair in a precise bob. She looks like a diplomat or a lawyer — someone with authority. Yasmin — disheveled, defensive, small in her chair.

**Emotional Beat:** The world reaches out to claim Yasmin. She is no longer an observer — she is being observed.

---

### Frame SC-03-SH-05
**Shot Type:** Two-Shot — Yasmin and Nour at Table
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, both profiles visible
**Duration:** 6 seconds

**Visual Composition:**
Yasmin and Nour face each other across the marble table. The composition is a duel — two women, one file, a world of meaning between them. Nour speaks; Yasmin listens. Nour's hands are flat on the table, controlled. Yasmin's hands are in her lap, clutching the fabric of her trench coat. The file remains closed but present — a visual promise of revelation. The café background is blurred but active — movement, life, the world continuing outside their bubble.

**Subject Placement:**
Both women in profile, facing each other. The file sits between them on the table — a third presence. The composition is balanced but tense — mirror images of different worlds.

**Lighting:**
Cool overhead café light. Both faces lit from above, creating slight shadows under the eyes — both women look tired, but Nour's tiredness is seasoned, professional. Yasmin's is raw.

**Color:** Teal/cyan. The file is manila — a warm intrusion in the cool palette, promising the warmth of truth or the burn of it.

**Mood:** The conversation that changes everything. The operational world explained.

**Props & Set:** The manila file. Two espresso cups (Nour's is full, untouched — she ordered to blend in). A glass of water. Nour's phone, face-down. Yasmin's sunglasses.

**Wardrobe & Makeup:** The contrast is the story: Nour's tailored precision versus Yasmin's improvised disguise. Two ways of being a woman in a man's world of secrets.

**Emotional Beat:** The truth offered, not forced. Yasmin can walk away. She doesn't.

---

### Frame SC-03-SH-06
**Shot Type:** Close-Up — File Opened, Photographs
**Aspect Ratio:** 2.39:1
**Camera:** Over the shoulder, looking down at file contents
**Duration:** 5 seconds

**Visual Composition:**
Nour opens the file. Yasmin looks down. The camera sees what Yasmin sees: photographs. Omar in various locations — cafés, markets, a car, a rooftop. In some photos he is alone. In others he is with people Yasmin doesn't know. In one photo he is handing a package to a man in a crowd. In another he is on a phone, face intense. The photos are surveillance photos — grainy, long lens, timestamped. They are evidence of a life Yasmin never knew. Her finger touches one photo — Omar at a café she has never been to, smiling at someone she doesn't know. The smile is his real smile. She recognizes it. The pain is that she recognizes it.

**Subject Placement:**
The file and photos fill the frame. Yasmin's hand enters from left, touching a photo. Nour's hand is visible at top, holding the file open.

**Lighting:**
The photos are matte, grainy, poorly lit — surveillance aesthetic. The café light falls on them without improving them. They look like evidence.

**Color:** The photos are desaturated, cyan-tinted — the color of surveillance. The manila file is warm. Yasmin's finger is pale against the photo's grey tones.

**Mood:** The evidence of betrayal in tangible form. The photos are more real than memory.

**Props & Set:** Surveillance photographs (8x10, grainy, timestamped). Some show locations: Khan el-Khalili market at night, a rooftop in Garden City, a car on the Corniche. One photo shows the woman from Omar's phone — but she is not a lover. She is older, severe, handing Omar a briefcase. Another operative? A source? The ambiguity is worse than certainty.

**Wardrobe & Makeup:** Hands only — Yasmin's hand with the silver concert watch, trembling. Nour's hands — steady, no jewelry, a small scar on the right thumb.

**Emotional Beat:** The evidence overwhelming. The double life documented. The smile she recognizes on a stranger's face.

---

### Frame SC-03-SH-07
**Shot Type:** Medium — Yasmin's Reaction
**Aspect Ratio:** 2.39:1
**Camera:** Frontal, close on Yasmin's face
**Duration:** 4 seconds

**Visual Composition:**
Yasmin looks up from the file. Her face has changed. The last softness is gone. She looks at Nour with an expression that is part hatred, part understanding, part terrible clarity. She nods once — a small, sharp movement. She accepts the file. She accepts the truth. She accepts the mission that Nour is about to propose. The café around them is irrelevant now. The world has narrowed to this table, this file, this decision.

**Subject Placement:**
Yasmin center frame. Nour is visible at the right edge, out of focus — the world is now Yasmin's interior.

**Lighting:**
Cool café light. But Yasmin's eyes seem to generate their own light — a cold fire.

**Color:** Dusty violet begins to invade the cyan. The betrayal color returns, deeper now.

**Mood:** The decision. The artist becomes operative. The wife becomes spy.

**Props & Set:** The file, now closed, in Yasmin's hands. Her decision made tangible.

**Wardrobe & Makeup:** Yasmin — the headscarf is removed. Her hair falls free. She looks more herself and less herself simultaneously. The sunglasses are forgotten.

**Emotional Beat:** The crossing of a threshold. She is no longer the woman who played Chopin. She is someone new, someone harder.

---

### Frame SC-03-SH-08
**Shot Type:** Wide — Leaving the Café
**Aspect Ratio:** 2.39:1
**Camera:** From the street, looking in through the glass doors
**Duration:** 6 seconds

**Visual Composition:**
Yasmin and Nour leave the café together. Through the glass doors, we see them as reflections and reality — doubled, like the life Yasmin now leads. They do not touch. They do not look at each other. They walk in parallel, two women who have made an alliance. The Cairo street swallows them. The café remains behind, its marble and chrome indifferent. The glass doors close. The scene ends with the doors — a threshold crossed, a world entered.

**Subject Placement:**
The glass doors center frame. Yasmin and Nour visible through the doors, walking away from camera, toward the street. Their reflections visible on the glass. The street beyond is bright, overwhelming.

**Lighting:**
Mixed — café interior cool, street exterior warm. The glass doors hold both worlds in suspension.

**Color:** The split is complete: cyan interior, amber exterior. They walk from cool into warm, from surveillance into the city.

**Mood:** The alliance formed. The city as cover. The beginning of the active phase.

**Props & Set:** The glass doors. The café's name in gold lettering ("Café Riche" — a real Cairo institution, historic, a place of secrets). The street: traffic, noise, life. Nour's car — black, European, anonymous — waiting at the curb.

**Wardrobe & Makeup:** Both women walk with purpose now. The watcher and the watched have become partners.

**Emotional Beat:** The end of passive surveillance. The beginning of active engagement.

---

## TRANSITION: SC-03 → SC-04
**Frame T-03-04**
**Shot Type:** Abstract — Map and City Lights
**Aspect Ratio:** 2.39:1
**Camera:** Overhead, a map of Cairo with pins, then dissolve to night city
**Duration:** 3 seconds

**Visual Composition:**
A map of Cairo spread on a table. Pins mark locations — the café, the opera house, the apartment, and now new pins: an address in Garden City, a location in Maadi. The camera pulls up from the map and dissolves to an aerial view of Cairo at night — the city as a field of lights, indifferent, beautiful, hiding everything. The transition from map to city suggests the gap between knowledge and reality.

**Color:** Deep blue night. Amber and cyan lights. The map is sepia, nostalgic, false.

**Mood:** The city as labyrinth. The map is not the territory.

---

## SCENE 4: THE SAFE HOUSE (48:00–52:00)
### "Midpoint Twist"
**Location:** Garden City Safe House — Dilapidated Belle époque Apartment
**Palette:** Dusty Violet / Bruised Rose (Betrayal fully bloomed)
**Emotional Beat:** Confrontation / Revelation / The Mission Revealed
**Total Frames:** 7

---

### Frame SC-04-SH-01
**Shot Type:** Wide — Exterior, Night
**Aspect Ratio:** 2.39:1
**Camera:** From across the street, low angle
**Duration:** 6 seconds

**Visual Composition:**
A Belle époque building in Garden City, once grand, now peeling. The facade is French colonial — balconies with iron lacework, tall shutters, carved stone. But the paint is flaking, the shutters are rotting, the garden is overgrown. A single light burns in a third-floor window — the only sign of life. The surrounding buildings are modern, concrete, indifferent. This building is a ghost of Cairo's cosmopolitan past, hiding secrets in its decay. Rain has just fallen — the street is wet, reflecting the streetlights in long gold streaks.

**Subject Placement:**
The building center frame. The wet street fills the foreground with reflections. The modern city frames the old building on left and right — the past surrounded by the present.

**Lighting:**
Streetlights (sodium vapor, warm orange). The single window light (cool white, 5600K). The wet street reflects both, doubling the light, doubling the mystery.

**Color:** Dusty violet night sky. Warm orange streetlights. Cool white window. The wet asphalt reflects all colors in smeared abstraction. The bruised rose of decay on the building's facade.

**Mood:** The safe house as symbol — beauty decayed, secrets preserved. The midpoint of the film, the fulcrum.

**Props & Set:** The building's architectural details: iron balconies, carved stonework, peeling paint in layers (blue, cream, green). Overgrown garden with dead and living plants intermixed. A stray cat. A parked car with condensation on windows.

**Wardrobe & Makeup:** No characters visible yet.

**Emotional Beat:** The location as character. The past hiding the present.

---

### Frame SC-04-SH-02
**Shot Type:** Medium — Stairwell
**Aspect Ratio:** 2.39:1
**Camera:** Following Yasmin from behind, ascending stairs
**Duration:** 5 seconds

**Visual Composition:**
Yasmin climbs a narrow stairwell. The walls are peeling, the steps are worn marble. A single bare bulb hangs from the ceiling, swinging slightly — perhaps from a draft, perhaps from the building's decay. Yasmin's shadow grows and shrinks with the bulb's swing. She wears dark clothing now — she has dressed for the night, for the mission. Her face is determined but afraid. The stairwell feels endless — each landing looks the same, each turn reveals more of the same decay. The building is a maze.

**Subject Placement:**
Yasmin center, climbing away from camera. The stairwell walls create converging lines. The swinging bulb is a point of visual interest above her head.

**Lighting:**
Single bare bulb (tungsten, 2800K, hard). The swing creates moving shadows. Yasmin's face alternates between light and shadow as she climbs — the visual rhythm of uncertainty.

**Color:** Warm tungsten light against cool blue shadow. The walls are grey-green, the marble steps are cream stained with age. Dusty violet in the deepest shadows.

**Mood:** The approach. The tension of the climb. Each step irreversible.

**Props & Set:** Worn marble steps with brass edges. Peeling wallpaper (pattern no longer visible). A broken window on one landing, letting in night air and city sound. A discarded shoe. A smell of mold and old perfume.

**Wardrobe & Makeup:** Yasmin — dark clothing (black turtleneck, dark jeans, boots — operational clothing, bought for this night). Hair pulled back severely. No makeup except darkened eyes — kohl, but applied for strength, not beauty. She carries a small bag.

**Emotional Beat:** The approach to confrontation. The artist in operative clothing. The costume does not fit.

---

### Frame SC-04-SH-03
**Shot Type:** Wide — Safe House Interior
**Aspect Ratio:** 2.39:1
**Camera:** From doorway, looking in
**Duration:** 6 seconds

**Visual Composition:**
Yasmin enters the safe house apartment. The room is large, high-ceilinged, once elegant. Now it is stripped and functional — a table with electronic equipment, maps on walls, a camp bed in the corner. Omar stands at the table, his back to the door. He does not turn immediately. He knows someone is there but does not know who. The room's decayed grandeur clashes with the operational equipment — the past and present in violent coexistence. A window is open, curtains moving in the night breeze. The city noise drifts in.

**Subject Placement:**
Yasmin enters from deep background (doorway). Omar stands at the table in the center-midground. The room's depth is emphasized — the doorway, the main space, the far window. Yasmin is small in the frame; Omar is larger. The power dynamic is visual.

**Lighting:**
Mixed — a desk lamp on the equipment table (warm, hard). Cool light from the open window (moonlight or city glow, 5600K). The bare ceiling bulb from the stairwell (visible through the open door). Multiple sources create multiple shadows. Nothing is clear.

**Color:** Dusty violet dominates. The warm desk lamp creates a small island of amber in a sea of bruised color. The equipment LEDs add pinpricks of red and green — operational colors.

**Mood:** The confrontation begins. The space between them is charged.

**Props & Set:** The operational table: laptops, radios, a map of Cairo with pins and circles, a coffee pot (cold), documents in Arabic and English. The camp bed — unmade, slept in. A wardrobe with clothes hanging — some Omar's usual style, some operational (dark, anonymous). A photograph pinned to the wall: Yasmin at a concert, the same photo from the phone. The irony is bitter.

**Wardrobe & Makeup:** Omar — dark clothing (similar to Yasmin's, unconscious matching), sleeves rolled up, operational watch visible. He looks tired, older than we've seen him. Yasmin — the dark clothing makes her look smaller, younger, more vulnerable than she wants to appear.

**Emotional Beat:** The moment before recognition. He does not know it is her. The audience holds its breath.

---

### Frame SC-04-SH-04
**Shot Type:** Two-Shot — Confrontation
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, both visible
**Duration:** 7 seconds

**Visual Composition:**
Omar turns. Sees Yasmin. His face shows — for one unguarded moment — pure shock, then fear, then a terrible sadness. He does not reach for a weapon. He does not call for help. He simply looks at her, and in that look is the confession of everything. Yasmin stands in the doorway, her bag dropped at her feet. She does not speak. The silence is the confrontation. The room's equipment blinks red and green behind them, indifferent to the human drama. The curtains continue to move. The city continues outside. But in this room, time has stopped.

**Subject Placement:**
Omar left of center, Yasmin right of center. The doorway behind Yasmin is bright — an escape route. The equipment table behind Omar is dark — his trap. The composition places them as opposing forces, but their faces tell a different story.

**Lighting:**
The desk lamp lights Omar's face from below and side — theatrical, revealing. Yasmin is backlit from the doorway, her face in shadow, unreadable. The contrast is deliberate: he is exposed, she is hidden.

**Color:** Dusty violet, bruised rose. The amber desk lamp warms Omar's face — he is still, in some way, the man she loved. Her face is cool, violet-shadowed — she is becoming someone else.

**Mood:** The confession without words. The silence louder than shouting.

**Props & Set:** The dropped bag. The blinking equipment. The photo of Yasmin on the wall — a cruel witness. The open window — freedom or danger, depending on who runs.

**Wardrobe & Makeup:** Omar — the operational clothing makes him look like a stranger, but his face is the same. The contradiction is unbearable. Yasmin — backlit silhouette, the details of her face obscured, but her posture speaks: shoulders back, chin up, terrified but standing.

**Emotional Beat:** The midpoint twist. He does not deny. He does not explain. He simply sees her, and the lie collapses.

---

### Frame SC-04-SH-05
**Shot Type:** Close-Up — Omar's Face
**Aspect Ratio:** 2.39:1
**Camera:** Slightly low, looking up
**Duration:** 5 seconds

**Visual Composition:**
Omar's face in the lamplight. He looks older than he has ever looked. The operational life has aged him in ways that were hidden by the warmth of their marriage. His eyes are red-rimmed, sleepless. His jaw is tight with held-back emotion. He opens his mouth to speak, then closes it. What can he say? The photo of Yasmin on the wall behind him is visible in soft focus — the artist he watched, the woman he loved, the cover he used. The layers of meaning are visible in the frame's depth.

**Subject Placement:**
Omar's face fills the frame. The photo is a soft blur in the background, upper right. The depth of field is shallow — his face is all that matters.

**Lighting:**
The desk lamp from below — Rembrandt lighting, dramatic, revealing every line, every shadow. The warmth is cruel now — it shows too much.

**Color:** Warm amber on his face. Dusty violet in the shadows. The bruised rose of exhaustion around his eyes.

**Mood:** The husband revealed as human. The operative revealed as trapped.

**Props & Set:** Only his face and the suggestion of the photo behind. The world has narrowed to his expression.

**Wardrobe & Makeup:** Omar — without the performance of being a husband, he looks diminished. The dark clothing absorbs light. He is a shadow of himself.

**Emotional Beat:** The silence breaks. He will speak. But what can words repair?

---

### Frame SC-04-SH-06
**Shot Type:** Medium — The Explanation
**Aspect Ratio:** 2.39:1
**Camera:** Over Yasmin's shoulder, looking at Omar
**Duration:** 6 seconds

**Visual Composition:**
Omar speaks. He explains — not everything, but enough. His hands move over the equipment as he speaks, showing her the scope of it: the maps, the timelines, the mission that is not yet complete. Yasmin listens, her face visible in profile. She does not interrupt. Her expression shifts from anger to horror to something like comprehension — terrible comprehension. The mission involves a weapons shipment, a terrorist cell, a deadline of days. He is not a traitor. He is something worse — a man who has used their love as operational cover. The equipment blinks. The city breathes outside. Their marriage is one more item on the table.

**Subject Placement:**
Omar center, active, gesturing. Yasmin's shoulder and profile in foreground left. The equipment table between them — the mission as physical barrier.

**Lighting:**
The desk lamp warms Omar. Yasmin remains in cooler light from the window. They are in different temperatures — different worlds, even in the same room.

**Color:** The dusty violet deepens. The bruised rose of the mission details — violence, danger, the world Omar has inhabited while she played Chopin.

**Mood:** The explanation as further betrayal. Knowledge does not bring peace.

**Props & Set:** The equipment: laptops showing surveillance footage, a map with red circles (targets, deadlines), a radio with static, a weapon (carefully placed, not handled — he does not want to frighten her further). The coffee pot — he pours her a cup, a domestic gesture in an operational space, absurd and heartbreaking.

**Wardrobe & Makeup:** Omar — the explanation makes him more animated, more like himself. But the gap between this man and the husband is unbridgeable. Yasmin — listening, processing, her face showing each stage of comprehension. She does not touch the coffee.

**Emotional Beat:** The mission revealed. The love reframed as cover. The worst truth: it was never just them.

---

### Frame SC-04-SH-07
**Shot Type:** Wide — Leaving the Safe House
**Aspect Ratio:** 2.39:1
**Camera:** From the window, looking back into the room
**Duration:** 7 seconds

**Visual Composition:**
Yasmin leaves. She does not kiss him. She does not say she understands. She walks to the door, picks up her bag, and exits without looking back. Omar does not follow. He stands at the table, the coffee cup in his hand (the one he poured for her), watching her go. The camera holds on him as the door closes. Then, from the window's perspective, we see Yasmin emerge onto the street below — a small figure in dark clothing, walking quickly, then running, then stopping, then leaning against a wall, weeping. Omar, above, does not see this. The vertical separation is the visual metaphor: he is above, trapped in his mission; she is below, free but destroyed.

**Subject Placement:**
The window frame creates a natural split. Omar visible inside, center. Yasmin visible below, small, running. The composition is divided horizontally — his world and hers.

**Lighting:**
Interior: warm desk lamp. Exterior: cool night, streetlights. The window glass reflects both, mixing them in smeared abstraction.

**Color:** Dusty violet interior, cyan exterior. The color split is now permanent. They inhabit different palettes.

**Mood:** The separation. The mission continues. The marriage ends.

**Props & Set:** The coffee cup in Omar's hand, undrunk. The closed door. The street below: wet, empty, indifferent.

**Wardrobe & Makeup:** Omar — diminished, holding the cup like a talisman. Yasmin — small, running, then broken against a wall. The operational clothing looks like a costume on her now — a disguise that no longer works.

**Emotional Beat:** The midpoint. She knows everything. She leaves. But she does not go home.

---

## TRANSITION: SC-04 → SC-05
**Frame T-04-05**
**Shot Type:** Abstract — Rain on Window
**Aspect Ratio:** 2.39:1
**Camera:** Extreme close-up of raindrops on glass
**Duration:** 3 seconds

**Visual Composition:**
Raindrops on a windowpane. Each drop is a lens, refracting the world behind it into distorted fragments. Through the drops, we see blurred lights — the city, the apartment, the life. The drops run down the glass, leaving trails. The image is beautiful and sad. The transition from safe house to home is bridged by rain — the weather that will dominate the next scene.

**Color:** Cool blue, grey, the amber of interior lights refracted into warm smears.

**Mood:** The world seen through tears. The distortion of grief.

---

## SCENE 5: THE RAINDROP (60:00–68:00)
### "Operation Invades Home"
**Location:** Yasmin & Omar's Apartment — Night / Rain
**Palette:** Slate Grey / Storm Blue / Ash + Emergency Red (Violence and invasion)
**Emotional Beat:** Invasion / Fear / The Operational World Crashes Home
**Total Frames:** 8

---

### Frame SC-05-SH-01
**Shot Type:** Wide — Apartment Exterior, Night, Rain
**Aspect Ratio:** 2.39:1
**Camera:** From the street, looking up at the apartment building
**Duration:** 5 seconds

**Visual Composition:**
The apartment building in a Cairo rainstorm — rare, violent, transformative. Rain sheets down in silver-grey curtains. The building's facade is art deco, elegant, but the rain makes it look like a watercolor running. Yasmin's window is visible on the fourth floor — lit, warm, a single amber rectangle in the grey storm. Other windows are dark. The street is empty except for a single black car parked across the way — its windows are tinted, opaque. The rain creates a visual veil between the warm interior and the cold exterior. The car waits.

**Subject Placement:**
The building center frame. Yasmin's window upper third, the warm light a beacon. The black car lower right, small but significant. The rain fills the entire frame — a moving, living texture.

**Lighting:**
Streetlights (sodium, warm) diffused by rain. The apartment window's warm light. The car's interior is dark — no light escapes. Lightning flickers, brief and white, illuminating the building for one stark moment.

**Color:** Slate grey dominant. Storm blue in the rain shadows. The amber window is an endangered island of warmth. The emergency red of the car's taillights, barely visible.

**Mood:** The storm as harbinger. The warm home threatened by the grey world.

**Props & Set:** The art deco building: geometric patterns in stone, curved balconies, porthole windows. The rain: heavy, tropical, Cairo's rare violent rain. The black car: European, official, ominous. The street: empty, the rain has driven everyone inside.

**Wardrobe & Makeup:** No characters visible yet.

**Emotional Beat:** The calm before the invasion. The home as target.

---

### Frame SC-05-SH-02
**Shot Type:** Medium — Yasmin at Window
**Aspect Ratio:** 2.39:1
**Camera:** Inside the apartment, behind Yasmin, looking out
**Duration:** 4 seconds

**Visual Composition:**
Yasmin stands at the apartment window, watching the rain. She wears a simple grey dress — the color of the storm, the color of her mood. Her arms are crossed, holding herself. The window glass is streaked with rain, distorting her view of the street. She sees the black car. She knows what it means. She has been expecting this since she left the safe house — or perhaps since she found the phone. The warm apartment behind her is lit by table lamps — the amber of Act I survives here, but it is under siege. The grey of her dress and the grey of the storm are merging.

**Subject Placement:**
Yasmin center, her back to camera. The window fills the frame, rain-streaked. The street below visible through the glass — the black car a dark shape. The warm room visible at the edges of the frame.

**Lighting:**
Warm interior light (2800K table lamps) from behind Yasmin, creating a warm rim on her shoulders and hair. The window light is cool, storm-grey (6500K). She is caught between two temperatures — warm past, cool future.

**Color:** Slate grey dress against warm amber room. The rain on the glass refracts both colors into abstraction. She is becoming part of the storm.

**Mood:** The waiting. The dread of expected violence. The knowledge that the operational world is coming for her.

**Props & Set:** The apartment: books, the piano (visible in background, its black form like a sleeping animal), framed photos (some turned facedown since the discovery), a cup of tea gone cold on the windowsill. The window: rain-streaked, the glass cold to touch.

**Wardrobe & Makeup:** Yasmin — grey jersey dress, simple, shapeless — she has stopped dressing for the world. Hair loose, unwashed. Face bare, pale, the dark circles permanent now. She looks like someone surviving, not living.

**Emotional Beat:** The isolation of knowledge. She knows they are coming. She does not run.

---

### Frame SC-05-SH-03
**Shot Type:** Wide — The Door
**Aspect Ratio:** 2.39:1
**Camera:** From the apartment interior, looking at the front door
**Duration:** 3 seconds

**Visual Composition:**
The front door. A solid wooden door, familiar, safe. But now it is the weakest point. Yasmin turns from the window to face the door. The camera holds on the door as sound builds from outside — footsteps in the hall, multiple, heavy. Then silence. Then three sharp knocks. The door seems to shrink in the frame. The warm room behind it feels suddenly small, fragile. The piano is visible in the background — a black shape waiting.

**Subject Placement:**
The door center frame. Yasmin visible at the right edge, turning toward it. The room's depth is visible — the door, the hall, the living room beyond with the piano.

**Lighting:**
Warm interior light. The door is in shadow — the hallway beyond is unlit. The contrast between the warm safety and the dark unknown is stark.

**Color:** Warm amber room. Dark door. The grey of Yasmin's dress as she moves toward it.

**Mood:** The threshold as threat. The familiar door becomes the mouth of danger.

**Props & Set:** The door: solid wood, brass handle, a peephole (Yasmin does not look through it — she knows). The hall beyond: dark, the footsteps still echoing. The apartment's normal life: a coat rack, an umbrella stand, a pair of Omar's shoes by the door — he is not here.

**Wardrobe & Makeup:** Yasmin — the grey dress, barefoot. She moves slowly, as if underwater.

**Emotional Beat:** The knock. The moment before the world breaks in.

---

### Frame SC-05-SH-04
**Shot Type:** Medium — The Invasion
**Aspect Ratio:** 2.39:1
**Camera:** From inside the hall, looking into the apartment as the door opens
**Duration:** 5 seconds

**Visual Composition:**
The door opens. Three figures enter — not police, not military, but operational: dark clothing, efficient movements, no badges. They are Omar's world made flesh. The first figure is Nour — she enters first, her face apologetic but hard. Behind her, two men who do not look at Yasmin as a person — they look at her as a location, a target, a variable. Yasmin stands in the living room doorway, backlit by the warm interior. She does not move. She does not scream. She simply watches them invade her home. The contrast between their dark operational clothing and her grey dress and the warm apartment is a visual invasion — the cool world entering the warm world.

**Subject Placement:**
The three figures enter from center (doorway). Yasmin stands at the far end of the hall, small, framed by the living room doorway. The composition is a visual assault — they advance, she retreats without moving.

**Lighting:**
The hall is now mixed — warm interior light from behind Yasmin, cool flashlight beams from the invaders' hands. The flashlights cut through the warm air like surgical instruments.

**Color:** Emergency red — the flashlights have red filters. The warm amber is under attack. Slate grey and storm blue in the invaders' clothing. The grey of Yasmin's dress merges with their world — she is already part of it, whether she chooses or not.

**Mood:** The invasion as violation. The home's sanctity destroyed in seconds.

**Props & Set:** The invaders' equipment: flashlights, a briefcase (documents, orders), radios with soft static. They move through the apartment with practiced efficiency — checking rooms, opening drawers, not destroying but searching. The violation is clinical, which makes it worse.

**Wardrobe & Makeup:** Nour — operational dark clothing, but her face shows conflict. The two men — anonymous, efficient, forgettable by design. Yasmin — barefoot, grey dress, a ghost in her own home.

**Emotional Beat:** The operational world enters the domestic. The two lives collide violently.

---

### Frame SC-05-SH-05
**Shot Type:** Close-Up — Yasmin's Face
**Aspect Ratio:** 2.39:1
**Camera:** Frontal, tight on face
**Duration:** 4 seconds

**Visual Composition:**
Yasmin's face as the search continues around her. She does not react to the sounds of drawers opening, of her belongings being touched by strangers. Her face is composed, almost serene — a mask she has learned to wear. But her eyes are alive with something — not fear, but a cold fire. She is calculating. She is deciding. The red flashlight beams cross her face, turning her skin briefly crimson, then returning to grey. The intermittent red is like a heartbeat — the emergency color of the film's darkest act.

**Subject Placement:**
Face fills the frame. The background is blurred but active — movement, light beams, shadows.

**Lighting:**
Mixed and moving. The red flashlight beams create moving patches of color. The warm interior light provides a base. Her face shifts between warm, cool, and red — three emotional states in one frame.

**Color:** Slate grey, storm blue, emergency red. The amber is almost gone — a memory in the corners.

**Mood:** The mask and the fire beneath. She is not a victim. She is becoming something else.

**Props & Set:** Only her face. The sounds of the search are off-screen.

**Wardrobe & Makeup:** Yasmin — the mask is new. She has never looked like this before. The pale face, the dark eyes, the stillness. She looks like an icon, a statue, someone carved from stone.

**Emotional Beat:** The decision made in silence. She will not be a pawn.

---

### Frame SC-05-SH-06
**Shot Type:** Wide — Nour and Yasmin
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, the living room
**Duration:** 6 seconds

**Visual Composition:**
Nour approaches Yasmin. The two men continue searching in the background — bedroom, bathroom, kitchen. Nour and Yasmin face each other in the living room. The piano is between them — a black bulk, silent, watching. Nour speaks quietly, urgently. She is not threatening — she is warning. The mission has been compromised. Omar is in danger. Yasmin is in danger. They need to move her to a safe location. Yasmin listens. Her face does not change. She looks past Nour to the piano. The piano is her answer. She will not leave it. She will not leave the home that is still, in some way, hers.

**Subject Placement:**
Nour and Yasmin in the center, facing each other. The piano to their right, dominant, black, silent. The searching men in the deep background, blurred. The rain on the windows creates moving shadows.

**Lighting:**
Warm interior light (table lamps). Cool flashes from the men's flashlights in the background. The piano absorbs light — it is a void in the warm room.

**Color:** The warm amber of the room battles with the cool operational light. The piano is black — neutral, waiting.

**Mood:** The negotiation. The choice: safety or defiance.

**Props & Set:** The piano: the Steinway from the opening scene, now in the apartment — a smaller model but the same black gleam. The search: drawers opened, clothes moved, books taken down and replaced. The rain: continuous, the sound of the storm filling the silences.

**Wardrobe & Makeup:** Nour — operational but human. Her face shows she did not want this. Yasmin — the stone mask. She will not be moved.

**Emotional Beat:** The standoff. She will not run. She will not be saved. She will fight for what is hers.

---

### Frame SC-05-SH-07
**Shot Type:** Medium — The Piano
**Aspect Ratio:** 2.39:1
**Camera:** Close on the piano, Yasmin's hand entering frame
**Duration:** 4 seconds

**Visual Composition:**
Yasmin's hand touches the piano. The black lid is closed. Her fingers rest on the lacquered surface, leaving faint prints in the condensation from the rainy air. The piano is a monolith — the symbol of everything she was, everything she believed. Her hand on the piano is a claim of ownership, a refusal to surrender. Nour watches from the background, understanding. The men have stopped searching. The room is quiet. The rain continues. The hand on the piano says everything.

**Subject Placement:**
The piano fills center frame. Yasmin's hand enters from left, small against the black bulk. The rest of her is out of frame — only the hand, the claim, the refusal.

**Lighting:**
Warm light on the piano's surface, creating a small reflection. The hand is warm, alive, against the cold black lacquer.

**Color:** Black piano, warm skin, amber light. The simplicity is the power.

**Mood:** The claim. The refusal. The piano as fortress.

**Props & Set:** The piano: closed, silent, the music trapped inside. A metronome on top, stopped. Sheet music on the stand — Chopin, the same Nocturne from the opening.

**Wardrobe & Makeup:** Only the hand — the same hand that played the Nocturne, that opened the drawer, that touched the surveillance photo. The hand that has done everything and will do more.

**Emotional Beat:** The line drawn. She stays. The piano stays. The battle is joined.

---

### Frame SC-05-SH-08
**Shot Type:** Wide — The Invaders Leave
**Aspect Ratio:** 2.39:1
**Camera:** From the doorway, looking out into the hall
**Duration:** 5 seconds

**Visual Composition:**
The invaders leave. Nour is last — she pauses at the door, looks back at Yasmin. Their eyes meet. Nour nods once — a promise, a warning, a farewell. Then she is gone. The door closes. Yasmin stands alone in the living room. The apartment has been searched but not destroyed — the violation is subtle, invisible except to her. The piano stands in the center of the room, untouched. The rain continues. Yasmin walks to the window and watches the black car pull away into the storm. She is alone. But she is not defeated.

**Subject Placement:**
Yasmin center, small in the wide frame. The doorway on the right, now empty. The window on the left, rain-streaked. The piano behind her, a black guardian.

**Lighting:**
Warm interior light, but diminished. The storm has taken something from the room. The lamps seem dimmer.

**Color:** Slate grey, storm blue. The amber is residual — a memory of warmth.

**Mood:** The aftermath. The violation absorbed. The resolve forming.

**Props & Set:** The searched apartment: everything in place but nothing the same. The piano. The rain. The empty hall.

**Wardrobe & Makeup:** Yasmin — alone, barefoot, grey dress. She looks at the door, then at the piano. She knows what comes next.

**Emotional Beat:** The invasion survived. The next phase begins. She will not be moved. She will move herself.

---

## TRANSITION: SC-05 → SC-06
**Frame T-05-06**
**Shot Type:** Abstract — The Piano Key, Extreme Close-Up
**Aspect Ratio:** 2.39:1
**Camera:** Macro, a single white key
**Duration:** 3 seconds

**Visual Composition:**
A single white piano key in extreme close-up. The ivory surface shows hairline cracks, imperfections, the yellowing of age. The key is beautiful and worn. A finger enters the frame and presses the key — the motion is slow, deliberate, like a ritual. The key descends, then releases. The sound is not heard but implied. The image is a meditation on beauty and fragility.

**Color:** Cream ivory, warm amber light. The purity before destruction.

**Mood:** The piano as living thing. The key that will be broken.

---

## SCENE 6: THE DESTRUCTION (68:00–75:00)
### "Piano Smashed"
**Location:** Yasmin & Omar's Apartment — Night / The Morning After
**Palette:** Slate Grey / Storm Blue / Ash + Emergency Red (The breaking point)
**Emotional Beat:** Rage / Grief / The Symbol Destroyed
**Total Frames:** 7

---

### Frame SC-06-SH-01
**Shot Type:** Wide — The Morning After
**Aspect Ratio:** 2.39:1
**Camera:** From the apartment doorway, looking in at dawn
**Duration:** 5 seconds

**Visual Composition:**
The apartment at dawn. The rain has stopped. Grey light enters through the windows. The room is unchanged from the search — everything in place, everything wrong. Yasmin sits on the floor by the piano, her back against its side. She has been there all night. An empty bottle of wine lies on its side nearby. She wears the same grey dress, now wrinkled, stained. Her hair is wild. She looks at the piano with an expression that is not love — it is accusation. The piano that was her altar is now her defendant. It has witnessed everything and remained silent. She has not played since the discovery. The keys are closed behind the fallboard — a mouth shut.

**Subject Placement:**
Yasmin small on the floor, left of center. The piano dominates center-right, towering over her. The grey dawn light fills the room. The composition makes the piano seem immense and Yasmin diminished.

**Lighting:**
Grey dawn light (6500K, overcast, no sun). No interior lights. The room is lit by the cold morning. The shadows are soft and merciless.

**Color:** Slate grey, ash, storm blue. No amber survives. The world has gone cold.

**Mood:** The morning after the invasion. The grief without tears. The numbness before the storm.

**Props & Set:** The apartment: silent, searched, unchanged. The wine bottle (Egyptian red, empty). A glass, tipped over, a red stain on the wood floor. The piano: closed, silent, black. The grey dress, now a rag.

**Wardrobe & Makeup:** Yasmin — the grey dress is ruined. Hair tangled. Face pale, eyes red but dry. She has cried all she can. She is empty.

**Emotional Beat:** The bottom. The numbness before rage. The piano waits.

---

### Frame SC-06-SH-02
**Shot Type:** Medium — Yasmin at Piano
**Aspect Ratio:** 2.39:1
**Camera:** Low angle, looking up at Yasmin and the piano
**Duration:** 4 seconds

**Visual Composition:**
Yasmin stands. She approaches the piano. The low angle makes her seem larger, more powerful, but the piano still towers. She reaches for the fallboard — the panel that covers the keys. Her hand hesitates. The fallboard represents the last barrier. Behind it are the keys — the source of her art, her identity, her marriage (Omar restored the piano for her). She opens it. The keys are revealed — black and white, orderly, beautiful. She looks at them with hatred and love. Her hands hover, then descend.

**Subject Placement:**
Yasmin center, the piano keyboard filling the lower frame. The low angle creates dominance and vulnerability simultaneously.

**Lighting:**
Grey dawn from the window. The keys catch the light — the white keys gleam, the black keys absorb. The contrast is absolute.

**Color:** Black and white keys. Grey room. Yasmin's skin is the only warmth — pale, exhausted, human.

**Mood:** The approach to the breaking point. The love turned to rage.

**Props & Set:** The keyboard: pristine, untouched, waiting. The fallboard: opened, revealing what was hidden. A metronome on the piano top — still stopped.

**Wardrobe & Makeup:** Yasmin — barefoot, the grey dress, hair falling in her face. She looks like a figure from a tragedy.

**Emotional Beat:** The decision to confront the symbol. The piano is not innocent.

---

### Frame SC-06-SH-03
**Shot Type:** Close-Up — Hands on Keys, First Notes
**Aspect Ratio:** 2.39:1
**Camera:** Directly above, looking down at keyboard
**Duration:** 5 seconds

**Visual Composition:**
Yasmin's hands on the keys. She plays — but not Chopin. Not music. She plays a single note, then another, then a cluster. The notes are wrong, discordant. Her fingers press too hard. The hands that created beauty now create noise. She plays louder, faster, the notes becoming a barrage. Her fingers stumble. The discord is painful. This is not music — it is a scream in musical form. The hands are the same hands from the opening scene, but they are transformed by grief.

**Subject Placement:**
Hands and keys fill the frame. The motion is violent, erratic. The orderly black-and-white is disrupted by the chaos of her playing.

**Lighting:**
Grey dawn from above. The keys reflect the light. The hands cast long shadows.

**Color:** Black and white. The monochrome of grief.

**Mood:** The music destroyed. The art turned to anguish.

**Props & Set:** Only the keys. The sound is implied in the violence of the motion.

**Wardrobe & Makeup:** Hands only — trembling, violent, beautiful and terrible.

**Emotional Beat:** The breakdown in musical form. The artist destroying her art.

---

### Frame SC-06-SH-04
**Shot Type:** Medium — The Destruction Begins
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, tracking Yasmin's movement
**Duration:** 6 seconds

**Visual Composition:**
Yasmin stands abruptly. She looks around the room. Her eyes fall on a heavy object — a brass bust of Mozart that Omar gave her as a joke early in their marriage. She picks it up. The weight is visible in her arms. She looks at it, then at the piano. The decision is visible on her face — a mix of madness and clarity. She raises the bust. The camera holds. Then she smashes it down on the piano keyboard.

**Subject Placement:**
Yasmin center, the bust in her hands. The piano to her right. The room behind — the life she is destroying.

**Lighting:**
Grey dawn, now with a faint warm intrusion — the sun is trying to break through. But the warmth is too late.

**Color:** The brass is gold — the last amber object. The piano is black. The moment is monochrome except for the gold that will destroy it.

**Mood:** The irrevocable act. The symbol chosen. The destruction begins.

**Props & Set:** The Mozart bust: brass, heavy, comical in normal times, now a weapon. The piano: waiting, innocent, guilty. The room: witness.

**Wardrobe & Makeup:** Yasmin — face transformed by rage. The mask is gone. This is raw, primal, ancient.

**Emotional Beat:** The first blow. The point of no return.

---

### Frame SC-06-SH-05
**Shot Type:** Wide — The Piano Destroyed
**Aspect Ratio:** 2.39:1
**Camera:** From the room's corner, wide view
**Duration:** 7 seconds

**Visual Composition:**
Yasmin destroys the piano. The brass bust falls again and again. Keys break — white and black fragments scatter. The sound is catastrophic — not music, not noise, but the death of an instrument. Strings snap, whipping through the air. The wooden frame cracks. Yasmin is relentless, mechanical, beyond grief. She is destruction itself. The room is filled with debris — ivory shards, wood splinters, brass dust. The piano that was her altar is now wreckage. She does not stop until the bust is too heavy to lift, until her arms are too weak, until the piano is unrecognizable.

**Subject Placement:**
Yasmin center, the piano center. The destruction radiates outward. The room's edges are filled with flying debris, dust, the chaos of the act.

**Lighting:**
The grey dawn is now joined by the warm sun breaking through — the irony is cruel. The light improves as the destruction reaches its peak. The room becomes brighter as the piano dies.

**Color:** Emergency red — the dawn breaking red through the grey. The debris is white (keys), black (wood), gold (brass dust). The color palette is the destruction itself.

**Mood:** The catharsis of destruction. The grief too large for tears, expressed in violence.

**Props & Set:** The destroyed piano: keys shattered, strings exposed like nerves, wood splintered, the frame broken. The Mozart bust: dented, tarnished, dropped on the floor. The room: covered in debris, dust, the remains of art. The framed photo of Yasmin and Omar at Luxor — knocked over, the glass cracked but the photo visible beneath: two smiling people who no longer exist.

**Wardrobe & Makeup:** Yasmin — covered in dust, sweat, tears (finally), blood from a cut on her hand (she does not notice). The grey dress is torn. She is a figure from a war zone.

**Emotional Beat:** The total destruction. The symbol smashed. The marriage ended in violence.

---

### Frame SC-06-SH-06
**Shot Type:** Close-Up — Yasmin Among the Wreckage
**Aspect Ratio:** 2.39:1
**Camera:** Low angle, looking up at Yasmin from floor level
**Duration:** 5 seconds

**Visual Composition:**
Yasmin stands among the wreckage of the piano. She breathes heavily. The brass bust is on the floor beside her. She looks at what she has done. Her face shows not satisfaction but a terrible emptiness. The destruction has not healed her. It has only created a new kind of loss. She looks at her hands — cut, bleeding, trembling. The same hands that played Chopin. The same hands that opened the drawer. The same hands that touched the surveillance photo. Now they are destruction's hands. She sinks to her knees among the ivory shards. A single white key lies near her — intact, alone, survivor.

**Subject Placement:**
Yasmin center, kneeling. The wreckage fills the frame around her. The single intact key in the foreground — a point of visual focus, a survivor, a symbol.

**Lighting:**
Morning sun now fully present, warm, cruel. The light falls on the wreckage and makes it beautiful — ivory gleams, dust motes dance. The destruction is rendered in golden light.

**Color:** Warm amber returns — but it is the amber of destruction, of fire, of aftermath. The emergency red of dawn fades to gold. The palette is beautiful and terrible.

**Mood:** The emptiness after rage. The destruction complete. The survivor key.

**Props & Set:** The wreckage: ivory shards like teeth, wood splinters like bones, the brass bust like a fallen idol. The single intact key: white, pure, waiting.

**Wardrobe & Makeup:** Yasmin — exhausted, bleeding, empty. The rage has burned out. What remains is worse — the silence after the scream.

**Emotional Beat:** The aftermath. The destruction did not save her. She is more alone than before.

---

### Frame SC-06-SH-07
**Shot Type:** Wide — The Room
**Aspect Ratio:** 2.39:1
**Camera:** From the doorway, looking in
**Duration:** 6 seconds

**Visual Composition:**
The room from the doorway. Yasmin kneels in the center of the wreckage. The destroyed piano is a black and white ruin. The morning sun streams through the window, illuminating the dust, the debris, the broken woman. The room that was warm and alive is now a battlefield. The camera holds. This is the visual summary of the film's turning point — the art destroyed, the love destroyed, the woman destroyed and remade. The doorway frames the scene like a painting — a Guernica in domestic scale.

**Subject Placement:**
Yasmin center, small in the wreckage. The destroyed piano dominates. The doorway creates a frame-within-frame — we are outsiders looking in at the destruction.

**Lighting:**
Full morning sun (5500K). The light is clear, honest, unforgiving. Every shard, every cut, every tear is visible.

**Color:** Warm amber sun against cool grey wreckage. The contrast is the film in miniature — the warmth of memory against the cold of reality.

**Mood:** The total picture. The turning point. After this, nothing can be the same.

**Props & Set:** The full room: destroyed piano, debris everywhere, the knocked-over photo frame, the empty wine bottle, the metronome still on top of the wreckage — somehow untouched, still stopped.

**Wardrobe & Makeup:** Yasmin — the ruined grey dress, the blood, the dust. She is a figure from a different kind of film — a war film, a tragedy. She is no longer the concert pianist. She is someone new, someone forged in destruction.

**Emotional Beat:** The end of Act II-B. The destruction as transformation. The phoenix must rise from this ash.

---

## TRANSITION: SC-06 → SC-07
**Frame T-06-07**
**Shot Type:** Abstract — Single Key in Light
**Aspect Ratio:** 2.39:1
**Camera:** Extreme close-up of the single intact white key
**Duration:** 3 seconds

**Visual Composition:**
The single intact white key from the wreckage. It lies on the wooden floor, illuminated by a shaft of morning sun. The key is perfect, unmarked, alone among the debris. It gleams. It is a survivor, a promise, a challenge. The camera holds on it. This key will be the key to the duet. This key is the unresolved note.

**Color:** White ivory, warm amber light, the brown of the wooden floor.

**Mood:** The survivor. The seed of what comes next. In destruction, a single intact thing.

---

## SCENE 7: THE DUOLOGY (85:00–95:00)
### "Piano Duet Confrontation"
**Location:** Cairo Opera House — Empty Concert Hall / Rehearsal Room
**Palette:** Slate Grey / Storm Blue / Ash + Emergency Red → Transitioning to Pale Sage
**Emotional Beat:** Confrontation / Truth / The Music as Battlefield
**Total Frames:** 9

---

### Frame SC-07-SH-01
**Shot Type:** Wide — Empty Opera House
**Aspect Ratio:** 2.39:1
**Camera:** From the stage, looking out at the empty seats
**Duration:** 6 seconds

**Visual Composition:**
The Cairo Opera House, but empty. No audience. No warmth. The house lights are off. Work lights (cool white, 5600K) illuminate the seats in stark, unforgiving clarity. The velvet is faded. The gilding is tarnished. Without an audience, the hall is a shell — beautiful but dead. Yasmin walks down the center aisle, toward the stage. She wears black — not the amber gown of the opening, but funeral black. She walks with purpose. She is not performing. She is preparing for battle. The piano on stage is a different piano — a rehearsal piano, upright, battered, but functional. It is not the gleaming Steinway. It is a working instrument, scarred but alive.

**Subject Placement:**
Yasmin small in the center aisle, walking toward camera/stage. The empty seats rise on both sides — a vast, indifferent amphitheater. The stage and piano wait at the top of the frame.

**Lighting:**
Work lights only (cool white, 5600K). No follow-spots. No warmth. The hall is lit for work, not art. The shadows are hard, architectural.

**Color:** Slate grey seats, storm blue shadows, ash-colored walls. The black of Yasmin's clothing. No amber. No gold. The palace of art is now a workplace of confrontation.

**Mood:** The return to the scene of the crime — the crime of innocence. The empty hall as witness.

**Props & Set:** The opera house: empty, stark, the seats visible in their worn reality. The rehearsal piano: upright, black, scarred, functional. A single music stand. A clock on the wall, ticking.

**Wardrobe & Makeup:** Yasmin — black dress (simple, severe, sleeveless), hair pulled back in a tight chignon, minimal makeup (pale, defined eyes, dark lip). She looks like a widow or a judge.

**Emotional Beat:** The return to the beginning. But everything is different.

---

### Frame SC-07-SH-02
**Shot Type:** Medium — Yasmin at Piano
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, Yasmin's profile
**Duration:** 4 seconds

**Visual Composition:**
Yasmin sits at the rehearsal piano. She does not play yet. Her hands rest on the keys — the same hands that destroyed the other piano, that played the Nocturne. She looks at the keys with an expression that is not love, not hatred, but something beyond both — acceptance. The piano is scarred, imperfect, like her. She touches a key — a single note, clear and alone. It echoes in the empty hall. The note is not music. It is a signal. It is a challenge. It is a beginning.

**Subject Placement:**
Yasmin left of center. The piano keyboard fills the lower frame. The empty hall is visible in the background — seats, balconies, the vast space that will swallow the sound.

**Lighting:**
Work light from above (cool white). A single warm spot — perhaps a ghost of the follow-spot from the opening scene, perhaps a memory — catches her face from above. The mix is deliberate: the cool reality and the warm memory.

**Color:** Cool grey, warm spot on her face. The black dress. The white key. The monochrome of confrontation.

**Mood:** The solitary note. The challenge issued. The battlefield prepared.

**Props & Set:** The rehearsal piano: upright, scarred wood, some keys yellowed, one key missing (replaced with a different color). The imperfection is the point. Sheet music on the stand — blank. She will improvise.

**Wardrobe & Makeup:** Yasmin — the black dress, severe and beautiful. She is no longer the girl in the amber gown. She is a woman who has destroyed and survived.

**Emotional Beat:** The challenge. The note that says: I am here. Face me.

---

### Frame SC-07-SH-03
**Shot Type:** Wide — Omar Enters
**Aspect Ratio:** 2.39:1
**Camera:** From the back of the hall, looking toward the stage
**Duration:** 5 seconds

**Visual Composition:**
Omar enters the opera house from the rear. He is far from the stage, small in the frame. He wears a dark suit — not the charcoal of the opening, not the navy of surveillance, but black, funeral black. He walks down the center aisle. Yasmin does not turn. She knows he is there. She plays another note — the same note, repeated, insistent. Omar walks slowly, deliberately. The empty seats frame him on both sides. He is walking a gauntlet of his own making. The distance between them is vast — the hall's depth is the distance of their marriage.

**Subject Placement:**
Omar small in the deep background, walking toward the stage. Yasmin at the piano in the midground, not turning. The vast hall between them.

**Lighting:**
Work lights illuminate Omar as he walks — he emerges from shadow into light, then back into shadow, as he passes under each fixture. The rhythm of light and dark is the rhythm of their marriage.

**Color:** Black suit, slate grey hall, the white work lights. He is a shadow walking toward light.

**Mood:** The approach. The husband walking the aisle of his own judgment.

**Props & Set:** The empty seats. The distant stage. The piano, small under the work lights. The clock on the wall — time passing.

**Wardrobe & Makeup:** Omar — black suit, white shirt, no tie. He looks like he is going to a funeral — his own. Hair neat but with grey visible at the temples that was not there before. He has aged.

**Emotional Beat:** The approach. Every step is a year, a lie, a love.

---

### Frame SC-07-SH-04
**Shot Type:** Two-Shot — The Confrontation
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, both at the piano
**Duration:** 7 seconds

**Visual Composition:**
Omar reaches the stage. He stands beside the piano. Yasmin does not look at him. She plays the single note again, then another, then a third — a simple, insistent pattern. The notes are not music. They are Morse code. They are a heartbeat. They are a demand. Omar stands, waiting to be acknowledged. The silence between the notes is louder than the notes themselves. Finally, Yasmin speaks — without turning: "Sit." Omar sits on the piano bench beside her. The bench is narrow. They are close, thigh touching thigh, but miles apart. The piano is between them and the world.

**Subject Placement:**
Both on the piano bench, center frame. Yasmin left, Omar right. The piano keyboard before them. The empty hall behind. The composition is intimate and vast simultaneously.

**Lighting:**
Work light from above, cool. But a single warm light (perhaps a ghost, perhaps a deliberate choice) catches both their faces from the side — the warmth of what was, the cool of what is.

**Color:** Black clothing on both. Cool grey hall. Warm side light on their faces. The contrast is their marriage in color.

**Mood:** The confrontation. The intimacy of enemies. The piano as neutral ground.

**Props & Set:** The rehearsal piano: scarred, imperfect, real. The bench: narrow, forcing proximity. The empty hall: witness, judge, jury.

**Wardrobe & Makeup:** Both in black — mirror images of grief. Yasmin's face is pale, hard. Omar's face is lined, sad, open. He has no defenses left.

**Emotional Beat:** The confrontation begins. Not with words, but with presence.

---

### Frame SC-07-SH-05
**Shot Type:** Close-Up — Hands on Keys, Four Hands
**Aspect Ratio:** 2.39:1
**Camera:** Directly above, looking down at the keyboard
**Duration:** 5 seconds

**Visual Composition:**
Four hands on the keyboard. Yasmin's hands on the left, Omar's on the right. They do not play together yet. Yasmin plays her insistent pattern — simple, repetitive, accusing. Omar's hands hover, then descend. He adds a counterpoint — a lower voice, responding, answering. The four hands create a duet that is also a dialogue. The notes clash, resolve, clash again. The keyboard is a chessboard. The fingers are armies. The music is a battle and a negotiation. Yasmin's hands are hard, percussive. Omar's are soft, pleading. The contrast is the conversation they cannot have in words.

**Subject Placement:**
The keyboard fills the frame. Four hands enter from top and bottom. The composition is symmetrical but tense — the left side attacks, the right side defends.

**Lighting:**
Direct overhead work light. The hands cast long shadows on the keys. The shadows reach toward each other but do not touch.

**Color:** Black and white keys. Skin tones — Yasmin's paler, Omar's slightly warmer. The monochrome of the keyboard makes the hands the only color.

**Mood:** The duet as dialogue. The music as truth. The fingers speaking what the lips cannot.

**Props & Set:** Only the keyboard. The world has been reduced to touch and sound again — but now the touch is violent, the sound is accusation.

**Wardrobe & Makeup:** Hands only — Yasmin's with a bandage on the left index finger (from the piano destruction). Omar's steady, strong, familiar.

**Emotional Beat:** The music as confrontation. The duet as battle.

---

### Frame SC-07-SH-06
**Shot Type:** Medium — Faces in Profile
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, both profiles
**Duration:** 6 seconds

**Visual Composition:**
Yasmin and Omar in profile, facing each other across the piano. They play the duet — now more complex, more intertwined. Their faces show the music's effect. Yasmin's face is hard, focused, angry — but tears stream down her cheeks. She is crying and playing simultaneously, the tears falling onto the keys. Omar's face is open, vulnerable, pleading — his eyes are on her, not the keys. He knows the notes by heart. She is reading nothing — she is improvising, attacking, demanding. The tears on her face catch the side light and become streaks of silver. His face is wet too — sweat, or tears, or both.

**Subject Placement:**
Both in profile, facing each other. Yasmin left, Omar right. The piano between them, lower frame. The empty hall behind. The profiles create a classical composition — a frieze of grief.

**Lighting:**
Side light from the left — warm, catching the tears, creating silver streaks. The work lights from above provide cool fill. The mix is the film's emotional palette: warm memory, cool reality.

**Color:** Warm side light on their faces. Cool grey hall. The black of their clothing. The tears: silver, liquid, the only moving light.

**Mood:** The truth emerging in music. The tears that words could not release.

**Props & Set:** The piano. The bench. The empty hall. The music that is being created and destroyed simultaneously.

**Wardrobe & Makeup:** Both — tears, sweat, exhaustion. Yasmin's black dress is damp at the collar. Omar's shirt is wrinkled, the first time we have seen him disheveled. The perfection is gone.

**Emotional Beat:** The music breaks through the armor. They cannot lie in music.

---

### Frame SC-07-SH-07
**Shot Type:** Wide — The Hall as Witness
**Aspect Ratio:** 2.39:1
**Camera:** From the balcony, looking down at the stage
**Duration:** 6 seconds

**Visual Composition:**
From above, Yasmin and Omar at the piano are small figures in the vast hall. The duet reaches its peak — complex, intertwined, painful and beautiful. The empty seats surround them like a silent congregation. The hall's architecture frames them — the balconies, the proscenium, the work lights. They are two people in a cathedral of art, using art to destroy and rebuild their connection. The camera holds the wide view — the intimacy is too painful to watch closely. We need distance. They need distance. The hall gives them none — it forces them together.

**Subject Placement:**
The two figures small at the piano, center-bottom of frame. The vast hall dominates — seats, balconies, architectural grandeur. The composition makes their intimacy seem both immense and insignificant.

**Lighting:**
Work lights from above. The warm side light is visible as a glow on their faces, but from this distance, they are mostly in cool light.

**Color:** Cool grey, slate, with a warm glow at the center where they sit. The warmth is small but intense.

**Mood:** The scale of their drama against the indifference of art. The hall has seen a thousand performances. It will see a thousand more.

**Props & Set:** The full opera house: empty, vast, indifferent. The two figures: small, human, everything.

**Wardrobe & Makeup:** Small figures, but their posture speaks — leaning toward each other, bodies angled, the intimacy of shared music.

**Emotional Beat:** The duet's peak. The truth in musical form, too large for words, too small for the hall.

---

### Frame SC-07-SH-08
**Shot Type:** Close-Up — Yasmin's Face, The Final Chord
**Aspect Ratio:** 2.39:1
**Camera:** Frontal, tight on Yasmin
**Duration:** 5 seconds

**Visual Composition:**
Yasmin plays the final chord of the duet. Her face is transformed — not angry, not sad, but something beyond both. She looks at Omar. Her eyes ask the final question: Can we survive this? The chord hangs in the air — unresolved, suspended, waiting. Her finger holds the key down. The note continues. She does not release it. The unresolved note is the film's central metaphor. She will not resolve it. She will not give him — or the audience — the satisfaction of an ending. The note continues as she looks at him. The look is the answer, and the answer is ambiguous.

**Subject Placement:**
Yasmin's face fills the frame. Omar is visible in the background, out of focus — a dark shape, waiting.

**Lighting:**
The warm side light catches her face fully now. The cool work light is secondary. She is illuminated by the warmth of the moment, even if the warmth is ambiguous.

**Color:** Warm amber on her face. Cool grey behind. The black of her dress. The palette is shifting — the first hint of pale sage, of dawn, of resolution.

**Mood:** The unresolved note. The question without answer. The beauty of ambiguity.

**Props & Set:** Only her face. The piano keys, blurred at bottom of frame. The key she holds down — the only thing in focus besides her face.

**Wardrobe & Makeup:** Yasmin — tears dried, face luminous. The black dress, but she seems to glow through it. She is beautiful and terrible in her ambiguity.

**Emotional Beat:** The question asked. The answer withheld. The power in her hands.

---

### Frame SC-07-SH-09
**Shot Type:** Wide — The Silence After
**Aspect Ratio:** 2.39:1
**Camera:** From the stage, looking out at the empty seats
**Duration:** 7 seconds

**Visual Composition:**
The duet ends. The final note dies. Silence fills the hall — a physical presence, heavy and alive. Yasmin and Omar sit at the piano, both still, both breathing. The empty seats seem to lean forward, listening. The hall is silent. The city outside is silent. The world holds its breath. Yasmin releases the key. The silence is complete. She stands. Omar remains seated. She walks off the stage, down the steps, up the aisle. She does not look back. Omar watches her go. The camera holds on the empty stage, the empty piano, the empty bench. Then, slowly, Omar stands. He follows. The camera does not show whether he catches her. The frame ends on the empty stage — the piano waiting, the hall waiting, the story unresolved.

**Subject Placement:**
The empty stage center frame. Yasmin exits left, Omar follows right. The hall dominates. The composition is of absence — the people leaving, the art remaining.

**Lighting:**
Work lights begin to dim — someone (unseen) is turning them off. The warm side light fades. The hall returns to grey, to silence, to waiting.

**Color:** Slate grey returning. The warm light fades. The palette is in transition — not yet pale sage, no longer storm blue.

**Mood:** The silence after music. The emptiness after confrontation. The story that refuses to end cleanly.

**Props & Set:** The empty piano. The empty bench. The empty hall. The work lights dimming one by one.

**Wardrobe & Makeup:** The figures become shadows, then silhouettes, then gone.

**Emotional Beat:** The unresolved ending. The silence as answer. The art outlives the artists.

---

## TRANSITION: SC-07 → SC-08
**Frame T-07-08**
**Shot Type:** Abstract — The Nile at Dawn
**Aspect Ratio:** 2.39:1
**Camera:** Wide, static, the river and the sky
**Duration:** 3 seconds

**Visual Composition:**
The Nile at dawn. The water is still, reflecting a sky that is neither night nor day — pale grey, soft silver, a hint of sage green on the eastern horizon. A single felucca sails, its sail white against the grey. The city is waking but quiet. The transition from the opera house to the river is the transition from confrontation to possibility. The water moves slowly, relentlessly, carrying everything forward.

**Color:** Pale sage, dawn grey, soft silver. The resolution palette begins.

**Mood:** The morning after. The possibility of peace. The river as time, as memory, as hope.

---

## SCENE 8: THE UNRESOLVED NOTE (100:00–105:00)
### "Final Scene"
**Location:** The Nile Corniche — Dawn / A Café Terrace
**Palette:** Pale Sage / Dawn Grey / Soft Silver (Ambiguous resolution)
**Emotional Beat:** Possibility / Peace / The Unresolved Note Continues
**Total Frames:** 7

---

### Frame SC-08-SH-01
**Shot Type:** Wide — Cairo at Dawn
**Aspect Ratio:** 2.39:1
**Camera:** From a café terrace, looking out at the Nile
**Duration:** 6 seconds

**Visual Composition:**
A café terrace on the Nile Corniche. Dawn is breaking — not the violent red of the destruction scene, but a soft, hesitant grey-silver. The Nile flows past, wide and brown, indifferent to human drama. The city wakes: a minaret's loudspeaker begins the call to prayer, distant and beautiful. A felucca passes. The terrace is empty except for one table. At the table: Yasmin. She wears a simple linen dress — the color of dawn, neither white nor grey, something soft and new. She drinks tea. She looks at the river. She is at peace — not happy, not healed, but at peace. The destruction is behind her. The confrontation is behind her. What remains is this: tea, river, dawn, possibility.

**Subject Placement:**
Yasmin at a table, right of center. The Nile fills the left and center. The city skyline behind — minarets, high-rises, the bridge in the distance. The composition is open, airy, full of space and light.

**Lighting:**
Dawn light (5600K but soft, diffused by high cloud). No artificial lights. The natural light is gentle, forgiving, new.

**Color:** Pale sage dress. Dawn grey sky. Soft silver on the water. The brown of the Nile. The palette is the film's resolution — soft, ambiguous, beautiful without being happy.

**Mood:** The peace after the storm. Not resolution, but possibility. The dawn that follows the longest night.

**Props & Set:** The café terrace: simple tables, metal chairs, a potted jasmine plant (blooming, white flowers). The tea: in a glass, amber, steaming. The river: wide, brown, eternal. The city: waking, indifferent, continuing.

**Wardrobe & Makeup:** Yasmin — linen dress (pale sage, simple, loose), hair loose and natural, minimal makeup (sun-kissed, healthy). She looks younger than she has looked since the opening — not because she is innocent again, but because she is free. A silver bracelet (new, not Omar's gift — her own choice).

**Emotional Beat:** The new beginning. The woman alone, at peace, choosing her own morning.

---

### Frame SC-08-SH-02
**Shot Type:** Medium — Yasmin at the Table
**Aspect Ratio:** 2.39:1
**Camera:** Frontal, slightly low
**Duration:** 4 seconds

**Visual Composition:**
Yasmin at the table. She holds the tea glass in both hands, warming them. Her face is calm — not the mask of the safe house, not the stone of the invasion, not the rage of the destruction, but a genuine calm. She has made a decision. We do not know what it is. She may have forgiven. She may have moved on. She may be waiting. The ambiguity is the point. She looks at the camera — or past it, at the river, at the dawn, at something we cannot see. Her expression is a small smile — not happiness, but acceptance.

**Subject Placement:**
Yasmin center frame. The table and tea in the lower frame. The river and sky behind, out of focus but present.

**Lighting:**
Dawn light from the left (the east). Soft, warm, gentle. Her face is lit without shadows — the dawn forgives everything.

**Color:** Pale sage, warm skin, the amber of the tea. The palette is warm again, but a different warmth — not the amber of performance, but the warmth of a real morning.

**Mood:** The acceptance. The peace. The ambiguity as gift.

**Props & Set:** The tea glass (Egyptian style, clear glass, amber liquid). A small plate of dates. The jasmine plant beside her — white flowers, sweet scent implied.

**Wardrobe & Makeup:** Yasmin — the linen dress, the silver bracelet, a pair of simple silver earrings (her own, bought with her own money, for herself). Hair loose, a few strands catching the dawn light. She is beautiful without performance.

**Emotional Beat:** The self reclaimed. The woman who needs no audience.

---

### Frame SC-08-SH-03
**Shot Type:** Wide — The Corniche, Figure Approaching
**Aspect Ratio:** 2.39:1
**Camera:** From behind Yasmin, looking down the terrace
**Duration:** 5 seconds

**Visual Composition:**
From behind Yasmin, we see a figure approaching along the Corniche. The figure is distant, indistinct — male, dark clothing, walking with a familiar gait. It could be Omar. It could be a stranger. The figure is too far to identify. Yasmin does not turn. She continues to drink her tea. The figure approaches slowly, deliberately. The Corniche is waking — a jogger passes, a vendor sets up his cart, a car drives past with its windows down, music playing. The world is normal. The drama is personal. The figure continues to approach.

**Subject Placement:**
Yasmin in foreground, her back to camera. The figure in the deep background, center, approaching. The composition creates a diagonal of expectation — the figure moving toward her, she unmoving.

**Lighting:**
Dawn light, now slightly warmer as the sun clears the horizon. Golden tones begin to mix with the grey-silver. The figure is backlit, a silhouette.

**Color:** Pale sage, dawn grey, soft silver — with a hint of gold from the rising sun. The palette is in transition. The film refuses to settle.

**Mood:** The approach. The possibility of reunion or continuation. The ambiguity sustained.

**Props & Set:** The Corniche: palm trees, benches, the river wall. The jogger (a woman, neon shoes). The vendor (setting up bread and falafel). The car (music: Umm Kulthum, faint and beautiful). The figure: walking, hands in pockets, gait familiar but not certain.

**Wardrobe & Makeup:** Yasmin — the linen dress, the morning light on her shoulders. The figure — indistinct, silhouetted, possibility.

**Emotional Beat:** The approach. The question: will she turn? Will he arrive? Is it him?

---

### Frame SC-08-SH-04
**Shot Type:** Close-Up — Yasmin's Hands on the Tea Glass
**Aspect Ratio:** 2.39:1
**Camera:** Close on hands and glass
**Duration:** 4 seconds

**Visual Composition:**
Yasmin's hands on the tea glass. The same hands that played Chopin, that opened the drawer, that destroyed the piano, that confronted Omar in duet. The hands are relaxed now. The fingers that attacked keys now gently circle the warm glass. A silver bracelet catches the dawn light. The hands are at peace. Whatever decision she has made, it is held in these hands. The tea's amber color is the only warm gold in the frame — a small sun in her palms.

**Subject Placement:**
Hands and glass fill center frame. The table surface provides texture — metal, cool, morning-damp.

**Lighting:**
Dawn light from the left. The glass and tea create a warm glow. The hands are lit gently, lovingly.

**Color:** Warm amber tea. Pale skin. Silver bracelet. The table's cool grey metal. The contrast is simple, human, beautiful.

**Mood:** The hands as summary. Everything they have done, everything they will do, held in this simple gesture.

**Props & Set:** The tea glass. The silver bracelet (new, simple, a circle — wholeness). The table's metal surface.

**Wardrobe & Makeup:** Hands only — no tremor, no tension. The hands of someone who has survived.

**Emotional Beat:** The peace in the hands. The decision made, held, accepted.

---

### Frame SC-08-SH-05
**Shot Type:** Medium — Yasmin Turns
**Aspect Ratio:** 2.39:1
**Camera:** Side angle, Yasmin turning her head
**Duration:** 4 seconds

**Visual Composition:**
Yasmin turns her head toward the approaching figure. Her face is visible in three-quarter view. She sees the figure. Her expression does not change — neither surprise, nor joy, nor fear. She simply sees. And in her seeing is everything: the possibility of reconciliation, the possibility of farewell, the possibility of a new beginning that includes or excludes him. She does not stand. She does not wave. She simply holds his gaze (or the gaze of the figure who may or may not be him). The moment stretches. The dawn continues to rise. The river continues to flow. The world does not stop for their drama. But in this moment, they are the center.

**Subject Placement:**
Yasmin center, turning. The figure visible in the deep background, now slightly closer but still indistinct. The composition holds them in suspension — close enough to see, far enough to be unknown.

**Lighting:**
Dawn light now fully golden as the sun rises. Her face catches the light. The figure remains in partial shadow — still possibility, still mystery.

**Color:** Pale sage, soft gold, dawn grey. The palette is the most beautiful of the film — not because it is happy, but because it is true.

**Mood:** The recognition. The choice. The moment before the choice becomes action.

**Props & Set:** The terrace. The river. The figure. The jasmine plant's white flowers, catching the first direct sun.

**Wardrobe & Makeup:** Yasmin — the dawn light makes her luminous. She is not the girl from the opening. She is not the operative from the café. She is not the destroyer from the apartment. She is someone new, someone whole.

**Emotional Beat:** The recognition. Whatever comes next, she is ready.

---

### Frame SC-08-SH-06
**Shot Type:** Two-Shot — Yasmin and the Figure
**Aspect Ratio:** 2.39:1
**Camera:** From the figure's POV, looking at Yasmin
**Duration:** 5 seconds

**Visual Composition:**
From the figure's point of view, Yasmin at the table. She is small in the frame, but the center of the world. The tea glass catches the sun. The jasmine flowers glow. The river moves behind her. She is smiling — not a performance smile, not a mask, but a genuine, complex, human smile. It is a smile that says: I see you. I am here. I am whole. What happens next is up to us. The frame holds her in this smile. The figure is not visible — only Yasmin, only her choice, only her wholeness.

**Subject Placement:**
Yasmin center, the table in foreground, the river behind. She is framed by the terrace, the river, the dawn — the world as her stage, but she is not performing.

**Lighting:**
Full dawn sun now — golden, warm, honest. Her face is fully lit. The shadows are soft. The world is new.

**Color:** Pale sage, soft gold, dawn grey, the white of jasmine. The resolution palette complete.

**Mood:** The smile as answer. The wholeness as resolution. The ambiguity as hope.

**Props & Set:** The table. The tea. The jasmine. The river. The world.

**Wardrobe & Makeup:** Yasmin — the smile transforms her face. It is not the rapture of the opening scene. It is something better — it is real.

**Emotional Beat:** The answer. Not in words. In presence. In smile. In being.

---

### Frame SC-08-SH-07
**Shot Type:** Wide — The Nile, The World Continues
**Aspect Ratio:** 2.39:1
**Camera:** From the café terrace, pulling back to reveal the river, the city, the dawn
**Duration:** 8 seconds

**Visual Composition:**
The camera pulls back from Yasmin and the figure (who may or may not be Omar — we never see his face clearly) to reveal the wider world. The Nile flows wide and brown, carrying the dawn's reflection. The city wakes — minarets, bridges, high-rises, the Corniche filling with cars and people. A felucca sails. Birds rise from the riverbank. The call to prayer continues, beautiful and eternal. Yasmin and the figure are two small people on a terrace by a river in a city of millions. Their drama is immense and insignificant. The camera continues to pull back — the terrace becomes a dot, the river becomes a ribbon, the city becomes a map. The unresolved note continues to sound, not in music but in the city's noise, the river's flow, the dawn's light. The film ends not with them, but with the world that contains them — a world that continues, indifferent and beautiful, with or without their resolution.

**Subject Placement:**
Yasmin and the figure become small, then tiny, then invisible as the camera pulls back. The world becomes the subject — the river, the city, the dawn.

**Lighting:**
Full morning sun. Golden, warm, life-giving. The shadows are short. The day has begun.

**Color:** Pale sage, dawn grey, soft silver, warm gold. The full resolution palette, blooming into the day.

**Mood:** The transcendence of the personal into the universal. The drama is real, but the world is larger. The unresolved note is not a problem — it is a truth. Life continues. Possibility remains.

**Props & Set:** The Nile: wide, eternal. The city: waking, continuing. The world: without end.

**Wardrobe & Makeup:** The figures become indistinguishable. Two people. A morning. A river. A city. A life.

**Emotional Beat:** The film's final statement: love and betrayal are immense, but they are also small. The world continues. The note remains unresolved — and that is the beauty of it. The music never ends. It only changes.

---

## KEY PROP AND SET DESIGN NOTES

### Recurring Props:
1. **The Piano** — Transforms from gleaming Steinway (art) to upright rehearsal piano (work) to destroyed wreckage (grief) to the memory of music (resolution)
2. **The Second Phone** — Matte black, thick, custom OS. The physical manifestation of the double life. Appears in drawer, in Omar's pocket, in operational photos
3. **The Antique Gold Earring** — Omar's gift, worn in opening scene, removed in dressing room, absent thereafter. The symbol of the marriage's authenticity
4. **The Silver Watch** — Yasmin's concert watch. Appears on her wrist in every scene until the destruction, when it is removed. Replaced by the silver bracelet in the final scene
5. **The Mozart Bust** — Comic gift become weapon. The irony of art destroying art
6. **The Manila File** — Nour's offering. The evidence as tangible betrayal
7. **The Single Intact White Key** — Survivor of destruction. Seed of resolution

### Set Design Evolution:
- **Act I (Amber):** Belle époque opera house (golden, ornate, sacred). Domestic apartment (warm, cultured, lived-in)
- **Act II-A (Cyan/Teal):** European café (cool, clinical, surveillance). Unmarked buildings (concrete, anonymous)
- **Act II-B (Dusty Violet):** Decayed safe house (beauty ruined, secrets preserved). Apartment under siege (warmth invaded)
- **Act III (Slate/Storm/Emergency Red):** Apartment in destruction (warmth shattered). Opera house empty (art without audience)
- **Resolution (Pale Sage):** Nile Corniche at dawn (open, natural, indifferent, beautiful)

---

## WARDROBE AND MAKEUP ARC

### Yasmin:
- **Opening (Amber Gold Gown):** Performance glamour, public self, goddess
- **Discovery (Cream Silk Robe):** Private vulnerability, morning-after innocence
- **Surveillance (Beige Trench/Headscarf):** Anonymity as disguise, watcher rather than performer
- **Safe House (Dark Clothing):** Operational costume, uncomfortable, borrowed identity
- **Invasion/Destruction (Grey Dress):** Grief made visible, the color of the storm
- **Confrontation (Black Dress):** Funeral/judicial severity, the self reclaimed through darkness
- **Resolution (Pale Sage Linen):** Natural, simple, self-chosen, whole

### Omar:
- **Opening (Charcoal Suit):** The perfect husband, warm but controlled
- **Surveillance (Navy Suit):** Operational mode, the other self emerging
- **Safe House (Dark Clothing):** The truest self — tired, aged, diminished without the performance
- **Confrontation (Black Suit):** Funeral wear, walking his own judgment
- **Resolution (Indistinct):** Never clearly seen. Remains possibility.

---

## TRANSITION FRAMES SUMMARY

| Transition | Visual Bridge | Duration | Color Shift |
|------------|--------------|----------|-------------|
| T-01-02 | Hand on drawer handle | 3s | Amber → Fading Amber |
| T-02-03 | Window day-to-night timelapse | 3s | Amber → Cyan |
| T-03-04 | Map dissolve to city lights | 3s | Cyan → Dusty Violet |
| T-04-05 | Rain on glass | 3s | Dusty Violet → Slate Grey |
| T-05-06 | Single piano key pressed | 3s | Slate Grey → Monochrome |
| T-06-07 | Intact key in light | 3s | Ash → Slate/Storm |
| T-07-08 | Nile at dawn | 3s | Storm Blue → Pale Sage |

**Total Transition Frames:** 7
**Total Transition Duration:** 21 seconds

---

## COMPLETE FRAME COUNT

| Scene | Frames | Duration (est.) |
|-------|--------|-----------------|
| 1: The Nocturne | 8 | ~50s |
| T-01-02 | 1 | 3s |
| 2: The Drawer | 7 | ~31s |
| T-02-03 | 1 | 3s |
| 3: The Follow | 8 | ~38s |
| T-03-04 | 1 | 3s |
| 4: The Safe House | 7 | ~42s |
| T-04-05 | 1 | 3s |
| 5: The Raindrop | 8 | ~37s |
| T-05-06 | 1 | 3s |
| 6: The Destruction | 7 | ~38s |
| T-06-07 | 1 | 3s |
| 7: The Duology | 9 | ~51s |
| T-07-08 | 1 | 3s |
| 8: The Unresolved Note | 7 | ~36s |

**TOTAL FRAMES:** 68 (61 scene frames + 7 transitions)
**TOTAL ESTIMATED STORYBOARD DURATION:** ~5 minutes 41 seconds

---

## KEY VISUAL MOTIFS ACROSS ALL FRAMES

1. **Mirrors & Reflections** — Appear in 12 frames: dressing room mirror (SC-01-SH-07), café glass doors (SC-03-SH-01, SC-03-SH-08), safe house mirror (SC-04-SH-03), apartment window (SC-05-SH-02), rain on glass (T-04-05). The motif peaks in the duet scene where the characters' emotional reflections are rendered in music rather than glass.

2. **The Piano Keyboard** — Appears in 8 frames: opening performance (SC-01-SH-03), dressing room (implied SC-01-SH-07), destruction (SC-06-SH-03, SC-06-SH-05), duet (SC-07-SH-02, SC-07-SH-05), single key (T-05-06, T-06-07). The keyboard transforms from sacred space to battlefield to neutral ground.

3. **Hands in Close-Up** — Appear in 7 frames: opening performance (SC-01-SH-03), drawer opening (SC-02-SH-03), phone screen (SC-02-SH-05), file photographs (SC-03-SH-06), key destruction (SC-06-SH-03), four-hand duet (SC-07-SH-05), tea glass (SC-08-SH-04). The hands tell the story that faces cannot.

4. **Thresholds & Doorways** — Appear in 9 frames: backstage corridor (SC-01-SH-06), bedroom doorway (SC-02-SH-01), café doors (SC-03-SH-01, SC-03-SH-08), safe house door (SC-04-SH-03, SC-04-SH-07), apartment door (SC-05-SH-03, SC-05-SH-08), opera house exit (SC-07-SH-09). Every doorway is a crossing from one world to another.

5. **Water & Glass** — Appear in 6 frames: rain on windshield (SC-01-SH-08), rain on café window (SC-03-SH-01), rain on apartment window (SC-05-SH-01, SC-05-SH-02), rain on glass transition (T-04-05), Nile at dawn (SC-08-SH-01). Water refracts, distorts, cleanses, reveals.

6. **The Single Intact White Key** — The film's recurring symbol of survival and unresolved possibility. Appears in destruction aftermath (SC-06-SH-06), transition (T-06-07), and echoes in the final tea glass (SC-08-SH-04) — the white of jasmine, the white of dawn, the white of new beginnings.

---

*Document prepared by Visual Storyboard Agent*
*For the production "حب وخيانة / The Garden of Broken Mirrors"*
*Frame descriptions designed for translation to illustrated storyboard panels*
*All durations estimated for 24fps motion picture*
