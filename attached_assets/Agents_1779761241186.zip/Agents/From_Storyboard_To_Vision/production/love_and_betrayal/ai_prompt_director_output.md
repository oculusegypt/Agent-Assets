# حب وخيانة — LOVE AND BETRAYAL / The Garden of Broken Mirrors
## AI Prompt Director — Master Prompt Library
### Production Pipeline: "From Storyboard To Vision"
**Date:** 2026-05-25 | **Aspect Ratio:** 2.39:1 Anamorphic Widescreen (4:3 for surveillance inserts)
**Platforms Covered:** Sora · Veo · Runway Gen-3 · Kling · Midjourney · Flux

---

## TABLE OF CONTENTS

1. [Cinematic Style Lock & Global Parameters](#1-cinematic-style-lock--global-parameters)
2. [Character Consistency Engine](#2-character-consistency-engine)
3. [Scene 1: The Nocturne (0:00–3:00)](#3-scene-1-the-nocturne)
4. [Scene 2: The Drawer (8:00–12:00)](#4-scene-2-the-drawer)
5. [Scene 3: The Follow (18:00–26:00)](#5-scene-3-the-follow)
6. [Scene 4: The Safe House (48:00–52:00)](#6-scene-4-the-safe-house)
7. [Scene 5: The Raindrop (60:00–68:00)](#7-scene-5-the-raindrop)
8. [Scene 6: The Destruction (68:00–75:00)](#8-scene-6-the-destruction)
9. [Scene 7: The Duology (85:00–95:00)](#9-scene-7-the-duology)
10. [Scene 8: The Unresolved Note (100:00–105:00)](#10-scene-8-the-unresolved-note)
11. [Negative Prompt Library](#11-negative-prompt-library)
12. [Temporal Video Sequence Prompts](#12-temporal-video-sequence-prompts)
13. [Prompt Testing & Variation Matrix](#13-prompt-testing--variation-matrix)

---

## 1. CINEMATIC STYLE LOCK & GLOBAL PARAMETERS

### 1.1 Master Style Reference Tokens

**Use in EVERY prompt (adapt per platform):**

> *"Cinematic film still / motion footage. Shot on Arri Alexa 35 with anamorphic lenses. Fine film grain, Kodak Vision3 5219 emulation. Roger Deakins cinematography style. Wong Kar-wai color saturation. Deep focus when wide, razor-thin depth of field on close-ups. Subtle anamorphic lens flare and oval bokeh. No digital sharpness artifacts. Photorealistic skin texture. Naturalistic motion blur on fast movement."*

### 1.2 Aspect Ratio Enforcement by Platform

| Platform | Aspect Ratio Command | Notes |
|----------|---------------------|-------|
| **Sora** | "widescreen cinematic 2.39:1 anamorphic scope" | Include in prompt body; Sora infers from description |
| **Veo** | "cinematic widescreen 2.39:1" | Veo supports 16:9 natively; crop to 2.39:1 in post |
| **Runway** | Generate at 16:9, letterbox to 2.39:1 | Use black-bar overlay in post |
| **Kling** | "cinematic ultra-wide composition, 2.39:1 anamorphic framing" | Kling respects framing language |
| **Midjourney** | `--ar 239:100` | Exact anamorphic ratio |
| **Flux** | "2.39:1 anamorphic widescreen composition" | Compositional framing in prompt |

### 1.3 Color Temperature & Lighting Continuity Matrix

| Scene | Dominant Kelvin | Key Light | Fill | Accent | Hex Dominant |
|-------|-----------------|-----------|------|--------|-------------|
| 1 — Nocturne | 2800K–3200K | Tungsten follow-spot | Bounce off piano lid | Single spotlight | `#D4A574` |
| 2 — Drawer | 2800K→5600K→4500K | Morning window → phone screen | Natural bounce | Drawer interior LED | `#7B6B8D` |
| 3 — Follow | 2200K–2800K | Sodium vapor street | Café tungsten spill | Phone screen 6500K | `#4A9B9B` |
| 4 — Safe House | 4100K–5000K | Fluorescent overhead | None — harsh flat | Phone flashlight 6500K | `#7B6B8D` |
| 5 — Raindrop | 2800K interior / 5600K rain | Tungsten practicals + HMI rain bars | Warm bounce | Red flashlight filters | `#708090` |
| 6 — Destruction | 2800K→3200K | Tungsten full → hard 2K Fresnel | None | Failing lamp flicker | `#8B0000` |
| 7 — Duology | 3000K spotlight | 750W Leko tight spot | Wood panel bounce | Moonlight 5600K | `#9B6B7B` |
| 8 — Unresolved | 5600K→3500K | Natural daylight only | Natural bounce | Dusk magic hour | `#9DC183` |

### 1.4 Director / Cinematographer Reference Phrases

Embed into prompts per scene mood:

- **Act I warmth:** *"In the style of Wong Kar-wai's In the Mood for Love — warm saturated skin tones, frame-within-frame compositions, color as emotional language"*
- **Surveillance / operational:** *"Tomas Alfredson's Tinker Tailor Soldier Spy aesthetic — cold paranoia, institutional flatness, information framed at margins"*
- **Emotional destruction:** *"Joe Wright's Atonement long-take energy — destruction as aesthetic overwhelming, color as trauma"*
- **Surveillance intimacy:** *"Florian Henckel von Donnersmarck's The Lives of Others — telephoto compression, the watcher as emotional participant"*
- **Neo-noir romance:** *"Roger Deakins on Sicario — moral ambiguity through frame width, anamorphic distortion as moral lens"*

---

## 2. CHARACTER CONSISTENCY ENGINE

### 2.1 Yasmin — Master Character Description Tokens

**Base appearance (use in ALL Yasmin prompts):**

> *"Elegant Egyptian woman in her mid-30s, Tang Wei / Juliette Binoche energy — controlled performer with luminous, restrained beauty. Olive skin with warm honey undertones. Dark brown eyes, expressive, often half-closed in musical concentration. Long dark hair, usually in a loose chignon with escaped strands that catch light. High cheekbones, full lips, minimal makeup — nude lip, defined brows, dewy natural skin. Her hands are the focal point: long elegant fingers, strong pianist's hands, clean short nails, no nail polish. A silver antique watch on left wrist. Single antique gold earring (Omar's gift) — sometimes visible, sometimes not."
*

**Wardrobe Arc Tokens:**

| Scene | Wardrobe | Color | Texture | Emotional Register |
|-------|----------|-------|---------|-------------------|
| 1 — Nocturne | Backless amber-gold silk gown, vintage 1930s-inspired modern cut | `#D4A574` | Silk, flowing sleeves, mirror-bright | Goddess / Performer |
| 2 — Drawer | Cream silk robe, loosely belted, morning-after vulnerability | `#F5F5DC` | Silk, unbrushed hair, no makeup | Private / Vulnerable |
| 3 — Follow | Beige trench coat, dark clothing underneath, charcoal silk headscarf, large sunglasses | `#C2B280` / `#36454F` | Cotton, silk disguise | Anonymous / Watcher |
| 4 — Safe House | Black turtleneck, dark jeans, boots — operational clothing bought for the night | `#0A0A0A` | Cotton, leather, severe hair pulled back | Operative / Determined |
| 5 — Raindrop | Simple grey jersey dress, shapeless, barefoot | `#708090` | Jersey, washed-out, unwashed hair | Surviving / Ghost |
| 6 — Destruction | Same grey dress, now torn, blood on hands from piano string | `#708090` + red | Damaged jersey, wild hair | Rage / Ruin |
| 7 — Duology | Dark clothing — severe, intentional, a tribunal uniform | `#1A1A1A` | Structured, hair pulled back, minimal makeup | Judge / Accuser |
| 8 — Unresolved | Simple natural-fiber clothing, no jewelry, no watch | `#E8E4C9` | Linen/cotton, hair loose, clean face | Reborn / Present |

### 2.2 Omar — Master Character Description Tokens

**Base appearance (use in ALL Omar prompts):**

> *"Egyptian man in his late 30s, Tony Leung / Rami Malek energy — masked operative behind warm husband persona. Olive skin, sharp bone structure that photographs differently in warm vs. cold light. Dark eyes that can appear adoring or unreadable depending on lighting. Short dark hair, neatly styled in "husband mode," combed flatter in "operative mode." Clean-shaven. Slim build. Two watches: elegant thin gold watch (husband mode) vs. thicker tactical watch (operative mode)."
*

**Wardrobe Arc Tokens:**

| Scene | Wardrobe | Color | Texture | Emotional Register |
|-------|----------|-------|---------|-------------------|
| 1 — Nocturne | Charcoal slim-fit suit, white shirt open at collar, no tie | `#36454F` | Wool, elegant, thin gold watch | Adoring husband / Watcher |
| 3 — Follow | Navy suit (operational), aviator sunglasses, more anonymous | `#000080` | Wool, tactical phone visible | Operative / Stranger |
| 4 — Safe House | Dark clothing, sleeves rolled up, operational watch visible | `#1A1A1A` | Cotton/utility, tired, older-looking | Trapped / Exposed |
| 5 — Raindrop | Charcoal suit (return to husband mode, but compromised) | `#36454F` | Wool, but disheveled | Divided / Guilty |
| 7 — Duology | Dark clothing, conservative, as if dressed for a funeral | `#0A0A0A` | Wool, face showing tears for first time | Broken / Confessing |
| 8 — Unresolved | Not present physically — only letter and photograph | N/A | N/A | Absent / Remembered |

### 2.3 Nour — Master Character Description Tokens

> *"Elegant severe woman in her 40s, Egyptian, precise bob haircut, defined brows, nude lip, minimal makeup. Teal tailored blazer over black silk shirt, no jewelry. Expensive utilitarian leather bag. Face shows professional tiredness — seasoned, unreadable, not cruel. Small scar on right thumb."
*

### 2.4 Character Variation Prompts (for img2img / reference workflows)

**Midjourney Character Reference Set:**

```
Yasmin character sheet --ar 239:100 --v 6 --style raw
[1] Front view: Yasmin in amber-gold gown, concert hall backstage, warm 3200K lighting --s 250
[2] Profile view: Yasmin at piano, hands raised above keys, spotlight from above --s 250
[3] Close-up: Yasmin's face, rapturous performance expression, single tear of gold --s 200
[4] Over-shoulder: Yasmin from behind, looking in mirror, dressing room bulbs --s 200
[5] Extreme close-up: Yasmin's hands on piano keys, warm skin on ivory, silver watch --s 150
```

```
Omar character sheet --ar 239:100 --v 6 --style raw
[1] Front view: Omar in charcoal suit, theater audience, warm spill light on half face --s 250
[2] Profile view: Omar in navy suit, operational mode, Cairo street, cold 5600K --s 250
[3] Close-up: Omar's face, mask dropping, safe house desk lamp from below --s 200
[4] Two-shot: Omar and Yasmin in car, night, passing streetlights strobe his face --s 200
```

---

## 3. SCENE 1: THE NOCTURNE (0:00–3:00)
### "Chopin Performance Duality — Public Perfection / Private Emptiness"
**Palette:** Amber `#D4A574` / Gold `#B5A642` / Warm Sand → Fading Night Blue
**Emotional Beat:** Ecstasy → Intimacy → The First Hairline Crack
**Key Shots:** 5 prompts per platform (Concert hall / Backstage / Car night)

---

### 3.1 SORA PROMPTS — Scene 1

**SORA-SC01-A — "Concert Hall Extreme Wide"**
> Cinematic motion footage, 2.39:1 anamorphic widescreen. Low angle from orchestra pit, tilted slightly upward toward the stage of the Cairo Opera House main concert hall. Rows of velvet burgundy seats descend in golden tiers. Belle époque architecture glows under warm amber house lights. Crystal chandeliers cast soft pools of tungsten light. In the deep background, center stage: a single black Steinway concert grand gleams under a focused warm spotlight. The piano is a tiny luminous island in an ocean of velvet and gold. Audience silhouettes fill the foreground, out of focus — beautiful oval bokeh circles of light. Camera holds absolutely static for 12 seconds. The hush before revelation. Warm tungsten 3200K lighting. Roger Deakins anamorphic style. Fine film grain. Sacred, anticipatory mood. No camera movement. Let the space breathe. Duration: 12 seconds.

**SORA-SC01-B — "Yasmin Performance Medium Wide"**
> Cinematic motion footage, 2.39:1 anamorphic widescreen. Stage right, slightly low angle, looking across the keyboard toward Yasmin's profile. An elegant Egyptian woman in her mid-30s with Tang Wei energy enters from stage left, walking with measured grace. She wears a flowing amber-gold silk gown that catches the follow-spot and seems to radiate warm light. The silk catches micro-highlights as she moves. She pauses at the piano, bows her head briefly in a private ritual, then sits. Camera holds as she lifts her hands above the keys. Her hands hover, angel-like, catching the spotlight. Her face is three-quarter view: serene, eyes half-closed, already somewhere else. Single hard follow-spot from above and slightly stage-front (2800K–3200K mixed). Soft bounce fill from the piano lid reflecting upward onto her face. No other light sources visible. The world outside the spotlight does not exist. Static camera, gentle slow dolly in over 8 seconds. Duration: 10 seconds.

**SORA-SC01-C — "Hands on Keys Extreme Close-Up"**
> Cinematic motion footage, 2.39:1 anamorphic. Directly above the keyboard, looking straight down. The black-and-white keys fill the frame in abstract geometry. Elegant long-fingered pianist's hands enter from top and bottom of frame. She plays a Chopin Nocturne passage — fingers press, release, glide with hypnotic precision. The contrast between warm honey skin and cold ivory is stark. Shadows from her fingers stretch across the white keys like dark fingers reaching. Motion blur on the fastest passages. Hard spotlight from directly above — hands cast long dramatic shadows across keys. High contrast. Chiaroscuro on miniature scale. Amber spotlight warms ivory to cream. Black keys are void-like true black. Hypnotic, devotional mood. Static camera. Duration: 6 seconds.

**SORA-SC01-D — "Match Cut: Piano String to Tea Ripple"**
> Cinematic motion footage, 2.39:1 anamorphic. Extreme close-up of a single piano string vibrating — the note she just played. The metal wire shimmers in warm spotlight, vibrating with visible harmonic motion. Razor-thin depth of field, everything else falls to creamy bokeh. Hard warm 2800K spotlight. The vibration is hypnotic, musical, alive. Camera holds static for 4 seconds, then the scene seamlessly transitions: the vibrating string becomes a ripple on the surface of tea in a white ceramic cup. The same harmonic motion, the same warm light, now domestic and tiny. The ripple expands in slow concentric circles. Refrigerator light cool 4100K. The duality of public perfection and private emptiness. Wong Kar-wai match cut energy. Duration: 8 seconds total.

**SORA-SC01-E — "Car Interior Night — The Crack"**
> Cinematic motion footage, 2.39:1 anamorphic. From back seat, between Yasmin and Omar, looking forward through windshield. Cairo streams past the windows — blurred neon, streetlights, the Nile's dark ribbon. Yasmin rests her head on Omar's shoulder, eyes closed, content, still in the amber-gold gown wrapped in Omar's charcoal suit jacket. Omar looks forward, not at her. His face is half-illuminated by passing streetlights — each light briefly reveals his expression, then plunges it into shadow. In one flash of light, his jaw is tight. In the next shadow, we cannot read him. Available light only — passing streetlights (mixed tungsten and sodium vapor), dashboard glow (green, cyan). The intermittent illumination creates a strobe effect on Omar's face. Yasmin remains mostly in shadow, nestled against him, peaceful. The windshield shows the road ahead and faint reflections of dashboard lights — green, red — like operational readouts. Warm amber from Yasmin's gown at frame edge. Cool cyan and green from dashboard. The palette is already splitting. Peace interrupted by subliminal unease. The camera holds steady, gentle sway matching the car's motion. Duration: 10 seconds.

---

### 3.2 VEO PROMPTS — Scene 1

**VEO-SC01-A — "Concert Hall Establishing"**
> Photorealistic cinematic footage of the Cairo Opera House main concert hall in majestic 2.39:1 widescreen. Warm amber and gold tungsten lighting (3200K) fills the Belle époque architecture. Rows of burgundy velvet seats descend in golden tiers. Crystal chandeliers glow softly. Center stage, a black Steinway concert grand gleams under a single warm follow-spot. The piano is a tiny luminous island. Audience silhouettes in foreground, out of focus with beautiful bokeh. Static camera, long take, no movement. The space breathes. Sacred anticipation. Photorealistic skin tones in warm honey. Fine film grain. Arri Alexa 35 anamorphic emulation. Duration: 10 seconds.

**VEO-SC01-B — "Yasmin at Piano — Performance"**
> Photorealistic footage of an elegant Egyptian concert pianist in her mid-30s performing Chopin at a Steinway concert grand. She wears a flowing amber-gold silk gown, vintage-inspired modern cut, backless with flowing sleeves. Warm spotlight (2800K) from above and front. Piano lid open, bouncing soft fill upward onto her face. Her hands hover above keys, long elegant fingers catching light. Eyes half-closed in musical rapture. Single antique gold earring glints. Silver watch at wrist. Warm honey skin tones. The world outside the spotlight does not exist. Gentle slow motion on hand descent. Photorealistic fabric simulation — silk catches micro-highlights. Duration: 8 seconds.

**VEO-SC01-C — "Omar in Audience — The Watcher"**
> Photorealistic footage of an Egyptian man in his late 30s sitting in a theater audience, fourth row center. Charcoal slim-fit suit, white shirt open at collar, no tie. He watches with an expression that reads as adoration — but his eyes are too focused, too controlled. He does not blink. Warm house light (2800K) on audience. His face catches a spill of stage light from the follow-spot — half his face is warmer than the other half. One eye catches gold; the other remains in cooler shadow. The split lighting creates a visual schism. Program unopened in his lap. Glass of water on floor beside seat. Around him, audience members blurred into soft shapes. A woman to his left wipes a tear. Omar does not blink. Adoration with a hairline fracture. Duration: 6 seconds.

**VEO-SC01-D — "Backstage Corridor — Descent"**
> Photorealistic tracking shot following an elegant Egyptian woman in an amber-gold silk gown from behind as she walks down a narrow backstage corridor. The corridor is concrete and utilitarian — harsh contrast to the gilded hall. Overhead fluorescents cast a greenish-white pallor (5600K). At the far end, a door opens into a warm dressing room, golden light spilling out (3200K). She walks toward that warmth. The corridor is cold, industrial, unforgiving. The transition from public goddess to private woman. Camera tracks smoothly, maintaining consistent distance. Cool grey-green corridor. Amber gown creating a trail of warmth that diminishes as she moves away. The golden door at the end is a beacon. Duration: 8 seconds.

**VEO-SC01-E — "Car Night — Two Figures"**
> Photorealistic footage from the back seat of a car at night in Cairo. A woman in an amber-gold gown rests her head on a man's shoulder, eyes closed, peaceful. The man in a charcoal suit looks forward, not at her. His face is half-lit by passing streetlights — strobe effect revealing tension, then hiding it. Dashboard glows green and cyan. Windshield shows blurred neon, the Nile's dark ribbon, minarets, high-rises. The woman is nestled in warm shadow. The man's face flickers between light and dark. Available light only — no movie lights. Sodium orange and neon pink exterior. Warm amber interior. The palette is splitting. Wong Kar-wai night-drive energy. Duration: 10 seconds.

---

### 3.3 RUNWAY GEN-3 PROMPTS — Scene 1

**RW-SC01-A — "Opera House Wide Static"**
> Cinematic establishing shot: Cairo Opera House main concert hall, extreme wide from orchestra pit looking up at stage. Belle époque architecture, velvet burgundy seats in golden tiers, crystal chandeliers, warm tungsten glow. Black Steinway concert grand under single spotlight. Audience silhouettes in foreground with soft bokeh. Camera locked-off, static, long take. The hall breathes. Warm amber dominant `#D4A574`. Deep brown shadows `#5C4033`. Cream white accents `#F5F5DC`. No camera movement. Let the space live. 12 seconds.

**RW-SC01-B — "Yasmin Enters Stage"**
> Cinematic medium wide: elegant Egyptian woman in flowing amber-gold silk gown walks across concert stage to Steinway grand. Measured grace. Gown catches follow-spot, radiates warm light. She bows her head in private ritual, sits, lifts hands above keys. Hands hover, angel-like. Profile view, three-quarter. Warm spotlight from above. Piano lid bounce fill on face. Eyes half-closed, serene. Single antique gold earring visible. Camera slow dolly in, gentle, reverent. Motion rich — fabric flow, hand gesture, light play. 10 seconds.

**RW-SC01-C — "Hands on Keys Macro"**
> Cinematic extreme close-up from directly above: pianist's hands on black and white keys. Elegant long fingers, strong, no nail polish. Chopin passage — press, release, glide. Warm skin against cold ivory. Finger shadows stretch across white keys. Motion blur on fast passages. Hard overhead spotlight. High contrast. Chiaroscuro. The marriage of flesh and machine. Static camera. Hypnotic rhythm. 6 seconds.

**RW-SC01-D — "Match Cut Transition"**
> Cinematic extreme close-up: single piano string vibrating in warm spotlight, visible harmonic shimmer. Razor-thin depth of field. Creamy bokeh. The vibration alive, musical. Then seamless match cut — the vibrating string becomes a ripple on tea surface in white ceramic cup. Same harmonic motion, same warm light, now tiny and domestic. Cool refrigerator light. The duality of public and private. Wong Kar-wai transition energy. Slow, poetic, motion-aware. 8 seconds.

**RW-SC01-E — "Car Night Intimacy"**
> Cinematic two-shot from back seat: woman in amber-gold gown rests head on man's shoulder, eyes closed, content. Man in charcoal suit looks forward, not at her. Cairo streams past windshield — blurred neon, streetlights, Nile ribbon. His face half-lit by passing lights — strobe reveals tension, then hides it. Dashboard glow green/cyan. Windshield reflections like operational readouts. Warm amber vs. cool cyan palette split. Gentle camera sway matching car motion. Intimate but uneasy. 10 seconds.

---

### 3.4 KLING PROMPTS — Scene 1

**KL-SC01-A — "Opera House Establishing"**
> Detailed cinematic scene setup: Cairo Opera House main concert hall interior. Low angle from orchestra pit tilted upward. Belle époque architecture with gilded balconies, crystal chandeliers, burgundy velvet seats in descending golden tiers. Warm tungsten house lights (3200K). Single follow-spot on black Steinway concert grand center stage. Audience silhouettes in foreground, out of focus with oval bokeh. The piano is a luminous island in an ocean of velvet and gold. Camera absolutely static — no movement, no drift. The hall holds its breath. High-quality cinematic rendering. Fine film grain. Arri Alexa 35 anamorphic emulation. 12 seconds.

**KL-SC01-B — "Yasmin Performance Entry"**
> Detailed physical dynamics: elegant Egyptian concert pianist in amber-gold silk gown enters stage left, walks with measured ballet-like grace to Steinway grand. Gown fabric flows and catches spotlight micro-highlights. She pauses, bows head in ritual, sits. Lifts hands above keys — long elegant fingers hover, catching light. Profile three-quarter view. Warm follow-spot (2800K) from above and front. Piano lid open, bouncing soft fill onto her face. Eyes half-closed, already in musical trance. Single antique gold earring. Silver watch. The world outside spotlight does not exist. Slow gentle dolly in. Smooth motion, no jitter. 10 seconds.

**KL-SC01-C — "Hands on Keys Overhead"**
> Detailed close-up dynamics: directly above piano keyboard looking straight down. Black and white keys in abstract geometry. Elegant pianist hands enter frame — long fingers, strong, clean. Playing Chopin Nocturne. Fingers press, release, glide with precise choreography. Warm honey skin against cold ivory. Shadows stretch across white keys. Motion blur on fastest passages. Hard overhead spotlight (2800K). High contrast, chiaroscuro. Static camera. The world reduced to touch and sound. 6 seconds.

**KL-SC01-D — "Backstage Corridor Tracking"**
> Detailed tracking shot: from behind, following elegant woman in amber-gold gown walking down narrow backstage corridor. Concrete walls, exposed wiring, fire extinguisher, mop and bucket — utilitarian and cold. Overhead fluorescents (5600K, greenish-white). At far end, dressing room door open with warm golden light (3200K) spilling out. She is a golden figure in a grey tunnel, walking toward warmth. Camera tracks smoothly, maintaining distance. Gown trails on concrete floor, hem picking up dust — first visual diminishment. The goddess becomes mortal. 8 seconds.

**KL-SC01-E — "Car Interior Night"**
> Detailed two-shot dynamics: back seat perspective between two figures looking through windshield. Woman in amber-gold gown rests head on man's shoulder, eyes closed, peaceful. Man in charcoal suit looks forward rigidly, not at her. Cairo streams past — blurred neon, streetlights, Nile. Passing streetlights create strobe on man's face: one flash reveals tight jaw, next shadow hides expression. Dashboard green/cyan glow. Windshield shows road and faint operational-looking reflections. Woman in warm shadow, nestled, content. Man's face flickers between gold and darkness. Available light only. Smooth gentle camera sway. The last frame of Act I warmth. 10 seconds.

---

### 3.5 MIDJOURNEY STILL FRAMES — Scene 1

**MJ-SC01-A — "Concert Hall Extreme Wide"**
```
Cairo Opera House main concert hall interior, extreme wide shot from orchestra pit looking up at stage. Belle époque architecture, gilded balconies, crystal chandeliers, rows of burgundy velvet seats descending in golden tiers. Black Steinway concert grand gleams under single warm follow-spot. Audience silhouettes in foreground, beautiful oval bokeh. Warm tungsten 3200K lighting. Roger Deakins anamorphic cinematography. Fine film grain. Sacred, anticipatory mood. Arri Alexa 35. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC01-B — "Yasmin at Piano"**
```
Elegant Egyptian concert pianist in amber-gold silk gown, backless with flowing sleeves, sitting at Steinway concert grand. Profile three-quarter view. Hands hover above keys, long elegant fingers catching warm spotlight. Eyes half-closed in musical rapture. Warm honey skin. Single antique gold earring glints. Loose chignon with escaped light-catching strands. Piano lid open, bouncing fill light onto face. Wong Kar-wai In the Mood for Love color saturation. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC01-C — "Hands on Keys Overhead"**
```
Extreme close-up directly above piano keyboard. Elegant pianist hands with long strong fingers playing Chopin. Warm honey skin against cold ivory and black keys. Finger shadows stretch across white keys. Hard overhead spotlight creates chiaroscuro. Motion blur on fast passages. Silver watch at wrist. The marriage of flesh and machine. Cinematic, photorealistic, abstract geometry. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC01-D — "Omar in Audience"**
```
Egyptian man in late 30s, charcoal slim-fit suit, white shirt open at collar, sitting in theater audience fourth row center. Expression reads adoration but eyes too focused, too controlled. Does not blink. Warm house light. Face catches stage light spill — half warm, half cool shadow. One eye gold, one eye shadow. Program unopened in lap. Around him, blurred audience shapes. A woman wipes a tear. Omar does not blink. Roger Deakins anamorphic style. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC01-E — "Car Interior Night"**
```
Two figures in back of car at night in Cairo. Woman in amber-gold silk gown rests head on man's shoulder, eyes closed, peaceful. Man in charcoal suit looks forward, jaw tight. Passing streetlights strobe his face — half-lit, half-shadow. Dashboard glows green and cyan. Windshield shows blurred Cairo neon, Nile, minarets. Warm amber interior vs. cool cyan exterior. Wong Kar-wai night energy. Cinematic, photorealistic, anamorphic. --ar 239:100 --style raw --v 6 --s 250
```

---

### 3.6 FLUX PROMPTS — Scene 1

**FLUX-SC01-A — "Opera Hall Establishing"**
> Cinematic widescreen 2.39:1 anamorphic establishing shot of the Cairo Opera House main concert hall. Majestic Belle époque architecture with gilded balconies and crystal chandeliers. Rows of burgundy velvet seats descend in golden tiers toward a single black Steinway concert grand gleaming under a warm follow-spot. Audience silhouettes in the foreground dissolve into creamy oval bokeh. Warm tungsten lighting at 3200K bathes the space in amber and gold. The composition is symmetric and reverent — the hall holds its breath before the performer arrives. Arri Alexa 35 cinematic quality. Fine film grain. The sacred emptiness of anticipation. Photorealistic, high detail, atmospheric depth.

**FLUX-SC01-B — "Yasmin Performance Portrait"**
> Cinematic widescreen portrait of an elegant Egyptian concert pianist in her mid-30s with Tang Wei energy, wearing a flowing amber-gold silk gown at a Steinway concert grand. She sits in profile three-quarter view, hands hovering angel-like above the keys, long elegant fingers catching warm spotlight. Eyes half-closed in serene musical trance. Warm honey skin with dewy natural makeup. Loose chignon with escaped strands that catch the light. Single antique gold earring. The warm follow-spot from above and front creates a natural vignette — the world outside the light does not exist. Piano lid open, bouncing soft fill upward onto her face. Cinematic photorealism. Wong Kar-wai color saturation. High skin detail. Fabric micro-highlights on silk.

**FLUX-SC01-C — "Hands and Keys Macro"**
> Cinematic extreme close-up from directly above a piano keyboard. Elegant pianist hands with long strong fingers and clean short nails press and glide across black and white keys. Warm honey skin tone against cold ivory. Hard overhead spotlight casts long dramatic finger shadows across the white keys. Chiaroscuro on miniature scale. The black keys absorb light like voids. A silver antique watch visible at the left wrist. The geometry of music made visible. Motion blur implied on the fastest passages. Photorealistic skin texture. Cinematic lighting. The hypnotic marriage of flesh and machine.

**FLUX-SC01-D — "Omar the Watcher"**
> Cinematic medium shot of an Egyptian man in his late 30s with Tony Leung energy, wearing a charcoal slim-fit suit and white open-collar shirt, seated in a theater audience. He watches with an expression of adoration that carries a hairline fracture — his eyes are too focused, too controlled. He does not blink. Warm house light (3200K) surrounds him, but a spill of stage light catches half his face in gold while the other half remains in cooler shadow. One eye illuminated, one eye in darkness. The asymmetry is subtle but present. Around him, blurred audience members — a woman wipes a tear, others are soft shapes. Cinematic anamorphic style. Photorealistic. The perfect husband watching too perfectly.

**FLUX-SC01-E — "Car Night Transition"**
> Cinematic two-shot from the back seat of a car at night in Cairo. A woman in an amber-gold silk gown, exhausted from performance, rests her head on a man's shoulder with eyes closed in contentment. The man in a charcoal suit stares forward through the windshield, not looking at her. His face is half-illuminated by passing streetlights — each light briefly reveals tension in his jaw, then plunges his expression into shadow. The windshield shows blurred neon, the dark ribbon of the Nile, Cairo's streaming cityscape. Dashboard glows green and cyan like operational readouts. Warm amber from the woman's gown clashes with cool cyan exterior light. The palette of their marriage is already splitting. Cinematic, photorealistic, anamorphic widescreen. The last warm frame before the crack.

---

## 4. SCENE 2: THE DRAWER (8:00–12:00)
### "Second Phone Discovery — Inciting Incident"
**Palette:** Fading Amber → Dusty Violet `#7B6B8D` (First intrusion of betrayal color)
**Emotional Beat:** Curiosity → Discovery → Fracture
**Key Shots:** 5 prompts per platform

---

### 4.1 SORA PROMPTS — Scene 2

**SORA-SC02-A — "Bedroom Morning Wide"**
> Cinematic motion footage, 2.39:1 anamorphic. Master bedroom in morning light, viewed from doorway looking in. Dust motes dance in sunbeams through sheer curtains. The bed is unmade — Omar's side empty, already gone. Yasmin's side shows the warm impression of her body, sheets still holding her shape. The room is tasteful, cultured: books in Arabic and French, a small writing desk, framed photos. Camera holds on a Victorian dressing table — polished mahogany, drawers closed. The room is quiet. Too quiet. Natural morning light (5600K but warmed by amber curtains to approximately 4800K). Soft, directional from window left. Long shadows. The light is beautiful but reveals everything — every dust mote, every wrinkle. Fading amber palette. The gold of curtains washed out by daylight. Domestic tranquility with undertone of absence. Static camera, 6 seconds.

**SORA-SC02-B — "Hand Opening Drawer"**
> Cinematic motion footage, 2.39:1 anamorphic. Direct side angle at drawer height. Yasmin's hand — the same elegant pianist hands from Scene 1 — pulls open the middle drawer of a polished mahogany dressing table. The drawer slides smoothly on well-oiled runners. Inside: the usual debris of a shared life — pink hair ties, cinema ticket stubs, a dried flower, a handwritten note. And beneath these, the corner of a black object, matte, rectangular. A phone. Not Omar's usual phone. Something alien. The drawer's interior is in shadow, making the black phone even darker — a void in the warm clutter. Morning light from above and left. Hand dominates left frame. Warm wood interior. Colorful clutter. The black phone is colorless — a monochrome intrusion. Static camera, 4 seconds.

**SORA-SC02-C — "Yasmin Holding the Phone — Face Transformation"**
> Cinematic motion footage, 2.39:1 anamorphic. Slightly low angle looking up at Yasmin's face. She holds the black phone in both hands, staring at it as if it were a dead thing. Her face transforms in slow motion: confusion, then dawning realization, then something like fear. She turns the phone over. It is heavier, thicker. No brand markings. A single LED blinks amber — slow, regular, like a heartbeat. She presses a button. The screen lights up with a lock screen: a photo of her. Taken without her knowledge. On stage, playing, unaware. Morning light now feels harsher — it falls across her face without mercy. The phone screen casts a blue-white glow (6500K) upward onto her chin and lips — an unnatural light source in the warm room. The first dusty violet intrusion. Her skin tone shifts — the warmth is leaving her face. Static camera, slow zoom in, 8 seconds.

**SORA-SC02-D — "Overhead Phone Screen and Hands"**
> Cinematic motion footage, 2.39:1 anamorphic. Directly above, looking down. Yasmin's hands on the dressing table, the black phone between them. She swipes through screens — encrypted messaging apps with codenames, a map with pins, photos of people and places she doesn't recognize. A photo of Omar in a café she doesn't know, with a woman she doesn't know. Her finger hovers over that photo. The screen's blue glow (6500K) illuminates her hands from below, making them look like someone else's hands. The dusty violet takes hold. Blue screen against warm wood. The clash of temperatures is visual dissonance. The amber is being defeated. Screen light dominates from below. Natural morning light still present but now feels like a memory. Static camera, 6 seconds.

**SORA-SC02-E — "Mirror — Self Unrecognizable"**
> Cinematic motion footage, 2.39:1 anamorphic. From behind Yasmin, looking at her reflection in a dressing mirror with warm tungsten bulbs (2800K). She stands abruptly. Chair scrapes backward. She looks at herself in the mirror — but does not recognize herself. Her hand reaches out to touch the mirror's surface, as if checking whether it is real. In the reflection, behind her, the bedroom door is visible. It is closed. She is alone with what she knows. Her face in the mirror shows a woman at the edge of something — she does not yet know what. The reflection is clearer than the reality. The mirror bulbs seem harsher now. The morning light seems to be fading, though it is only mid-morning. Dusty violet dominant. Her skin looks grey-violet in the mirror. The cream robe looks stained, though it is not. Color as emotional state. Static camera, 6 seconds.

---

### 4.2 VEO PROMPTS — Scene 2

**VEO-SC02-A — "Morning Bedroom Establishing"**
> Photorealistic footage of a master bedroom in morning light, viewed from doorway. Dust motes visible in sunbeams through sheer amber curtains. Unmade bed — one side empty, one side holding the warm impression of a body. Tasteful cultured room: Arabic and French books, writing desk, framed photos. Victorian dressing table with polished mahogany drawers, closed, waiting. Natural morning light 4800K, soft directional from window left. Long shadows. Fading amber palette `#D4A574` transitioning to dusty violet `#7B6B8D`. The light reveals everything. Domestic tranquility with undertone of absence. Static camera. 6 seconds.

**VEO-SC02-B — "Drawer POV — The Alien Object"**
> Photorealistic footage from inside a drawer looking up. A hand pulls open the drawer — elegant pianist's hand, cream silk sleeve. Inside: colorful domestic clutter — pink hair ties, blue ticket stubs, dried flower, handwritten note. And at the back: a black rectangular phone, matte finish, alien, wrong. The phone is a void in warm clutter. No brand markings. A single amber LED blinks slow and regular. Morning light from above. Warm wood grain visible. The monochrome intrusion in a colorful world. The first wrong note. Photorealistic texture on wood, paper, phone. 5 seconds.

**VEO-SC02-C — "Face in Phone Glow"**
> Photorealistic close-up of an elegant Egyptian woman's face lit by a phone screen from below. She holds a thick black phone, staring at it. Her expression transforms: confusion → realization → fear. The phone screen casts a blue-white glow (6500K) upward onto her chin and lips — unnatural in the warm morning room. Morning light now feels harsher. Her skin loses warmth as the dusty violet `#7B6B8D` invades. Cream silk robe slips from one shoulder, unnoticed. Face drains of color. The phone screen shows a photo of her — taken without her knowledge. The violation made visible. Photorealistic skin texture. 8 seconds.

**VEO-SC02-D — "Mirror Self-Confrontation"**
> Photorealistic footage from behind a woman looking at her reflection in a dressing mirror with warm bulbs. She does not recognize herself. Hand reaches toward the mirror as if checking reality. In the reflection: her pale face, the closed bedroom door behind her, the unmade bed. The mirror bulbs that were warm and welcoming now seem harsh — interrogation lights. Her skin looks grey-violet in the mirror. Dusty violet `#7B6B8D` dominant. The cream robe looks stained though it is not. Color as emotional state. She looks younger and older simultaneously. Photorealistic mirror reflection, no distortion. 6 seconds.

**VEO-SC02-E — "Drawer Closes — Decision Made"**
> Photorealistic close-up: a hand places the black phone back in the drawer, covers it with ticket stubs and hair ties, closes the drawer. The click is loaded with finality. Hand rests on drawer front for a moment — steady now, the tremor become resolve. Morning light is fully cool. The warmth has left the room. Dusty violet dominant. Amber is a memory. The decision to investigate rather than confront. The watcher becomes the watched. Static camera. 5 seconds.

---

### 4.3 RUNWAY GEN-3 PROMPTS — Scene 2

**RW-SC02-A — "Bedroom Morning Wide"**
> Cinematic wide shot from doorway: master bedroom in morning light. Dust motes in sunbeams through sheer curtains. Unmade bed, one side empty. Victorian dressing table center-right, drawers closed. Books, photos, cultured domesticity. Natural morning light 4800K, soft directional. Long shadows. Fading amber `#D4A574` to dusty violet `#7B6B8D`. The room is too quiet. Camera locked-off, static. The space waits. 6 seconds.

**RW-SC02-B — "Drawer Opening — Hand"**
> Cinematic close-up side angle: elegant hand pulls open mahogany drawer. Inside: colorful clutter — hair ties, tickets, dried flower, handwritten note. And the black phone, matte, anonymous, wedged at back. The alien object. Warm wood interior. The black phone is colorless — monochrome intrusion. Morning light from left. Hand hesitates. The drawer doesn't close smoothly. Something blocks it. The first wrong note. Static camera. 5 seconds.

**RW-SC02-C — "Phone Screen Glow on Face"**
> Cinematic close-up slightly low: woman's face illuminated by phone screen from below and chest level. Expression transforms through confusion to fear. Blue-white screen glow (6500K) clashes with warm morning. Skin shifts from honey to grey-violet. The phone screen shows her own photo — taken without knowledge. The lock screen: her on stage, playing, unaware. The violation visceral. Slow zoom in. Motion rich — the micro-expressions, the hand tremor, the screen flicker. 8 seconds.

**RW-SC02-D — "Mirror Reflection"**
> Cinematic medium from behind: woman at dressing mirror with warm bulbs. She stands, does not recognize herself. Hand reaches to touch mirror surface. Reflection shows pale face, closed door, unmade bed. The bulbs now read as interrogation lights. Dusty violet `#7B6B8D` dominant in reflection. Skin grey-violet. The cream robe looks stained. The self unrecognizable. Static camera. 6 seconds.

**RW-SC02-E — "Phone Returned — Drawer Closes"**
> Cinematic close-up side angle: hand places black phone back in drawer, covers with mundane debris, closes drawer. The click of a door closing on old life. Hand rests on drawer front. Steady. The tremor has become resolve. Morning light fully cool. Warmth has left. Dusty violet dominant. The secret kept. The watcher becomes the watched. Static camera. 5 seconds.

---

### 4.4 KLING PROMPTS — Scene 2

**KL-SC02-A — "Bedroom Morning Establishing"**
> Detailed cinematic scene setup: master bedroom viewed from doorway. Morning light (4800K, warmed by amber curtains) streams through sheer curtains, making dust motes dance. Unmade bed — one side empty and cold, one side holding warm body impression in white linens. Tasteful room: Arabic and French books, small writing desk, framed wedding photo. Victorian dressing table with polished mahogany, drawers closed, waiting. The room is quiet. Too quiet. Natural directional light from window left creates long shadows. Fading amber palette transitioning to first hints of dusty violet. Static camera. The space breathes its secrets. 6 seconds.

**KL-SC02-B — "Drawer POV Discovery"**
> Detailed physical dynamics: direct side angle at drawer height. Elegant pianist's hand pulls open middle drawer of mahogany dressing table. Drawer slides smoothly on oiled runners. Inside: domestic debris — pink hair ties, blue cinema ticket stubs, dried flower, handwritten note in Omar's script ("Pick up milk"). And beneath: the corner of a black matte rectangular phone. Alien object. Wrong. The drawer's interior is shadowed, making the black phone a void in warm clutter. Morning light from above and left. Hand dominates left frame. Warm wood. Colorful clutter. The monochrome intrusion. Static camera. 5 seconds.

**KL-SC02-C — "Face Transformation in Phone Light"**
> Detailed close-up dynamics: slightly low angle looking up at elegant Egyptian woman's face. She holds thick black phone in both hands, staring as if at a dead thing. Face transforms: confusion → dawning realization → fear. Turns phone over — heavier, thicker, no branding. Amber LED blinks slow like heartbeat. Presses button. Screen lights up: her photo, taken without knowledge, on stage playing. Morning light now feels harsher, falls without mercy. Phone screen casts blue-white glow (6500K) upward onto chin and lips — unnatural light in warm room. First dusty violet intrusion. Skin loses warmth. Static camera, slow zoom in. 8 seconds.

**KL-SC02-D — "Overhead Screen and Hands"**
> Detailed overhead dynamics: directly above dressing table. Elegant hands hold black phone, swipe through screens. Encrypted messaging with codenames. Map with pins across Cairo, Alexandria, Sinai. Photos of Omar in unknown places with unknown people. Screen's blue glow (6500K) illuminates hands from below, making them look like someone else's. Dusty violet takes hold. Blue screen against warm wood. Clash of temperatures is visual dissonance. Amber being defeated. Screen light dominates. Natural morning light now a memory. Static camera. 6 seconds.

**KL-SC02-E — "Mirror — Unrecognizable Self"**
> Detailed medium dynamics: from behind woman looking at dressing mirror with warm tungsten bulbs (2800K). She stands abruptly, chair scrapes. Looks at reflection — does not recognize herself. Hand reaches to touch mirror surface, checking reality. In reflection: pale face, closed bedroom door behind, unmade bed. Mirror bulbs seem harsher now — interrogation lights. Morning light seems to fade though it's mid-morning. Dusty violet dominant. Skin grey-violet in mirror. Cream robe looks stained though clean. Color as emotional state. Static camera. 6 seconds.

---

### 4.5 MIDJOURNEY STILL FRAMES — Scene 2

**MJ-SC02-A — "Morning Bedroom Wide"**
```
Master bedroom in morning light, viewed from doorway. Dust motes in sunbeams through sheer amber curtains. Unmade bed — one side empty, one side with warm body impression. Victorian dressing table with closed drawers. Books in Arabic and French, framed photos. Natural morning light 4800K, soft directional from window left. Long shadows. Fading amber `#D4A574` transitioning to dusty violet `#7B6B8D`. Domestic tranquility with undertone of absence. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC02-B — "Drawer Interior with Phone"**
```
Inside a mahogany dressing table drawer looking up. Elegant hand pulling drawer open. Inside: colorful domestic clutter — pink hair ties, blue ticket stubs, dried flower, handwritten note. And at the back: a thick black matte phone, anonymous, alien, wrong. A single amber LED blinks slow. Warm wood grain. Morning light from above. The monochrome intrusion in a colorful world. Cinematic, photorealistic, high detail. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC02-C — "Face in Phone Glow"**
```
Close-up of elegant Egyptian woman's face lit by phone screen from below. She holds a thick black phone, expression transforming from confusion to realization to fear. Blue-white screen glow (6500K) illuminates her chin and lips — unnatural in warm morning room. Cream silk robe slips from shoulder. Face drains of color. Dusty violet `#7B6B8D` invades skin tone. The violation made visible. Cinematic, photorealistic skin texture. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC02-D — "Mirror Reflection"**
```
From behind, elegant woman at dressing mirror with warm bulbs. She does not recognize herself. Hand reaches toward mirror. Reflection shows pale face, closed door, unmade bed behind her. Mirror bulbs now read as interrogation lights. Skin grey-violet in reflection. Dusty violet `#7B6B8D` dominant. Cream silk robe. She looks younger and older simultaneously. Cinematic, photorealistic. Wong Kar-wai mirror energy. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC02-E — "Phone Screen Contents"**
```
Overhead view of black phone on dressing table, held by elegant hands. Screen glows blue-white (6500K). Visible on screen: encrypted messaging app with codename "AL-MOZAINI", geolocation pins across Cairo, surveillance-style photos of a man in various locations. Finger hovering over a photo. Blue glow illuminates hands from below. Warm wood table surface. The digital portal to another life. Cinematic, photorealistic, high detail. --ar 239:100 --style raw --v 6 --s 200
```

---

### 4.6 FLUX PROMPTS — Scene 2

**FLUX-SC02-A — "Morning Bedroom Wide"**
> Cinematic widescreen establishing shot of a master bedroom viewed from the doorway in morning light. Dust motes dance visibly in sunbeams filtering through sheer amber curtains. An unmade bed dominates the center — one side empty and cold, the other still holding the warm impression of a woman's body in white linens. The room is tasteful and cultured: books in Arabic and French on a nightstand, a small writing desk with a fountain pen, framed photographs. A Victorian dressing table in polished mahogany sits in the right third, its drawers closed, waiting. Natural morning light at approximately 4800K enters softly from a window left, casting long shadows across the floor. The palette is in transition — fading amber gold `#D4A574` giving way to the first intrusion of dusty violet `#7B6B8D`. The light is beautiful but reveals too much. The room is quiet. Too quiet. Photorealistic, cinematic, anamorphic 2.39:1.

**FLUX-SC02-B — "The Alien Phone in Drawer"**
> Cinematic close-up from a side angle at drawer height. An elegant woman's hand — the same pianist's hands that played Chopin — pulls open the middle drawer of a polished mahogany dressing table. The drawer slides smoothly, revealing the colorful debris of a shared domestic life: pink hair ties, blue cinema ticket stubs, a dried flower pressed between pages, a handwritten note in a man's script saying "Pick up milk." And beneath these familiar objects, the corner of something wrong: a thick black matte phone, rectangular, anonymous, with no brand markings. A single amber LED blinks slow and regular, like a heartbeat. The drawer's interior is in warm shadow, making the black phone a void — a monochrome intrusion in a world of color. Morning light falls from above and left. Warm wood grain. The first physical evidence of the double life. Photorealistic, cinematic, high detail.

**FLUX-SC02-C — "Face Transformed by Screen Light"**
> Cinematic close-up from a slightly low angle looking up at an elegant Egyptian woman's face as she holds a thick black phone. Her expression transforms in slow motion across her features: first confusion, then dawning realization, then something approaching fear. She turns the phone over — it is heavier and thicker than any consumer device. No brand markings. A single amber LED blinks. She presses a button and the screen lights up with a lock screen photo of herself — taken without her knowledge, on stage at the piano, unaware, beautiful but violated. The morning light that was warm now feels harsh, falling across her face without mercy. The phone screen casts a blue-white glow upward onto her chin and lips — an unnatural light source that steals the warmth from her skin. The first dusty violet `#7B6B8D` invades her complexion. Her cream silk robe has slipped from one shoulder, unnoticed. Photorealistic skin texture. Cinematic, anamorphic.

**FLUX-SC02-D — "Overhead Phone and Hands"**
> Cinematic overhead shot looking directly down at a woman's elegant hands holding a black phone on a polished wood dressing table. She swipes through screens that show a world she doesn't recognize — encrypted messaging apps with codenames, a map of Cairo with location pins, photos of her husband in places she's never been with people she doesn't know. The phone screen's blue-white glow illuminates her hands from below, making them look like someone else's hands — alien, disconnected. The dusty violet `#7B6B8D` takes hold of the image. Blue digital light clashes with warm wood. The temperature clash is visual dissonance. The amber of their marriage is being defeated by the cold blue of operational truth. Screen light dominates. The natural morning light feels like a memory now. Photorealistic, cinematic, high detail.

**FLUX-SC02-E — "Mirror — The Unrecognizable Self"**
> Cinematic medium shot from behind an elegant woman looking at her reflection in a dressing mirror ringed with warm tungsten bulbs. She has stood abruptly — the chair behind her is askew. She looks at herself in the mirror but does not recognize the woman staring back. Her hand reaches out to touch the mirror's surface, as if checking whether the reflection is real. In the mirror, behind her reflected face, the bedroom door is visible — closed. She is alone with what she now knows. The warm bulbs that once created a welcoming halo now seem harsh, like interrogation lights. The morning light seems to be fading though it is only mid-morning. Dusty violet `#7B6B8D` is now the dominant emotional tone. Her skin looks grey-violet in the reflection. The cream silk robe looks stained, though it is clean. Color as emotional state. She looks simultaneously younger and older than herself. Photorealistic, cinematic, anamorphic widescreen.

---

## 5. SCENE 3: THE FOLLOW (18:00–26:00)
### "Café Surveillance — Act I Climax"
**Palette:** Cyan `#4A9B9B` / Teal / Sea Glass (Operational coolness invades)
**Emotional Beat:** Suspicion → Confirmation → The Other Woman (is not what she seems)
**Key Shots:** 5 prompts per platform

---

### 5.1 SORA PROMPTS — Scene 3

**SORA-SC03-A — "Café Interior — Yasmin Watching"**
> Cinematic motion footage, 2.39:1 anamorphic. From inside a European-style Cairo café, looking out through glass doors. The café interior is cool, teal-toned — marble floors, chrome fixtures, potted palms. Through the glass doors, the Cairo street is dusty, warm, chaotic. Yasmin sits at a corner table, alone, wearing sunglasses and a charcoal silk headscarf — an attempt at anonymity that makes her more conspicuous. She holds an espresso she hasn't touched. Her eyes, behind the sunglasses, watch the street. Late afternoon sun (warm, 4500K) from the street side. The café interior is lit by cool LED panels (5600K). The contrast between warm exterior and cool interior is stark — she has entered a colder world. Cyan `#4A9B9B` / teal dominant. She is in the cool world now. Camera static, 10 seconds.

**SORA-SC03-B — "Omar Across Street — Telephoto"**
> Cinematic motion footage, 2.39:1 anamorphic. From Yasmin's POV, extreme telephoto compression (135mm lens feel). Omar across the street, entering a building. The telephoto compression makes the distance between them feel both immense and flattened — he is close enough to see but unreachable behind the glass. He wears a navy suit — operational, not his usual charcoal. He checks his phone as he walks. His gait is different — more purposeful, less relaxed. He does not look around. Natural late afternoon light. Harsh sunlight from the west. His face is half-lit, half-shadowed. The building entrance is in shadow — he moves from light to dark. Warm exterior palette. Omar is in the warm world while Yasmin watches from the cool café. The split is maintained. Static camera, surveillance grammar, 8 seconds.

**SORA-SC03-C — "Nour Enters — The Operational World"**
> Cinematic motion footage, 2.39:1 anamorphic. From behind Yasmin, over her shoulder. A woman enters the café and walks directly to Yasmin's table. Nour — in her forties, elegant, severe. Tailored teal blazer over black. She sits without asking. Yasmin looks up, startled. The café around them continues its bustle, but a bubble of silence forms. Nour places a thin manila file on the table. She looks at Yasmin with an expression that is not quite pity, not quite warning. Cool café light from above. Nour's face is sharper, more angular. The contrast between them is visual: softness versus hardness, artist versus operative. Teal `#4A9B9B` dominates. Nour's blazer matches the café — she belongs to this world. Yasmin's beige looks out of place, a refugee from the warm world. Static camera, 8 seconds.

**SORA-SC03-D — "File Opened — Surveillance Photos"**
> Cinematic motion footage, 2.39:1 anamorphic. Over the shoulder, looking down at file contents. Nour opens the file. Yasmin looks down. The camera sees what she sees: photographs. Omar in various locations — cafés, markets, a car, a rooftop. Surveillance photos — grainy, long lens, timestamped. Evidence of a life Yasmin never knew. Her finger touches one photo — Omar at a café she has never been to, smiling at someone she doesn't know. The smile is his real smile. She recognizes it. The pain is that she recognizes it. The photos are desaturated, cyan-tinted — the color of surveillance. The manila file is warm. Yasmin's finger is pale against the photo's grey tones. Camera slow dolly across photos, 10 seconds.

**SORA-SC03-E — "360° Orbit — Living Room Confession"**
> Cinematic motion footage, 2.39:1 anamorphic. Eye-level in a living room, slow circular dolly orbit around two figures. Yasmin plays a recording on her phone. Omar stands frozen. The camera orbits them — the room becomes a stage set. The orbit reveals: the piano, the wedding photograph, the bookshelf, the window. Each object becomes evidence. The living room overhead chandelier is dimmed to tungsten 2800K. The only pool of warmth is small. Window shows cool moonlight (5600K). The 360° orbit takes 25 seconds — almost painfully slow. The living room must be dressed for all angles. The marriage as performance. The camera movement is smooth, motorized, relentless. 25 seconds.

---

### 5.2 VEO PROMPTS — Scene 3

**VEO-SC03-A — "Café Interior — The Watcher"**
> Photorealistic footage from inside a European-style Cairo café looking out through glass doors. Cool teal interior — marble floors, chrome fixtures, potted palms. Through glass: dusty warm Cairo street, chaotic. Woman in beige trench coat and charcoal silk headscarf sits at corner table, large sunglasses, untouched espresso. Watching the street. Late afternoon sun 4500K from street. Café interior LED 5600K. Contrast between warm exterior and cool interior. She has entered a colder world. Cyan `#4A9B9B` / teal dominant. Her neutral clothing makes her more conspicuous, not less. Photorealistic glass reflections. 8 seconds.

**VEO-SC03-B — "Omar Across Street"**
> Photorealistic telephoto footage: Egyptian man in navy suit across Cairo street, entering unmarked concrete building. Extreme compression makes distance feel immense yet flattened. He checks matte black phone. Gait purposeful, operational. Does not look around. Late afternoon harsh sunlight from west. Face half-lit, half-shadowed. Building entrance in shadow — he moves from light to dark. Warm exterior palette. Street traffic creates moving foreground — cars, pedestrians, carts. He is both visible and hidden by the city. Surveillance aesthetic. Photorealistic. 6 seconds.

**VEO-SC03-C — "Nour and Yasmin — The File"**
> Photorealistic two-shot side angle: two women face each other across marble café table. One in beige trench coat, disheveled, defensive. The other in tailored teal blazer, severe, elegant, forties. A thin manila file between them — barrier and bridge. Cool café overhead light. Teal `#4A9B9B` dominant. Nour's blazer matches café interior — she belongs. Yasmin's beige is out of place, refugee from warm world. The file remains closed but present. Both faces show slight shadow under eyes — tired, but different kinds. Photorealistic skin texture. 8 seconds.

**VEO-SC03-D — "Surveillance Photos in File"**
> Photorealistic over-shoulder view looking down at file contents. Grainy surveillance photographs — 8x10, timestamped, long lens. Man in various Cairo locations: Khan el-Khalili market at night, rooftop in Garden City, car on Corniche. Some alone. Some with people unknown. One photo: man at unknown café, smiling at unknown person — the smile is real, recognized, devastating. Photos are desaturated, cyan-tinted `#4A9B9B`. Manila file warm. A woman's pale finger touches one photo. The evidence of a double life in tangible form. Photorealistic paper grain, photo texture. 8 seconds.

**VEO-SC03-E — "Confession — Two-Shot Power Shift"**
> Photorealistic two-shot eye-level: woman seated, man standing. Power shift — she is grounded, he is unmoored. Living room, dimmed tungsten chandelier (2800K). Window shows cool moonlight (5600K). Small pool of warmth shrinking. She holds a phone — the recording. He stands frozen. His height now reads as vulnerability. Living room as stage set. Piano visible in background. Wedding photograph on wall. The space between them is a chasm. Cool shadows swallow the room's corners. Photorealistic. 12 seconds.

---

### 5.3 RUNWAY GEN-3 PROMPTS — Scene 3

**RW-SC03-A — "Café — Yasmin the Watcher"**
> Cinematic wide: European-style Cairo café interior, cool teal `#4A9B9B` tones. Marble floors, chrome fixtures, potted palms. Through glass doors: dusty warm street, chaotic Cairo. Woman in beige trench coat, charcoal headscarf, large sunglasses sits at corner table. Untouched espresso. Watching street. Late afternoon sun 4500K exterior. LED 5600K interior. Contrast stark — warm out, cool in. She has entered the operational world. Camera static. 10 seconds.

**RW-SC03-B — "Telephoto Omar"**
> Cinematic long lens: Egyptian man in navy suit across street, entering unmarked building. Telephoto compression — immense yet flattened distance. Checks phone. Purposeful gait. Late afternoon sun, face half-lit half-shadowed. Building entrance in shadow. Warm exterior. Street traffic partially obscures him. Both visible and hidden. Surveillance grammar. Camera static, distant, observational. 8 seconds.

**RW-SC03-C — "Nour Arrives"**
> Cinematic over-shoulder: woman in tailored teal blazer enters café, walks directly to table, sits without asking. Other woman in beige trench coat looks up, startled. Bubble of silence forms. Manila file placed on table. Not pity, not warning — something operational. Cool café light. Teal `#4A9B9B` dominant. Contrast: softness vs. hardness, artist vs. operative. Static camera. 8 seconds.

**RW-SC03-D — "The File Contents"**
> Cinematic over-shoulder close-up: file opens. Grainy surveillance photos visible. Man in various Cairo locations. Timestamped. Long lens aesthetic. One photo: man smiling at someone unknown — the smile recognized, devastating. Photos desaturated, cyan-tinted. Manila file warm intrusion. Finger touches photo. The evidence in tangible form. Camera slow dolly across photos. Motion rich — paper texture, photo grain, finger movement. 10 seconds.

**RW-SC03-E — "360° Orbit Confession"**
> Cinematic eye-level: slow circular dolly orbit around two figures in living room. Woman seated plays recording. Man stands frozen. Orbit reveals piano, wedding photo, bookshelf, window — each object evidence. Dimmed tungsten 2800K. Window moonlight 5600K. Warm pool shrinking. The room becomes stage set. Marriage as performance. Camera orbit smooth, motorized, relentless. Takes 20 seconds. Objects pass through frame sequentially. Motion-rich, choreographed. 20 seconds.

---

### 5.4 KLING PROMPTS — Scene 3

**KL-SC03-A — "Café Interior Establishing"**
> Detailed cinematic scene setup: European-style Cairo café interior, looking out through glass doors. Cool teal-toned space — marble floors, chrome fixtures, potted palms, café tables. Through glass doors: dusty warm Cairo street, chaotic traffic, vendors, donkey carts. Woman in beige trench coat and charcoal silk headscarf sits at corner table, large sunglasses hiding half her face. Untouched espresso in white cup. Late afternoon sun (4500K) from street side. Café interior lit by cool LED panels (5600K). Contrast between warm exterior and cool interior is stark — she has crossed into a colder world. Cyan `#4A9B9B` / teal dominant. Camera static. 10 seconds.

**KL-SC03-B — "Omar Across Street — Telephoto"**
> Detailed surveillance-style dynamics: from inside café looking out, extreme telephoto compression. Egyptian man in navy suit (operational, not his usual charcoal) across the street, entering unmarked concrete building. Telephoto makes distance feel immense yet flattened. He checks matte black phone as he walks. Gait more purposeful, less relaxed — operational mode. Does not look around. Late afternoon harsh sunlight from west. Face half-lit, half-shadowed. Building entrance in shadow — he moves from light to dark. Warm exterior palette while Yasmin watches from cool café. The split maintained. Camera static, surveillance grammar. 8 seconds.

**KL-SC03-C — "Nour and Yasmin at Table"**
> Detailed two-shot dynamics: side angle, both profiles visible across marble café table. Yasmin in beige trench coat, disheveled, defensive, charcoal headscarf removed, hair falling free. Nour in tailored teal blazer over black silk shirt, severe, elegant, forties, precise bob, defined brows, no jewelry. Manila file between them — third presence. Cool overhead café light. Both faces lit from above, slight shadows under eyes — both tired, but different kinds. Teal `#4A9B9B` dominant. Nour belongs to this world; Yasmin is a refugee. Static camera. 8 seconds.

**KL-SC03-D — "File Opened — Surveillance Photos"**
> Detailed over-shoulder dynamics: looking down at file contents as Nour opens it. Grainy surveillance photographs — 8x10, timestamped, long lens aesthetic. Omar in various locations: Khan el-Khalili market at night, Garden City rooftop, car on Corniche. Some alone, some with unknown people. One photo: Omar at unknown café, smiling at unknown person — the smile is his real smile, and Yasmin recognizes it. The pain is that she recognizes it. Photos desaturated, cyan-tinted. Manila file warm. Yasmin's pale finger touches the photo. Camera slow dolly across photos. 10 seconds.

**KL-SC03-E — "360° Living Room Orbit"**
> Detailed circular dynamics: eye-level in living room, slow motorized dolly orbit around Yasmin and Omar. Yasmin seated, plays recording on phone. Omar stands frozen. The 360° orbit takes 25 seconds — almost painfully slow. As camera moves, it reveals: the piano, the wedding photograph on the wall, the bookshelf, the window with cool moonlight. Each object becomes evidence. Living room chandelier dimmed to tungsten 2800K. Window shows cool moonlight 5600K. The only pool of warmth is small and shrinking. The marriage as performance. The room as stage set. Smooth, relentless orbit. 25 seconds.

---

### 5.5 MIDJOURNEY STILL FRAMES — Scene 3

**MJ-SC03-A — "Café Interior — Yasmin Watching"**
```
European-style Cairo café interior looking out through glass doors. Cool teal `#4A9B9B` tones — marble floors, chrome fixtures, potted palms. Through glass: dusty warm Cairo street, chaotic. Elegant woman in beige trench coat, charcoal silk headscarf, large sunglasses sits at corner table. Untouched espresso. Late afternoon sun 4500K exterior, LED 5600K interior. Contrast stark. She is in the cool world now. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC03-B — "Omar Across Street — Telephoto"**
```
Egyptian man in navy suit across Cairo street, entering unmarked concrete building. Extreme telephoto compression. Checks matte black phone. Purposeful operational gait. Late afternoon harsh sun from west, face half-lit half-shadowed. Building entrance in shadow. Street traffic — cars, pedestrians, carts — partially obscures him. Warm exterior palette. Surveillance aesthetic. Tinker Tailor Soldier Spy energy. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC03-C — "Nour and Yasmin — The File"**
```
Two women face each other across marble café table. One in beige trench coat, disheveled, defensive. The other in tailored teal blazer over black silk shirt, severe, elegant, forties, precise bob. Manila file between them. Cool café overhead light. Teal `#4A9B9B` dominant. Contrast: softness vs. hardness. Both faces show tiredness — different kinds. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC03-D — "Surveillance Photos"**
```
Over-shoulder view looking down at file of grainy surveillance photographs. 8x10, timestamped, long lens aesthetic. Man in various Cairo locations. Desaturated, cyan-tinted `#4A9B9B`. Manila file warm. Woman's pale finger touches one photo. The evidence of a double life. Photo grain, paper texture. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC03-E — "Confession Two-Shot"**
```
Two-shot eye-level: woman seated holding phone (recording), man standing frozen. Living room. Dimmed tungsten chandelier 2800K. Window shows cool moonlight 5600K. Piano visible in background. Wedding photograph on wall. The space between them is a chasm. She is grounded, he is unmoored. Cool shadows swallow room corners. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

---

### 5.6 FLUX PROMPTS — Scene 3

**FLUX-SC03-A — "Café — The Watcher"**
> Cinematic widescreen shot from inside a European-style Cairo café looking out through glass doors. The interior is cool and teal-toned — marble floors, chrome fixtures, potted palms, café tables with white cups. Through the glass doors, the Cairo street is dusty, warm, and chaotic — vendors, traffic, a donkey cart, the endless motion of the city. Yasmin sits at a corner table, alone, wearing a beige trench coat over dark clothing and a charcoal silk headscarf, with large dark sunglasses that obscure half her face. An untouched espresso sits before her in a white cup. She watches the street. The late afternoon sun (4500K) filters in from the street side while the café interior is lit by cool LED panels (5600K). The contrast between the warm exterior and the cool interior is stark — she has crossed a threshold into a colder world. Cyan `#4A9B9B` and teal dominate the frame. Her attempt at anonymity has made her more conspicuous. Photorealistic, cinematic, anamorphic 2.39:1.

**FLUX-SC03-B — "Omar Across Street — Telephoto Surveillance"**
> Cinematic widescreen shot with extreme telephoto compression, as if viewed through a long lens from a distance. Omar is across the street, entering an unmarked concrete building in downtown Cairo. He wears a navy suit — operational, not his usual charcoal — and checks a matte black phone as he walks. His gait is different from the man Yasmin knows: more purposeful, less relaxed, habitual. He does not look around; he is not worried about being followed. This is his operational mode. The late afternoon sun from the west casts his face in half-light, half-shadow. The building entrance is in shadow — he moves from light to dark. The street traffic creates a moving foreground that partially obscures him: cars, pedestrians, a fruit cart. He is both visible and hidden by the city. The warm exterior palette contrasts with the cool café interior where Yasmin watches. Photorealistic, surveillance aesthetic, anamorphic.

**FLUX-SC03-C — "Nour and Yasmin — The Operational World"**
> Cinematic two-shot side angle showing two women facing each other across a marble café table. Yasmin, in her beige trench coat with the charcoal headscarf now removed and her hair falling free, looks up with a startled, defensive expression. Nour, in her forties, elegant and severe in a tailored teal blazer over a black silk shirt, sits without asking permission. A thin manila folder rests on the table between them — both barrier and bridge. The cool overhead café light casts slight shadows under both women's eyes, but Nour's tiredness is seasoned and professional while Yasmin's is raw and new. Teal `#4A9B9B` dominates the palette — Nour's blazer matches the café, proving she belongs to this world. Yasmin's neutral beige looks out of place, the clothing of a refugee from a warmer life. Photorealistic, cinematic, anamorphic widescreen.

**FLUX-SC03-D — "The File — Surveillance Photos"**
> Cinematic over-shoulder shot looking down at the contents of a manila file as it is opened. Inside: grainy surveillance photographs, 8x10, timestamped, shot with long lenses. Omar in various Cairo locations — the Khan el-Khalili market at night, a rooftop in Garden City, a car on the Corniche. In some photos he is alone. In others he is with people Yasmin doesn't know. One photograph shows him at a café she has never been to, smiling at someone she doesn't know. The smile is his real smile, and the pain is that Yasmin recognizes it. The photos are desaturated and cyan-tinted — the color of surveillance. The manila file is a warm intrusion in the cool palette. Yasmin's pale finger touches the photograph, as if contact could explain what she is seeing. Photorealistic, high detail, surveillance aesthetic.

**FLUX-SC03-E — "360° Orbit — The Confession"**
> Cinematic eye-level shot in a living room, with the camera executing a slow circular dolly orbit around two figures. Yasmin is seated, playing a recording on her phone. Omar stands frozen, listening. The orbit takes time — almost painfully slow — and as the camera moves, it reveals the room's objects sequentially: the piano where she has played for seven years, the wedding photograph on the wall, the bookshelf they built together, the window showing cool moonlight outside. Each object becomes evidence in the trial of their marriage. The living room chandelier is dimmed to warm tungsten (2800K) but the pool of warmth is shrinking. The window lets in cool moonlight (5600K). The room has become a stage set. The marriage is revealed as performance. The camera movement is smooth, motorized, relentless — the mechanical eye of judgment. Photorealistic, cinematic, anamorphic 2.39:1.

---

## 6. SCENE 4: THE SAFE HOUSE (48:00–52:00)
### "Midpoint Twist — Surveillance File & Other Woman"
**Palette:** Dusty Violet `#7B6B8D` / Bruised Rose `#9B6B7B` / Fluorescent 4100K
**Emotional Beat:** Confrontation → Revelation → The Mission Revealed
**Key Shots:** 5 prompts per platform

---

### 6.1 SORA PROMPTS — Scene 4

**SORA-SC04-A — "Safe House Exterior Night"**
> Cinematic motion footage, 2.39:1 anamorphic. From across the street, low angle. A Belle époque building in Garden City, once grand, now peeling. French colonial facade — balconies with iron lacework, tall shutters, carved stone. Paint flaking, shutters rotting, garden overgrown. A single light burns in a third-floor window — the only sign of life. Surrounding buildings are modern, concrete, indifferent. Rain has just fallen — the street is wet, reflecting streetlights in long gold streaks. Streetlights: sodium vapor, warm orange. The single window light: cool white, 5600K. Wet street reflects both, doubling the light, doubling the mystery. Dusty violet night sky. Warm orange streetlights. Cool white window. Wet asphalt reflects all colors in smeared abstraction. The bruised rose `#9B6B7B` of decay on the facade. Camera static, 10 seconds.

**SORA-SC04-B — "Stairwell Ascent"**
> Cinematic motion footage, 2.39:1 anamorphic. Following Yasmin from behind as she climbs a narrow stairwell. Walls are peeling, steps are worn marble with brass edges. A single bare bulb hangs from the ceiling, swinging slightly — perhaps from a draft, perhaps from decay. Yasmin's shadow grows and shrinks with the bulb's swing. She wears dark clothing — black turtleneck, dark jeans, boots. Hair pulled back severely. No makeup except darkened eyes — kohl applied for strength, not beauty. Single bare bulb: tungsten, 2800K, hard. The swing creates moving shadows. Her face alternates between light and shadow as she climbs — visual rhythm of uncertainty. Warm tungsten against cool blue shadow. Walls grey-green, marble cream stained with age. Dusty violet in deepest shadows. Camera tracks smoothly from behind, 8 seconds.

**SORA-SC04-C — "Safe House Interior — Confrontation"**
> Cinematic motion footage, 2.39:1 anamorphic. From doorway, looking in. Yasmin enters the safe house apartment. The room is large, high-ceilinged, once elegant. Now stripped and functional — a table with electronic equipment, maps on walls, a camp bed in the corner. Omar stands at the table, his back to the door. He does not turn immediately. He knows someone is there but does not know who. The room's decayed grandeur clashes with operational equipment — past and present in violent coexistence. A window is open, curtains moving in night breeze. Mixed light: desk lamp on equipment table (warm, hard), cool light from open window (moonlight or city glow, 5600K), bare ceiling bulb from stairwell (visible through open door). Multiple sources create multiple shadows. Nothing is clear. Dusty violet `#7B6B8D` dominates. Warm desk lamp creates a small island of amber in a sea of bruised color. Equipment LEDs add pinpricks of red and green. Camera static, 8 seconds.

**SORA-SC04-D — "Omar Turns — The Mask Drops"**
> Cinematic motion footage, 2.39:1 anamorphic. Two-shot side angle. Omar turns. Sees Yasmin. His face shows — for one unguarded moment — pure shock, then fear, then terrible sadness. He does not reach for a weapon. He does not call for help. He simply looks at her, and in that look is the confession of everything. Yasmin stands in the doorway, her bag dropped at her feet. She does not speak. The silence is the confrontation. Equipment blinks red and green behind them, indifferent. Curtains continue to move. City continues outside. But in this room, time has stopped. Omar left of center, Yasmin right of center. Doorway behind Yasmin is bright — escape route. Equipment table behind Omar is dark — his trap. Desk lamp lights Omar's face from below and side — theatrical, revealing. Yasmin is backlit from doorway, her face in shadow, unreadable. He is exposed, she is hidden. Dusty violet, bruised rose. The amber desk lamp warms Omar's face — he is still, in some way, the man she loved. Her face is cool, violet-shadowed. Camera static, 10 seconds.

**SORA-SC04-E — "Mirror — Yasmin Sees Herself as File"**
> Cinematic motion footage, 2.39:1 anamorphic. Medium shot eye-level, through doorway. Yasmin in the safe house mirror. Behind her: the wall of photographs. Hundreds of them. Her life, catalogued. She sees herself among her own surveillance. She cannot recognize herself. Fluorescent bathroom light: 4100K, institutional, flat. No fill — harsh shadow under eyes, nose. She looks like a file photograph. The worst light for a woman — every flaw exposed. Dusty violet `#7B6B8D` in the mirror reflection. The photographs behind her are desaturated, grey, evidence. She is both the subject and the object of surveillance. The midpoint's visual thesis. Camera static, 12 seconds.

---

### 6.2 VEO PROMPTS — Scene 4

**VEO-SC04-A — "Safe House Exterior"**
> Photorealistic footage of Belle époque building in Garden City at night, from across street, low angle. Once grand, now peeling. French colonial facade: iron balconies, tall shutters, carved stone. Paint flaking in layers — blue, cream, green. Shutters rotting. Garden overgrown with dead and living plants. Single light in third-floor window — only sign of life. Surrounding buildings modern concrete, indifferent. Rain just fallen — wet street reflects streetlights in long gold streaks. Sodium vapor streetlights warm orange. Window light cool white 5600K. Wet asphalt reflects all colors in abstraction. Dusty violet `#7B6B8D` night sky. Bruised rose `#9B6B7B` decay on facade. Cinematic, photorealistic. 8 seconds.

**VEO-SC04-B — "Stairwell Climb"**
> Photorealistic tracking shot following woman from behind climbing narrow stairwell. Peeling walls, worn marble steps with brass edges. Single bare bulb swings from ceiling — moving shadows grow and shrink. Woman in black turtleneck, dark jeans, boots. Hair pulled back severely. Kohl on eyes for strength. Face alternates between light and shadow with bulb swing. Tungsten 2800K hard light. Warm against cool blue shadow. Walls grey-green. Marble cream stained with age. Dusty violet in deepest shadows. The approach. Each step irreversible. Cinematic, photorealistic. 8 seconds.

**VEO-SC04-C — "Confrontation — Safe House Interior"**
> Photorealistic wide shot from doorway looking into safe house apartment. Large high-ceilinged room, once elegant, now stripped. Table with electronic equipment, maps with pins and circles, camp bed in corner. Man stands at table, back to door — does not turn. Knows someone is there but not who. Decayed grandeur clashes with operational equipment. Window open, curtains moving in night breeze. Mixed light: desk lamp warm hard, window cool 5600K, stairwell bulb visible through door. Multiple shadows. Nothing clear. Dusty violet `#7B6B8D` dominant. Equipment LEDs red and green. Cinematic, photorealistic. 8 seconds.

**VEO-SC04-D — "The Mask Drops"**
> Photorealistic two-shot side angle: man turns, sees woman in doorway. Face shows shock → fear → terrible sadness. No weapon. No call for help. Just the look that confesses everything. Woman stands in doorway, bag dropped at feet. Does not speak. Equipment blinks red and green behind them. Curtains move. City continues. Time stopped in this room. Man lit from below by desk lamp — theatrical, revealing. Woman backlit from doorway, face in shadow. He is exposed, she is hidden. Dusty violet, bruised rose `#9B6B7B`. Amber lamp warms his face. Her face cool, violet-shadowed. Cinematic, photorealistic skin texture. 10 seconds.

**VEO-SC04-E — "Mirror — Self as Surveillance"**
> Photorealistic medium shot through doorway: woman in safe house mirror. Behind her: wall covered with hundreds of photographs. Her life, catalogued. She sees herself among her own surveillance files. Cannot recognize herself. Fluorescent 4100K institutional light. No fill. Harsh shadows under eyes and nose. She looks like a file photograph. Every flaw exposed. Dusty violet `#7B6B8D` in reflection. Photographs behind her desaturated, grey, evidence. She is both subject and object. The midpoint visual thesis. Cinematic, photorealistic. 10 seconds.

---

### 6.3 RUNWAY GEN-3 PROMPTS — Scene 4

**RW-SC04-A — "Safe House Exterior Night"**
> Cinematic wide from across street, low angle: Belle époque Garden City building, once grand, now decaying. French colonial facade — iron balconies, tall shutters, carved stone. Peeling paint in bruised rose `#9B6B7B` layers. Overgrown garden. Single cool white light in third-floor window. Surrounding modern concrete buildings indifferent. Rain-wet street reflects sodium streetlights in long gold streaks. Dusty violet `#7B6B8D` night sky. Wet asphalt color abstraction. The safe house as symbol — beauty decayed, secrets preserved. Camera locked-off. 8 seconds.

**RW-SC04-B — "Stairwell Ascent"**
> Cinematic tracking from behind: woman in black turtleneck and boots climbs narrow stairwell. Peeling wallpaper, worn marble steps with brass edges. Single bare bulb swings overhead — her shadow grows and shrinks rhythmically. Face alternates light and shadow. Tungsten 2800K hard. Cool blue shadows. Walls grey-green. Dusty violet in depths. Each landing looks the same. The building is a maze. Camera tracks smoothly. Motion rich — shadow play, step rhythm, curtain of hair. 8 seconds.

**RW-SC04-C — "Interior Confrontation"**
> Cinematic wide from doorway: large high-ceilinged room, decayed grandeur vs. operational equipment. Table with laptops, radios, maps with red circles. Camp bed. Man at table, back to door, does not turn. Woman enters from deep background. Window open, curtains moving. Mixed light sources create multiple shadows. Dusty violet `#7B6B8D` dominant. Small island of amber from desk lamp. Red and green equipment LEDs. The anti-home. Camera static. 8 seconds.

**RW-SC04-D — "The Mask Drops — Two-Shot"**
> Cinematic two-shot side angle: man turns, sees woman. Face: shock → fear → sadness. No weapon, no defense. Just the confession in his eyes. Woman in doorway, bag dropped. Does not speak. Silence is confrontation. Equipment blinks behind them. City outside. Time stopped. Man lit from below by desk lamp. Woman backlit from doorway, face shadowed. He exposed, she hidden. Dusty violet and bruised rose. The midpoint. Camera static. 10 seconds.

**RW-SC04-E — "Mirror with Surveillance Wall"**
> Cinematic medium through doorway: woman in mirror. Behind her in reflection: wall covered with hundreds of surveillance photographs. Her life as case file. She cannot recognize herself among her own files. Fluorescent 4100K flat institutional light. Harsh shadows under eyes and nose. Looks like a file photograph. Dusty violet `#7B6B8D` reflection. Photographs desaturated grey evidence. She is both watcher and watched. Camera static. 10 seconds.

---

### 6.4 KLING PROMPTS — Scene 4

**KL-SC04-A — "Safe House Exterior"**
> Detailed cinematic scene setup: Belle époque building in Garden City at night, viewed from across street, low angle. French colonial facade with iron lacework balconies, tall shutters, carved stone details. Paint flaking in visible layers — blue, cream, green. Shutters rotting. Garden overgrown with dead and living plants intermixed. Single cool white light (5600K) burns in third-floor window — only sign of life. Surrounding buildings are modern concrete, indifferent to the ghost. Rain has just fallen — wet asphalt street reflects sodium vapor streetlights in long gold streaks. Dusty violet `#7B6B8D` night sky. Warm orange streetlights. Cool white window. Wet asphalt reflects all colors in smeared abstraction. Bruised rose `#9B6B7B` of decay on facade. Static camera. 8 seconds.

**KL-SC04-B — "Stairwell Ascent"**
> Detailed tracking dynamics: following woman from behind as she climbs narrow stairwell. Worn marble steps with brass edges. Peeling wallpaper with pattern no longer visible. Single bare bulb (tungsten 2800K, hard) hangs from ceiling, swinging slightly — perhaps from draft, perhaps from decay. Woman's shadow grows and shrinks with bulb's swing. She wears black turtleneck, dark jeans, boots — operational clothing bought for this night. Hair pulled back severely. Kohl on eyes for strength, not beauty. Face alternates between light and shadow as she climbs — visual rhythm of uncertainty. Warm tungsten light against cool blue shadow. Walls grey-green. Marble cream stained with age. Dusty violet in deepest shadows. Camera tracks smoothly from behind. 8 seconds.

**KL-SC04-C — "Interior Confrontation Setup"**
> Detailed wide dynamics: from doorway looking into safe house apartment. Large high-ceilinged room, once elegant, now stripped and functional. Table with electronic equipment — laptops, radios, map of Cairo with pins and red circles, cold coffee pot, documents in Arabic and English. Camp bed in corner, unmade. Man stands at table, back to door. Does not turn immediately — knows someone is there but not who. Decayed grandeur clashes with operational equipment. Window open, curtains moving in night breeze. City noise drifts in. Mixed light: desk lamp warm and hard, cool light from open window (5600K), stairwell bulb visible through open door. Multiple sources create multiple shadows. Nothing is clear. Dusty violet `#7B6B8D` dominant. Warm desk lamp creates small island of amber. Equipment LEDs add red and green pinpricks. Camera static. 8 seconds.

**KL-SC04-D — "Omar Turns — Mask Drops"**
> Detailed two-shot dynamics: side angle, both visible. Man turns, sees woman in doorway. Face shows — for one unguarded moment — pure shock, then fear, then terrible sadness. Does not reach for weapon. Does not call for help. Simply looks, and in that look is confession of everything. Woman stands in doorway, bag dropped at feet. Does not speak. Silence is confrontation. Equipment blinks red and green behind them, indifferent. Curtains move. City continues outside. But in this room, time has stopped. Man positioned left of center, woman right. Doorway behind woman is bright — escape. Equipment table behind man is dark — his trap. Desk lamp lights man's face from below and side — theatrical, revealing. Woman backlit from doorway, face in shadow, unreadable. He is exposed, she is hidden. Dusty violet, bruised rose `#9B6B7B`. Amber lamp warms his face. Her face cool, violet-shadowed. Camera static. 10 seconds.

**KL-SC04-E — "Mirror — Surveillance Self"**
> Detailed medium dynamics: eye-level, through doorway. Woman in safe house mirror. Behind her in the mirror's reflection: the wall of photographs. Hundreds of them. Her life, catalogued. Mixed with them: another woman. Same time period. Same wedding ring on Omar's hand in photos. She sees herself among her own surveillance. She cannot recognize herself. Fluorescent bathroom light: 4100K, institutional, flat. No fill — harsh shadow under eyes, nose. She looks like a file photograph. The worst light for a woman — every flaw exposed. Dusty violet `#7B6B8D` in mirror reflection. Photographs behind her desaturated, grey, evidence. She is both subject and object of surveillance. The midpoint's visual thesis. Camera static. 10 seconds.

---

### 6.5 MIDJOURNEY STILL FRAMES — Scene 4

**MJ-SC04-A — "Safe House Exterior Night"**
```
Belle époque building in Garden City at night, viewed from across wet street, low angle. French colonial facade: iron balconies, tall shutters, carved stone. Paint flaking in layers. Shutters rotting. Overgrown garden. Single cool white light in third-floor window. Surrounding modern concrete buildings indifferent. Wet street reflects sodium streetlights in gold streaks. Dusty violet `#7B6B8D` night sky. Bruised rose `#9B6B7B` decay on facade. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC04-B — "Stairwell Ascent"**
```
Woman in black turtleneck and boots climbing narrow stairwell from behind. Peeling walls, worn marble steps with brass edges. Single bare bulb swinging overhead — shadows grow and shrink. Face alternates light and shadow. Tungsten 2800K hard. Cool blue shadows. Walls grey-green. Dusty violet `#7B6B8D` in depths. The approach. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC04-C — "Safe House Interior"**
```
Wide shot from doorway into large high-ceilinged room, once elegant, now stripped. Table with electronic equipment, maps with pins, camp bed. Man stands at table, back to door. Decayed grandeur vs. operational equipment. Window open, curtains moving. Mixed light: desk lamp warm, window cool 5600K. Dusty violet `#7B6B8D` dominant. Equipment LEDs red and green. The anti-home. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC04-D — "The Mask Drops"**
```
Two-shot side angle: Egyptian man turns, sees woman in doorway. Face shows shock, fear, terrible sadness. Woman stands with bag dropped, does not speak. Equipment blinks red and green behind them. Man lit from below by desk lamp — theatrical. Woman backlit from doorway, face in shadow. He exposed, she hidden. Dusty violet and bruised rose `#9B6B7B`. The midpoint. Cinematic, photorealistic skin texture. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC04-E — "Mirror with Surveillance Wall"**
```
Woman in safe house mirror. Behind her: wall covered with hundreds of surveillance photographs. Her life as case file. Cannot recognize herself. Fluorescent 4100K flat light. Harsh shadows under eyes and nose. Looks like a file photograph. Dusty violet `#7B6B8D` reflection. Photographs desaturated grey evidence. Both subject and object. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

---

### 6.6 FLUX PROMPTS — Scene 4

**FLUX-SC04-A — "Safe House Exterior Night"**
> Cinematic widescreen shot of a Belle époque building in Garden City, Cairo, viewed from across the street at a low angle at night. The building was once grand but is now peeling and decaying — a French colonial facade with iron lacework balconies, tall wooden shutters, and carved stone details. The paint flakes in visible layers of blue, cream, and green. The shutters are rotting. The garden is overgrown with dead and living plants intertwined. A single cool white light burns in a third-floor window — the only sign of life in the ghost building. Surrounding buildings are modern concrete structures, indifferent to the decayed beauty beside them. Rain has just fallen, and the wet asphalt street reflects the sodium vapor streetlights in long gold streaks. The night sky is dusty violet `#7B6B8D`. The warm orange streetlights clash with the cool white window. The wet asphalt reflects all colors in smeared abstraction. The bruised rose `#9B6B7B` of decay colors the facade. The safe house as symbol — beauty decayed, secrets preserved. Photorealistic, cinematic, anamorphic 2.39:1.

**FLUX-SC04-B — "Stairwell Ascent"**
> Cinematic tracking shot from behind as a woman climbs a narrow stairwell in the decayed building. She wears a black turtleneck, dark jeans, and boots — operational clothing bought for this night. Her hair is pulled back severely and her eyes are darkened with kohl, applied for strength rather than beauty. The walls are peeling, the steps are worn marble with brass edges. A single bare tungsten bulb (2800K, hard light) hangs from the ceiling, swinging slightly — perhaps from a draft, perhaps from the building's decay. Her shadow grows and shrinks with the bulb's swing, creating a visual rhythm of uncertainty. Her face alternates between warm light and cool blue shadow as she climbs. The walls are grey-green, the marble steps are cream stained with age. Dusty violet `#7B6B8D` lurks in the deepest shadows. Each landing looks the same, each turn reveals more of the same decay. The building is a maze, and each step is irreversible. Photorealistic, cinematic, anamorphic.

**FLUX-SC04-C — "Safe House Interior — Confrontation"**
> Cinematic wide shot from the doorway looking into a safe house apartment. The room is large and high-ceilinged, once elegant but now stripped and functional. A table holds electronic equipment — laptops showing surveillance footage, radios with soft static, a map of Cairo with pins and red circles marking targets and deadlines, a cold coffee pot, documents in Arabic and English. A camp bed sits in the corner, unmade, slept in. A wardrobe with clothes hanging — some his usual style, some operational and anonymous. A photograph pinned to the wall: Yasmin at a concert, the same photo from the phone. The irony is bitter. Omar stands at the table, his back to the door. He does not turn immediately — he knows someone is there but does not know who. The room's decayed grandeur clashes violently with the operational equipment. A window is open, curtains moving in the night breeze, city noise drifting in. Mixed light sources create multiple shadows: a desk lamp warm and hard, cool light from the open window (5600K), the bare stairwell bulb visible through the open door. Nothing is clear. Dusty violet `#7B6B8D` dominates the palette. The warm desk lamp creates only a small island of amber in a sea of bruised color. Equipment LEDs add pinpricks of red and green. Photorealistic, cinematic, anamorphic 2.39:1.

**FLUX-SC04-D — "Omar Turns — The Mask Drops"**
> Cinematic two-shot from a side angle showing the moment of confrontation. Omar turns and sees Yasmin in the doorway. His face shows — for one unguarded moment — pure shock, then fear, then a terrible sadness that contains everything he has hidden. He does not reach for a weapon. He does not call for help. He simply looks at her, and in that look is the confession of seven years. Yasmin stands in the doorway, her bag dropped at her feet. She does not speak. The silence is the confrontation. Behind them, electronic equipment blinks red and green, indifferent to the human drama. The curtains continue to move in the night breeze. The city continues outside. But in this room, time has stopped. Omar is positioned left of center, Yasmin right of center. The doorway behind her is bright — an escape route. The equipment table behind him is dark — his trap. The desk lamp lights Omar's face from below and the side — theatrical, revealing every line and shadow. Yasmin is backlit from the doorway, her face in shadow, unreadable. The contrast is deliberate: he is exposed, she is hidden. Dusty violet and bruised rose `#9B6B7B` color the shadows. The amber desk lamp warms Omar's face — he is still, in some way, the man she loved. Her face is cool, violet-shadowed — she is becoming someone else. Photorealistic, cinematic, anamorphic widescreen.

**FLUX-SC04-E — "Mirror — Yasmin Sees Herself as Surveillance"**
> Cinematic medium shot through a doorway showing Yasmin in a safe house mirror. Behind her, reflected in the mirror, is a wall covered with hundreds of photographs — her life, catalogued as a surveillance file. Mixed with them are photos of another woman, younger, in a different city, with Omar's wedding ring visible in the background. Yasmin sees herself among her own surveillance photographs. She cannot recognize herself. The lighting is fluorescent 4100K — institutional, flat, emotionally dead. There is no fill light. Harsh shadows fall under her eyes and nose. She looks like a file photograph. This is the worst light for a woman — every flaw is exposed, every line magnified. Dusty violet `#7B6B8D` dominates the mirror reflection. The photographs behind her are desaturated, grey, evidence. She is both the subject and the object of surveillance. The midpoint's visual thesis made flesh. Photorealistic, cinematic, anamorphic 2.39:1.

---

## 7. SCENE 5: THE RAINDROP (60:00–68:00)
### "Operation Invades Home"
**Palette:** Slate Grey `#708090` / Storm Blue `#4A6B8D` + Emergency Red `#8B0000`
**Emotional Beat:** Invasion → Fear → The Operational World Crashes Home
**Key Shots:** 5 prompts per platform

---

### 7.1 SORA PROMPTS — Scene 5

**SORA-SC05-A — "Apartment Exterior — Rainstorm"**
> Cinematic motion footage, 2.39:1 anamorphic. From the street, looking up at the apartment building. Art deco facade in a Cairo rainstorm — rare, violent, transformative. Rain sheets down in silver-grey curtains. The facade is elegant but the rain makes it look like a watercolor running. Yasmin's window is visible on the fourth floor — lit, warm, a single amber rectangle in the grey storm. Other windows are dark. The street is empty except for a single black car parked across the way — tinted windows, opaque. Rain creates a visual veil between the warm interior and the cold exterior. The car waits. Streetlights: sodium, warm, diffused by rain. Apartment window's warm light. Car interior is dark — no light escapes. Lightning flickers, brief and white, illuminating the building for one stark moment. Slate grey `#708090` dominant. Storm blue `#4A6B8D` in rain shadows. The amber window is an endangered island of warmth. Emergency red of car taillights, barely visible. Camera static, 8 seconds.

**SORA-SC05-B — "Overhead Two-Shot — Hands on Keys, Hands Hovering"**
> Cinematic motion footage, 2.39:1 anamorphic. Overhead two-shot looking straight down. Yasmin's hands on piano keys, playing Chopin's Raindrop Prelude. Omar's hands hover above the keys — not touching, just hovering. The repeated A-flat, the note of doom. The hands are the story: her hands certain, practiced, grounded on the ivory; his hands uncertain, suspended, unable to land. Hard 2K Fresnel overhead light creates stark contrast. The keys are a chessboard of black and white. Her hands are warm honey. His hands are in shadow. The overhead angle makes them specimens, specimens of a marriage. Slate grey `#708090` and storm blue `#4A6B8D`. The red of emergency barely visible at frame edges. Camera static, 12 seconds.

**SORA-SC05-C — "Invasion — Door Opens"**
> Cinematic motion footage, 2.39:1 anamorphic. From the apartment interior, looking at the front door. A solid wooden door, familiar, safe. But now it is the weakest point. Yasmin turns from the window to face the door. Sound builds from outside — footsteps in the hall, multiple, heavy. Then silence. Then three sharp knocks. The door seems to shrink in the frame. The warm room behind it feels suddenly small, fragile. The piano is visible in the background — a black shape waiting. Warm interior light (2800K). The door is in shadow — the hallway beyond is unlit. The contrast between warm safety and dark unknown is stark. Slate grey `#708090` dress of Yasmin moving toward the door. Camera static, 5 seconds.

**SORA-SC05-D — "Operational Figures Enter"**
> Cinematic motion footage, 2.39:1 anamorphic. From inside the hall, looking into the apartment as the door opens. Three figures enter — not police, not military, but operational: dark clothing, efficient movements, no badges. The first figure is Nour — she enters first, face apologetic but hard. Behind her, two men who do not look at Yasmin as a person — they look at her as a location, a target, a variable. Yasmin stands in the living room doorway, backlit by warm interior. She does not move. She does not scream. She simply watches them invade her home. The contrast between their dark operational clothing and her grey dress and the warm apartment is a visual invasion — the cool world entering the warm world. Hall mixed: warm interior light from behind Yasmin, cool flashlight beams from invaders' hands. The flashlights cut through warm air like surgical instruments. Slate grey, storm blue, emergency red `#8B0000` from flashlight filters. Camera static, 6 seconds.

**SORA-SC05-E — "Yasmin's Face — The Mask and the Fire"**
> Cinematic motion footage, 2.39:1 anamorphic. Close-up frontal, tight on Yasmin's face. The search continues around her — off-screen sounds of drawers opening, belongings touched by strangers. Her face is composed, almost serene — a mask she has learned to wear. But her eyes are alive with something — not fear, but cold fire. She is calculating. She is deciding. Red flashlight beams cross her face, turning her skin briefly crimson, then returning to grey. The intermittent red is like a heartbeat — the emergency color of the film's darkest act. Mixed and moving light. Red flashlight beams create moving patches of color. Warm interior light provides base. Her face shifts between warm, cool, and red — three emotional states in one frame. Slate grey `#708090`, storm blue `#4A6B8D`, emergency red `#8B0000`. The amber is almost gone — a memory in corners. Camera static, 6 seconds.

---

### 7.2 VEO PROMPTS — Scene 5

**VEO-SC05-A — "Rainstorm Exterior"**
> Photorealistic footage of art deco Cairo apartment building in violent rainstorm. From street looking up. Rain sheets down in silver-grey curtains. Elegant facade becoming watercolor running. Fourth-floor window lit warm amber — single rectangle in grey storm. Other windows dark. Empty street except for black car across way, tinted opaque windows. Rain creates visual veil between warm interior and cold exterior. Streetlights sodium warm, diffused by rain. Lightning flickers white, building starkly illuminated. Slate grey `#708090` dominant. Storm blue `#4A6B8D` in rain shadows. Amber window endangered island. Cinematic, photorealistic. 8 seconds.

**VEO-SC05-B — "Overhead Hands — Piano and Hovering"**
> Photorealistic overhead two-shot looking straight down at piano keyboard. Woman's hands on keys playing Chopin Raindrop Prelude. Man's hands hover above — not touching, just hovering. Repeated A-flat, note of doom. Her hands certain and grounded on ivory. His hands uncertain, suspended, unable to land. Hard 2K Fresnel overhead light. Stark contrast. Keys are chessboard of black and white. Her hands warm honey. His hands in shadow. Overhead angle makes them specimens of a marriage. Slate grey `#708090` and storm blue `#4A6B8D`. Emergency red at frame edges. Cinematic, photorealistic. 10 seconds.

**VEO-SC05-C — "Door — The Threshold"**
> Photorealistic footage of solid wooden apartment door from interior. Door familiar and safe, now weakest point. Woman in grey dress turns from window to face door. Sound builds from outside — multiple heavy footsteps in hall. Silence. Three sharp knocks. Door seems to shrink in frame. Warm room behind feels small, fragile. Piano visible in background — black shape waiting. Warm interior light 2800K. Door in shadow — hallway beyond unlit. Contrast between warm safety and dark unknown stark. Slate grey `#708090` dress. Cinematic, photorealistic. 5 seconds.

**VEO-SC05-D — "Operational Invasion"**
> Photorealistic footage from inside hall looking into apartment as door opens. Three figures enter in dark operational clothing, efficient movements, no badges. First woman enters, face apologetic but hard. Behind her two men who look at Yasmin as target, not person. Yasmin stands in living room doorway, backlit by warm interior. Does not move. Does not scream. Simply watches them invade. Contrast between dark operational clothing and grey dress and warm apartment is visual invasion. Mixed light: warm interior from behind Yasmin, cool flashlight beams from invaders. Flashlights cut through warm air like surgical instruments. Slate grey, storm blue, emergency red `#8B0000` from filters. Cinematic, photorealistic. 6 seconds.

**VEO-SC05-E — "Yasmin's Face — Cold Fire"**
> Photorealistic close-up frontal tight on woman's face. Search continues around her off-screen. Face composed, almost serene — a learned mask. But eyes alive with cold fire. She is calculating. Deciding. Red flashlight beams cross her face, skin briefly crimson, then grey. Intermittent red like heartbeat. Mixed moving light. Face shifts between warm, cool, and red — three emotional states. Slate grey `#708090`, storm blue `#4A6B8D`, emergency red `#8B0000`. Amber almost gone. Cinematic, photorealistic skin texture. 6 seconds.

---

### 7.3 RUNWAY GEN-3 PROMPTS — Scene 5

**RW-SC05-A — "Rainstorm Building"**
> Cinematic wide from street looking up: art deco Cairo apartment building in violent rainstorm. Rain sheets down silver-grey. Elegant facade becoming watercolor. Fourth-floor window warm amber rectangle in grey storm. Black car across street, opaque windows. Rain veil between warm interior and cold exterior. Sodium streetlights diffused by rain. Lightning flickers white. Slate grey `#708090` dominant. Storm blue `#4A6B8D` shadows. Amber window endangered. Camera locked-off. 8 seconds.

**RW-SC05-B — "Overhead Piano Hands"**
> Cinematic overhead two-shot: woman's hands on piano keys playing Raindrop Prelude. Man's hands hover above — not touching, suspended. Repeated A-flat as note of doom. Her hands certain on ivory. His hands uncertain, unable to land. Hard 2K Fresnel overhead. Stark contrast. Keys as chessboard. Her hands warm honey. His hands shadow. Specimens of marriage. Slate grey `#708090` and storm blue `#4A6B8D`. Camera static. 10 seconds.

**RW-SC05-C — "Door Threshold"**
> Cinematic wide: solid wooden apartment door from interior. Familiar, safe, now weakest point. Woman in grey dress turns from window to face door. Footsteps build in hall — multiple, heavy. Silence. Three sharp knocks. Door shrinks in frame. Warm room feels fragile. Piano visible in background. Warm interior 2800K. Door in shadow — hall beyond unlit. Contrast between safety and unknown. Slate grey `#708090`. Camera static. 5 seconds.

**RW-SC05-D — "Invasion"**
> Cinematic from hall looking into apartment as door opens. Three figures in dark operational clothing enter. Efficient, no badges. First woman apologetic but hard. Two men look at target, not person. Yasmin in living room doorway, backlit by warm interior. Does not move. Simply watches invasion. Dark clothing vs. grey dress vs. warm apartment — visual invasion. Mixed light: warm interior behind her, cool flashlight beams from invaders. Flashlights like surgical instruments. Slate grey, storm blue, emergency red `#8B0000`. Camera static. 6 seconds.

**RW-SC05-E — "Face — Cold Fire"**
> Cinematic close-up frontal: woman's face during search. Composed, serene mask. But eyes alive with cold fire. Calculating. Deciding. Red flashlight beams cross face — skin briefly crimson, then grey. Intermittent red like heartbeat. Mixed moving light. Face shifts warm → cool → red. Three emotional states in one frame. Slate grey `#708090`, storm blue `#4A6B8D`, emergency red `#8B0000`. Amber memory in corners. Camera static. 6 seconds.

---

### 7.4 KLING PROMPTS — Scene 5

**KL-SC05-A — "Rainstorm Exterior"**
> Detailed cinematic scene setup: art deco Cairo apartment building in violent rainstorm, viewed from street looking up. Rain sheets down in silver-grey curtains, rare and transformative for Cairo. Elegant art deco facade — geometric stone patterns, curved balconies, porthole windows — becoming watercolor running. Fourth-floor window lit warm amber — single rectangle in grey storm. Other windows dark. Street empty except for black European car across way, tinted opaque windows. Rain creates visual veil between warm interior and cold exterior. The car waits. Streetlights: sodium vapor warm, diffused by rain. Apartment window's warm light. Car interior dark — no light escapes. Lightning flickers brief and white, illuminating building for one stark moment. Slate grey `#708090` dominant. Storm blue `#4A6B8D` in rain shadows. Amber window is endangered island of warmth. Emergency red of car taillights barely visible. Camera static. 8 seconds.

**KL-SC05-B — "Overhead Hands on Piano"**
> Detailed overhead dynamics: straight down at piano keyboard. Woman's hands on keys playing Chopin's Raindrop Prelude. Man's hands hover above the keys — not touching, just hovering. The repeated A-flat, the note of doom. Her hands certain, practiced, grounded on ivory. His hands uncertain, suspended, unable to land. Hard 2K Fresnel overhead light creates stark contrast. The keys are a chessboard of black and white. Her hands are warm honey tone. His hands are in shadow. The overhead angle makes them specimens, specimens of a marriage under operational strain. Slate grey `#708090` and storm blue `#4A6B8D` color the shadows. Emergency red barely visible at frame edges. Camera static. 12 seconds.

**KL-SC05-C — "Door and Threshold"**
> Detailed wide dynamics: from apartment interior looking at front door. Solid wooden door, familiar, safe. But now it is the weakest point. Yasmin in simple grey jersey dress turns from window to face the door. Sound builds from outside — footsteps in hall, multiple, heavy. Then silence. Then three sharp knocks. The door seems to shrink in the frame. The warm room behind it feels suddenly small, fragile. The piano is visible in the background — a black shape waiting. Warm interior light (2800K table lamps). The door is in shadow — the hallway beyond is unlit. The contrast between warm safety and dark unknown is stark. Slate grey `#708090` dress of Yasmin moving toward the door. Camera static. 5 seconds.

**KL-SC05-D — "Operational Invasion"**
> Detailed dynamics from inside hall looking into apartment as door opens. Three figures enter — not police, not military, but operational: dark clothing, efficient movements, no badges. First figure is Nour — she enters first, face apologetic but hard. Behind her, two men who do not look at Yasmin as a person — they look at her as location, target, variable. Yasmin stands in living room doorway, backlit by warm interior. She does not move. She does not scream. She simply watches them invade her home. The contrast between their dark operational clothing and her grey dress and the warm apartment is a visual invasion — the cool world entering the warm world. Hall mixed: warm interior light from behind Yasmin, cool flashlight beams from invaders' hands. The flashlights cut through warm air like surgical instruments. Slate grey, storm blue, emergency red `#8B0000` from flashlight filters. Camera static. 6 seconds.

**KL-SC05-E — "Yasmin's Face — The Mask and Fire"**
> Detailed close-up dynamics: frontal tight on Yasmin's face. The search continues around her — off-screen sounds of drawers opening, belongings touched by strangers. Her face is composed, almost serene — a mask she has learned to wear since the discovery. But her eyes are alive with something — not fear, but a cold fire. She is calculating. She is deciding. Red flashlight beams cross her face, turning her skin briefly crimson `#8B0000`, then returning to grey. The intermittent red is like a heartbeat — the emergency color of the film's darkest act. Mixed and moving light. Red flashlight beams create moving patches of color. Warm interior light provides base. Her face shifts between warm, cool, and red — three emotional states in one frame. Slate grey `#708090`, storm blue `#4A6B8D`, emergency red. The amber is almost gone — a memory in corners. Camera static. 6 seconds.

---

### 7.5 MIDJOURNEY STILL FRAMES — Scene 5

**MJ-SC05-A — "Rainstorm Building"**
```
Art deco Cairo apartment building in violent rainstorm, viewed from street looking up. Rain sheets down silver-grey. Elegant facade becoming watercolor. Fourth-floor window lit warm amber in grey storm. Black car across street, opaque windows. Rain veil between interior and exterior. Sodium streetlights diffused by rain. Lightning flickers white. Slate grey `#708090` dominant. Storm blue `#4A6B8D` shadows. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC05-B — "Overhead Hands"**
```
Overhead shot looking straight down at piano keyboard. Woman's hands on keys playing Chopin. Man's hands hover above — not touching, suspended. Hard overhead light. Stark contrast. Keys as chessboard. Her hands warm honey. His hands in shadow. Slate grey `#708090` and storm blue `#4A6B8D`. Specimens of a marriage. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC05-C — "Door Threshold"**
```
Solid wooden apartment door from interior. Woman in grey dress turns from window to face door. Footsteps build in hall — multiple, heavy. Three sharp knocks. Door in shadow — hallway beyond unlit. Warm interior light 2800K. Piano visible in background. Contrast between warm safety and dark unknown. Slate grey `#708090`. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC05-D — "Operational Invasion"**
```
From inside hall looking into apartment as door opens. Three figures in dark operational clothing enter. First woman apologetic but hard. Two men look at target. Yasmin in living room doorway, backlit by warm interior. Does not move. Dark clothing vs. grey dress vs. warm apartment — visual invasion. Mixed light: warm interior behind, cool flashlight beams from invaders. Slate grey, storm blue, emergency red `#8B0000`. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC05-E — "Face with Red Flashlight"**
```
Close-up frontal tight on woman's face during search. Composed serene mask. Eyes alive with cold fire. Red flashlight beams cross face — skin briefly crimson, then grey. Mixed moving light. Face shifts warm, cool, red. Slate grey `#708090`, storm blue `#4A6B8D`, emergency red `#8B0000`. Cinematic, photorealistic skin texture. --ar 239:100 --style raw --v 6 --s 250
```

---

### 7.6 FLUX PROMPTS — Scene 5

**FLUX-SC05-A — "Rainstorm Exterior"**
> Cinematic widescreen shot of an art deco Cairo apartment building in a violent rainstorm, viewed from the street looking up. Rain sheets down in silver-grey curtains — rare and transformative for Cairo. The elegant art deco facade with geometric stone patterns, curved balconies, and porthole windows is becoming like a watercolor running down the frame. A single window on the fourth floor glows warm amber — a lone rectangle of light in the grey storm. All other windows are dark. The street below is empty except for a single black European car parked across the way, its windows tinted and opaque. The rain creates a visual veil between the warm interior and the cold exterior. The car waits. Sodium vapor streetlights glow warm but are diffused by the rain into soft halos. The apartment window's warm light is a threatened island. Lightning flickers brief and white, illuminating the building in one stark moment. Slate grey `#708090` is dominant. Storm blue `#4A6B8D` lurks in the rain shadows. The amber window is endangered. Emergency red taillights of the car are barely visible. Photorealistic, cinematic, anamorphic 2.39:1.

**FLUX-SC05-B — "Overhead Hands — Piano and Hovering"**
> Cinematic overhead two-shot looking straight down at a piano keyboard. Yasmin's hands are on the keys, playing Chopin's Raindrop Prelude with certainty and precision — the repeated A-flat that represents doom. Omar's hands hover above the keys, not touching, just suspended in the air. His hands are uncertain, unable to land, paralyzed by what is unfolding. A hard 2K Fresnel overhead light creates stark contrast across the scene. The black and white keys become a chessboard. Her hands are warm honey in color, grounded and certain on the ivory. His hands are in shadow, disconnected, unable to commit. The overhead angle reduces them to specimens — specimens of a marriage at its breaking point. Slate grey `#708090` and storm blue `#4A6B8D` color the shadows. The emergency red `#8B0000` is barely visible at the frame edges, a warning. Photorealistic, cinematic, anamorphic.

**FLUX-SC05-C — "The Door — Threshold as Threat"**
> Cinematic wide shot from the apartment interior looking at the front door. It is a solid wooden door, familiar, safe — the same door they have closed behind them a thousand times. But now it is the weakest point in their world. Yasmin in a simple grey jersey dress turns from the window to face the door. Sound builds from the hallway outside — footsteps, multiple, heavy. Then silence. Then three sharp knocks. The door seems to shrink in the frame under the threat. The warm room behind it feels suddenly small, fragile. The piano is visible in the background — a black shape waiting like a sleeping animal. Warm interior light from table lamps (2800K) fills the room. The door itself is in shadow — the hallway beyond is unlit and unknown. The contrast between the warm safety inside and the dark unknown outside is stark. Slate grey `#708090` is the color of Yasmin's dress as she moves toward the door. Photorealistic, cinematic, anamorphic 2.39:1.

**FLUX-SC05-D — "Operational Invasion"**
> Cinematic shot from inside the hallway looking into the apartment as the front door opens. Three figures enter — not police, not military, but operational personnel in dark anonymous clothing, moving with efficient practiced movements, displaying no badges or identification. The first figure is Nour — she enters first, her face showing apology but also hardness. Behind her, two men who do not look at Yasmin as a person — they assess her as a location, a target, a variable to be managed. Yasmin stands in the living room doorway, backlit by the warm interior light. She does not move. She does not scream. She simply watches them invade her home with a composed stillness that is more terrifying than any reaction. The contrast between their dark operational clothing, her grey dress, and the warm amber apartment is a visual invasion — the cool operational world entering the warm domestic world. The hallway is filled with mixed light: warm interior light from behind Yasmin, cool flashlight beams from the invaders' hands. The flashlights cut through the warm air like surgical instruments. Slate grey, storm blue `#4A6B8D`, and emergency red `#8B0000` from the flashlight filters dominate. Photorealistic, cinematic, anamorphic widescreen.

**FLUX-SC05-E — "Yasmin's Face — The Mask and the Fire Beneath"**
> Cinematic extreme close-up frontal and tight on Yasmin's face as the operational search continues around her. Off-screen sounds of drawers opening, her belongings being touched by strangers' hands. Her face is composed, almost serene — a mask she has learned to wear in the weeks since the discovery. But her eyes are alive with something that is not fear — it is a cold fire. She is calculating. She is deciding. Red flashlight beams from the invaders' equipment cross her face, turning her skin briefly crimson `#8B0000`, then returning to grey. The intermittent red is like a heartbeat — the emergency color of the film's darkest act, pulsing across her features. The lighting is mixed and moving. Red flashlight beams create moving patches of color. Warm interior light provides a base. Her face shifts between warm, cool, and red — three emotional states existing in one frame. Slate grey `#708090`, storm blue `#4A6B8D`, emergency red. The amber of Act I is almost gone now — just a memory in the corners of the frame. Photorealistic skin texture. Cinematic, anamorphic 2.39:1.

---

## 8. SCENE 6: THE DESTRUCTION (68:00–75:00)
### "Piano Smashed — Emotional Annihilation"
**Palette:** Emergency Red `#8B0000` + Ash / Slate Grey `#708090`
**Emotional Beat:** Rage → Destruction → Ruin
**Aspect Ratio Note:** 2.39:1 → 1.85:1 → 2.39:1 squeeze during destruction
**Key Shots:** 5 prompts per platform

---

### 8.1 SORA PROMPTS — Scene 6

**SORA-SC06-A — "Pre-Destruction Stillness"**
> Cinematic motion footage, 2.39:1 anamorphic → squeezing to 1.85:1 → releasing to 2.39:1. Wide shot eye-level. Yasmin standing at the piano. Omar in background. She is terrifyingly still. The apartment is lit brighter than ever before — full tungsten practicals (2800K), no shadows to hide in. The truth is fully exposed. Blinding warmth — too much, too late. Yasmin's face: no tears. A decision has been made. The piano waits — black, lacquered, the instrument that has been her voice, her sanity, her identity. Emergency red `#8B0000` barely bleeding in at frame edges. Slate grey `#708090` dress. The stillness before the violence of control breaks. Camera static, 10 seconds. Aspect ratio holds 2.39:1, then begins squeeze.

**SORA-SC06-B — "Piano Lid Lifted"**
> Cinematic motion footage, 1.85:1 squeezed aspect ratio. Medium shot low angle. Yasmin's hands lift the piano lid. The sound is wrong — too loud, too final. The lid rises, revealing the strings, the hammers, the inner mechanism. Her face is visible above the lid: no tears, a decision. Hard 2K Fresnel overhead light (3200K). No fill — black shadows, the void opening. The piano's own light is now unstable. Camera whip pan fast from her face to the lid, then holds. The first act of violence — the instrument exposed. Emergency red `#8B0000` growing in intensity. Motion blur on the lid lift. 5 seconds.

**SORA-SC06-C — "Piano Smash — Slow Motion Destruction"**
> Cinematic motion footage, 1.85:1 squeezed aspect ratio, 48fps slow motion played as 24fps (2×). Wide shot high angle. Yasmin smashes the piano lid down with both hands, with all her strength. In slow motion: the wood splinters along the grain, wire strings scream and snap, hammers break free, dust erupts in a cloud. Each shard of wood and wire suspended in air, visible, beautiful, wrong. The destruction as ballet — beauty in annihilation. The world literally compresses around the violence, then will release. Hard overhead Fresnel. The light of interrogation — no softness. Slate grey `#708090` and emergency red `#8B0000` dust in the air. Camera locked-off for slow-motion capture, 12 seconds.

**SORA-SC06-D — "String Snapping — Macro"**
> Cinematic motion footage, 1.85:1 squeezed, 48fps slow motion. Extreme close-up eye-level. Piano string vibrating, then snapping. The metal whipping through air. The string as nerve — the instrument's pain made visible. Razor-thin depth of field. The vibrating string shimmers, then tension releases, then the whip-crack of metal through air. Dust motes suspended around the break. Emergency red `#8B0000` backlight on dust. The beauty must feel wrong — horrifying in its aesthetic. Hard key light. No fill. The violence of precision breaking. Camera static slow-motion capture, 8 seconds.

**SORA-SC06-E — "Aftermath — Ruin as Landscape"**
> Cinematic motion footage, 2.39:1 releasing back to full widescreen. Wide shot low angle. The destroyed piano. Yasmin on her knees among the wreckage — splintered wood, snapped wires, broken hammers. Omar has not moved. He stands in the background, witness to what he caused. The broken piano lamp flickers — practical tungsten, 2800K, failing electrical short from the impact. The flicker creates an unstable light. Dust particles suspended in air, backlit by failing lamp — destruction as constellation, dust as stars. Cool moonlight from window (5600K HMI) provides distant indifferent fill. The light dies with the piano. Dust particles backlit create unexpected beauty. Camera static, 15 seconds. Aspect ratio slowly releases back to 2.39:1.

---

### 8.2 VEO PROMPTS — Scene 6

**VEO-SC05-A — "Pre-Destruction Stillness" (Intended as SC06-A)****
> Photorealistic wide shot: woman standing at black piano, man in background. She is terrifyingly still. Apartment lit brighter than ever — full tungsten 2800K, no shadows. Truth fully exposed. Blinding warmth, too much, too late. Woman's face: no tears, a decision made. Piano waits — black, lacquered, her voice and sanity. Emergency red `#8B0000` bleeding at frame edges. Slate grey `#708090` dress. Stillness before violence breaks. Photorealistic. 8 seconds.

**VEO-SC06-B — "Piano Lid Lift"**
> Photorealistic medium low angle: woman's hands lift piano lid. Sound implied — too loud, too final. Lid rises revealing strings, hammers, inner mechanism. Face visible above lid: no tears, only decision. Hard 2K Fresnel overhead 3200K. No fill — black shadows opening. Piano's own light unstable. Motion blur on lid lift. Emergency red `#8B0000` growing. Photorealistic wood grain, metal mechanism. 5 seconds.

**VEO-SC06-C — "Slow Motion Smash"**
> Photorealistic slow-motion wide high angle: woman smashes piano lid down with full strength. Wood splinters along grain. Wire strings scream and snap. Hammers break free. Dust erupts in cloud. Each shard suspended in air, visible, beautiful, wrong. Destruction as ballet. Hard overhead Fresnel. Slate grey and emergency red `#8B0000` dust. The beauty feels wrong. Photorealistic debris simulation. 12 seconds.

**VEO-SC06-D — "String Snap Macro"**
> Photorealistic slow-motion extreme close-up: piano string vibrates, then snaps. Metal whips through air. String as nerve — instrument's pain visible. Razor-thin depth of field. Vibrating string shimmers, tension releases, whip-crack of metal. Dust motes suspended. Emergency red `#8B0000` backlight on dust. Beauty that horrifies. Hard key light. No fill. Photorealistic metal texture, motion blur. 8 seconds.

**VEO-SC06-E — "Aftermath — Kneeling in Ruin"**
> Photorealistic wide low angle: destroyed piano. Woman on knees among wreckage — splintered wood, snapped wires, broken hammers. Man in background, has not moved, witness to what he caused. Broken piano lamp flickers — tungsten 2800K, failing electrical short. Dust particles suspended, backlit by failing lamp. Dust as stars, destruction as constellation. Cool moonlight 5600K from window. Light dies with piano. Photorealistic debris, dust simulation, flicker. 15 seconds.

---

### 8.3 RUNWAY GEN-3 PROMPTS — Scene 6

**RW-SC06-A — "Stillness Before"**
> Cinematic wide eye-level: woman standing at piano, man in background. Terrifying stillness. Apartment brightest ever — full tungsten 2800K, no shadows. Truth exposed. Blinding warmth, too late. Woman's face: no tears, decision made. Piano waits — her voice, sanity, identity. Emergency red `#8B0000` at edges. Slate grey `#708090` dress. Stillness before violence of control breaks. Camera locked-off. 8 seconds. Aspect ratio 2.39:1.

**RW-SC06-B — "Lid Lift"**
> Cinematic medium low angle: hands lift piano lid. Too loud, too final. Lid rises revealing strings, hammers, mechanism. Face above: no tears, only decision. Hard 2K Fresnel overhead. No fill — void opening. Piano's light unstable. Whip pan to lid, then hold. First act of violence — instrument exposed. Emergency red `#8B0000` growing. Motion rich — lid weight, hand tension, mechanism reveal. 5 seconds. Aspect ratio squeezing to 1.85:1.

**RW-SC06-C — "Slow-Motion Smash"**
> Cinematic wide high angle, slow motion: woman smashes lid down with full strength. Wood splinters. Strings snap. Hammers break. Dust erupts. Each shard suspended, visible, beautiful, wrong. Destruction as ballet. Hard overhead Fresnel. Slate grey and emergency red `#8B0000` dust. Beauty that horrifies. Camera locked-off for slow-motion. 12 seconds. Aspect ratio 1.85:1.

**RW-SC06-D — "String Whip Macro"**
> Cinematic extreme close-up slow motion: piano string vibrates, snaps. Metal whips through air. Razor-thin depth of field. String shimmers, tension releases, whip-crack. Dust motes suspended. Emergency red `#8B0000` backlight. Instrument's pain made visible. Hard key light. No fill. Static camera for slow-motion capture. 8 seconds. Aspect ratio 1.85:1.

**RW-SC06-E — "Aftermath — Ruin"**
> Cinematic wide low angle: destroyed piano. Woman on knees in wreckage. Man in background, unmoving, witness. Broken piano lamp flickers — tungsten 2800K, electrical short. Dust particles suspended, backlit by failing lamp. Dust as stars, destruction as constellation. Cool moonlight 5600K from window. Light dies with piano. Camera static. 15 seconds. Aspect ratio releasing back to 2.39:1.

---

### 8.4 KLING PROMPTS — Scene 6

**KL-SC06-A — "Pre-Destruction Stillness"**
> Detailed cinematic wide dynamics: eye-level. Yasmin standing at the piano. Omar in background. She is terrifyingly still — the stillness of control about to break. The apartment is lit brighter than it has ever been — full tungsten practicals (2800K), no shadows to hide in. The truth is fully exposed. Blinding warmth — too much, too late. Yasmin's face: no tears. A decision has been made. The piano waits — black, lacquered, the instrument that has been her voice, her sanity, her identity for twenty years. Emergency red `#8B0000` barely bleeding in at frame edges. Slate grey `#708090` dress. The stillness before the violence of control breaks. Camera static, 8 seconds. Aspect ratio 2.39:1.

**KL-SC06-B — "Piano Lid Lifted"**
> Detailed medium dynamics: low angle. Yasmin's hands lift the piano lid. The sound is wrong — too loud, too final. The lid rises, revealing the strings, the hammers, the inner mechanism. Her face is visible above the rising lid: no tears, only a terrible decision. Hard 2K Fresnel overhead light (3200K). No fill — black shadows, the void opening. The piano's own light is now unstable. Fast whip pan from her face to the lid, then camera holds. The first act of violence — the instrument exposed. Emergency red `#8B0000` growing in intensity. Motion blur on the lid lift conveying weight and finality. 5 seconds. Aspect ratio squeezing to 1.85:1.

**KL-SC06-C — "Slow-Motion Piano Smash"**
> Detailed wide dynamics: high angle, 48fps slow-motion capture. Yasmin smashes the piano lid down with both hands, with all her strength, with seven years of unspoken truth. In slow motion: the wood splinters along the grain, wire strings scream and snap, hammers break free from their mounts, dust erupts in a cloud that expands like a slow breath. Each shard of wood and wire suspended in air, visible, beautiful, and wrong. The destruction as ballet — beauty in annihilation. The world literally compresses around the violence. Hard overhead Fresnel. The light of interrogation — no softness, no forgiveness. Slate grey `#708090` and emergency red `#8B0000` in the dust cloud. Camera locked-off for slow-motion capture. 12 seconds. Aspect ratio 1.85:1.

**KL-SC06-D — "String Snapping — Macro"**
> Detailed extreme close-up dynamics: eye-level, 48fps slow motion. Piano string vibrating with visible harmonic motion, then snapping. The metal whips through air with a violence that is beautiful. The string as nerve — the instrument's pain made visible. Razor-thin depth of field. The vibrating string shimmers in hard light, then tension releases in a visible wave, then the whip-crack of metal through air. Dust motes suspended around the break. Emergency red `#8B0000` backlight on dust particles. The beauty must feel wrong — we should be horrified by how beautiful it is. Hard key light. No fill. The violence of precision breaking. Camera static for slow-motion capture. 8 seconds. Aspect ratio 1.85:1.

**KL-SC06-E — "Aftermath — Ruin as Landscape"**
> Detailed wide dynamics: low angle, aspect ratio releasing back to 2.39:1. The destroyed piano — a corpse of wood and wire. Yasmin on her knees among the wreckage: splintered mahogany, snapped steel strings curling like dead nerves, broken felt hammers. Omar has not moved. He stands in the background, witness to what he caused. The broken piano lamp flickers — practical tungsten 2800K, failing from electrical short created by the impact. The flicker creates unstable, dying light. Dust particles suspended in air, backlit by the failing lamp — destruction as constellation, dust as stars. Cool moonlight from window (5600K) provides distant, indifferent fill. The light dies with the piano. The unexpected beauty of ruin. Camera static, holding the aftermath. 15 seconds. Aspect ratio slowly releases back to full 2.39:1 widescreen.

---

### 8.5 MIDJOURNEY STILL FRAMES — Scene 6

**MJ-SC06-A — "Pre-Destruction Stillness"**
```
Woman standing at black piano in brightly lit apartment, man in background. Terrifying stillness. Full tungsten 2800K, no shadows. Truth exposed. Blinding warmth. Woman's face: no tears, decision made. Piano waits — black, lacquered. Emergency red `#8B0000` bleeding at edges. Slate grey `#708090` dress. Stillness before violence breaks. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC06-B — "Lid Lifted"**
```
Medium low angle: woman's hands lift piano lid. Lid rises revealing strings, hammers, inner mechanism. Face above: no tears, only decision. Hard 2K Fresnel overhead 3200K. No fill — black shadows opening. Piano's own light unstable. Emergency red `#8B0000` growing. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC06-C — "Slow-Motion Smash"**
```
Wide high angle: woman smashes piano lid down with full strength. Wood splinters along grain. Wire strings scream and snap. Hammers break free. Dust erupts in cloud. Each shard suspended in air, visible, beautiful, wrong. Destruction as ballet. Hard overhead Fresnel. Slate grey and emergency red `#8B0000` dust. Cinematic, photorealistic debris. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC06-D — "String Snap Macro"**
```
Extreme close-up: piano string vibrating, then snapping. Metal whips through air. Razor-thin depth of field. String shimmers, tension releases, whip-crack. Dust motes suspended. Emergency red `#8B0000` backlight. Instrument's pain visible. Hard key light. No fill. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC06-E — "Aftermath — Kneeling in Ruin"**
```
Wide low angle: destroyed piano. Woman on knees in wreckage — splintered wood, snapped wires, broken hammers. Man in background, unmoving, witness. Broken piano lamp flickers — tungsten 2800K, electrical short. Dust particles suspended, backlit by failing lamp. Dust as stars, destruction as constellation. Cool moonlight 5600K from window. Light dies with piano. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

---

### 8.6 FLUX PROMPTS — Scene 6

**FLUX-SC06-A — "Pre-Destruction Stillness"**
> Cinematic widescreen shot of Yasmin standing at the black piano in her apartment, with Omar visible in the background. She is terrifyingly still — the stillness of control about to shatter into violence. The apartment is lit brighter than it has ever been in the film — full tungsten practicals at 2800K with no shadows to hide in. The truth is fully exposed, and the light is blinding in its warmth — too much, too late. Yasmin's face shows no tears. A decision has been made. The piano waits before her — black, lacquered, the instrument that has been her voice, her sanity, her identity for twenty years. Emergency red `#8B0000` barely bleeds in at the frame edges, a warning. Her slate grey `#708090` dress absorbs light. The stillness before the violence of control breaks. This is the breath before the scream. Photorealistic, cinematic, anamorphic 2.39:1.

**FLUX-SC06-B — "Piano Lid Lifted"**
> Cinematic medium shot from a low angle as Yasmin's hands lift the piano lid. The implied sound is wrong — too loud, too final. The lid rises slowly, revealing the strings, the hammers, the inner mechanism of the instrument that has been her sanctuary. Her face is visible above the rising lid: no tears, only a terrible decision crystallized in her expression. A hard 2K Fresnel overhead light at 3200K creates stark contrast. There is no fill — black shadows open like voids around her. The piano's own light is now unstable, threatened. The first act of violence against the instrument that has been her voice. Emergency red `#8B0000` grows in intensity at the edges of the frame. Motion blur on the lid conveys its weight and the finality of the gesture. Photorealistic, cinematic, anamorphic 2.39:1 squeezing to 1.85:1.

**FLUX-SC06-C — "Slow-Motion Piano Smash"**
> Cinematic wide shot from a high angle, captured in slow motion: Yasmin smashes the piano lid down with both hands, with all her strength, with seven years of unspoken truth condensed into one gesture of annihilation. The wood splinters along the grain in visible agony. Wire strings scream and snap, recoiling like severed nerves. Hammers break free from their mounts and tumble through air. Dust erupts in a cloud that expands like a slow breath of grief. Each shard of wood and wire is suspended in air, visible, beautiful, and utterly wrong. The destruction becomes ballet — beauty in annihilation. The aspect ratio literally compresses around the violence, the world closing in. A hard overhead Fresnel provides the light of interrogation — no softness, no forgiveness. Slate grey `#708090` and emergency red `#8B0000` fill the dust cloud with the colors of trauma. Photorealistic debris simulation, cinematic, anamorphic 1.85:1.

**FLUX-SC06-D — "String Snapping — Macro"**
> Cinematic extreme close-up at eye level, in slow motion: a single piano string vibrating with visible harmonic motion, then snapping under impossible tension. The metal whips through air with a violence that is strangely beautiful. The string as nerve — the instrument's pain made visible to the eye. Razor-thin depth of field isolates the string while everything else dissolves into creamy bokeh. The vibrating string shimmers in hard light, then tension releases in a visible wave traveling along the wire, then the whip-crack as the broken end flies through air. Dust motes suspended around the break catch emergency red `#8B0000` backlight. The beauty must feel wrong — the audience should be horrified by how beautiful the destruction is. Hard key light. No fill. The violence of precision breaking against itself. Photorealistic metal texture, cinematic, anamorphic 1.85:1.

**FLUX-SC06-E — "Aftermath — Ruin as Landscape"**
> Cinematic wide shot from a low angle as the aspect ratio slowly releases back to full 2.39:1 widescreen. The destroyed piano lies like a corpse of wood and wire. Yasmin is on her knees among the wreckage — splintered mahogany, snapped steel strings curling like dead nerves, broken felt hammers scattered like organs. Omar has not moved. He stands in the background, witness to what he caused, unable to intervene or speak. The broken piano lamp flickers — practical tungsten at 2800K, failing from the electrical short created by the impact. The flicker creates unstable, dying light that makes the scene feel like a failing heartbeat. Dust particles suspended in air are backlit by the failing lamp — destruction becomes constellation, dust becomes stars in a perverse night sky. Cool moonlight from the window at 5600K provides distant, indifferent fill. The light dies with the piano. The unexpected beauty of complete ruin. Photorealistic debris, dust simulation, flickering light, cinematic, anamorphic 2.39:1.

---

## 9. SCENE 7: THE DUOLOGY (85:00–95:00)
### "Piano Duet Confrontation"
**Palette:** Bruised Rose `#9B6B7B` / Dusty Violet `#7B6B8D` / Warm Piano Spot 3000K
**Emotional Beat:** Confrontation → Silence → The Unresolved Note
**Key Shots:** 5 prompts per platform

---

### 9.1 SORA PROMPTS — Scene 7

**SORA-SC07-A — "Empty Conservatory — Tribunal"**
> Cinematic motion footage, 2.39:1 anamorphic. Wide shot from balcony, static. Empty conservatory at night. Yasmin at the piano. Single spotlight from above — 750W Leko, tight spot, warm 3000K. The hall is a cathedral of wood and shadow. Rows of empty seats disappear into darkness. The wood paneling glows faintly in the spill. Exit signs glow cold green — institutional, subliminal "exit." The space is too large for one person — loneliness as architecture. The single spotlight creates a natural vignette: Yasmin and the piano are an island of warm light in a sea of shadow. She reads from a file. Her voice is clinical but her hands shake. Moonlight through high windows: cool 5600K, distant. The hall's own voice is silence. Camera static, 12 seconds.

**SORA-SC07-B — "Four Hands on Keyboard — Chessboard"**
> Cinematic motion footage, 2.39:1 anamorphic. Close-up overhead, static. Four hands on the keyboard. Yasmin's hands on the lower keys, certain, playing the opening Nocturne from Scene 1. Omar's hands hover above the upper keys — the courtship gesture from their first meeting. His hands do not touch the keys. They hover, aligned but not touching, not playing. The geometry of almost-contact. The black and white keys become a chessboard of black and white fingers. Her hands are warm honey, certain, grounded. His hands are in shadow, suspended, unable to commit. The 750W Leko spotlight from above creates hard shadows. The contrast between her certainty and his paralysis is the entire marriage in one frame. Warm 3000K spotlight. No fill. Camera static, 10 seconds.

**SORA-SC07-C — "Omar Cries — Mask Destroyed"**
> Cinematic motion footage, 2.39:1 anamorphic. Close-up eye-level, static. Omar's face. He does not play. He rests his fingers on top of hers on the keys — the first physical contact in the scene. He is crying. The first true tears in the film. The operative cannot perform anymore. The mask is destroyed. His face is lit only by the piano spotlight spill — half-lit, half-shadow, incomplete. No fill. The tears catch the warm 3000K light and become liquid gold on his olive skin. His expression contains seven years of performance collapsing into truth. Camera holds static, 8 seconds. The 85mm portrait compression makes the background fall away — only the face remains.

**SORA-SC07-D — "Yasmin Stops — 15-Second Silence"**
> Cinematic motion footage, 2.39:1 anamorphic. Close-up eye-level, static. Yasmin's face. She stops playing. The silence is the most devastating sound in the film. Her fingers rest on the keys but do not press. Her eyes are open, looking forward, not at him. The expression is not anger. It is not grief. It is the absence of music — the refusal to continue the duet. The 750W Leko spot slowly dims over the 15 seconds — not a cut to black, but a fade to near-darkness. The light follows the music: as she stops, the light mourns. By second 15, her face is barely visible, a ghost in the dying spotlight. Camera holds absolutely static for the full 15 seconds. No movement. The audience must feel the silence as physical pressure.

**SORA-SC07-E — "The Empty Hall — Music Has Died"**
> Cinematic motion footage, 2.39:1 anamorphic. Wide shot low angle from floor, static. The conservatory. Two figures at the piano, barely visible in the dying spotlight. The hall is empty. The music has died. The space that the music filled is now void — a physical emptiness. The wood paneling that glowed with harmonic resonance is now dead wood. The empty seats are witnesses that have seen everything and can do nothing. As the spotlight finally dies, only moonlight through high windows remains — cool 5600K, blue-grey, indifferent. The two figures become silhouettes, then shadows, then barely visible. Camera holds static. The emptiness is the point. 12 seconds.

---

### 9.2 VEO PROMPTS — Scene 7

**VEO-SC07-A — "Empty Conservatory Night"**
> Photorealistic wide from balcony: empty conservatory at night. Woman at piano. Single 750W Leko spotlight warm 3000K. Hall is cathedral of wood and shadow. Empty seats disappear into darkness. Wood paneling glows faintly in spill. Exit signs cold green — institutional. Space too large for one person — loneliness as architecture. Spotlight creates natural vignette: woman and piano are island of warm light in sea of shadow. Moonlight through high windows cool 5600K. Hall's voice is silence. Photorealistic wood grain, seat texture, atmospheric depth. 10 seconds.

**VEO-SC07-B — "Four Hands Overhead"**
> Photorealistic overhead close-up: four hands on piano keyboard. Woman's hands on lower keys, certain. Man's hands hover above upper keys — courtship gesture, aligned but not touching, not playing. Black and white keys become chessboard of fingers. Her hands warm honey, grounded. His hands in shadow, suspended, unable. Hard spotlight from above creates stark shadows. Contrast between certainty and paralysis. Warm 3000K. No fill. Photorealistic skin texture, key detail. 8 seconds.

**VEO-SC07-C — "Omar Crying"**
> Photorealistic close-up eye-level: Egyptian man's face, tears streaming. Fingers rest on woman's hands on piano keys — first physical contact. First true tears in film. Operative mask destroyed. Face half-lit by piano spotlight spill — incomplete. No fill. Tears catch warm 3000K light, liquid gold on olive skin. Seven years of performance collapsing into truth. 85mm portrait compression. Background falls away. Photorealistic skin texture, tear detail, emotional destruction. 8 seconds.

**VEO-SC07-D — "Yasmin Stops — The Silence"**
> Photorealistic close-up eye-level: elegant woman's face as she stops playing piano. Fingers rest on keys. Eyes open, looking forward, not at him. Expression is absence — refusal to continue duet. Spotlight dying, face becoming ghost in near-darkness. Warm 3000K fading to shadow. Camera holds static. Silence as physical pressure. Photorealistic skin in dying light. 12 seconds.

**VEO-SC07-E — "Void Hall After Music"**
> Photorealistic wide low angle from floor: empty conservatory at night. Two figures at piano in dying spotlight. Hall is empty. Music has died. Space is physical void. Wood paneling dead. Empty seats helpless witnesses. Only moonlight through high windows remains — cool 5600K, blue-grey, indifferent. Figures become silhouettes, then shadows, then barely visible. The emptiness. Photorealistic atmospheric depth, wood detail, moonlight. 10 seconds.

---

### 9.3 RUNWAY GEN-3 PROMPTS — Scene 7

**RW-SC07-A — "Conservatory Tribunal"**
> Cinematic wide from balcony: empty conservatory at night. Woman at piano reading from file. Single 750W Leko tight spot warm 3000K. Hall is cathedral of wood and shadow. Empty seats disappear into darkness. Wood paneling glows faintly. Exit signs cold green — institutional, subliminal "exit." Spotlight creates natural vignette — island of warm light in sea of shadow. Loneliness as architecture. Moonlight through high windows cool 5600K. Camera locked-off. 10 seconds.

**RW-SC07-B — "Four Hands Chessboard"**
> Cinematic overhead close-up: four hands on piano keyboard. Woman's hands on lower keys, certain. Man's hands hover above upper keys — courtship gesture, aligned but not touching. Keys as chessboard. Her hands warm honey, grounded. His hands in shadow, suspended, unable. Hard overhead spotlight. Stark shadows. Contrast between certainty and paralysis — the marriage in one frame. Warm 3000K. No fill. Camera static. 8 seconds.

**RW-SC07-C — "Omar's Tears"**
> Cinematic close-up eye-level: man's face, tears streaming. He does not play. Fingers rest on hers — first contact. First true tears. The operative mask destroyed. Face half-lit by piano spotlight spill — incomplete. No fill. Tears catch warm 3000K light. Seven years collapsing into truth. Camera static. The face as final landscape. 8 seconds.

**RW-SC07-D — "The Stopped Note"**
> Cinematic close-up eye-level: woman stops playing. Fingers rest on keys. Eyes forward, not at him. Expression is absence — refusal to continue duet. Spotlight slowly dims over duration — light mourns the music. Face becomes ghost in dying light. Camera holds absolutely static. The silence is the shot. 12 seconds.

**RW-SC07-E — "Void Hall"**
> Cinematic wide low angle from floor: two figures at piano in dying light. Empty conservatory. Music has died. Space is physical void. Wood paneling dead. Empty seats helpless witnesses. Spotlight dies. Only moonlight through high windows remains — cool 5600K, blue-grey, indifferent. Figures become silhouettes, then shadows, then barely visible. The emptiness. Camera static. 10 seconds.

---

### 9.4 KLING PROMPTS — Scene 7

**KL-SC07-A — "Empty Conservatory Tribunal"**
> Detailed cinematic wide dynamics: from balcony, static. Empty conservatory at night. Yasmin at the piano. Single 750W Leko spotlight tight and warm 3000K. The hall is a cathedral of wood and shadow — rows of empty seats disappear into absolute darkness. Wood paneling glows faintly in the spotlight spill. Exit signs glow cold green — institutional, subliminal "exit" message. The space is too large for one person; the architecture itself creates loneliness. The single spotlight forms a natural vignette: Yasmin and the piano are an island of warm light in a sea of shadow. She reads from Omar's operational file. Her voice is clinical: "Subject is emotionally accessible, professionally isolated..." But her hands shake. Moonlight filters through high windows at a cool 5600K, distant and indifferent to the tribunal below. The hall's only voice is silence. Camera static, 12 seconds.

**KL-SC07-B — "Four Hands on Keyboard"**
> Detailed overhead close-up dynamics: four hands on the piano keyboard. Yasmin's hands on the lower keys, certain and grounded, playing the opening Nocturne from Scene 1 — the same music that opened the film, now returned as evidence in a tribunal. Omar's hands hover above the upper keys — the courtship gesture from their first meeting, hands not touching, but aligned. The geometry of almost-contact. The black and white keys become a chessboard, and the black and white fingers are pieces in a game that is already over. Her hands are warm honey in color, certain, grounded on the ivory. His hands are in shadow, suspended, unable to commit to pressing a single key. The 750W Leko spotlight from above creates hard, defining shadows. The contrast between her certainty and his paralysis is the entire marriage compressed into one frame. Warm 3000K. No fill. Camera static, 10 seconds.

**KL-SC07-C — "Omar Cries — Mask Destroyed"**
> Detailed close-up dynamics: eye-level, static. Omar's face. He does not play. He rests his fingers gently on top of Yasmin's on the piano keys — the first physical contact in this scene, the first true intimacy after so much performance. He is crying. These are the first true tears in the entire film — the operative who has performed as husband for seven years can no longer maintain the mask. His face is lit only by the piano spotlight spill — half-lit, half-shadow, incomplete. No fill light. The tears catch the warm 3000K light and become liquid gold streaming down his olive skin. His expression contains seven years of performance collapsing into raw truth, the impossibility of being both husband and spy, the recognition that he has destroyed the only real thing he ever had. The 85mm portrait compression makes the background fall away — only the face remains, and the tears, and the truth. Camera holds static, 8 seconds.

**KL-SC07-D — "Yasmin Stops — 15-Second Silence"**
> Detailed close-up dynamics: eye-level, absolutely static. Yasmin's face. She stops playing. The silence is the most devastating sound in the film. Her fingers rest on the keys but do not press. Her eyes are open, looking forward into the empty hall, not at him. The expression on her face is not anger. It is not grief. It is the absence of music — the refusal to continue the duet, the refusal to continue the performance of their marriage. The 750W Leko spotlight slowly dims over time — not a cut to black, but a gentle fade to near-darkness as if the light itself is mourning the music. As she stops, the light mourns. By the end of the duration, her face is barely visible, a ghost in the dying spotlight. The camera holds absolutely static for the full duration. No movement. The audience must feel the silence as physical pressure, as the weight of everything unspoken. 15 seconds.

**KL-SC07-E — "The Empty Hall — Music Has Died"**
> Detailed wide dynamics: low angle from floor, static. The conservatory. Two figures are at the piano, barely visible in the dying spotlight. The hall is empty. The music has died. The vast space that the music filled is now a physical void that presses against the viewer's chest. The wood paneling that glowed with harmonic resonance is now dead wood. The empty seats are witnesses that have seen everything and can do nothing to help. As the spotlight finally extinguishes, only moonlight through the high windows remains — cool 5600K, blue-grey, utterly indifferent to human grief. The two figures become silhouettes, then shadows, then barely visible shapes in the blue moonlight. The camera holds static. The emptiness is the entire point of the shot. 12 seconds.

---

### 9.5 MIDJOURNEY STILL FRAMES — Scene 7

**MJ-SC07-A — "Empty Conservatory Night"**
```
Empty conservatory at night, wide from balcony. Woman at piano. Single 750W Leko spotlight warm 3000K. Cathedral of wood and shadow. Empty seats disappear into darkness. Wood paneling glows faintly. Exit signs cold green. Spotlight vignette — island of warm light in sea of shadow. Moonlight through high windows cool 5600K. Loneliness as architecture. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC07-B — "Four Hands Chessboard"**
```
Overhead close-up: four hands on piano keyboard. Woman's hands on lower keys, certain. Man's hands hover above upper keys — aligned but not touching, not playing. Black and white keys as chessboard of fingers. Her hands warm honey, grounded. His hands in shadow, suspended, unable. Hard overhead spotlight. Stark shadows. Contrast between certainty and paralysis. Warm 3000K. No fill. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC07-C — "Omar Crying"**
```
Close-up eye-level: Egyptian man's face with tears streaming. Fingers rest on woman's hands on piano keys — first physical contact. First true tears. Operative mask destroyed. Face half-lit by piano spotlight spill — incomplete. No fill. Tears catch warm 3000K light, liquid gold on olive skin. Seven years of performance collapsing. 85mm portrait compression. Background falls away. Cinematic, photorealistic skin texture. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC07-D — "Yasmin Stops — Silence"**
```
Close-up eye-level: elegant woman's face as she stops playing piano. Fingers rest on keys. Eyes open, looking forward, not at him. Expression is absence — refusal to continue duet. Spotlight dying, face becoming ghost in near-darkness. Warm 3000K fading to shadow. Camera holds static. Silence as physical pressure. Cinematic, photorealistic skin in dying light. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC07-E — "Void Hall After Music"**
```
Wide low angle from floor: empty conservatory at night. Two figures at piano in dying spotlight. Hall is empty. Music has died. Space is physical void. Wood paneling dead. Empty seats helpless witnesses. Only moonlight through high windows remains — cool 5600K, blue-grey, indifferent. Figures become silhouettes, then shadows. The emptiness. Cinematic, photorealistic atmospheric depth. --ar 239:100 --style raw --v 6 --s 250
```

---

### 9.6 FLUX PROMPTS — Scene 7

**FLUX-SC07-A — "Empty Conservatory — Tribunal"**
> Cinematic widescreen shot from a balcony looking down at an empty conservatory at night. Yasmin is at the piano, illuminated by a single 750W Leko tight spotlight at 3000K warm tungsten. The hall is a cathedral of wood and shadow — rows of empty wooden seats disappear into absolute darkness beyond the spotlight's reach. The wood paneling glows faintly in the spill light. Cold green exit signs glow at the far edges — institutional, subliminal messages telling the audience to leave. The space is too large for one person; the architecture itself creates loneliness. The single spotlight forms a natural vignette: Yasmin and the piano are an island of warm light in a sea of shadow. She reads from Omar's operational file, her voice clinical but her hands shaking. Moonlight filters through high windows at a cool 5600K, distant and indifferent to the tribunal below. The hall's only voice is silence. Photorealistic wood grain, seat texture, atmospheric depth. Cinematic, anamorphic 2.39:1.

**FLUX-SC07-B — "Four Hands on Keyboard as Chessboard"**
> Cinematic overhead close-up looking straight down at four hands on a piano keyboard. Yasmin's hands are on the lower keys, certain and grounded, playing the opening Nocturne from Scene 1 — the same music that opened the film, now returned as evidence in a tribunal. Omar's hands hover above the upper keys in the courtship gesture from their first meeting, hands not touching the keys, just aligned but not playing, not touching, suspended in the air. The black and white keys become a chessboard, and the black and white fingers are pieces in a game that is already over. Her hands are warm honey in color, certain, grounded on the ivory. His hands are in shadow, suspended, unable to commit to pressing a single key. The 750W Leko spotlight from above creates hard, defining shadows. The contrast between her certainty and his paralysis is the entire marriage compressed into one frame. Warm 3000K. No fill light. Photorealistic skin texture, key detail, shadow precision. Cinematic, anamorphic.

**FLUX-SC07-C — "Omar Cries — The Mask Destroyed"**
> Cinematic close-up at eye level of Omar's face as he does not play. He rests his fingers gently on top of Yasmin's on the piano keys — the first physical contact in this scene, the first true intimacy after so much performance. He is crying. These are the first true tears in the entire film — the operative who has performed as husband for seven years can no longer maintain the mask. His face is lit only by the piano spotlight spill — half-lit, half-shadow, incomplete. No fill light. The tears catch the warm 3000K light and become liquid gold streaming down his olive skin. His expression contains seven years of performance collapsing into raw truth, the impossibility of being both husband and spy, the recognition that he has destroyed the only real thing he ever had. The 85mm portrait compression makes the background fall away — only the face remains, and the tears, and the truth. Photorealistic skin texture, tear detail, emotional destruction made visible. Cinematic, anamorphic 2.39:1.

**FLUX-SC07-D — "Yasmin Stops — The 15-Second Silence"**
> Cinematic close-up at eye level of Yasmin's face as she stops playing the piano. Her fingers rest on the keys but do not press. Her eyes are open, looking forward into the empty hall, not at him. The expression on her face is not anger. It is not grief. It is the absence of music — the refusal to continue the duet, the refusal to continue the performance of their marriage. The 750W Leko spotlight slowly dims over time — not a cut to black, but a gentle fade to near-darkness as if the light itself is mourning the music. As she stops, the light mourns. By the end of the duration, her face is barely visible, a ghost in the dying spotlight. The camera holds absolutely static. The audience must feel the silence as physical pressure, as the weight of everything unspoken. Photorealistic skin in dying light, the subtle shift from illuminated to shadow. Cinematic, anamorphic 2.39:1.

**FLUX-SC07-E — "The Empty Hall — Music Has Died"**
> Cinematic wide shot from a low angle near the floor looking up at the conservatory. Two figures are at the piano, barely visible in the dying spotlight. The hall is empty. The music has died. The vast space that the music filled is now a physical void that presses against the viewer's chest. The wood paneling that glowed with harmonic resonance is now dead wood. The empty seats are witnesses that have seen everything and can do nothing to help. As the spotlight finally extinguishes, only moonlight through the high windows remains — cool 5600K, blue-grey, utterly indifferent to human grief. The two figures become silhouettes, then shadows, then barely visible shapes in the blue moonlight. The emptiness is the entire point of the shot. The music has died, and the hall mourns in silence. Photorealistic wood detail, atmospheric depth, moonlight precision. Cinematic, anamorphic 2.39:1.

---

## 10. SCENE 8: THE UNRESOLVED NOTE (100:00–105:00)
### "Final Scene — One Note, Unresolved, Film Fades on Harmonic Tension"
**Palette:** Pale Sage `#9DC183` / Dawn Grey / Soft Silver → Natural light only
**Aspect Ratio Note:** 2.39:1 slowly narrows to 1.85:1 over final 15 seconds
**Emotional Beat:** Ambiguous Peace → The Unresolved Note Hangs in Air
**Key Shots:** 5 prompts per platform

---

### 10.1 SORA PROMPTS — Scene 8

**SORA-SC08-A — "New Apartment Morning"**
> Cinematic motion footage, 2.39:1 anamorphic (beginning slow narrowing to 1.85:1). Wide shot eye-level, static. New apartment. Different neighborhood. Plants everywhere — green life reclaiming space. Morning light through muslin curtains — natural daylight only, 5600K, diffused and honest. Yasmin at a different piano — smaller, older, real. Not the concert Steinway. A domestic upright, scarred, loved. She improvises. No sheet music. Raw, unstructured, honest. Natural light only. No artificial lights on. The apartment breathes — air, light, life. She is lit by the world, not by performance. Pale sage `#9DC183` in the plants. Dawn grey light on walls. Soft silver on metal fixtures. Camera static, 12 seconds. The frame is already beginning its slow narrowing.

**SORA-SC08-B — "Yasmin Improvising — The Music of the Self"**
> Cinematic motion footage, aspect ratio slowly narrowing. Medium shot eye-level, slow gentle dolly in. Yasmin improvising at the upright piano. No sheet music. Her face: concentrated, alive, sad, present — all emotions held simultaneously. Natural daylight 5600K through window, soft, diffused. Her face in natural light — every line visible, every line accepted. She is not performing. She is being. The music is not Chopin. It is her own voice, finding itself. Slow dolly in over 15 seconds. The closer the camera gets, the narrower the frame becomes. The intimacy increases as the world decreases. Pale sage `#9DC183` and dawn grey. Natural light only. 15 seconds.

**SORA-SC08-C — "Hands — New Language"**
> Cinematic motion footage, aspect ratio narrowing. Extreme close-up eye-level, static. Her hands. Different rhythm from all previous scenes. Searching, finding, losing, finding again. The hands have learned a new language — improvisation as emotional truth. The upright piano keys are more worn, more yellowed than the concert grand's pristine ivory. Her fingers press with uncertainty and discovery, not with the certainty of performance. Natural daylight 5600K. No artificial light. The hands are the same hands, but they are learning to speak differently. Static camera, 10 seconds. The frame continues to narrow.

**SORA-SC08-D — "Letter and Photograph"**
> Cinematic motion footage, aspect ratio approaching 1.85:1. Close-up insert, static. The letter. Omar's handwriting on aged paper. "Thank you for the architecture. — O." The photograph beneath: Omar, somewhere new, older, standing in front of a building. He looks at peace. The handwriting is the same handwriting from the note in Scene 2 ("Pick up milk") — the same man, the same hand, a different life. Natural daylight falls on the paper. Pale sage `#9DC183` and soft silver. The last word — "architecture" as their shared language, now relinquished. Camera static, 6 seconds.

**SORA-SC08-E — "Final Pull Back — City to River to World"**
> Cinematic motion footage, aspect ratio now 1.85:1 and holding. Wide shot through window, exterior, slow pull back. Yasmin at the window. Cairo at dusk. The call to prayer begins — the azan as Cairo's eternal voice, indifferent to all private tragedies, sounding five times a day through her marriage, her betrayal, her destruction, her recovery. It will sound after the film ends. The city endures. Camera slowly pulls back from the window: Yasmin's figure becomes small, then the apartment becomes small, then the building, then the street, then the neighborhood, then the Nile appears — the dark ribbon that has witnessed all of Cairo's love and betrayal for millennia. The city breathes. The note she played continues over the image, unresolved, hanging in the air as the image fades not to black but to very dark grey `#1A1A1A`. The harmonic tension continues in the audience's ear. Camera slow pull back, 20 seconds. Final frame.

---

### 10.2 VEO PROMPTS — Scene 8

**VEO-SC08-A — "New Apartment Morning"**
> Photorealistic wide: new apartment, different neighborhood. Plants everywhere — green life reclaiming space. Morning light through muslin curtains. Natural daylight only 5600K, diffused, honest. Woman at smaller older upright piano. She improvises. No sheet music. Raw, unstructured, honest. No artificial lights on. Apartment breathes — air, light, life. She is lit by the world, not by performance. Pale sage `#9DC183` in plants. Dawn grey light on walls. Soft silver on fixtures. Cinematic, photorealistic natural light. 10 seconds.

**VEO-SC08-B — "Improvising Face"**
> Photorealistic medium: woman improvising at upright piano. No sheet music. Face concentrated, alive, sad, present — all emotions held simultaneously. Natural daylight 5600K through window, soft diffused. Every line visible, every line accepted. Not performing. Being. Music is not Chopin. Her own voice finding itself. Cinematic, photorealistic skin in natural light. 12 seconds.

**VEO-SC08-C — "Hands New Language"**
> Photorealistic extreme close-up: pianist hands on worn upright piano keys. Different rhythm — searching, finding, losing, finding again. Worn yellowed keys — not pristine concert ivory. Fingers press with uncertainty and discovery. Natural daylight 5600K only. Same hands learning to speak differently. Cinematic, photorealistic. 8 seconds.

**VEO-SC08-D — "The Letter"**
> Photorealistic close-up insert: aged paper with handwriting. "Thank you for the architecture. — O." Photograph beneath: older man, building, at peace. Same handwriting as earlier domestic note — same man, different life. Natural daylight. Pale sage and soft silver. Last word. Cinematic, photorealistic paper texture, ink detail. 6 seconds.

**VEO-SC08-E — "Final Pull Back — City Endures"**
> Photorealistic wide through window, slow pull back: woman at window, Cairo at dusk. Call to prayer beginning — azan as eternal voice, indifferent to private tragedies. Camera pulls back — figure small, apartment small, building, street, neighborhood, Nile appears. City breathes. Unresolved note over image. Fades to very dark grey `#1A1A1A` — not black. Harmonic tension. Cinematic, photorealistic cityscape, dusk light, atmospheric depth. 20 seconds.

---

### 10.3 RUNWAY GEN-3 PROMPTS — Scene 8

**RW-SC08-A — "New Apartment Morning"**
> Cinematic wide eye-level: new apartment, different neighborhood. Plants reclaiming space. Morning light through muslin curtains. Natural daylight 5600K only. Woman at smaller upright piano, improvising. No sheet music. Raw, honest. No artificial lights on. Apartment breathes. She is lit by the world. Pale sage `#9DC183`. Dawn grey. Soft silver. Frame beginning slow narrowing. Camera locked-off. 10 seconds.

**RW-SC08-B — "Improvising Face"**
> Cinematic medium eye-level, slow dolly in: woman improvising. Face concentrated, alive, sad, present. Natural daylight 5600K, soft diffused. Every line visible, every line accepted. Not performing — being. Her own voice finding itself. Closer camera gets, narrower frame becomes. Intimacy increases as world decreases. Pale sage and dawn grey. Camera slow gentle dolly in. 12 seconds.

**RW-SC08-C — "Hands New Language"**
> Cinematic extreme close-up: hands on upright piano keys. Different rhythm — searching, finding, losing, finding. Worn yellowed keys. Fingers press with uncertainty and discovery. Natural daylight 5600K. Same hands learning to speak differently. Camera static. 8 seconds.

**RW-SC08-D — "The Letter"**
> Cinematic insert close-up: aged paper with handwriting. "Thank you for the architecture. — O." Photo beneath: older man, building, at peace. Same handwriting as earlier note — same man, different life. Natural daylight. Pale sage and soft silver. Last word. Camera static. 6 seconds.

**RW-SC08-E — "Final Pull Back"**
> Cinematic wide through window, slow pull back: woman at window. Cairo at dusk. Call to prayer beginning. Camera pulls back — figure small, apartment small, building, street, neighborhood, Nile appears. City breathes. Unresolved note over image. Fades to dark grey `#1A1A1A` — not black. Harmonic tension. Camera slow pull back. 20 seconds. Final frame.

---

### 10.4 KLING PROMPTS — Scene 8

**KL-SC08-A — "New Apartment Morning"**
> Detailed cinematic wide dynamics: eye-level, static. New apartment. Different neighborhood. Plants everywhere — green life reclaiming space after destruction. Morning light through muslin curtains: natural daylight only, 5600K, diffused and honest. Yasmin at a different piano — smaller, older, real. A domestic upright, scarred and loved, not the pristine concert Steinway. She improvises. No sheet music. Raw, unstructured, honest music — the music of the self, not of performance. Natural light only. No artificial lights on in the apartment. The apartment breathes — air, light, life continuing. She is lit by the world, not by performance spotlight. Pale sage `#9DC183` in the plants. Dawn grey light on walls. Soft silver on metal fixtures. The aspect ratio is 2.39:1 but already beginning its slow, imperceptible narrowing toward 1.85:1. Camera static, 10 seconds.

**KL-SC08-B — "Improvising — The Music of Being"**
> Detailed medium dynamics: eye-level, slow gentle dolly in. Yasmin improvising at the upright piano. No sheet music on the stand. Her face: concentrated, alive, sad, present — all emotions held simultaneously without performance. Natural daylight 5600K through the window, soft, diffused, honest. Her face in natural light — every line visible, every line accepted. She is not performing. She is simply being. The music is not Chopin — it is her own voice, finding itself after silence. The slow dolly in over 12 seconds brings the camera closer to her face. The closer the camera gets, the more the frame narrows. The intimacy increases as the world outside decreases. Pale sage `#9DC183` and dawn grey. Natural light only. 12 seconds.

**KL-SC08-C — "Hands — New Language"**
> Detailed extreme close-up dynamics: eye-level, static. Her hands. Different rhythm from all previous scenes in the film. Searching, finding, losing, finding again. The hands have learned a new language — improvisation as emotional truth. The upright piano keys are more worn, more yellowed than the concert grand's pristine ivory — real, used, loved. Her fingers press the keys with uncertainty and discovery, not with the trained certainty of a performer. Natural daylight 5600K. No artificial light. The hands are the same hands that played Chopin, smashed a piano, confronted a liar — but now they are learning to speak differently. Static camera, 8 seconds.

**KL-SC08-D — "Letter and Photograph"**
> Detailed insert dynamics: close-up, static. The letter. Omar's handwriting on aged, textured paper. "Thank you for the architecture. — O." Beneath the letter is a photograph: Omar, somewhere new, looking older, standing in front of a building he has built or given away. He looks at peace. The handwriting is the same handwriting from the domestic note in Scene 2 ("Pick up milk") — the same man, the same hand, a different life. Natural daylight falls on the paper. Pale sage `#9DC183` and soft silver tones. The last word — "architecture" — was their shared language, the metaphor for everything they built together and everything that collapsed. Now it is relinquished, now it is understood. Camera static, 6 seconds.

**KL-SC08-E — "Final Pull Back — City Endures"**
> Detailed wide dynamics: through window, exterior, slow pull back. Yasmin at the window. Cairo at dusk. The call to prayer begins — the azan as Cairo's eternal voice, indifferent to all private tragedies, having sounded five times a day through her entire marriage, her betrayal, her destruction, and her recovery. It will continue to sound after the film ends. The city endures. The camera slowly pulls back from the window: Yasmin's figure becomes small, then the apartment becomes small, then the building, then the street, then the neighborhood, and finally the dark ribbon of the Nile appears — the river that has witnessed all of Cairo's love and betrayal for millennia. The city breathes. The note she played on the piano continues over the image, unresolved, hanging in the air as the image fades not to black but to a very dark grey `#1A1A1A`, leaving the screen "almost" dark. The harmonic tension continues in the audience's ear after the image is gone. The aspect ratio is now fully 1.85:1. Camera slow pull back, 20 seconds. Final frame of the film.

---

### 10.5 MIDJOURNEY STILL FRAMES — Scene 8

**MJ-SC08-A — "New Apartment Morning"**
```
New apartment, different neighborhood. Plants everywhere — green life reclaiming space. Morning light through muslin curtains. Natural daylight 5600K only, diffused. Woman at smaller older upright piano, improvising. No sheet music. Raw, unstructured, honest. No artificial lights on. Apartment breathes — air, light, life. Pale sage `#9DC183` in plants. Dawn grey light on walls. Soft silver fixtures. Cinematic, photorealistic natural light. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC08-B — "Improvising Face"**
```
Medium shot: woman improvising at upright piano. Face concentrated, alive, sad, present — all emotions held simultaneously. Natural daylight 5600K through window, soft diffused. Every line visible, every line accepted. Not performing, being. Her own voice finding itself. Pale sage and dawn grey. Cinematic, photorealistic skin in natural light. --ar 239:100 --style raw --v 6 --s 250
```

**MJ-SC08-C — "Hands New Language"**
```
Extreme close-up: pianist hands on worn upright piano keys. Different rhythm — searching, finding, losing, finding again. Worn yellowed keys — not pristine concert ivory. Fingers press with uncertainty and discovery. Natural daylight 5600K only. Same hands learning to speak differently. Cinematic, photorealistic. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC08-D — "The Letter"**
```
Close-up insert: aged paper with handwriting. "Thank you for the architecture. — O." Photograph beneath: older man in front of building, at peace. Same handwriting as earlier domestic note — same man, different life. Natural daylight. Pale sage and soft silver. Last word. Cinematic, photorealistic paper texture, ink detail. --ar 239:100 --style raw --v 6 --s 200
```

**MJ-SC08-E — "Final Pull Back — City at Dusk"**
```
Wide through window: woman at window, Cairo at dusk. Call to prayer beginning. Camera perspective pulling back — figure small, apartment small, building, street, neighborhood, Nile appears. City breathes. Unresolved note over image. Fades to dark grey `#1A1A1A` — not black. Harmonic tension. Pale sage and dusk grey. Cinematic, photorealistic cityscape, atmospheric depth. --ar 239:100 --style raw --v 6 --s 250
```

---

### 10.6 FLUX PROMPTS — Scene 8

**FLUX-SC08-A — "New Apartment Morning"**
> Cinematic widescreen establishing shot of a new apartment in a different Cairo neighborhood. Plants are everywhere — green life reclaiming space after destruction, pale sage `#9DC183` leaves reaching toward morning light. The morning light filters through muslin curtains — natural daylight only at 5600K, diffused and honest. No artificial lights are on in the apartment. Yasmin is at a different piano — a smaller, older, real domestic upright, scarred and loved, not the pristine concert Steinway from Scene 1. She improvises. There is no sheet music. The music is raw, unstructured, honest — the sound of a woman being rather than performing. The apartment breathes with air, light, and continued life. She is lit by the world, not by a performance spotlight. Dawn grey light falls on the walls. Soft silver tones on metal fixtures. The aspect ratio is 2.39:1 but has already begun its slow, almost imperceptible narrowing toward 1.85:1. Photorealistic, cinematic, anamorphic.

**FLUX-SC08-B — "Improvising — The Music of the Self"**
> Cinematic medium shot at eye level with a slow gentle dolly in toward Yasmin as she improvises at the upright piano. No sheet music sits on the stand. Her face shows concentration, aliveness, sadness, and presence — all emotions held simultaneously without the need to perform any of them. Natural daylight at 5600K streams through the window, soft and diffused, honest. Her face is rendered in natural light where every line is visible and every line is accepted. She is not performing. She is simply being. The music is not Chopin — it is her own voice, finding itself after so much silence. The closer the camera moves, the more the frame narrows, increasing intimacy as the world outside decreases. Pale sage `#9DC183` and dawn grey color the scene. Natural light only. Photorealistic skin texture in honest daylight. Cinematic, anamorphic.

**FLUX-SC08-C — "Hands — A New Language"**
> Cinematic extreme close-up at eye level of Yasmin's hands on the upright piano keys. The rhythm is entirely different from every previous scene in the film — searching, finding, losing, finding again. The hands have learned a new language: improvisation as emotional truth. The upright piano keys are more worn and more yellowed than the concert grand's pristine ivory — they are real, used, loved. Her fingers press the keys with uncertainty and discovery, not with the trained certainty of a performer. Natural daylight at 5600K is the only light source. These are the same hands that played Chopin, smashed a piano in rage, confronted a liar, and held a file of evidence — but now they are learning to speak differently, to tell a new story. Photorealistic skin texture, key detail, natural light. Cinematic, anamorphic.

**FLUX-SC08-D — "The Letter — Architecture Relinquished"**
> Cinematic close-up insert of a letter on aged, textured paper with Omar's handwriting: "Thank you for the architecture. — O." Beneath the letter is a photograph: Omar, somewhere new, looking older, standing in front of a building. He looks at peace. The handwriting is the same handwriting from the domestic note in Scene 2 ("Pick up milk") — the same man, the same hand, living a different life now. Natural daylight falls across the paper and photograph. Pale sage `#9DC183` and soft silver tones color the image. The last word — "architecture" — was their shared language, the metaphor for everything they built together and everything that collapsed. Now it is relinquished, now it is understood. Photorealistic paper texture, ink detail, photograph grain. Cinematic, anamorphic.

**FLUX-SC08-E — "Final Pull Back — The City Endures"**
> Cinematic wide shot seen through a window, with the camera executing a slow pull back from the interior to the exterior. Yasmin stands at the window. Cairo spreads before her at dusk — the city that has witnessed all her love and betrayal, all her destruction and recovery. The call to prayer begins, the azan rising from minarets across the city — Cairo's eternal voice, indifferent to all private tragedies, having sounded five times a day through her entire marriage, her betrayal, her destruction, and her recovery. It will continue to sound after the film ends. The city endures. The camera slowly pulls back: Yasmin's figure becomes small, then the apartment becomes small, then the building, then the street, then the neighborhood, and finally the dark ribbon of the Nile appears — the river that has witnessed all of Cairo's love and betrayal for millennia. The city breathes. The note she played on the piano continues over the image, unresolved, hanging in the air as the image fades not to black but to a very dark grey `#1A1A1A`, leaving the screen "almost" dark. The harmonic tension continues in the audience's ear after the image is gone. The aspect ratio is now fully 1.85:1. Photorealistic cityscape, dusk light, atmospheric depth, the eternal Cairo. The final frame of the film.

---

## 11. NEGATIVE PROMPT LIBRARY

### 11.1 Universal Negative Prompts (apply per platform)

**For ALL image/video prompts, append or embed:**

> **Avoid:** cartoon, anime, illustration, painting, sketch, 3D render, CGI, video game, plastic skin, oversaturated colors, oversharpened details, artificial smoothness, deformed hands, extra fingers, mutated hands, poorly drawn hands, missing fingers, fused fingers, too many fingers, malformed limbs, missing arms, missing legs, extra arms, extra legs, poorly drawn face, mutation, mutated, extra nipples, deformed iris, deformed pupils, semi-realistic eyes, bad anatomy, bad proportions, cross-eyed, blurry, out of focus, duplicate, watermark, signature, text, logo, cropped, worst quality, low quality, normal quality, jpeg artifacts, chromatic aberration, scanlines, excessive film grain, overexposed, underexposed.

### 11.2 Scene-Specific Negative Modifiers

| Scene | Additional Negatives |
|-------|---------------------|
| 1 — Nocturne | cold sterile lighting, modern LED concert lighting, fluorescent, overexposed spotlight, audience visible in sharp focus |
| 2 — Drawer | bright cheerful morning, clean pristine bedroom, cartoon phone, smartphone brand logos, happy expression, warm amber maintained |
| 3 — Follow | warm café lighting, romantic café atmosphere, oversaturated teal, Nour looking friendly, surveillance photos in color |
| 4 — Safe House | warm cozy apartment, bright lighting, Omar looking happy, clean modern interior, no dust, no decay, fluorescent buzz visible |
| 5 — Raindrop | dry weather, sunny day, warm interior maintained, friendly visitors, Nour smiling, Yasmin looking scared (not composed) |
| 6 — Destruction | intact piano, clean apartment, no debris, no dust, Yasmin looking calm, slow-motion too smooth (needs violent energy), no blood |
| 7 — Duology | bright concert hall lighting, full audience, Yasmin looking angry, Omar not crying, music continuing, spotlight bright |
| 8 — Unresolved | artificial lights on, bright artificial lighting, Yasmin looking happy, modern smartphone letter, no plants, dark black fade |

### 11.3 Platform-Specific Negative Prompt Engineering

**Midjourney:** Use `--no` parameter for strongest negatives:
```
--no cartoon, anime, illustration, 3D render, deformed hands, extra fingers, plastic skin, oversaturated, text, watermark, logo, cropped, low quality
```

**Stable Diffusion / ComfyUI:** Weighted negative tokens:
```
(3D render:1.3), (cartoon:1.2), (anime:1.2), (deformed hands:1.4), (extra fingers:1.3), (plastic skin:1.2), (oversaturated:1.1), (text:1.2), (watermark:1.2), (low quality:1.2), (blurry:1.2), (chromatic aberration:1.1), (scanlines:1.1)
```

**Flux:** Natural language negative:
> *"Avoid cartoon, anime, illustration, or 3D rendered appearance. No deformed or extra fingers. No plastic or overly smooth skin texture. No text, watermarks, logos, or signatures. No oversaturated or unnatural colors. No low quality, blur, or chromatic aberration."*

---

## 12. TEMPORAL VIDEO SEQUENCE PROMPTS

### 12.1 Shot-to-Shot Transition Prompts

| Transition | Prompt Language | Platforms |
|------------|-----------------|-----------|
| **SC-01 → SC-02: Hard Cut** | "Abrupt cut from warm concert hall to cool morning bedroom. No dissolve. The warmth ends, the suspicion begins." | Sora, Veo, Kling |
| **SC-02 → SC-03: Dissolve** | "Slow dissolve from hands on piano keys to hands holding coffee cup. Piano practice bleeds into café surveillance. Time passes in the dissolve." | Sora, Veo, Runway |
| **SC-03 → SC-04: Fade to Black → Fade from Black** | "Fade to black for 3 seconds. Hold. Fade from black into safe house door. The midpoint demands darkness." | Sora, Veo, Kling |
| **SC-04 → SC-05: Sound Bridge** | "Door slam echoes, transforms into first note of Raindrop Prelude. Sound bridge: door → piano note → rain begins." | Sora, Veo, Runway |
| **SC-05 → SC-06: Hard Cut** | "Violent hard cut from operational confrontation to pre-destruction stillness. No sound bridge. Thrown from precision to chaos." | Sora, Veo, Kling |
| **SC-06 → SC-07: Long Fade to Black** | "Fade to black. Hold for 5 seconds (longest in film). Fade from black into empty conservatory. The void before judgment." | Sora, Veo, Kling |
| **SC-07 → SC-08: Slow Dissolve** | "Very slow 4-second dissolve from silence after duet to morning light of new apartment. Three months pass in a single breath." | Sora, Veo, Runway |

### 12.2 Camera Movement Continuity

**Across all platforms, maintain these movement rules:**

| Act | Movement Style | Prompt Language |
|-----|---------------|-----------------|
| Act I (Scenes 1–3) | Static / Gentle dolly | "Camera locked-off, static, long takes. When moving: slow dolly in only, gentle, reverent." |
| Act II-A (Scene 3 follow) | Surveillance grammar | "Distant static shots, slight handheld sway, reframing. The camera checks things — a face, a phone, a shadow." |
| Act II-B (Scenes 4–5) | Walk-through / Dutch | "Slow walk-through POV, occasional Dutch tilt at moments of vertigo. Camera becomes unstable." |
| Act III (Scenes 6–7) | Handheld / Static extremes | "Expressive handheld for destruction (not documentary-shaky but emotional). Then absolutely static for silence." |
| Resolution (Scene 8) | Slow pull back | "Slow gentle pull back only. The world expands. The frame narrows. The camera retreats." |

### 12.3 Action Flow Descriptions

**For video platforms, embed continuity notes:**

> *"Maintain character hand continuity: Yasmin's left hand always wears the silver antique watch in all scenes. Omar's watch changes from thin gold (husband mode) to thick tactical (operative mode) and back."*

> *"Maintain wardrobe color continuity: Yasmin's amber gown in Scene 1 reappears as memory/flashback only. Her cream robe in Scene 2 never reappears. Her operational black clothing in Scenes 4–5 transitions to grey dress in Scene 5."*

> *"Maintain piano continuity: The concert Steinway is black and pristine in Scenes 1, 5, 7. It is destroyed in Scene 6 and never reappears. The upright piano in Scene 8 is older, yellowed keys, scarred wood — completely different instrument."*

---

## 13. PROMPT TESTING & VARIATION MATRIX

### 13.1 A/B Prompt Variations for Key Shots

| Shot ID | Variation A (Quality) | Variation B (Speed/Fallback) | Platform Recommendation |
|---------|----------------------|---------------------------|------------------------|
| SC-01 Hands on Keys | 100mm Macro, f/2.0, extreme detail | Simplified: "close-up pianist hands on keys, warm spotlight" | A: Midjourney/Flux. B: Runway/Sora |
| SC-02 Phone Screen | Full UI detail, encrypted text, map pins | Simplified: "phone screen glows blue, woman stares" | A: Flux/Midjourney. B: Veo/Sora |
| SC-04 Mirror + Surveillance | Full wall of photos, practical mirror | Simplified: "woman in mirror with photos behind" | A: Kling/Flux. B: Runway/Veo |
| SC-06 Piano Smash | Full debris physics, 48fps slow-mo | Simplified: "woman destroys piano, wood breaks" | A: Sora/Kling. B: Veo/Runway |
| SC-07 15-Sec Silence | Spotlight dimming, skin in dying light | Simplified: "woman stops playing, light fades" | A: Sora/Veo. B: Runway/Kling |
| SC-08 Final Pull Back | Full city render, Nile visible, dusk | Simplified: "pull back from window to city" | A: Sora/Kling. B: Veo/Runway |

### 13.2 Quality vs. Speed Trade-off Options

| Platform | Max Quality Settings | Fast Fallback Settings |
|----------|---------------------|----------------------|
| **Sora** | Full cinematic description, 10–20s duration, detailed motion | Shorten to 5–8s, reduce motion description, focus on single action |
| **Veo** | Full lighting specification, photorealistic skin, natural light emphasis | Reduce lighting detail, use "cinematic footage" shorthand |
| **Runway** | Full motion intensity, camera behavior, style references | Reduce to stylized description, focus on mood keywords |
| **Kling** | Full physical dynamics, detailed action choreography | Simplify to "cinematic scene setup" with basic action |
| **Midjourney** | `--v 6 --style raw --s 250` with full parameter set | `--v 6 --s 100` or `--style expressive` for faster iteration |
| **Flux** | Full natural language cinematic description with all tokens | Reduce to core visual description, remove director references |

### 13.3 Upscaling and Refinement Prompts

**For Midjourney concept art refinement:**
```
[Base prompt] --ar 239:100 --v 6 --style raw --s 250 --q 2
Upscale subtle: Add "extreme detail, 8K texture, photorealistic skin pore detail, fabric micro-texture"
Upscale creative: Add "dramatic lighting enhancement, atmospheric haze, lens flare"
```

**For Flux high-fidelity output:**
> *"Render at maximum resolution. Photorealistic skin pore detail. Individual fabric thread visible. Natural subsurface scattering on skin. Accurate caustics and reflections. Film grain: Kodak Vision3 5219, fine grade. No digital smoothing."*

**For video platform refinement (Sora/Veo):**
> *"Extend duration by 2 seconds. Add subtle camera breathing. Enhance motion blur on fast elements. Refine skin texture in close-ups."*

---

## APPENDIX A: MASTER TOKEN QUICK REFERENCE

### Color Hex Map (embed in prompts)
| Color | Hex | Scene Usage |
|-------|-----|-------------|
| Warm Amber | `#D4A574` | Scenes 1–2, Act I warmth |
| Dusty Violet | `#7B6B8D` | Scenes 2, 4, betrayal color |
| Sea Cyan | `#4A9B9B` | Scene 3, surveillance coolness |
| Slate Grey | `#708090` | Scenes 5–6, storm, destruction |
| Storm Blue | `#4A6B8D` | Scenes 5–6, cold grief |
| Bruised Rose | `#9B6B7B` | Scenes 4, 7, emotional pain |
| Emergency Red | `#8B0000` | Scene 6, destruction, danger |
| Pale Sage | `#9DC183` | Scene 8, new growth, resolution |
| Deep Brown Shadow | `#5C4033` | Act I shadow tones |
| Soft Gold Memory | `#D4C4A8` | Scene 8, warm intrusion |

### Lighting Temperature Map
| Kelvin | Quality | Scene Usage |
|--------|---------|-------------|
| 2200K | Sodium vapor | Scene 3 streetlights |
| 2600K–2800K | Tungsten warm | Scenes 1, 2, 5, 6, 7 interior |
| 3000K | Leko spot | Scene 7 piano |
| 3200K | Stage/house warm | Scene 1 concert |
| 4100K–4500K | Fluorescent/LED | Scene 4 safe house, Scene 2 phone |
| 4500K–4800K | Morning daylight | Scene 2 morning |
| 5000K | Cool LED | Scene 4 desk lamp |
| 5600K | Daylight/moonlight | Scenes 3, 4, 5, 8 exterior |
| 6500K | Screen/digital blue | Scenes 2, 3 phone screens |

### Director/Cinematographer Reference Quick Embed
| Reference | Embed Phrase |
|-----------|-------------|
| Wong Kar-wai | *"Wong Kar-wai In the Mood for Love color saturation, frame-within-frame, unspoken longing"* |
| Roger Deakins | *"Roger Deakins anamorphic cinematography, moral ambiguity through frame width, oval bokeh"* |
| Hoyte van Hoytema | *"Hoyte van Hoytema cold paranoia, institutional flatness, information at margins"* |
| Seamus McGarvey | *"Seamus McGarvey long-take emotional overwhelming, color as trauma"* |
| Christopher Doyle | *"Christopher Doyle 50mm close-ups as emotional penetration, saturated skin tones"* |
| Emmanuel Lubezki | *"Emmanuel Lubezki expressive handheld, nature as oppressive architecture"* |

---

## APPENDIX B: ARABIC PROMPT TRANSLATIONS

For platforms supporting multilingual input or for Arabic-speaking creative teams:

### Scene 1 Arabic Prompt Core
> *"قاعة أوبرا القاهرة، لقطة واسعة جداً من حفرة الأوركسترا، إضاءة كهرمانية دافئة 3200K، بيانو كونسرت Steinway أسود لامع تحت بؤرة ضوء واحدة، مقاعد مخملية بورجوندي، شandeliers كريستال، بنية بيل إيبوك، نسبة عرض 2.39:1 سينمائية، حبكة أنامورفيك"*

### Scene 6 Arabic Prompt Core
> *"امرأة مصرية أنيقة تدمر بيانوها بيديها، خشب يتشظى، أوتار تتقطع، حركة بطيئة 48 إطاراً، إضاءة حمراء طارئة `#8B0000`، رمادي `#708090`، دمار جميل، سينمائي، واقعي فوتوغرافي"*

### Scene 8 Arabic Prompt Core
> *"شقة جديدة، نباتات خضراء، إضاءة طبيعية صباحية 5600K فقط، بيانو عادي قديم، امرأة تعزف بدون موسيقى مكتوبة، موسيقى ارتجالية صادقة، القاهرة عند الغسق، الأذان، انسحاب بطيء للكاميرا، لقطة أخيرة"*

---

**END OF AI PROMPT DIRECTOR — MASTER PROMPT LIBRARY**

*Document Version: 1.0*
*Date: 2026-05-25*
*Production: حب وخيانة / Love and Betrayal / The Garden of Broken Mirrors*
*Pipeline Stage: Phase 3 — From Storyboard To Vision*
*Next Stage: Phase 4 — AI Asset Generation & Assembly*
