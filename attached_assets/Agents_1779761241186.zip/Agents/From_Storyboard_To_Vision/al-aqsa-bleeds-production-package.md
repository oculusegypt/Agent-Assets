# الأقصى ينزف — Al-Aqsa Bleeds
## Complete Pre-Production Package
### Hollywood-Grade Cinematic Pipeline | From Storyboard To Vision
**Runtime:** 5:00 minutes | **Format:** Short Film — Spiritual Existential Drama / Magic Realism
**Date:** 2026-05-25

---

## LOGLINE / اللوغلاين
> في قلب القدس، تتحول الأقصى إلى كائن حيّ ينزف دمًا، ويكتشف حارسها الشيخ سليم أن نزيف الحجر هو صرخة الروح، وآخر فرصة لإيقاظ ضمير العالم قبل أن يصمت الأذان إلى الأبد.

> *In the heart of Jerusalem, the Al-Aqsa Mosque transforms into a living, breathing being that bleeds stone-blood, and its aging guardian, Sheikh Salim, discovers that the bleeding stones are the soul's final scream—a last chance to awaken the world's conscience before the call to prayer falls silent forever.*

---

## SYNOPSIS / الملخص الدرامي
تدور أحداث الفيلم في القدس، حيث يعيش الشيخ سليم (70 عامًا)، حارس الأقصى منذ أربعين عامًا. في ليلة عاصفة، يكتشف سليم أن حجارة المسجد قد بدأت "تنزف"—تسيل منها سائل أحمر داكن يشبه الدم، ينبض بإيقاع قلب بشري. يرى سليم ذلك رؤيةً: الأقصى كائن حيّ يتألم.

مع انتشار الخبر، يتدفق الناس—مصورون، صحفيون، سيّاح، جنود. البعض يؤمن، والبعض يستهزئ، والبعض يخاف. تتصاعد التوتر بين الإيمان والتشكيك، بين الروحانية والسياسة. تصل ذروة الأحداث عندما يقرّر الجنود اقتحام المسجد لـ "فحص الحجارة"، فيعتصم سليم وحفيدته نور (12 عامًا) على باب الأقصى، مصدّين بأجسادهم.

في المشهد الأخير، يقع نور على الحجارة النازفة وتضع يدها عليها. ينبض الحجر تحت راحتها. يعلو الأذان. تقفز عدسة الكاميرا إلى السماء—فتجد الأقصى كقلب عملاق ينبض فوق القدس، يبثّ ضوءًا ذهبيًّا يغطّي المدينة بأكملها. ينتهي الفيلم بسؤال بصري واحد: هل يكفي النبض لإيقاظ الضمير؟

---

## THREE-ACT STRUCTURE (5:00 Minutes)

### ACT I — الاستعداد (00:00 – 01:15)
- **00:00–00:15** | Opening Image: فجر القدس، أذان مكتوم، سليم يمشي بين أروقة الأقصى
- **00:15–00:25** | Theme Stated: سليم يمسك حجرًا ينبض، يهمس: "أنت حيّ... لماذا لم نرك؟"
- **00:25–00:40** | Inciting Incident: الحجر ينزف دمًا حقيقيًا
- **00:40–01:00** | Debate: هل يخبر العالم؟ هل يحمي السرّ؟
- **01:00–01:15** | Catalyst: يفتح الباب — يدخل النور الذهبي

### ACT II — التصعيد والتحطّم (01:15 – 03:30)
- **01:15–01:30** | B Story: نور تصل، تعانق سليم، تضع يدها على الحجر
- **01:30–02:00** | Fun & Games: الناس يتجمّعون—صلاة، بكاء، سوشيال ميديا
- **02:00–02:45** | Midpoint: دبابة في الخلفية، جنود يتجمّعون: "هذا احتلال علمي!"
- **02:45–03:10** | Bad Guys Close In: الجنود يتقدّمون، يدفعون الناس
- **03:10–03:25** | All Is Lost: سليم يقع، نظارته تتكسر، نور تصرخ
- **03:25–03:30** | Dark Night: يهمس: "سامحيني يا قدس"

### ACT III — الحل (03:30 – 05:00)
- **03:30–03:45** | Break Into Three: نور تقف، تمسح دمعتها، تسير نحو الحجر
- **03:45–04:30** | Finale: الحجر ينبض تحت يد نور، ينتشر الضوء الذهبي، الأذان يعلو من الحجارة
- **04:30–04:55** | Final Image: الأقصى كقلب عملاق ينبض فوق القدس
- **04:55–05:00** | Denouement: شاشة سوداء — "الأقصى ينزف. هل نسمع؟"

---

## CHARACTER BIBLE / كتاب الشخصيات

### الشيخ سليم (Sheikh Salim) — Protagonist
- **العمر:** 70 سنة | حارس الأقصى منذ 40 عامًا
- **فقد ابنه في انتفاضة. زوجته توفيت قبل 5 سنوات.**
- **الدوافع:** حماية الأقصى جسديًا وروحيًا
- **العيب:** يؤمن بالصمت كمقاومة، يخاف من "الضوضاء"
- **القوس:** من الصمت الروحي → إلى الصراخ بالحجر
- **الخطّ الأخير:** "سامحيني يا قدس."

### نور (Noor) — Emotional Anchor
- **العمر:** 12 سنة | والدها (ابن سليم) شهيد
- **الدوافع:** تؤمن بالأقصى ككائن حيّ ببراءة
- **العيب:** براءة مفرطة—لا تفهم السياسة
- **القوس:** من المتفرّجة → إلى الفاعلة
- **الخطّ الأخير:** "جدي، إنه يحبنا."

### قائد الجنود (The Captain) — Antagonist
- **العمر:** 35 سنة | ضابط عسكري
- **الدوافع:** منع "الفوضى"، إثبات أن الحجارة "لا تنزف"
- **الفلسفة:** "الحجر لا يشعر. الناس تشعر."
- **القوس:** مسطح—يمثّل القوة الصمّاء

### الأقصى نفسها (Al-Aqsa Itself) — Silent Protagonist
- **الطبيعة:** كيان حيّ رمزي
- **الدوافع:** "الصراخ" — محاولة أخيرة للتواصل
- **الرموز:** النزيف = الألم المكبوت | النبض = الحياة المتبقية | الضوء الذهبي = الروح غير القابلة للقهر

---

## SCENE-BY-SCENE BREAKDOWN

| SC | Name | Time | Key Action | VFX | Audio |
|---|---|---|---|---|---|
| SC-01 | الصحوة | 00:00–00:40 | سليم يكتشف الحجر النازف | نزيف الحجر، نبض ذهبي | أذان مكتوم، نبض خفي |
| SC-02 | الباب | 00:40–01:15 | سليم يفتح الباب | ضوء ذهبي يغمر | ناي صاعد، انفجار صوتي |
| SC-03 | نور | 01:15–01:45 | نور تلامس الحجر، موجة ذهبية | موجة صادمة ذهبية | جرس نعمة 8kHz |
| SC-04 | العالم | 01:45–02:30 | الفوضى، الإعلام، الجدل | — | فوضى صوتية، هاتف |
| SC-05 | الظلال | 02:30–03:10 | الجنود يتقدمون، الدبابة | دبابة، غاز مسيل | طبول حربية، 80 BPM |
| SC-06 | السقوط | 03:10–03:30 | سليم يسقط، النظارة تنكسر | النظارة في ماكرو بطيء | صمت رقمي 1 ثانية |
| SC-07 | القلب | 03:30–05:00 | نور تضيء الحجر، القلب في السماء | القلب الذهبي العملاق، الفضاء | أذان من الحجارة، أوركسترا |

---

## SHOT LIST — 35 SHOTS ACROSS 7 SCENES

### SC-01: 6 Shots (EWS→WS→MS→CU Macro→ECU Macro→CU Eyes)
### SC-02: 5 Shots (WS Door→OTS→CU Hand→WS Flood→ECU Dust)
### SC-03: 5 Shots (Tracking→MS→Two-Shot→Macro Hand→CU Smile)
### SC-04: 9 Shots (Whip Pan→Handheld MS→Phone POV→Drone→Low MS→Steadicam→CU Salim→WS Van→ECU Stone)
### SC-05: 8 Shots (EWS Tank→Low MS Boots→CU Captain→OTS→Handheld MS→Steadicam→CU Salim→WS Shield)
### SC-06: 5 Shots (ECU Push→Slow-Mo Fall→Ground MS→ECU Blood→CU Noor Scream)
### SC-07: 8 Shots (CU Tear→MS Hand→WS Glow→ECU Veins→Crane→Drone→CGI Heart→Earth Space)

**Camera Philosophy:** Sacred Observation → Conscious Chaos → Divine Ascension
**Lens Package:** ARRI Master Prime (18mm–100mm Macro) + Cooke S7/i + Angenieux Zoom
**Aspect Ratio:** 2.39:1 Cinemascope (with selective 1.85:1 moment at climax)
**Camera Body:** ARRI ALEXA 35 (primary) | RED V-RAPTOR (drone/aerial)
**Frame Rates:** 24fps base | 48fps violence/slow-mo | 12fps dream-state

---

## LIGHTING & COLOR DESIGN

### LUT Pipeline (8 Scenes)
| Scene | LUT Name | Color Direction |
|---|---|---|
| SC-01 | DAWN_TWILIGHT | Blue hour desaturation, shadows cyan, highlights warm |
| SC-02 | THRESHOLD_GOLD | Blue cools to neutral, gold strengthens |
| SC-03 | NOOR_GOLDEN | Full golden hour, skin tones peak warm |
| SC-04 | CHAOS_DOCUMENTARY | Desaturated documentary, high contrast, ugly reality |
| SC-05 | SHADOW_MILITARY | Flat, desaturated, green-yellow bias, institutional |
| SC-06 | RUPTURE_BLEED | High contrast, red push in shadows, shattered look |
| SC-07A | TRANSFIGURATION_GOLD | Gold overwhelms frame, warm flood, divine saturation |
| SC-07B | ASCENSION_COSMIC | Gold to white, transcendence, clean digital finish |

### Key Lighting Instruments
- ARRI M18 + 4x4 Half Grid (moonlight key)
- Aputure 600d/300d (practical fill/bounce)
- 10K Tungsten + 12x12 Grid (god-light through door)
- RGB LED panels + Aputure 600c (golden VFX practicals)
- Dedolight (eye light)

---

## SOUND & MUSIC DESIGN

### Score Structure (D Minor Arc)
| Time | Scene | Key | Tempo | Instruments | Dynamics |
|---|---|---|---|---|---|
| 00:00–00:40 | SC-01 | D Minor/Dorian | Rubato→65 BPM | Solo Oud, Cello, Moog Sub-bass 40Hz | ppp→mp |
| 00:40–01:15 | SC-02 | F Minor | 70 BPM | Ney, Strings (8V/4Va/2Vc), Processed Harp | mp→mf |
| 01:15–01:45 | SC-03 | G Minor | 72 BPM→5/4 skip | Qanun, Solo Violin (flautando) | p→mp |
| 01:45–02:30 | SC-04 | Atonal clusters | 90→140→80 BPM | Prepared Piano, Modular Synth, Distorted Oud | mf→fff |
| 02:30–03:10 | SC-05 | C Phrygian Dom. | 80 BPM march | Full Brass, Taiko, Frame Drum, Square-wave Sub | fff (LFE peak -6dBFS) |
| 03:10–03:30 | SC-06 | D pedal tone | 60→50 BPM | Exposed heartbeat, microtonal Violin (-20c), wind | fff→ppp in 2s |
| 03:30–05:00 | SC-07 | D Minor→Melodic Min. | Rubato 55→45 BPM | 60-piece Orchestra, Oud, Boys' Choir, Ney, Qanun, Celestial Synth | ppp→fff→ppp |

### The Adhan (Call to Prayer) Sonic Arc
1. **SC-01:** Muted/buried — only 200-600Hz, incomplete phrase
2. **SC-02:** Wind-borne, approaching — full spectrum, real muezzin
3. **SC-03:** Absolute silence — sacred voice stops to listen to the child
4. **SC-04:** Fragmented/desecrated — multiple overlapping, out of sync, phone degradation
5. **SC-05:** Drowned/martyred — tear gas masks the "salah", only "Allahu Akbar" survives
6. **SC-06:** Absent/void — complete silence, God is silent or listening
7. **SC-07:** The stones sing — Adhan rises from bleeding stones via convolution reverb + vocoder + boys' choir, intentionally unresolved on dominant

### Heartbeat Motif Evolution
60 BPM (asleep) → 65 BPM (discovery) → skipped beat at Noor's touch → arrhythmic 80-100 (chaos) → 80 BPM military march → 60→50 BPM exposed (dying) → orchestral bass drum (resurrection) → one pulse every 4 seconds → stop → replaced by Adhan

### Key Foley
- Salim's thobe on marble (heavy woven cotton, decades of weight)
- Olive wood misbaha (prayer beads) clicking
- Child's sneakers (Converse-style, light staccato)
- Skin on wet sandstone (suction sound as viscous blood releases)
- Military boots synced to orchestral bass drum
- Tank treads as LFE pulse at 35Hz
- Glass shatter with pitched D5 component decaying to noise
- Stone pulse: honey/wine on porous limestone (hydrophone pickup)

### Final Mix Specs
- **Theatrical DCP:** -23 LUFS, True Peak -1 dBTP, 20 LU dynamic range
- **Streaming:** -16 LUFS, True Peak -1 dBTP, 15 LU dynamic range
- **Dolby Atmos 7.1.4:** Height speakers = Adhan + golden sweeps + ascension strings
- **LFE:** Heartbeat 30-50Hz, tank treads, bass drum, sub-bass drone

---

## VFX DIRECTION

### The Bleeding Stone
- **Concept:** Stone pores seeping dark crimson fluid — biological, not magical
- **Practical Base:** Silicone stone replica with embedded tubes, Kensington stage blood + chocolate syrup
- **VFX Enhancement:** 15% digital augmentation, subsurface scattering in pores
- **Color:** Dark crimson #5C0011 → oxidized near-black edges
- **Texture:** Thick, viscous, catches light like oil, not water
- **Software:** Houdini (fluid sim) → Nuke (comp) → DaVinci (color)

### The Pulsing Heart
- **Concept:** Al-Aqsa as giant golden pulsing heart over Jerusalem
- **Scale:** Building → City → Cosmic
- **Design:** Golden heart (Jerusalem stone made flesh), translucent, luminous
- **Pulse Rhythm:** 60 BPM → 80 BPM → one giant beat at 04:55
- **Veins:** Jerusalem streets light up in golden sequence
- **Software:** Cinema 4D/Blender → Houdini → Nuke → DaVinci

### The Golden Light
- **Concept:** Liquid gold spreading like spilled honey, rising like incense
- **Practical Base:** RGB LED panels, Aputure 600c full amber
- **VFX:** Glow bloom, particle atmosphere, god-rays
- **Behavior:** Circular ripple from tear → climbs walls → ascends like steam
- **Software:** Practical + Nuke + Houdini → DaVinci

### Roof Penetration / Ascension
- **Concept:** Camera rises through dome as translucent golden mist
- **Execution:** Crane to 15m → VCG takeover → translucent roof → drone match
- **Software:** Blender/C4D → Nuke → Drone footage match

### Earth from Space
- **Concept:** Jerusalem as single golden point, slowly rotating
- **Execution:** Full CGI, NASA Blue Marble textures, accurate coordinates
- **Software:** Blender/C4D → NASA textures → Nuke → DaVinci

---

## EMOTIONAL ARC MAP

| Time | Phase | Primary Emotion | Secondary | Intensity |
|---|---|---|---|---|
| 00:00–00:45 | Knowing Silence | Nostalgia | Subsurface Dread | 3/10 |
| 00:45–01:20 | First Violation | Shock | Disorientation | 7/10 |
| 01:20–02:10 | The Witnessing | Suppressed Rage | Helplessness | 6/10 |
| 02:10–03:00 | The Bleeding | Epic Grief | Sacred Anger | 9/10 |
| 03:00–03:45 | The Hollow | Despair | Existential Loneliness | 8/10 |
| 03:45–04:30 | The Call | Solidarity | Fractured Hope | 5/10 |
| 04:30–05:00 | Dying Hope | Mourning | Fragile Resilience | 4/10 |

---

## AI VIDEO GENERATION PROMPTS

### SORA (OpenAI) — 6 Video Prompts
1. **SC-01 Macro Touch:** Extreme close-up, Sheikh Salim's weathered hand reaching to bleeding stone, golden light erupts from subsurface, ARRI ALEXA 35 macro, 2.39:1, 8s
2. **SC-02 Door Flood:** Wide shot, ancient wooden door with iron studs bleeding, blinding golden light floods interior, dust motes, 2.39:1, 10s
3. **SC-03 Shockwave:** Two-shot, Noor touches stone, radial shockwave of golden light bursts outward, 2.39:1, 8s
4. **SC-05 Military Wide:** Extreme wide, tank enters Al-Aqsa courtyard, soldiers advance, tear gas, dust, 2.39:1, 12s
5. **SC-06 Glass Shatter:** Macro slow-motion, wire-rimmed glasses shatter against stone, golden reflections in shards, Noor's face reflected, 2.39:1, 10s
6. **SC-07 Ascension:** Ground to space continuous, Noor on stone → golden light spreads → through dome → heart over Jerusalem → Earth from space, 2.39:1, 20s

### VEO (Google) — 4 Video Prompts
1. **SC-04 Crowd Chaos:** Documentary-style handheld weaving through journalists, phones, prayers, arguments, mixed warm/cold lighting, 2.39:1, 10s
2. **SC-05 Violence:** Military action, tank, tear gas, rubber bullets, civilians scattering, real-time brutal urgency, 2.39:1, 12s
3. **SC-03 Noor's Arrival:** Running through corridors, backlit golden, embrace with Salim, 270° camera arc, 2.39:1, 15s
4. **SC-07 Golden Pulse:** 360° orbit around kneeling Noor, golden veins spreading through floor cracks, 2.39:1, 10s

### RUNWAY GEN-3 — 3 Video Prompts
1. **SC-01 Dawn Atmosphere:** Stylized atmospheric, Salim walks between columns, cold dawn light, volumetric beams, heavy film grain, 2.39:1, 8s
2. **SC-02 Dust Motes:** Hyper-stylized macro, door rivets bleeding, dust motes in golden light, anamorphic bokeh, 2.39:1, 6s
3. **SC-07 Transfiguration:** Dreamlike golden overwhelming, Noor on stone, light ripples in air, slow descent, bloom, 2.39:1, 12s

### KLING — 2 Video Prompts
1. **SC-05 Military Long-Take:** Complex action choreography, tank, soldiers, tear gas, long-take whip-pans, 2.39:1, 15s
2. **SC-07 Ascension & Heart:** Shockwave, rapid vertical boom through dome, heart over Jerusalem, cosmic scale, 2.39:1, 18s

### MIDJOURNEY V6 — 10 Image Prompts
- Sheikh Salim portrait (85mm, cold dawn, DAWN_TWILIGHT)
- Noor backlit arrival (50mm, golden rim, NOOR_GOLDEN)
- Bleeding stone macro (100mm macro, THRESHOLD_GOLD)
- Ancient door with golden flood (27mm, THRESHOLD_GOLD)
- Noor & Salim embrace (40mm, NOOR_GOLDEN)
- Crowd chaos wide (18mm, CHAOS_DOCUMENTARY)
- Military Captain low angle (65mm, SHADOW_MILITARY)
- Glass shatter macro (100mm macro, RUPTURE_BLEED)
- Noor & golden veins (24mm, TRANSFIGURATION_GOLD)
- Heart over Jerusalem (18mm, ASCENSION_COSMIC)

### FLUX — 5 Image Prompts
- Stone bleeding extreme macro (100mm macro)
- Noor's glowing finger (85mm macro)
- Military overhead aerial (24mm)
- Door from inside low angle (14mm)
- Earth from space (cosmic)

---

## PRODUCTION SPECIFICATIONS

| Category | Decision |
|---|---|
| Runtime | 5:00 minutes (300 seconds) |
| Scenes | 7 |
| Shots | 35 VFX shots (est.) |
| Speaking Characters | 4 |
| Locations | 3 (Interior Al-Aqsa, Courtyard, Sky) |
| Aspect Ratio | 2.39:1 Cinemascope |
| Camera | ARRI ALEXA 35 (primary) |
| Lenses | ARRI Master Prime + Cooke S7/i + Angenieux Zoom |
| Frame Rate | 24fps base / 48fps slow-mo / 12fps dream |
| Color Science | ARRI Reveal + 8-scene custom LUT pipeline |
| VFX Software | Houdini + Nuke + Blender/C4D |
| Audio | Dolby Atmos 7.1.4 / 5.1 / Stereo |
| Music | 60-piece orchestra + Oud + Ney + Qanun + Boys' Choir |
| Deliverables | 4K DCI (4096×1716) |

---

## THEMES & SYMBOLS

### Primary Theme: الصراخ الصامت — The Silent Scream
> "عندما يصمت العالم عن الظلم، يضطر الحجر نفسه إلى الكلام."

### Secondary Themes
- **البراءة كشهادة** — Innocence as Witness (نور ترى الحقيقة)
- **الشهادة ضد الاستهلاك** — Witnessing vs. Consuming (يوسف المصوّر)
- **جيل يموت وجيل يولد** — Dying Generation & Rising One (سليم ونور)

### Key Symbols
| Symbol | Meaning | Appearance |
|---|---|---|
| النزيف | الألم المكبوت الذي يصرخ | All interior scenes |
| النبض | الحياة المتبقية | Progressive escalation |
| النظارة المكسورة | كسر الرؤية التقليدية | 03:10 |
| الضوء الذهبي | الروح غير القابلة للقهر | Climax |
| الأذان | صوت الأقصى الحقيقي | 00:00 (muted) → 04:30 (from stones) |
| اليد على الحجر | التواصل الجسدي الروحي | SC-01 (سليم) → SC-07 (نور) |
| القلب في السماء | الأقصى كروح كونية | Final image |

---

## FINAL WORD

> "الأقصى لا تموت. الأقصى تصرخ. السؤال ليس عما إذا كانت حية—السؤال هو: هل نحن على قيد الحياة بما يكفي لنسمع؟"

---

*Prepared by: From Storyboard To Vision Pipeline*
*Story Architect | Emotional Narrative | Cinematic Director | Visual Storyboard | Sound & Music | AI Prompt Director | Interactive Experience*
*Date: 2026-05-25*
