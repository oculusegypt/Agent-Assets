# AI Autonomous Film Studio — Intelligent Model Router Engine (IMRE)

## Overview

The IMRE is the central nervous system of the AI Autonomous Film Studio. It makes sub-second decisions about which AI model handles which task, balancing quality, cost, speed, and cinematic fit. It is not a simple switch. It is a decision engine with weighted scoring, health monitoring, cost tracking, and autonomous recovery.

---

## Core Components

### 1. Task Analyzer
Classifies every incoming task into:
- **Media type**: `video | image | text | audio | vfx | code | composite`
- **Cinematic complexity**: `1-10` (shot count × characters × environment × motion × lighting)
- **Quality tier**: `draft | production | cinematic | masterpiece`
- **Speed requirement**: `realtime | fast | standard | slow`
- **Budget context**: `cost-sensitive | balanced | quality-first`

### 2. Model Capability Registry (MCR)
A live database of every model's capabilities, performance, and status.

### 3. Router Decider
Weighted scoring algorithm that selects the optimal model.

### 4. Quality Supervisor
Post-generation quality scoring and regeneration triggers.

### 5. Cost Optimizer
Real-time budget tracking and smart downgrading.

---

## Model Capability Registry — Full Schema

### Current Registry (v2.0)

| Provider | Model | Family | Video | Image | Text | Audio | Reason | Code | Cinematic | Arabic | Context | Latency | Cost/1K | Status | Rank |
|----------|-------|--------|--------|--------|------|--------|--------|------|-----------|--------|---------|---------|---------|--------|------|
| **Alibaba** | Qwen-VL-Plus | vision | 0.85 | 0.92 | 0.75 | 0.10 | 0.80 | 0.70 | 0.88 | 0.90 | 128K | 2.1s | $0.003 | online | 1 |
| **Alibaba** | WanX-Video-v2 | video | 0.92 | 0.30 | 0.05 | 0.05 | 0.10 | 0.00 | 0.90 | 0.40 | 8K | 12.5s | $0.045 | online | 1 |
| **Alibaba** | Tongyi-Image-v2 | image | 0.05 | 0.94 | 0.10 | 0.05 | 0.15 | 0.00 | 0.91 | 0.50 | 4K | 8.9s | $0.040 | online | 1 |
| **Alibaba** | Audio-Synthesis-v1 | audio | 0.00 | 0.00 | 0.20 | 0.88 | 0.10 | 0.00 | 0.75 | 0.60 | 16K | 4.2s | $0.012 | online | 1 |
| **Alibaba** | Qwen-72B | language | 0.05 | 0.10 | 0.88 | 0.10 | 0.85 | 0.82 | 0.70 | 0.92 | 128K | 1.8s | $0.002 | online | 2 |
| **Google** | Gemini-2.5-Pro | language | 0.15 | 0.25 | 0.96 | 0.20 | 0.95 | 0.93 | 0.94 | 0.88 | 2M | 3.2s | $0.007 | online | 1 |
| **Google** | Gemini-2.5-Flash | language | 0.10 | 0.15 | 0.88 | 0.15 | 0.82 | 0.85 | 0.80 | 0.85 | 1M | 1.1s | $0.002 | online | 2 |
| **Google** | Gemini-1.5-Pro | vision | 0.20 | 0.40 | 0.85 | 0.15 | 0.80 | 0.75 | 0.82 | 0.80 | 2M | 2.8s | $0.005 | online | 3 |
| **OpenAI** | GPT-4o | language | 0.10 | 0.20 | 0.94 | 0.10 | 0.88 | 0.90 | 0.85 | 0.75 | 128K | 2.5s | $0.010 | offline | 3 |
| **OpenAI** | DALL-E-3 | image | 0.00 | 0.90 | 0.05 | 0.00 | 0.05 | 0.00 | 0.85 | 0.60 | 4K | 6.5s | $0.080 | offline | 3 |
| **Anthropic** | Claude-3.5-Sonnet | language | 0.05 | 0.10 | 0.92 | 0.10 | 0.90 | 0.88 | 0.86 | 0.78 | 200K | 4.1s | $0.008 | offline | 2 |
| **ElevenLabs** | Multilingual-v2 | audio | 0.00 | 0.00 | 0.30 | 0.94 | 0.05 | 0.00 | 0.80 | 0.85 | 8K | 1.5s | $0.018 | offline | 2 |
| **Runway** | Gen-3-Alpha | video | 0.90 | 0.20 | 0.05 | 0.05 | 0.10 | 0.00 | 0.92 | 0.50 | 16K | 15.2s | $0.055 | offline | 2 |
| **Pika** | Pika-1.5 | video | 0.85 | 0.15 | 0.05 | 0.05 | 0.05 | 0.00 | 0.87 | 0.40 | 8K | 18.5s | $0.050 | offline | 3 |
| **Flux** | Flux-Pro | image | 0.00 | 0.93 | 0.10 | 0.00 | 0.10 | 0.00 | 0.90 | 0.55 | 4K | 7.2s | $0.035 | offline | 2 |
| **Kling** | Kling-v1.5 | video | 0.88 | 0.20 | 0.05 | 0.05 | 0.08 | 0.00 | 0.89 | 0.45 | 8K | 14.8s | $0.048 | offline | 3 |

### Capability Score Definitions

- **Video generation**: Ability to generate coherent cinematic video with temporal consistency
- **Image generation**: Ability to create photorealistic/cinematic still frames
- **Text generation**: Narrative writing, screenplay, dialogue quality
- **Audio generation**: Sound synthesis, music, foley, speech quality
- **Reasoning**: Logical inference, planning, dramatic structure analysis
- **Code generation**: Frontend/backend code, prompt engineering, configuration
- **Cinematic**: Proven track record in film/art production benchmarks
- **Arabic**: Quality of Arabic language understanding and generation
- **Context**: Effective context window size for long-form tasks

---

## Routing Decision Engine

### Algorithm: Weighted Multi-Factor Scoring

```python
class RoutingEngine:
    WEIGHTS = {
        'quality': 0.40,
        'speed': 0.20,
        'cost': 0.15,
        'cinematic': 0.15,
        'complexity': 0.10
    }
    
    def route(self, task: Task) -> ModelAssignment:
        # Step 1: Filter by capability
        candidates = self.mcr.query(
            media_type=task.media_type,
            min_capability=task.quality_floor,
            status='online'
        )
        
        # Step 2: Score each candidate
        scored = []
        for model in candidates:
            score = self._calculate_score(model, task)
            scored.append((model, score))
        
        # Step 3: Sort and assign
        scored.sort(key=lambda x: x[1], reverse=True)
        
        return ModelAssignment(
            primary=scored[0][0],
            fallback=scored[1][0] if len(scored) > 1 else None,
            confidence=scored[0][1],
            routing_reason=self._explain_decision(scored[0][0], task)
        )
    
    def _calculate_score(self, model: Model, task: Task) -> float:
        # Quality match (40%)
        quality = self._quality_match(model, task) * self.WEIGHTS['quality']
        
        # Speed match (20%) — inverse of latency
        speed = (1.0 - min(model.avg_latency_ms / 30000, 1.0)) * self.WEIGHTS['speed']
        
        # Cost optimization (15%) — inverse of cost
        cost = (1.0 - min(self._task_cost(model, task) / task.budget_max, 1.0)) * self.WEIGHTS['cost']
        
        # Cinematic fit (15%)
        cinematic = model.cinematic_quality_score * self.WEIGHTS['cinematic']
        
        # Complexity match (10%)
        complexity = min(model.max_context_tokens / 2000000, 1.0) * self.WEIGHTS['complexity']
        
        total = quality + speed + cost + cinematic + complexity
        
        # Apply degradation penalty
        if model.status == 'degraded':
            total *= 0.7
        
        # Apply consecutive failure penalty
        if model.consecutive_failures > 0:
            total *= (0.9 ** model.consecutive_failures)
        
        return total
```

### Routing Examples

#### Example 1: Screenplay Writing
```
Task: Write full screenplay for 14-scene short film
Media: text | Complexity: 8 | Quality: cinematic | Speed: standard

Router Analysis:
├─ Gemini-2.5-Pro:  quality=0.96×0.40=0.384 | speed=0.89×0.20=0.178 
│                    cost=0.98×0.15=0.147 | cinematic=0.94×0.15=0.141
│                    complexity=1.0×0.10=0.100 | TOTAL=0.950 ✓
├─ Gemini-2.5-Flash: quality=0.88×0.40=0.352 | speed=0.96×0.20=0.192
│                    cost=1.0×0.15=0.150 | cinematic=0.80×0.15=0.120
│                    complexity=0.5×0.10=0.050 | TOTAL=0.864
├─ Qwen-72B:         quality=0.88×0.40=0.352 | speed=0.94×0.20=0.188
│                    cost=1.0×0.15=0.150 | cinematic=0.70×0.15=0.105
│                    complexity=0.06×0.10=0.006 | TOTAL=0.801

DECISION: Gemini-2.5-Pro (confidence: 0.950)
REASON: 2M context needed for 14-scene continuity. Gemini's narrative
        depth and cinematic quality score make it optimal.
FALLBACK: Gemini-2.5-Flash (if 2.5-Pro latency exceeds 10s)
```

#### Example 2: Storyboard Frame Generation
```
Task: Generate cinematic concept art frame for lighthouse interior
Media: image | Complexity: 5 | Quality: cinematic | Speed: fast

Router Analysis:
├─ Tongyi-Image-v2:  quality=0.94×0.40=0.376 | speed=0.70×0.20=0.140
│                    cost=1.0×0.15=0.150 | cinematic=0.91×0.15=0.137
│                    complexity=N/A | TOTAL=0.803 ✓
├─ Qwen-VL-Plus:     quality=0.92×0.40=0.368 | speed=0.93×0.20=0.186
│                    cost=1.0×0.15=0.150 | cinematic=0.88×0.15=0.132
│                    complexity=N/A | TOTAL=0.836

DECISION: Tongyi-Image-v2 (confidence: 0.803)
REASON: Highest image generation score (0.94). Native Alibaba pipeline.
        Context matching for Chinese-international hybrid aesthetic.
FALLBACK: Qwen-VL-Plus (multimodal reasoning for complex compositions)
```

#### Example 3: Video Preview Generation
```
Task: Generate 8-second cinematic video clip of lighthouse storm scene
Media: video | Complexity: 9 | Quality: masterpiece | Speed: slow

Router Analysis:
├─ WanX-Video-v2:    quality=0.92×0.40=0.368 | speed=0.58×0.20=0.116
│                    cost=1.0×0.15=0.150 | cinematic=0.90×0.15=0.135
│                    complexity=N/A | TOTAL=0.769 ✓
├─ Runway-Gen-3:     OFFLINE (status: offline, skip)
├─ Kling-v1.5:       OFFLINE (status: offline, skip)
├─ Pika-1.5:          OFFLINE (status: offline, skip)

DECISION: WanX-Video-v2 (confidence: 0.769)
REASON: Only online video generation provider. Alibaba's WanX has
        proven cinematic quality (0.90) for atmospheric scenes.
FALLBACK: None available — queue for when Runway/Kling online
```

---

## Quality Supervisor

### Post-Generation Scoring

Every generated asset gets a quality score (0.0 - 1.0):

```python
class QualitySupervisor:
    THRESHOLDS = {
        'draft': 0.60,
        'production': 0.75,
        'cinematic': 0.85,
        'masterpiece': 0.92
    }
    
    def evaluate(self, asset: GeneratedAsset, task: Task) -> QualityReport:
        scores = {}
        
        # Text quality (Gemini evaluation)
        if task.media_type == 'text':
            scores['coherence'] = self._check_narrative_coherence(asset)
            scores['character_voice'] = self._check_character_consistency(asset)
            scores['dramatic_structure'] = self._check_three_act_integrity(asset)
            scores['emotional_arc'] = self._check_emotion_progression(asset)
        
        # Image quality (Qwen-VL evaluation + human-like metrics)
        elif task.media_type == 'image':
            scores['composition'] = self._check_cinematic_composition(asset)
            scores['lighting'] = self._check_lighting_quality(asset)
            scores['character_consistency'] = self._check_character_match(asset)
            scores['color_harmony'] = self._check_palette_coherence(asset)
        
        # Video quality (frame-by-frame analysis)
        elif task.media_type == 'video':
            scores['temporal_coherence'] = self._check_frame_continuity(asset)
            scores['motion_smoothness'] = self._check_motion_quality(asset)
            scores['cinematic_language'] = self._check_shot_grammar(asset)
            scores['audio_sync'] = self._check_av_sync(asset)
        
        # Audio quality
        elif task.media_type == 'audio':
            scores['emotional_match'] = self._check_emotional_alignment(asset, task)
            scores['clarity'] = self._check_audio_clarity(asset)
            scores['atmosphere'] = self._check_atmospheric_depth(asset)
        
        overall = sum(scores.values()) / len(scores)
        
        return QualityReport(
            overall_score=overall,
            breakdown=scores,
            passed=overall >= self.THRESHOLDS[task.quality_tier],
            regeneration_recommended=overall < self.THRESHOLDS[task.quality_tier] + 0.05
        )
```

### Auto-Regeneration Trigger

```
Quality Report Received
    │
    ├──► Score >= threshold → APPROVE → Store asset → Update manifest
    │
    └──► Score < threshold → REJECT
              │
              ├──► Retry count < 3 → REGENERATE
              │         • Switch to fallback model
              │         • Adjust prompt based on failure analysis
              │         • Increase quality parameters
              │
              └──► Retry count >= 3 → FLAG FOR MANUAL
                        • Store best attempt
                        • Notify user
                        • Offer alternative model options
```

---

## Cost Optimization Engine

### Smart Model Downgrading Strategy

```python
class CostOptimizer:
    BUDGET_THRESHOLDS = {
        'warning': 0.80,   # Switch non-critical to cheaper models
        'critical': 0.90,  # Disable video, keep text/image
        'halt': 0.95       # Stop all generation, notify user
    }
    
    def check_budget(self, session: ProductionSession):
        spent = session.total_cost_usd
        budget = session.budget_usd
        ratio = spent / budget
        
        if ratio >= self.BUDGET_THRESHOLDS['halt']:
            self._halt_generation(session)
            self._notify_user(session, "Budget exhausted. Top up to continue.")
            
        elif ratio >= self.BUDGET_THRESHOLDS['critical']:
            self._disable_video_generation(session)
            self._switch_to_cheaper_text_models(session)
            self._notify_user(session, "Budget critical. Video generation paused.")
            
        elif ratio >= self.BUDGET_THRESHOLDS['warning']:
            self._downgrade_non_critical_tasks(session)
            self._notify_user(session, "Budget at 80%. Optimizing model selection.")
```

### Cost-Aware Routing

For cost-sensitive sessions, the cost weight increases from 15% to 35%:

```python
def get_weights(self, budget_context: str) -> dict:
    if budget_context == 'cost-sensitive':
        return {'quality': 0.30, 'speed': 0.15, 'cost': 0.35, 
                'cinematic': 0.10, 'complexity': 0.10}
    elif budget_context == 'quality-first':
        return {'quality': 0.50, 'speed': 0.15, 'cost': 0.05,
                'cinematic': 0.20, 'complexity': 0.10}
    else:  # balanced
        return {'quality': 0.40, 'speed': 0.20, 'cost': 0.15,
                'cinematic': 0.15, 'complexity': 0.10}
```

---

## Health Check System

### Continuous Monitoring

Every 30 seconds, the system checks:

```python
class HealthMonitor:
    CHECK_INTERVAL = 30  # seconds
    
    async def health_check(self, model: Model):
        try:
            # Send test prompt based on model family
            test_task = self._generate_test_task(model.model_family)
            start = time.time()
            result = await self._call_model(model, test_task)
            latency = time.time() - start
            
            # Update metrics
            model.avg_latency_ms = self._ewma(model.avg_latency_ms, latency * 1000)
            model.last_health_check = datetime.now()
            model.consecutive_failures = 0
            
            # Quality score the result
            quality = self.quality_supervisor.quick_evaluate(result)
            model.cinematic_quality_score = self._ewma(
                model.cinematic_quality_score, quality
            )
            
            # Status update
            if latency > 30 or quality < 0.6:
                model.status = 'degraded'
            else:
                model.status = 'online'
                
        except Exception as e:
            model.failure_count += 1
            model.consecutive_failures += 1
            
            if model.consecutive_failures >= 3:
                model.status = 'offline'
                await self._notify_orchestrator(model, "Provider offline")
                await self._trigger_fallback_routing(model)
```

---

## Session-Based Intelligence

### Per-Session Learning

The system learns from each session:

```sql
CREATE TABLE session_model_learning (
    session_id UUID,
    model_provider VARCHAR(100),
    model_name VARCHAR(200),
    task_type VARCHAR(100),
    scenes_generated INTEGER,
    avg_quality_score DECIMAL(3,2),
    total_cost_usd DECIMAL(10,4),
    user_satisfaction INTEGER, -- 1-5, if user provides feedback
    
    -- Learning outcomes
    preferred_for_next_session BOOLEAN DEFAULT false,
    avoid_for_next_session BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- After each session, update model preferences
-- If a model consistently scores > 0.90 for a task type,
-- it gets priority boost for next session of same genre
```

---

## API: Router Engine Endpoints

```
POST /api/v2/router/evaluate
  Body: { task_type, complexity, quality_tier, budget_context }
  Response: { primary_model, fallback_model, confidence, reasoning }

GET /api/v2/router/registry
  Response: { models: [...] } // Full MCR dump

GET /api/v2/router/health
  Response: { providers: [...], overall_status }

POST /api/v2/router/feedback
  Body: { session_id, asset_id, quality_score, user_rating }
  Response: { learning_applied: true }

GET /api/v2/sessions/{id}/routing-log
  Response: { decisions: [...], costs: [...], quality_scores: [...] }
```

---

## Future Expansion: OpenRouter Integration

When new providers are added, they self-register:

```python
class ProviderRegistration:
    def register(self, provider_config: ProviderConfig):
        # Validate credentials via Vault
        creds = vault.read(provider_config.vault_path)
        
        # Run capability benchmark suite
        benchmark = self._run_benchmark_suite(provider_config)
        
        # Add to MCR with initial scores
        mcr.add_model(
            provider=provider_config.name,
            model_name=provider_config.model_name,
            capabilities=benchmark.scores,
            status='online',
            priority_rank=provider_config.initial_rank
        )
        
        # Start health monitoring
        health_monitor.start_monitoring(provider_config)
```

---

*"The router doesn't just choose a model. It chooses a vision."*
