# From Storyboard To Vision — AI Prompt Engineering System

## Philosophy
Our prompt engineering system is built on the principle of "Cinematic Translation" — converting human creative vision into machine-optimized instructions that produce Hollywood-grade visual output. Every prompt is designed to capture not just what to show, but how to feel.

## Prompt Architecture

### Core Prompt Structure (Universal)
```
[CINEMATIC QUALITY PREFIX] + [SUBJECT/CHARACTER] + [ACTION/MOTION] + 
[ENVIRONMENT/SETTING] + [CAMERA WORK] + [LIGHTING] + [COLOR PALETTE] + 
[MOOD/ATMOSPHERE] + [STYLE REFERENCE] + [TECHNICAL SPECIFICATIONS] + 
[NEGATIVE PROMPT]
```

### Quality Prefixes
```
# Video Generation (Sora, Veo, Runway, Kling, Pika)
"Cinematic film still, highly detailed, 8K resolution, photorealistic, 
dramatic lighting, shallow depth of field, professional cinematography, 
film grain, anamorphic lens characteristics"

# Image Generation (Midjourney, Stable Diffusion, Flux)
"Cinematic concept art, highly detailed digital painting, dramatic composition, 
professional illustration, award-winning visual design, studio quality, 
8K UHD, trending on ArtStation"

# Character Consistency
"Consistent character appearance: [specific physical description], 
wearing [specific outfit], same face, same proportions, same lighting conditions"
```

## Platform-Specific Prompt Patterns

### 1. Sora (OpenAI)
```
Prompt Template:
"A cinematic [shot_type] of [subject_description] [action_description] 
in [environment_description]. [camera_movement_description]. 
[lighting_description] creates [mood_description]. 
[color_palette_description]. [time_of_day]. 
Shot on [lens_description] with [film_stock_reference]. 
[director_style_reference]. [technical_quality]."

Example:
"A cinematic wide shot of a young woman in a flowing red dress standing 
at the edge of a misty cliff, her hair catching the golden hour wind, 
looking out at an infinite ocean. The camera slowly dollies in from a 
low angle, revealing her contemplative expression. Golden hour sunlight 
breaks through dramatic storm clouds, rim-lighting her silhouette. 
Warm amber and deep teal color palette. Shot on a 35mm anamorphic lens 
with subtle film grain. In the visual style of Denis Villeneuve's 
'Dune' cinematography. Highly detailed, photorealistic, 8K cinematic quality."

Negative Prompt (for SD/Flux only, Sora doesn't use negatives):
"blurry, low quality, distorted, ugly, deformed, bad anatomy, 
watermark, text, logo, oversaturated, overexposed"

Sora-Specific Tips:
- Use natural language camera descriptions (dolly in, crane up, handheld)
- Specify duration: "5 seconds of..." or "10-second sequence..."
- Include temporal continuity: "continuous motion", "smooth transition"
- Mention frame rate quality: "24fps cinematic motion", "smooth camera movement"
```

### 2. Veo (Google)
```
Prompt Template:
"[Establishing shot/environment] [Subject in motion] [Camera behavior] 
[Lighting conditions] [Atmosphere effects] [Color grading] 
[Director reference] [Cinematic quality markers]"

Example:
"Establishing aerial shot of a neon-lit cyberpunk city at night. 
A lone figure in a reflective trench coat walks through rain-soaked streets, 
reflected in puddles. Camera tracks from behind, slowly revealing 
the character's face as they stop and look up at towering holographic 
advertisements. Neon blues, hot pinks, and deep purples color the scene. 
Atmospheric fog and rain particles visible. Directed by Ridley Scott 
Blade Runner aesthetic. 4K, photorealistic, cinematic motion, 
24 frames per second."

Veo-Specific Tips:
- Strong establishing shots work well
- Specify camera tracking behavior clearly
- Atmosphere effects (rain, fog, dust) enhance output
- Color palette descriptions improve consistency
```

### 3. Runway Gen-3
```
Prompt Template:
"[Visual description with motion]. [Camera: movement, angle, lens]. 
[Lighting: type, direction, mood]. [Atmosphere: particles, weather, time]. 
[Color: palette, grading style]. [Style: director, film reference]. 
[Quality: resolution, detail level]."

Example:
"Medium close-up of an elderly man sitting in a vintage train compartment, 
sunlight streaming through dusty windows creating volumetric light beams. 
Camera slowly pushes in, rack focusing from the window to his weathered face. 
Warm golden light mixed with cool blue shadows. Dust motes dance in the light. 
Muted earth tones with golden highlights. In the style of Wong Kar-wai's 
'In the Mood for Love'. Cinematic, photorealistic, highly detailed textures, 
8K quality."

Runway-Specific Tips:
- Explicit "Camera:" prefix helps movement control
- "rack focusing" works well for depth
- Volumetric light descriptions produce good results
- Director references strongly influence style
```

### 4. Kling (Kuaishou)
```
Prompt Template:
"[Scene setup]. [Character action and motion]. [Environment and props]. 
[Camera work and movement]. [Lighting and atmosphere]. [Color and style]. 
[Technical specs]."

Example:
"Ancient library interior with towering bookshelves and warm candlelight. 
A young scholar carefully pulls a leather-bound book from a shelf, 
dust particles swirling in the candlelight. Camera orbits slowly around 
the character in a circular tracking shot. Multiple practical light sources 
create layered shadows. Warm amber and deep brown palette with golden 
highlights. Painterly cinematic style reminiscent of classical oil paintings. 
High detail, smooth motion, cinematic quality."

Kling-Specific Tips:
- Detailed environment descriptions improve consistency
- Motion descriptions should be explicit and continuous
- Practical lighting sources create rich shadows
- Painterly styles work exceptionally well
```

### 5. Pika Labs
```
Prompt Template:
"[Main subject], [action], in [environment]. [Camera movement]. 
[Lighting]. [Mood]. [Style]. [Quality]."

Example:
"Warrior in ornate samurai armor, drawing katana in a single fluid motion, 
in a bamboo forest during a light rain. Camera low angle tracking the draw, 
slow motion droplets visible. Soft diffused light filtering through bamboo. 
Contemplative, deadly calm mood. Akira Kurosawa Seven Samurai visual style. 
Cinematic, detailed, photorealistic."

Pika-Specific Tips:
- Concise prompts work better than verbose ones
- Motion verbs should be clear (drawing, running, falling)
- Simple lighting descriptions produce cleaner results
- Film references strongly guide the aesthetic
```

### 6. Midjourney (Still Frames)
```
Prompt Template:
"[Shot description], [subject], [environment], [lighting], [mood], 
[camera/lens], [film reference], [artist reference], [technical parameters]"

Parameters:
--ar 2.39:1 (cinematic widescreen)
--ar 1.85:1 (standard cinematic)
--ar 4:3 (vintage/classic)
--s 750 (stylization, higher = more artistic)
--c 15 (chaos, slight variation)
--v 6.1 (version)
--q 2 (quality)
--style raw (less Midjourney default styling)

Example:
"Cinematic wide shot, lone astronaut standing on the surface of Mars, 
vast red desert stretching to horizon, tiny figure against enormous 
rock formations, dust storm brewing in distance. Golden hour light 
with deep shadows. Sense of isolation and awe. Shot on IMAX 70mm, 
Denis Villeneuve Dune cinematography style. --ar 2.39:1 --s 750 
--v 6.1 --style raw --q 2"

Midjourney-Specific Tips:
- Aspect ratio strongly affects composition
- --style raw for photorealistic results
- Camera lens specifications (35mm, 85mm) influence depth
- Artist references (Greg Rutkowski, Beeple, etc.) for style
- Weighted prompts (subject::2, background::1) for emphasis
```

### 7. Stable Diffusion / ComfyUI
```
Prompt Template:
"(masterpiece, best quality, cinematic:1.4), [subject], [environment], 
[lighting], [camera], [mood], [style], [details]"

Negative Prompt:
"(worst quality, low quality, normal quality:1.4), blurry, deformed, 
disfigured, bad anatomy, bad proportions, watermark, signature, text, 
logo, cropped, out of frame, duplicate, error, jpeg artifacts, 
ugly, morbid, mutated, extra limbs, fused fingers, too many fingers"

Parameters:
- Checkpoint: RealVisXL, JuggernautXL, or SDXL base
- CFG Scale: 7-9 (lower for artistic, higher for adherence)
- Sampler: DPM++ 2M Karras or Euler a
- Steps: 30-50
- Resolution: 1024x576 (for 16:9) or 1344x768

LoRA Recommendations:
- Film Grain LoRA (subtle grain)
- Cinematic Lighting LoRA
- Character-specific LoRAs for consistency

Example:
"(masterpiece, best quality, cinematic lighting:1.4), 
(cinematic wide shot:1.2), a weathered lighthouse keeper looking out 
from a storm-lashed lighthouse tower, lightning illuminating angry waves, 
rain streaming down glass windows. (dramatic chiaroscuro lighting:1.3), 
(rim light from lightning:1.2), cool blue and warm orange color contrast. 
Shot on 35mm film, grain visible. (atmospheric, moody, cinematic:1.3). 
Inspired by Christopher Nolan's visual style."

SD-Specific Tips:
- Weighted tokens (word:1.4) for emphasis
- Automatic1111: use Highres Fix for detail
- ComfyUI: custom node workflows for batch processing
- ControlNet: use depth maps and pose references for consistency
- IP-Adapter: use reference images for style and character consistency
```

### 8. Flux (Black Forest Labs)
```
Prompt Template:
"[Natural language cinematic description]. Be extremely specific about 
[visual details], [lighting conditions], [camera behavior], [emotional tone]."

Example:
"An ultra-detailed cinematic photograph of a ballerina performing 
a grand jeté in an empty, decaying grand theater. Dust motes caught 
in single shaft of golden light from a broken skylight above. 
The camera is positioned at stage level, slightly below her, 
capturing the full extension of her leap. Her white tutu contrasts 
against the dark, ornate theater interior. Shallow depth of field 
with the ballerina in perfect focus and the background softly blurred. 
Film grain, Kodak Portra 800 color characteristics. Melancholic beauty, 
transient moment frozen in time. Photographed by Gregory Crewdson."

Flux-Specific Tips:
- Extremely detailed natural language works best
- Specific camera positions ("camera at stage level") improve composition
- Film stock references produce authentic grain and color
- Artist photographer references strongly influence style
- No special parameters needed — just detailed descriptions
```

## Character Consistency System

### Master Character Description Template
```
CHARACTER_ID: [name]
PHYSICAL: [age], [gender], [height], [build], [skin tone], 
          [hair color/style], [eye color], [distinguishing features]
WARDROBE: [outfit description], [colors], [style era], [condition]
EXPRESSION BASELINE: [default expression], [emotional range]
LIGHTING: [typical lighting on face], [shadow patterns]
SCALE: [height relative to environment], [proportions]

AI CONSISTENCY TOKENS:
- Face: "same face, identical features, consistent facial structure"
- Hair: "same [color] [style] hair"
- Outfit: "wearing [exact outfit description]"
- Build: "same body type, same proportions"
- Age: "[age]-year-old appearance"
```

### Character Variation Prompts
```
# Same character, different angle
"[character_description], [new_angle_description], 
consistent appearance with previous frames, same character"

# Same character, different lighting
"[character_description], [new_lighting_description], 
same face, same outfit, same proportions, different lighting conditions"

# Same character, different action
"[character_description], [new_action_description], 
same person, same appearance, different pose and action"
```

### Negative Prompts for Character Consistency
```
"different face, changed appearance, different person, different outfit, 
changed proportions, age change, different hair, different skin tone, 
inconsistent character, character swap, face swap"
```

## Scene Continuity System

### Location Consistency Tokens
```
LOCATION_ID: [name]
MASTER DESCRIPTION: [detailed environment description]
KEY ELEMENTS: [list of permanent features]
ATMOSPHERE BASELINE: [default weather, time, mood]
COLOR BASELINE: [default palette for this location]

VARIATION PROMPTS:
- Time change: "same [location], now at [new_time], same architecture, 
  same layout, different lighting"
- Weather change: "same [location], now with [new_weather], 
  same buildings, same streets, atmospheric change"
- Season change: "same [location], now in [new_season], 
  same structures, vegetation changed"
```

### Temporal Video Continuity
```
# Shot-to-shot transition prompts
PREVIOUS_SHOT: [description of ending frame]
NEXT_SHOT: [description of starting frame]
TRANSITION: "smooth transition from [previous] to [next], 
continuous motion, temporal coherence"

# Action continuity
ACTION_SEQUENCE: [character] [action_part_1], then [action_part_2], 
then [action_part_3]. "Same character, same location, continuous action, 
seamless motion between frames"
```

## Cinematic Style Reference Library

### Director Style Prompts
```
Denis Villeneuve: "cinematic wide shots, monumental scale, 
moody atmospheric lighting, desaturated color palette, 
minimalist composition, contemplative pacing"

Christopher Nolan: "practical effects, IMAX scale, 
practical lighting, temporal manipulation, complex narrative structure, 
dramatic wide-angle compositions"

Wes Anderson: "symmetrical compositions, pastel color palette, 
flat lighting, centered framing, whimsical production design, 
meticulous detail"

Sofia Coppola: "soft natural lighting, intimate close-ups, 
dreamlike atmosphere, pastel and muted tones, 
nostalgic mood, delicate emotional moments"

Bong Joon-ho: "dynamic camera movement, social commentary visualized, 
 genre-blending, dark humor, detailed production design, 
unexpected compositions"

Studio Ghibli: "hand-painted aesthetic, lush natural environments, 
whimsical character design, warm lighting, environmental storytelling, 
magical realism"

Pixar: "vibrant color palette, emotionally expressive characters, 
meticulous world-building, dynamic lighting, heartfelt storytelling, 
accessible yet profound"
```

### Cinematographer Style Prompts
```
Roger Deakins: "masterful natural lighting, subtle color grading, 
elegant camera movement, atmospheric depth, painterly compositions"

Emmanuel Lubezki: "natural light, long continuous takes, 
immersive camera work, poetic wide shots, organic movement"

Hoyte van Hoytema: "IMAX scale, deep focus, practical lighting, 
dense compositions, rich detail, immersive wide shots"

Rachel Morrison: "emotional lighting, intimate framing, 
natural skin tones, subtle color storytelling, authentic atmosphere"
```

## Shot Type Prompt Templates

```
ESTABLISHING SHOT:
"Wide establishing shot of [location], [time of day], 
[atmosphere], [scale reference], [camera behavior]"

CLOSE-UP:
"Intimate close-up of [subject's feature], [expression/emotion], 
[lighting on face], [shallow depth of field], [bokeh background], 
[skin texture detail]"

OVER-THE-SHOULDER:
"Over-the-shoulder shot, [foreground character's shoulder] in 
soft focus, [background subject] in sharp focus, 
[conversation context], [spatial relationship]"

POV SHOT:
"First-person POV shot, [character's] perspective, 
[what they see], [motion/movement], [emotional context], 
[head movement/ breathing]"

AERIAL SHOT:
"Cinematic aerial/drone shot, [location] from above, 
[scale reveal], [movement pattern], [atmospheric conditions], 
[lighting from above]"

TRACKING SHOT:
"Dynamic tracking shot following [subject] through [environment], 
[camera movement type], [background blur/motion], 
[speed/urgency feeling], [spatial depth]"
```

## Color Palette Prompt Engineering

```
WARM/GOLDEN: "warm golden hour lighting, amber and honey tones, 
soft orange highlights, rich brown shadows, nostalgic warmth"

COOL/BLUE: "cool blue-toned lighting, steel blue and cyan palette, 
cold atmosphere, icy highlights, deep navy shadows, isolation"

NEON/CYBER: "neon-lit environment, electric blue and hot pink highlights, 
deep purple shadows, reflective surfaces, futuristic glow"

EARTHY/NATURAL: "natural earth tones, olive greens and warm browns, 
sun-dappled lighting, organic textures, grounded atmosphere"

DESATURATED/DRAMATIC: "desaturated color palette, near-monochrome 
with single accent color, high contrast, dramatic chiaroscuro, 
moody atmosphere"

PASTEL/DREAMY: "soft pastel color palette, powder blues and blush pinks, 
diffused lighting, dreamy haze, gentle gradients, ethereal mood"
```

## Quality Assurance Checklist

Before finalizing any prompt set, verify:
- [ ] Character descriptions are specific and consistent across all prompts
- [ ] Location descriptions maintain continuity across scenes
- [ ] Lighting descriptions match the emotional arc progression
- [ ] Camera movements have clear motivation
- [ ] Color palettes are consistent within scenes, evolve across acts
- [ ] Style references match the intended cinematic vision
- [ ] Technical specifications match target platform capabilities
- [ ] Negative prompts prevent common AI artifacts
- [ ] Temporal continuity is maintained across video sequences
- [ ] All prompts include sufficient detail for high-quality output
- [ ] Prompts are optimized for their specific platform's strengths
