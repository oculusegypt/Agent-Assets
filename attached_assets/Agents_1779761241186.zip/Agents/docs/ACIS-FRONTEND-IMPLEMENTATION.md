# ACIS Frontend Implementation — Cinematic Production Dashboard

## Architecture

```
Next.js 15 App Router
    ↓
React Server Components + Client Components
    ↓
Zustand State Management (FilmState)
    ↓
WebSocket Client (Real-time updates)
    ↓
Three.js / WebGPU Background Layer
    ↓
Shadcn UI + Tailwind CSS
    ↓
Framer Motion + GSAP Animations
```

## State Management (Zustand)

```typescript
// stores/filmStore.ts
import { create } from 'zustand';

interface FilmState {
  filmId: string | null;
  idea: string;
  genre: string;
  status: 'idle' | 'initializing' | 'story' | 'scenes' | 'production' | 
          'routing' | 'rendering' | 'critic' | 'timeline' | 'post' | 'complete';
  progress: number;
  scenes: Scene[];
  assets: Record<string, Asset[]>;
  timeline: Timeline | null;
  finalRender: string | null;
  qualityScores: Record<string, number>;
  modelDecisions: ModelDecision[];
  logs: LogEntry[];
  
  // Actions
  startProduction: (idea: string, genre?: string) => void;
  updateProgress: (progress: number) => void;
  addScene: (scene: Scene) => void;
  updateScene: (sceneId: string, updates: Partial<Scene>) => void;
  addAsset: (asset: Asset) => void;
  addLog: (log: LogEntry) => void;
  setStatus: (status: FilmState['status']) => void;
}

export const useFilmStore = create<FilmState>((set) => ({
  filmId: null,
  idea: '',
  genre: '',
  status: 'idle',
  progress: 0,
  scenes: [],
  assets: {},
  timeline: null,
  finalRender: null,
  qualityScores: {},
  modelDecisions: [],
  logs: [],
  
  startProduction: (idea, genre) => set({ idea, genre, status: 'initializing', progress: 0 }),
  updateProgress: (progress) => set({ progress }),
  addScene: (scene) => set((state) => ({ scenes: [...state.scenes, scene] })),
  updateScene: (sceneId, updates) => set((state) => ({
    scenes: state.scenes.map(s => s.id === sceneId ? { ...s, ...updates } : s)
  })),
  addAsset: (asset) => set((state) => ({
    assets: { ...state.assets, [asset.sceneId]: [...(state.assets[asset.sceneId] || []), asset] }
  })),
  addLog: (log) => set((state) => ({ logs: [...state.logs, log] })),
  setStatus: (status) => set({ status })
}));
```

## WebSocket Client

```typescript
// hooks/useWebSocket.ts
import { useEffect } from 'react';
import { useFilmStore } from '@/stores/filmStore';

export function useFilmWebSocket(filmId: string | null) {
  const addLog = useFilmStore(state => state.addLog);
  const updateScene = useFilmStore(state => state.updateScene);
  const updateProgress = useFilmStore(state => state.updateProgress);
  const addAsset = useFilmStore(state => state.addAsset);
  const setStatus = useFilmStore(state => state.setStatus);
  
  useEffect(() => {
    if (!filmId) return;
    
    const ws = new WebSocket(`ws://localhost:8000/ws/film/${filmId}`);
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'status_update':
          setStatus(data.status);
          updateProgress(data.progress);
          break;
          
        case 'job_queued':
          addLog({
            timestamp: new Date(),
            type: 'info',
            message: `Job queued: ${data.asset_type} for scene ${data.scene_id}`,
            model: data.model
          });
          break;
          
        case 'asset_complete':
          addAsset({
            sceneId: data.scene_id,
            type: data.asset_type,
            model: data.model,
            qualityScore: data.score,
            status: 'complete'
          });
          addLog({
            timestamp: new Date(),
            type: 'success',
            message: `Asset complete: ${data.asset_type} (score: ${data.score})`,
            model: data.model
          });
          break;
          
        case 'asset_retry':
          addLog({
            timestamp: new Date(),
            type: 'warning',
            message: `Asset retry: ${data.asset_id} (${data.reason})`,
            model: data.fallback_model
          });
          break;
          
        case 'scene_complete':
          updateScene(data.scene_id, { status: 'complete', qualityScore: data.avg_score });
          break;
          
        case 'fallback_triggered':
          addLog({
            timestamp: new Date(),
            type: 'warning',
            message: `Fallback triggered: ${data.original_model} → ${data.fallback_model}`,
            reason: data.reason
          });
          break;
          
        case 'error':
          addLog({
            timestamp: new Date(),
            type: 'error',
            message: data.message
          });
          break;
          
        case 'production_complete':
          setStatus('complete');
          updateProgress(100);
          break;
      }
    };
    
    return () => ws.close();
  }, [filmId]);
}
```

## Core Components

### Control Room Layout

```tsx
// app/page.tsx
import { ControlRoom } from '@/components/ControlRoom';

export default function Home() {
  return <ControlRoom />;
}

// components/ControlRoom.tsx
'use client';

import { FilmHeader } from './FilmHeader';
import { ScenePanel } from './ScenePanel';
import { LivePreview } from './LivePreview';
import { AssetLibrary } from './AssetLibrary';
import { TimelineEngine } from './TimelineEngine';
import { AILogs } from './AILogs';
import { ModelRouterViewer } from './ModelRouterViewer';
import { useFilmStore } from '@/stores/filmStore';

export function ControlRoom() {
  const status = useFilmStore(state => state.status);
  
  return (
    <div className="h-screen w-screen bg-[#050508] text-white overflow-hidden flex flex-col">
      {/* Header */}
      <FilmHeader />
      
      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel — Scenes */}
        <div className="w-80 flex flex-col border-r border-white/5">
          <ScenePanel />
        </div>
        
        {/* Center — Live Preview + Timeline */}
        <div className="flex-1 flex flex-col">
          <div className="flex-1">
            <LivePreview />
          </div>
          <div className="h-80 border-t border-white/5">
            <TimelineEngine />
          </div>
        </div>
        
        {/* Right Panel — Assets + AI Logs */}
        <div className="w-96 flex flex-col border-l border-white/5">
          <AssetLibrary />
          <div className="flex-1 overflow-y-auto">
            <AILogs />
          </div>
        </div>
      </div>
      
      {/* Bottom Bar — Model Routing */}
      <div className="h-16 border-t border-white/5 bg-white/[0.02]">
        <ModelRouterViewer />
      </div>
    </div>
  );
}
```

### Film Header

```tsx
// components/FilmHeader.tsx
'use client';

import { useFilmStore } from '@/stores/filmStore';
import { Film, Play, Pause, Circle, Zap } from 'lucide-react';

export function FilmHeader() {
  const { filmId, idea, status, progress, qualityScores } = useFilmStore();
  const avgQuality = Object.values(qualityScores).reduce((a, b) => a + b, 0) / 
    (Object.keys(qualityScores).length || 1);
  
  return (
    <div className="h-14 bg-white/[0.03] border-b border-white/5 flex items-center px-6 gap-6">
      <div className="flex items-center gap-3">
        <Film className="w-5 h-5 text-amber-400" />
        <span className="font-semibold text-sm">ACIS</span>
      </div>
      
      {filmId && (
        <>
          <div className="h-6 w-px bg-white/10" />
          
          <div className="flex items-center gap-2 text-sm text-white/60">
            <span className="font-mono text-xs text-amber-400/60">{filmId.slice(0, 8)}</span>
            <span className="truncate max-w-[200px]">{idea}</span>
          </div>
          
          <div className="h-6 w-px bg-white/10" />
          
          <div className="flex items-center gap-3">
            <StatusBadge status={status} />
            <div className="w-40 h-1.5 bg-white/5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-amber-400 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            <span className="text-xs font-mono text-white/40">{progress.toFixed(0)}%</span>
          </div>
          
          <div className="h-6 w-px bg-white/10" />
          
          <div className="flex items-center gap-2 text-xs">
            <Circle className={`w-2 h-2 ${avgQuality >= 85 ? 'text-emerald-400' : 'text-amber-400'}`} fill="currentColor" />
            <span className="text-white/40">Quality</span>
            <span className="font-mono">{avgQuality.toFixed(1)}</span>
          </div>
          
          <div className="flex items-center gap-2 text-xs">
            <Zap className="w-3 h-3 text-cyan-400" />
            <span className="text-white/40">Cost</span>
            <span className="font-mono text-emerald-400">FREE</span>
          </div>
        </>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    idle: 'text-white/40',
    initializing: 'text-cyan-400',
    story: 'text-purple-400',
    scenes: 'text-blue-400',
    production: 'text-amber-400',
    routing: 'text-pink-400',
    rendering: 'text-amber-400 animate-pulse',
    critic: 'text-orange-400',
    timeline: 'text-teal-400',
    post: 'text-rose-400',
    complete: 'text-emerald-400'
  };
  
  return (
    <span className={`text-xs font-mono uppercase ${colors[status] || 'text-white/40'}`}>
      {status.replace('_', ' ')}
    </span>
  );
}
```

### Scene Panel with Production Units

```tsx
// components/ScenePanel.tsx
'use client';

import { useFilmStore } from '@/stores/filmStore';
import { Film, Play, RotateCcw, Eye, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export function ScenePanel() {
  const { scenes, updateScene } = useFilmStore();
  
  const produceScene = async (sceneId: string) => {
    updateScene(sceneId, { status: 'generating' });
    
    // Call API to produce scene
    const response = await fetch('/api/scene/produce', {
      method: 'POST',
      body: JSON.stringify({ scene_id: sceneId })
    });
    
    if (response.ok) {
      updateScene(sceneId, { status: 'complete' });
    } else {
      updateScene(sceneId, { status: 'error' });
    }
  };
  
  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-white/5">
        <h2 className="text-sm font-semibold text-white/80 flex items-center gap-2">
          <Film className="w-4 h-4" />
          Scenes
        </h2>
      </div>
      
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {scenes.length === 0 ? (
          <div className="text-center py-8 text-white/20 text-xs">
            No scenes yet. Start a production.
          </div>
        ) : (
          scenes.map(scene => (
            <SceneCard key={scene.id} scene={scene} onProduce={produceScene} />
          ))
        )}
      </div>
    </div>
  );
}

function SceneCard({ scene, onProduce }: { scene: Scene, onProduce: (id: string) => void }) {
  const statusColors: Record<string, string> = {
    queued: 'bg-white/5 text-white/40',
    generating: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    complete: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    error: 'bg-red-500/10 text-red-400 border-red-500/20'
  };
  
  return (
    <div className={`p-3 rounded-lg border ${statusColors[scene.status] || 'bg-white/5'} 
      hover:border-white/10 transition-colors cursor-pointer group`}>
      <div className="flex items-start justify-between mb-2">
        <div>
          <span className="text-xs font-mono opacity-60">{scene.id}</span>
          <h3 className="text-sm font-medium mt-0.5">{scene.title}</h3>
        </div>
        <Badge variant="outline" className="text-xs font-mono">
          {scene.duration}
        </Badge>
      </div>
      
      <div className="flex items-center gap-1.5 mb-2">
        <Badge className={`text-[10px] ${getEmotionColor(scene.emotion)}`}>
          {scene.emotion}
        </Badge>
        <Badge variant="outline" className="text-[10px]">
          {scene.shots?.length || 0} shots
        </Badge>
      </div>
      
      {/* Asset Preview */}
      <div className="grid grid-cols-4 gap-1 mb-2">
        {['image', 'video', 'audio', 'music'].map(type => (
          <div key={type} className="aspect-video bg-black/30 rounded border border-white/5 
            flex items-center justify-center">
            <div className={`w-1.5 h-1.5 rounded-full ${
              scene.assets?.[type]?.length > 0 ? 'bg-emerald-400' : 'bg-white/10'
            }`} />
          </div>
        ))}
      </div>
      
      {/* Actions */}
      <div className="flex gap-1.5">
        {scene.status === 'complete' ? (
          <>
            <Button size="sm" variant="ghost" className="h-7 text-xs flex-1">
              <Eye className="w-3 h-3 mr-1" /> View
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-xs">
              <RotateCcw className="w-3 h-3" />
            </Button>
          </>
        ) : scene.status === 'generating' ? (
          <Button size="sm" disabled className="h-7 text-xs flex-1 bg-amber-500/20">
            <Loader2 className="w-3 h-3 mr-1 animate-spin" /> Producing...
          </Button>
        ) : (
          <Button 
            size="sm" 
            className="h-7 text-xs flex-1 bg-amber-500/20 hover:bg-amber-500/30"
            onClick={() => onProduce(scene.id)}
          >
            <Play className="w-3 h-3 mr-1" /> Produce Scene
          </Button>
        )}
      </div>
    </div>
  );
}

function getEmotionColor(emotion: string): string {
  const colors: Record<string, string> = {
    hope: 'bg-cyan-500/20 text-cyan-400',
    tension: 'bg-amber-500/20 text-amber-400',
    conflict: 'bg-rose-500/20 text-rose-400',
    climax: 'bg-purple-500/20 text-purple-400',
    resolution: 'bg-emerald-500/20 text-emerald-400'
  };
  return colors[emotion] || 'bg-white/10';
}
```

### Live Preview

```tsx
// components/LivePreview.tsx
'use client';

import { useFilmStore } from '@/stores/filmStore';
import { Play, Pause, Maximize2 } from 'lucide-react';

export function LivePreview() {
  const { scenes, finalRender, status } = useFilmStore();
  
  return (
    <div className="relative h-full bg-black flex items-center justify-center">
      {/* Video or Placeholder */}
      {finalRender ? (
        <video 
          src={finalRender} 
          controls 
          className="max-w-full max-h-full"
          poster={scenes[0]?.assets?.images?.[0]?.url}
        />
      ) : (
        <div className="text-center">
          <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 
            flex items-center justify-center mx-auto mb-4">
            <Play className="w-6 h-6 text-white/20" />
          </div>
          <p className="text-white/20 text-sm">
            {status === 'complete' ? 'Film ready' : 'Preview will appear here'}
          </p>
          {status === 'rendering' && (
            <div className="mt-4 flex items-center justify-center gap-2">
              <div className="w-4 h-4 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin" />
              <span className="text-xs text-amber-400/60 font-mono">Rendering...</span>
            </div>
          )}
        </div>
      )}
      
      {/* Overlay Controls */}
      {finalRender && (
        <div className="absolute bottom-4 right-4">
          <button className="p-2 bg-black/50 rounded-lg hover:bg-black/70 transition-colors">
            <Maximize2 className="w-4 h-4 text-white/60" />
          </button>
        </div>
      )}
    </div>
  );
}
```

### Timeline Engine

```tsx
// components/TimelineEngine.tsx
'use client';

import { useState, useRef, useEffect } from 'react';
import { useFilmStore } from '@/stores/filmStore';

const TRACKS = [
  { id: 'V1', name: 'Video', type: 'video', color: 'bg-blue-500/20' },
  { id: 'V2', name: 'VFX', type: 'video', color: 'bg-purple-500/20' },
  { id: 'A1', name: 'Dialogue', type: 'audio', color: 'bg-cyan-500/20' },
  { id: 'A2', name: 'Music', type: 'audio', color: 'bg-pink-500/20' },
  { id: 'A3', name: 'Foley', type: 'audio', color: 'bg-amber-500/20' },
  { id: 'A4', name: 'Atmosphere', type: 'audio', color: 'bg-teal-500/20' },
  { id: 'A5', name: 'SFX', type: 'audio', color: 'bg-rose-500/20' }
];

export function TimelineEngine() {
  const { scenes, timeline } = useFilmStore();
  const [zoom, setZoom] = useState(1);
  const [playhead, setPlayhead] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const timelineRef = useRef<HTMLDivElement>(null);
  
  // Frame-based playhead
  useEffect(() => {
    if (!isPlaying) return;
    
    const interval = setInterval(() => {
      setPlayhead(p => (p + 1) % (24 * 60 * 20)); // 20 min max
    }, 1000 / 24);
    
    return () => clearInterval(interval);
  }, [isPlaying]);
  
  // Convert playhead to SMPTE
  const frames = playhead % 24;
  const seconds = Math.floor(playhead / 24) % 60;
  const minutes = Math.floor(playhead / (24 * 60));
  const smpte = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}:${String(frames).padStart(2, '0')}`;
  
  return (
    <div className="h-full flex flex-col">
      {/* SMPTE Ruler */}
      <div className="h-6 bg-white/[0.02] border-b border-white/5 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 flex text-[10px] font-mono text-white/30 
          select-none" style={{ transform: `translateX(${-playhead * zoom}px)` }}>
          {Array.from({ length: 20 * 60 }, (_, m) => (
            <div key={m} className="flex-shrink-0 w-20 border-l border-white/5">
              {m % 60 === 0 ? `${String(Math.floor(m / 60)).padStart(2, '0')}:00:00` : ''}
            </div>
          ))}
        </div>
      </div>
      
      {/* Tracks */}
      <div className="flex-1 overflow-y-auto overflow-x-auto relative" ref={timelineRef}>
        {TRACKS.map(track => (
          <div key={track.id} className="h-10 flex items-center border-b border-white/5 relative">
            {/* Track Label */}
            <div className="w-24 flex-shrink-0 px-3 text-[10px] font-mono text-white/40 
              border-r border-white/5 h-full flex items-center">
              {track.id}
            </div>
            
            {/* Track Clips */}
            <div className="flex-1 relative h-full">
              {scenes.map((scene, idx) => {
                const start = idx * 10 * 24; // Each scene ~10 seconds for demo
                const width = 10 * 24 * zoom;
                
                return (
                  <div
                    key={scene.id}
                    className={`absolute top-1 bottom-1 rounded ${track.color} 
                      border border-white/10 hover:border-white/30 transition-colors 
                      cursor-pointer flex items-center px-2 overflow-hidden`}
                    style={{
                      left: `${start * zoom}px`,
                      width: `${width}px`
                    }}
                  >
                    <span className="text-[10px] text-white/60 truncate">
                      {scene.id}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        
        {/* Playhead */}
        <div 
          className="absolute top-0 bottom-0 w-px bg-red-500 z-10 pointer-events-none"
          style={{ left: `${playhead * zoom + 96}px` }}
        >
          <div className="absolute -top-1 -left-1 w-0 h-0 border-l-[6px] border-l-transparent 
            border-r-[6px] border-r-transparent border-t-[8px] border-t-red-500" />
        </div>
      </div>
      
      {/* Transport Controls */}
      <div className="h-8 bg-white/[0.02] border-t border-white/5 flex items-center px-3 gap-4">
        <button onClick={() => setIsPlaying(!isPlaying)} className="text-white/60 hover:text-white">
          {isPlaying ? '⏸' : '▶'}
        </button>
        <span className="font-mono text-xs text-amber-400">{smpte}</span>
        <div className="flex-1" />
        <input 
          type="range" 
          min={0.1} 
          max={5} 
          step={0.1} 
          value={zoom}
          onChange={e => setZoom(parseFloat(e.target.value))}
          className="w-24"
        />
        <span className="text-[10px] text-white/30">{zoom.toFixed(1)}x</span>
      </div>
    </div>
  );
}
```

### AI Logs Panel

```tsx
// components/AILogs.tsx
'use client';

import { useFilmStore } from '@/stores/filmStore';
import { CheckCircle, AlertTriangle, Loader2, Info, XCircle } from 'lucide-react';

const typeIcons: Record<string, any> = {
  info: Info,
  success: CheckCircle,
  warning: AlertTriangle,
  error: XCircle
};

const typeColors: Record<string, string> = {
  info: 'text-blue-400',
  success: 'text-emerald-400',
  warning: 'text-amber-400',
  error: 'text-red-400'
};

export function AILogs() {
  const logs = useFilmStore(state => state.logs);
  
  return (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b border-white/5">
        <h3 className="text-xs font-semibold text-white/60">AI Logs</h3>
      </div>
      
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {logs.map((log, idx) => {
          const Icon = typeIcons[log.type] || Info;
          const color = typeColors[log.type] || 'text-white/40';
          
          return (
            <div key={idx} className="flex items-start gap-2 p-1.5 rounded hover:bg-white/[0.02] 
              text-[11px]">
              <Icon className={`w-3 h-3 mt-0.5 flex-shrink-0 ${color}`} />
              <div className="flex-1 min-w-0">
                <p className="text-white/60 truncate">{log.message}</p>
                {log.model && (
                  <span className="text-white/30 font-mono text-[10px]">{log.model}</span>
                )}
                <span className="text-white/20 text-[9px] ml-2">
                  {log.timestamp.toLocaleTimeString()}
                </span>
              </div>
            </div>
          );
        })}
        
        {logs.length === 0 && (
          <div className="text-center py-4 text-white/20 text-[10px]">
            Waiting for production events...
          </div>
        )}
      </div>
    </div>
  );
}
```

## Export System

```tsx
// components/ExportPanel.tsx
'use client';

import { useState } from 'react';
import { useFilmStore } from '@/stores/filmStore';
import { Download, Film, FileText, Music, Image } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function ExportPanel() {
  const { filmId, status, finalRender } = useFilmStore();
  const [exporting, setExporting] = useState(false);
  
  const exportFilm = async (mode: 'preview' | 'cinematic' | 'master') => {
    setExporting(true);
    
    const response = await fetch('/api/film/export', {
      method: 'POST',
      body: JSON.stringify({ film_id: filmId, mode })
    });
    
    if (response.ok) {
      const data = await response.json();
      window.open(data.url, '_blank');
    }
    
    setExporting(false);
  };
  
  if (status !== 'complete') return null;
  
  return (
    <div className="p-4 border-t border-white/5 bg-white/[0.02]">
      <h3 className="text-sm font-semibold text-white/80 mb-3 flex items-center gap-2">
        <Download className="w-4 h-4" />
        Export Final Film
      </h3>
      
      <div className="grid grid-cols-3 gap-2">
        <Button
          variant="outline"
          className="flex-col h-auto py-3 border-white/10 hover:bg-white/5"
          onClick={() => exportFilm('preview')}
          disabled={exporting}
        >
          <Film className="w-4 h-4 mb-1 text-white/40" />
          <span className="text-[10px]">Preview</span>
          <span className="text-[9px] text-white/30">720p H.264</span>
        </Button>
        
        <Button
          variant="outline"
          className="flex-col h-auto py-3 border-white/10 hover:bg-white/5"
          onClick={() => exportFilm('cinematic')}
          disabled={exporting}
        >
          <Film className="w-4 h-4 mb-1 text-amber-400/60" />
          <span className="text-[10px]">Cinematic</span>
          <span className="text-[9px] text-white/30">1080p H.265</span>
        </Button>
        
        <Button
          variant="outline"
          className="flex-col h-auto py-3 border-white/10 hover:bg-white/5"
          onClick={() => exportFilm('master')}
          disabled={exporting}
        >
          <Film className="w-4 h-4 mb-1 text-purple-400/60" />
          <span className="text-[10px]">Master</span>
          <span className="text-[9px] text-white/30">ProRes 2K</span>
        </Button>
      </div>
      
      <div className="mt-3 grid grid-cols-3 gap-2">
        <Button variant="ghost" size="sm" className="text-[10px]">
          <FileText className="w-3 h-3 mr-1" /> OTIO
        </Button>
        <Button variant="ghost" size="sm" className="text-[10px]">
          <Music className="w-3 h-3 mr-1" /> Stems
        </Button>
        <Button variant="ghost" size="sm" className="text-[10px]">
          <Image className="w-3 h-3 mr-1" /> Assets
        </Button>
      </div>
    </div>
  );
}
```

## Styling System

```css
/* globals.css */
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --bg-primary: #050508;
    --bg-secondary: #0a0a10;
    --bg-elevated: #101018;
    --accent-gold: #d4a853;
    --accent-cyan: #4ecdc4;
    --accent-rose: #ff6b6b;
    --accent-purple: #a855f7;
    --text-primary: #f5f5f0;
    --text-secondary: #b8b8b0;
    --text-muted: #6b6b6b;
    --border-subtle: rgba(255,255,255,0.06);
  }
  
  body {
    @apply bg-[#050508] text-white antialiased;
    font-family: 'Inter', 'Noto Naskh Arabic', sans-serif;
  }
  
  ::-webkit-scrollbar {
    @apply w-1.5;
  }
  ::-webkit-scrollbar-track {
    @apply bg-transparent;
  }
  ::-webkit-scrollbar-thumb {
    @apply bg-white/10 rounded-full;
  }
}

@layer components {
  .glass-panel {
    @apply bg-white/[0.03] backdrop-blur-xl border border-white/[0.06] 
      shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)];
  }
  
  .cinematic-glow {
    @apply shadow-[0_0_30px_rgba(212,168,83,0.15),0_0_60px_rgba(212,168,83,0.05)];
  }
}
```

## Package.json

```json
{
  "name": "acis-studio",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "next": "^15.0.0",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "zustand": "^5.0.0",
    "framer-motion": "^11.0.0",
    "gsap": "^3.12.0",
    "three": "^0.170.0",
    "@react-three/fiber": "^9.0.0",
    "@react-three/drei": "^9.0.0",
    "lucide-react": "^0.460.0",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.1.0",
    "tailwind-merge": "^2.5.0",
    "@radix-ui/react-slot": "^1.1.0",
    "@radix-ui/react-dialog": "^1.1.0",
    "@radix-ui/react-dropdown-menu": "^2.1.0",
    "@radix-ui/react-tooltip": "^1.1.0"
  },
  "devDependencies": {
    "typescript": "^5.6.0",
    "@types/node": "^22.0.0",
    "@types/react": "^19.0.0",
    "@types/react-dom": "^19.0.0",
    "@types/three": "^0.170.0",
    "tailwindcss": "^4.0.0",
    "postcss": "^8.4.0",
    "autoprefixer": "^10.4.0",
    "eslint": "^9.0.0",
    "eslint-config-next": "^15.0.0"
  }
}
```
