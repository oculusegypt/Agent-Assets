# From Storyboard To Vision — Frontend Component Specifications

## Technology Stack
- **Framework**: Next.js 15 (App Router)
- **UI Library**: React 19, TailwindCSS 4
- **Animation**: Framer Motion + GSAP (optional)
- **3D**: Three.js (hero background effects)
- **Icons**: Lucide React
- **Fonts**: Cinematic serif (Playfair Display, Cinzel) + Clean sans (Inter, SF Pro)

## Design System

### Color Palette (Cinematic Dark Theme)
```
--color-bg-primary: #0a0a0f       (Deep black with blue undertone)
--color-bg-secondary: #12121a     (Slightly lighter)
--color-bg-elevated: #1a1a2e      (Card backgrounds)
--color-bg-glass: rgba(26,26,46,0.7) (Glassmorphism)

--color-accent-gold: #d4a853      (Premium gold)
--color-accent-warm: #e8c87a      (Warm highlight)
--color-accent-cyan: #4ecdc4      (Cool highlight)
--color-accent-rose: #ff6b6b      (Emotional red)

--color-text-primary: #f5f5f0     (Warm white)
--color-text-secondary: #b8b8b0   (Muted)
--color-text-muted: #6b6b6b       (Very muted)

--color-border: rgba(255,255,255,0.08)
--color-border-glow: rgba(212,168,83,0.3)

--gradient-hero: linear-gradient(180deg, #0a0a0f 0%, #12121a 50%, #1a1a2e 100%)
--gradient-card: linear-gradient(145deg, rgba(26,26,46,0.8), rgba(18,18,26,0.9))
--gradient-gold: linear-gradient(135deg, #d4a853, #e8c87a, #d4a853)
```

### Typography Scale
```
Display: 72px / Playfair Display / Weight 700 / Letter-spacing -2px
H1: 48px / Playfair Display / Weight 600 / Letter-spacing -1px
H2: 36px / Playfair Display / Weight 500
H3: 24px / Inter / Weight 600
Body: 16px / Inter / Weight 400 / Line-height 1.6
Caption: 14px / Inter / Weight 400 / Letter-spacing 0.5px
Mono: 13px / JetBrains Mono / Weight 400 (for timecodes, technical data)
```

### Spacing System
```
Space-xs: 4px
Space-sm: 8px
Space-md: 16px
Space-lg: 24px
Space-xl: 32px
Space-2xl: 48px
Space-3xl: 64px
Space-4xl: 96px
```

### Animation Tokens
```
Duration-fast: 150ms
Duration-normal: 300ms
Duration-slow: 500ms
Duration-cinematic: 800ms
Easing-default: cubic-bezier(0.4, 0, 0.2, 1)
Easing-enter: cubic-bezier(0, 0, 0.2, 1)
Easing-exit: cubic-bezier(0.4, 0, 1, 1)
Easing-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55)
```

## Component Specifications

### 1. Project Input Component
```
Location: /app/components/ProjectInput.tsx
Purpose: Story idea capture and submission

Features:
- Large text area with placeholder: "Describe your story idea..."
- Genre selector (dropdown with film genres)
- Tone selector (mood chips: Epic, Intimate, Dark, Hopeful, etc.)
- Target duration slider (1-120 minutes)
- Submit button with cinematic animation
- Voice input button (microphone icon with animation)
- Recent ideas sidebar (previous projects)

Animation:
- Text area: glow border on focus (gold gradient)
- Submit: ripple effect, transitions to loading state
- Genre chips: hover scale 1.05, active glow

States:
- Empty, Filling, Ready, Submitting, Error
```

### 2. Production Dashboard
```
Location: /app/components/ProductionDashboard.tsx
Purpose: Main production view with all sections

Layout:
- Sticky top navigation with project title
- Left sidebar: Section navigation (Structure, Scenes, Storyboard, etc.)
- Main content area: Scrollable sections
- Right panel: Inspector/Details for selected item

Sections:
1. Hero Banner (project title, logline, stats)
2. Timeline Navigation
3. Scene Cards Grid
4. Storyboard Viewer
5. Emotional Arc Graph
6. Audio Design Panel
7. AI Prompts Library
8. Export Panel

Animation:
- Section entrance: stagger fade-up (100ms delay per item)
- Scroll-triggered: Intersection Observer + GSAP
- Sidebar: slide-in from left on desktop, bottom sheet on mobile
```

### 3. Timeline Navigation Component
```
Location: /app/components/TimelineNav.tsx
Purpose: Horizontal scrollable timeline with scene markers

Features:
- Horizontal scroll container
- Scene markers as vertical bars
- Height of bar = emotional intensity
- Color of bar = emotion type (blue=hope, red=conflict, gold=climax)
- Timecode labels below
- Current position indicator (glowing dot)
- Click to jump to scene
- Zoom in/out buttons
- Hover: tooltip with scene info

Animation:
- Smooth scroll with momentum
- Marker entrance: scaleY from 0
- Current position: pulse animation
- Hover: marker glow, tooltip fade-in

Data:
- scenes[] with { id, number, title, timecode, emotionalIntensity, emotionType }
```

### 4. Scene Card Component
```
Location: /app/components/SceneCard.tsx
Purpose: Rich interactive card for each scene

Card Content:
┌─────────────────────────────────────────┐
│ SC-01                          [expand] │
│ The Awakening                             │
│ ───────────────────────────────────────── │
│ 🎬 Wide | Eye-level | Static              │
│ 💡 Natural | Golden Hour | Key+Rim        │
│ 🎵 Theme: Main (piano, strings)          │
│ 💭 Hope +3 | Duration: 2:30              │
│ ───────────────────────────────────────── │
│ [swatches] 🟦🟨🟧                         │
│ Characters: [ava] [kai]                   │
│ Transition: Fade In                       │
└─────────────────────────────────────────┘

Expanded Content:
- Full screenplay text
- Shot list breakdown
- Frame thumbnails
- Audio cue details
- AI prompts for this scene
- Edit/Regenerate buttons

Animation:
- Entrance: scale(0.95) → scale(1) + opacity 0→1
- Hover: translateY(-4px), shadow increase
- Expand: height auto, content fade-in
- Badge icons: subtle bounce on load

Props:
- scene: SceneData
- isExpanded: boolean
- onExpand: () => void
- onNavigate: () => void
```

### 5. Storyboard Viewer Component
```
Location: /app/components/StoryboardViewer.tsx
Purpose: Grid/lightbox view of all storyboard frames

Features:
- Masonry grid layout of frame thumbnails
- Each frame: image placeholder + frame number + shot info
- Click to open lightbox modal
- Lightbox: Large frame view + detailed info panel
- Navigation arrows (prev/next)
- Zoom controls
- Download frame description
- Filter by scene, shot type, emotion

Animation:
- Grid: stagger entrance (50ms per frame)
- Lightbox open: scale from thumbnail position
- Navigation: slide transition between frames
- Zoom: smooth scale with transform-origin center

Props:
- frames: StoryboardFrame[]
- selectedSceneId?: string
- onFrameSelect: (frameId) => void
```

### 6. Emotional Arc Graph Component
```
Location: /app/components/EmotionalArcGraph.tsx
Purpose: SVG line chart of emotional journey

Features:
- SVG-based responsive line chart
- X-axis: Scene progression
- Y-axis: Emotional intensity (-10 to +10)
- Colored line segments by emotion type
- Scene markers (dots) with hover tooltips
- Area fill with gradient
- Animate on load (draw line from left)
- Click marker to navigate to scene

Styling:
- Line: 3px, gradient stroke
- Markers: 8px circles with glow
- Area: gradient fill with 0.2 opacity
- Grid: subtle horizontal lines

Animation:
- Line draw: stroke-dasharray animation, 2s duration
- Markers: fade-in after line reaches them
- Tooltip: fade-in with scene info

Props:
- beats: EmotionalBeat[]
- onBeatClick: (beat) => void
```

### 7. Audio Design Panel Component
```
Location: /app/components/AudioDesignPanel.tsx
Purpose: Display audio cues with visual representation

Features:
- Cue list with timeline visualization
- Each cue: waveform placeholder + cue info
- Color-coded by type (music=blue, sfx=orange, ambience=green)
- Play button (simulated progress bar)
- Scene association
- Filter by type, scene
- Reference track links

Animation:
- Waveform: CSS animation of bars
- Play button: morph from play to pause
- Cue entrance: slide-in from right

Props:
- cues: AudioCue[]
- onCuePlay: (cueId) => void
```

### 8. AI Prompts Library Component
```
Location: /app/components/AIPromptsLibrary.tsx
Purpose: Platform-specific prompt display and copy

Features:
- Platform tabs (Sora, Veo, Runway, Kling, Pika, Midjourney, Flux, SD)
- Prompt cards with syntax highlighting
- Copy to clipboard button
- Character consistency reference panel
- Platform parameter badges
- Quality score indicator
- Generated media preview (if available)
- Filter by scene, shot, character

Animation:
- Tab switch: content crossfade (200ms)
- Copy: button morph to checkmark, revert after 2s
- Card entrance: stagger fade-up

Props:
- prompts: AIPrompt[]
- platforms: string[]
```

### 9. Export Panel Component
```
Location: /app/components/ExportPanel.tsx
Purpose: Production package export options

Features:
- Export type cards (HTML, Screenplay, Shot List, Storyboard, Full Package)
- Format selector per type
- Download buttons with progress
- Preview option for HTML
- Shareable link generation
- Cloud storage integration (optional)

Animation:
- Card hover: glow border
- Download: progress bar animation
- Success: confetti or checkmark animation

Props:
- projectId: string
- exports: Export[]
- onGenerateExport: (type, format) => void
```

### 10. Production Status Component
```
Location: /app/components/ProductionStatus.tsx
Purpose: Real-time agent execution status

Features:
- Phase indicators (1, 2, 3)
- Agent status cards (pending, running, completed, failed)
- Progress bars per agent
- Streaming update messages
- Retry failed agents button
- Estimated completion time

Animation:
- Status dot: pulse for running, check for completed, X for failed
- Progress bar: smooth width transition
- Phase completion: glow animation
- Messages: typewriter effect for streaming text

Props:
- phases: PhaseStatus[]
- onRetry: (agentName) => void
```

## Page Routes

```
/                          → Landing page with idea input
/projects                  → User's production list
/projects/new              → New production wizard
/projects/[id]             → Production dashboard (main view)
/projects/[id]/structure   → Story structure view
/projects/[id]/storyboard  → Full storyboard viewer
/projects/[id]/timeline    → Timeline + shot list
/projects/[id]/emotions    → Emotional arc deep dive
/projects/[id]/audio       → Audio design workspace
/projects/[id]/prompts     → AI prompts workspace
/projects/[id]/html        → Full-screen HTML experience
/projects/[id]/export      → Export center
```

## Responsive Breakpoints

```
Mobile: < 768px
- Single column layout
- Bottom sheet navigation
- Simplified timeline (vertical)
- Stacked scene cards
- Touch-optimized interactions
- Hamburger menu

Tablet: 768px - 1199px
- Two-column layout (sidebar + main)
- Horizontal timeline (condensed)
- Grid scene cards (2 columns)
- Touch + mouse support

Desktop: 1200px+
- Three-column layout (sidebar + main + inspector)
- Full horizontal timeline
- Grid scene cards (3-4 columns)
- Hover interactions
- Keyboard navigation
- Maximized storyboard viewer
```

## Accessibility Requirements

- WCAG 2.1 AA compliance
- Keyboard navigation (Tab, Arrow keys, Enter, Escape)
- Screen reader support (ARIA labels, roles, live regions)
- Color contrast ratios ≥ 4.5:1 for normal text, ≥ 3:1 for large text
- Reduced motion support (prefers-reduced-motion)
- Focus indicators visible
- RTL support for Arabic content

## Performance Targets

- First Contentful Paint: < 1.5s
- Largest Contentful Paint: < 2.5s
- Time to Interactive: < 3.5s
- Animation frame rate: 60fps
- Lighthouse Performance score: 90+
- Bundle size: < 200KB initial JS
- Image optimization: WebP/AVIF with fallbacks
- Code splitting: Route-based + component-based
