# ACIS Backend Implementation — Real Execution Layer

## Architecture

```
Frontend Request
    ↓
FastAPI Gateway (8000)
    ↓
LangGraph Orchestrator (FilmState)
    ↓
Scene Breakdown → Redis Queue → GPU Workers
    ↓
Asset Storage (MinIO/S3)
    ↓
Critic Engine → Timeline Assembly
    ↓
Post Production → Final Export
```

## FastAPI Gateway

### Entry Points

```python
from fastapi import FastAPI, WebSocket
from pydantic import BaseModel

app = FastAPI(title="ACIS Film Studio API")

class FilmRequest(BaseModel):
    idea: str
    genre_hint: str = None
    style: str = "cinematic"
    duration_estimate: str = None
    quality_mode: str = "cinematic"  # preview|cinematic|final_master

@app.post("/film/start")
async def start_film(request: FilmRequest):
    """Start a new film production session"""
    film_id = generate_uuid()
    
    # Initialize FilmState
    state = FilmState(
        film_id=film_id,
        idea=request.idea,
        genre=request.genre_hint,
        style=request.style,
        quality_mode=request.quality_mode,
        story={},
        scenes=[],
        shots=[],
        assets={"images": [], "videos": [], "audio": [], "music": []},
        timeline={},
        model_plan={},
        quality_scores={},
        final_render=None,
        status="initializing"
    )
    
    # Save to PostgreSQL
    await db.save_film_state(state)
    
    # Trigger LangGraph workflow
    asyncio.create_task(run_acis_pipeline(state))
    
    return {"film_id": film_id, "status": "production_started"}

@app.get("/film/{film_id}/status")
async def get_film_status(film_id: str):
    """Get current production status"""
    state = await db.get_film_state(film_id)
    return {
        "film_id": film_id,
        "status": state.status,
        "progress_percent": calculate_progress(state),
        "scenes_completed": len([s for s in state.scenes if s.render_ready]),
        "total_scenes": len(state.scenes),
        "assets_generated": len(state.assets["images"]) + len(state.assets["videos"]),
        "quality_average": calculate_avg_quality(state)
    }

@app.websocket("/ws/film/{film_id}")
async def film_websocket(websocket: WebSocket, film_id: str):
    """Real-time production updates"""
    await websocket.accept()
    
    # Subscribe to Redis pub/sub for this film
    pubsub = redis.pubsub()
    pubsub.subscribe(f"film:{film_id}:updates")
    
    async for message in pubsub.listen():
        if message["type"] == "message":
            await websocket.send_json(json.loads(message["data"]))
```

## LangGraph Orchestrator

### FilmState Definition

```python
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class Asset:
    id: str
    type: str  # image|video|audio|music
    model: str
    path: str
    url: str
    quality_score: float
    generation_time_ms: int
    retries: int = 0
    fallback_used: bool = False

@dataclass
class Scene:
    scene_id: str
    title: str
    act: str
    emotion: str
    duration_estimate: str
    shots: List[Dict] = field(default_factory=list)
    assets: Dict[str, List[Asset]] = field(default_factory=lambda: {"images": [], "videos": [], "audio": [], "music": []})
    timeline: Dict = field(default_factory=dict)
    quality_score: float = 0.0
    render_ready: bool = False

@dataclass
class FilmState:
    film_id: str
    idea: str
    genre: Optional[str] = None
    style: str = "cinematic"
    quality_mode: str = "cinematic"
    story: Dict = field(default_factory=dict)
    scenes: List[Scene] = field(default_factory=list)
    shots: List[Dict] = field(default_factory=list)
    assets: Dict[str, List[Asset]] = field(default_factory=lambda: {"images": [], "videos": [], "audio": [], "music": []})
    timeline: Dict = field(default_factory=dict)
    model_plan: Dict = field(default_factory=dict)
    quality_scores: Dict = field(default_factory=dict)
    final_render: Optional[str] = None
    status: str = "idle"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
```

### LangGraph Workflow

```python
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated
import operator

class FilmStateDict(TypedDict):
    film_id: str
    idea: str
    genre: str
    style: str
    story: dict
    scenes: Annotated[list, operator.add]
    assets: dict
    timeline: dict
    quality_scores: dict
    status: str

# Initialize graph
workflow = StateGraph(FilmStateDict)

# Define nodes
def director_node(state: FilmStateDict):
    """Analyze idea, detect genre, create production strategy"""
    state["genre"] = detect_genre(state["idea"])
    state["style"] = select_pipeline(state["genre"])
    state["model_plan"] = create_model_plan(state["style"], state["quality_mode"])
    state["status"] = "director_complete"
    return state

def story_node(state: FilmStateDict):
    """Generate screenplay with Gemini 2.5 Pro"""
    screenplay = generate_screenplay(
        idea=state["idea"],
        genre=state["genre"],
        style=state["style"]
    )
    state["story"] = screenplay
    state["status"] = "story_complete"
    return state

def scene_breakdown_node(state: FilmStateDict):
    """Break story into autonomous production units"""
    scenes = break_into_scenes(
        screenplay=state["story"],
        genre=state["genre"],
        model_plan=state["model_plan"]
    )
    state["scenes"] = scenes
    state["status"] = "scenes_complete"
    return state

def production_node(state: FilmStateDict):
    """Generate all assets for all scenes"""
    for scene in state["scenes"]:
        # Queue asset generation jobs
        jobs = create_asset_jobs(scene, state["model_plan"])
        for job in jobs:
            redis.lpush("asset_jobs", json.dumps(job))
    
    state["status"] = "production_queued"
    return state

def model_router_node(state: FilmStateDict):
    """Monitor job queue, route to appropriate GPU workers"""
    # This node runs in background, monitoring Redis queue
    # and routing jobs to GPU workers
    state["status"] = "routing_active"
    return state

def critic_node(state: FilmStateDict):
    """Evaluate all generated assets"""
    for scene in state["scenes"]:
        for asset_type, assets in scene.assets.items():
            for asset in assets:
                score = evaluate_asset(asset, scene.emotion)
                asset.quality_score = score
                
                if score < 85:
                    # Queue for regeneration
                    redis.lpush("retry_jobs", json.dumps({
                        "asset_id": asset.id,
                        "score": score,
                        "improvement_notes": generate_improvement_notes(asset)
                    }))
    
    state["status"] = "critic_complete"
    return state

def timeline_node(state: FilmStateDict):
    """Assemble all assets into multi-track timeline"""
    timeline = assemble_timeline(state["scenes"])
    state["timeline"] = timeline
    state["status"] = "timeline_complete"
    return state

def post_production_node(state: FilmStateDict):
    """Color grade, audio mix, final render"""
    final_render = run_post_production(
        timeline=state["timeline"],
        quality_mode=state["quality_mode"]
    )
    state["final_render"] = final_render
    state["status"] = "complete"
    return state

# Build graph
workflow.add_node("director", director_node)
workflow.add_node("story", story_node)
workflow.add_node("scenes", scene_breakdown_node)
workflow.add_node("production", production_node)
workflow.add_node("model_router", model_router_node)
workflow.add_node("critic", critic_node)
workflow.add_node("timeline", timeline_node)
workflow.add_node("post", post_production_node)

workflow.set_entry_point("director")
workflow.add_edge("director", "story")
workflow.add_edge("story", "scenes")
workflow.add_edge("scenes", "production")
workflow.add_edge("production", "model_router")
workflow.add_edge("model_router", "critic")
workflow.add_edge("critic", "timeline")
workflow.add_edge("timeline", "post")
workflow.add_edge("post", END)

# Compile
app = workflow.compile()
```

## Redis Queue System

### Queue Design

```python
import redis
import json

redis_client = redis.Redis(host='redis', port=6379, db=0)

# Queue structure
QUEUES = {
    "film_jobs": "acis:film_jobs",       # Film-level jobs
    "scene_jobs": "acis:scene_jobs",    # Scene-level jobs
    "asset_jobs": "acis:asset_jobs",    # Individual asset generation jobs
    "retry_jobs": "acis:retry_jobs",    # Failed asset retry jobs
    "render_jobs": "acis:render_jobs",  # Timeline render jobs
    "completed": "acis:completed"       # Completed jobs log
}

# Job structure
def create_asset_job(scene_id, asset_type, model, prompt, parameters):
    return {
        "job_id": generate_uuid(),
        "film_id": get_current_film_id(),
        "scene_id": scene_id,
        "asset_type": asset_type,
        "model": model,
        "prompt": prompt,
        "parameters": parameters,
        "priority": 5,  # 1-10, 10 = highest
        "gpu_requirements": get_gpu_requirements(model),
        "max_retries": 3,
        "created_at": datetime.now().isoformat()
    }

# Producer: Add job to queue
async def queue_asset_generation(scene, asset_plan):
    job = create_asset_job(
        scene_id=scene.scene_id,
        asset_type=asset_plan["type"],
        model=asset_plan["model"],
        prompt=asset_plan["prompt"],
        parameters=asset_plan["parameters"]
    )
    redis_client.lpush(QUEUES["asset_jobs"], json.dumps(job))
    
    # Publish update via WebSocket
    redis_client.publish(f"film:{job['film_id']}:updates", json.dumps({
        "type": "job_queued",
        "scene_id": scene.scene_id,
        "asset_type": asset_plan["type"],
        "model": asset_plan["model"]
    }))

# Consumer: GPU Worker
async def asset_worker():
    while True:
        # Block until job available
        _, job_data = redis_client.brpop(QUEUES["asset_jobs"], timeout=5)
        if job_data:
            job = json.loads(job_data)
            
            try:
                # Execute generation
                result = await generate_asset(job)
                
                # Quality check
                score = await evaluate_asset(result)
                
                if score >= 85:
                    # Save to storage
                    url = await save_asset(result)
                    
                    # Mark complete
                    redis_client.lpush(QUEUES["completed"], json.dumps({
                        "job_id": job["job_id"],
                        "status": "complete",
                        "score": score,
                        "url": url
                    }))
                    
                    # Publish success
                    redis_client.publish(f"film:{job['film_id']}:updates", json.dumps({
                        "type": "asset_complete",
                        "scene_id": job["scene_id"],
                        "asset_type": job["asset_type"],
                        "score": score
                    }))
                    
                else:
                    # Queue for retry
                    job["retry_count"] = job.get("retry_count", 0) + 1
                    if job["retry_count"] < job["max_retries"]:
                        job["improvement_notes"] = generate_improvement_notes(result, score)
                        redis_client.lpush(QUEUES["retry_jobs"], json.dumps(job))
                    else:
                        # Use fallback model
                        job["model"] = get_fallback_model(job["model"])
                        job["retry_count"] = 0
                        redis_client.lpush(QUEUES["asset_jobs"], json.dumps(job))
                        
            except Exception as e:
                # Log error and retry
                job["error"] = str(e)
                job["retry_count"] = job.get("retry_count", 0) + 1
                if job["retry_count"] < 3:
                    redis_client.lpush(QUEUES["asset_jobs"], json.dumps(job))
```

## Model Router Service

```python
class ModelRouter:
    """Free-first intelligent model selection"""
    
    MODEL_REGISTRY = {
        "image": {
            "FLUX.1[dev]": {"quality": 95, "cost": 0.0, "speed": 8, "vram": 12},
            "FLUX.1[pro]": {"quality": 98, "cost": 0.0, "speed": 6, "vram": 24},
            "Juggernaut_XL": {"quality": 88, "cost": 0.0, "speed": 9, "vram": 8},
            "RealVis_XL": {"quality": 86, "cost": 0.0, "speed": 9, "vram": 8},
            "SDXL": {"quality": 82, "cost": 0.0, "speed": 10, "vram": 6}
        },
        "video": {
            "WAN_Video": {"quality": 90, "cost": 0.0, "speed": 5, "vram": 16},
            "Hunyuan_Video": {"quality": 85, "cost": 0.0, "speed": 6, "vram": 12},
            "LTX_Video": {"quality": 80, "cost": 0.0, "speed": 8, "vram": 8},
            "CogVideoX": {"quality": 78, "cost": 0.0, "speed": 4, "vram": 20}
        },
        "audio": {
            "Kokoro_TTS": {"quality": 88, "cost": 0.0, "speed": 10, "vram": 2},
            "XTTS_v2": {"quality": 86, "cost": 0.0, "speed": 8, "vram": 4},
            "MeloTTS": {"quality": 84, "cost": 0.0, "speed": 9, "vram": 2},
            "Gemini_TTS": {"quality": 82, "cost": 0.0, "speed": 7, "vram": 0}
        },
        "music": {
            "ACE_Step": {"quality": 90, "cost": 0.0, "speed": 6, "vram": 8},
            "Stable_Audio_Open": {"quality": 86, "cost": 0.0, "speed": 7, "vram": 6},
            "MusicGen": {"quality": 82, "cost": 0.0, "speed": 8, "vram": 4},
            "AudioCraft": {"quality": 80, "cost": 0.0, "speed": 7, "vram": 6}
        }
    }
    
    @classmethod
    def select_model(cls, asset_type, style, quality_mode, vram_available):
        candidates = cls.MODEL_REGISTRY.get(asset_type, {})
        
        # Filter by VRAM
        candidates = {k: v for k, v in candidates.items() if v["vram"] <= vram_available}
        
        # Score: quality * 0.4 + speed * 0.3 + (100 - vram) * 0.2 + (100 if cost == 0 else 50) * 0.1
        scored = []
        for name, specs in candidates.items():
            score = (
                specs["quality"] * 0.4 +
                specs["speed"] * 0.3 +
                (100 - specs["vram"]) * 0.2 +
                (100 if specs["cost"] == 0 else 50) * 0.1
            )
            scored.append((name, score, specs))
        
        scored.sort(key=lambda x: x[1], reverse=True)
        
        return {
            "primary": scored[0][0],
            "primary_specs": scored[0][2],
            "fallbacks": [s[0] for s in scored[1:4]],
            "selection_reason": f"Best quality-speed-cost balance for {asset_type}"
        }
```

## Asset Storage (MinIO)

```python
from minio import Minio

minio_client = Minio(
    "minio:9000",
    access_key="acis_access",
    secret_key="acis_secret",
    secure=False
)

BUCKET = "acis-films"

def save_asset(file_data, film_id, scene_id, asset_type, asset_id):
    """Save generated asset to MinIO storage"""
    path = f"films/{film_id}/scenes/{scene_id}/{asset_type}/{asset_id}"
    
    minio_client.put_object(
        BUCKET,
        path,
        file_data,
        length=len(file_data),
        content_type=get_content_type(asset_type)
    )
    
    # Generate presigned URL (valid for 24 hours)
    url = minio_client.presigned_get_object(BUCKET, path, expires=timedelta(hours=24))
    
    return url

def get_content_type(asset_type):
    return {
        "image": "image/png",
        "video": "video/mp4",
        "audio": "audio/wav",
        "music": "audio/wav"
    }.get(asset_type, "application/octet-stream")
```

## Timeline Engine (OpenTimelineIO)

```python
import opentimelineio as otio

def build_timeline(film_state):
    """Build professional multi-track timeline from film state"""
    
    timeline = otio.schema.Timeline(name=film_state.film_id)
    
    # Video track
    video_track = otio.schema.Sequence(name="Video", kind=otio.schema.SequenceKind.Video)
    
    # Audio tracks
    dialogue_track = otio.schema.Sequence(name="Dialogue", kind=otio.schema.SequenceKind.Audio)
    music_track = otio.schema.Sequence(name="Music", kind=otio.schema.SequenceKind.Audio)
    foley_track = otio.schema.Sequence(name="Foley", kind=otio.schema.SequenceKind.Audio)
    atmos_track = otio.schema.Sequence(name="Atmosphere", kind=otio.schema.SequenceKind.Audio)
    sfx_track = otio.schema.Sequence(name="SFX", kind=otio.schema.SequenceKind.Audio)
    
    # Add clips from scenes
    current_time = otio.opentime.RationalTime(0, 24)
    
    for scene in film_state.scenes:
        for shot in scene.shots:
            # Video clip
            video_clip = otio.schema.Clip(
                name=f"{scene.scene_id}-{shot['shot_id']}",
                media_reference=otio.schema.ExternalReference(
                    target_url=shot["video_url"],
                    available_range=otio.opentime.TimeRange(
                        start_time=otio.opentime.RationalTime(0, 24),
                        duration=otio.opentime.RationalTime(shot["duration_frames"], 24)
                    )
                )
            )
            video_track.append(video_clip)
            
            # Dialogue clip (if exists)
            if shot.get("dialogue_audio"):
                dialogue_clip = otio.schema.Clip(
                    name=f"{scene.scene_id}-dialogue",
                    media_reference=otio.schema.ExternalReference(
                        target_url=shot["dialogue_audio"]
                    ),
                    source_range=otio.opentime.TimeRange(
                        start_time=current_time,
                        duration=otio.opentime.RationalTime(shot["dialogue_duration_frames"], 24)
                    )
                )
                dialogue_track.append(dialogue_clip)
            
            current_time += otio.opentime.RationalTime(shot["duration_frames"], 24)
    
    timeline.tracks.append(video_track)
    timeline.tracks.append(dialogue_track)
    timeline.tracks.append(music_track)
    timeline.tracks.append(foley_track)
    timeline.tracks.append(atmos_track)
    timeline.tracks.append(sfx_track)
    
    return timeline
```

## FFmpeg Render Pipeline

```python
import subprocess
import os

async def render_film(film_state, output_mode="preview"):
    """Render final film using FFmpeg"""
    
    # Prepare input files list
    input_list = []
    for scene in film_state.scenes:
        for shot in scene.shots:
            input_list.append(shot["video_url"])
    
    # Create concat demuxer file
    concat_file = f"/tmp/{film_state.film_id}_concat.txt"
    with open(concat_file, "w") as f:
        for url in input_list:
            f.write(f"file '{url}'\n")
    
    # Output settings based on mode
    if output_mode == "preview":
        output = f"/tmp/{film_state.film_id}_preview.mp4"
        cmd = [
            "ffmpeg", "-f", "concat", "-safe", "0", "-i", concat_file,
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
            "-r", "24", "-movflags", "+faststart",
            "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
            "-pix_fmt", "yuv420p",
            output
        ]
    elif output_mode == "cinematic":
        output = f"/tmp/{film_state.film_id}_cinematic.mp4"
        cmd = [
            "ffmpeg", "-f", "concat", "-safe", "0", "-i", concat_file,
            "-c:v", "libx265", "-preset", "slow", "-crf", "18",
            "-c:a", "aac", "-b:a", "320k", "-ar", "48000",
            "-r", "24", "-movflags", "+faststart",
            "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
            "-pix_fmt", "yuv420p",
            output
        ]
    elif output_mode == "master":
        output = f"/tmp/{film_state.film_id}_master.mov"
        cmd = [
            "ffmpeg", "-f", "concat", "-safe", "0", "-i", concat_file,
            "-c:v", "prores_ks", "-profile:v", "3", "-qscale:v", "9",
            "-c:a", "pcm_s24le", "-ar", "48000",
            "-r", "24", "-pix_fmt", "yuv422p10le",
            output
        ]
    
    # Execute render
    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    if process.returncode == 0:
        # Upload to storage
        with open(output, "rb") as f:
            url = save_asset(f.read(), film_state.film_id, "export", output_mode, os.path.basename(output))
        
        return {"status": "complete", "url": url, "mode": output_mode}
    else:
        return {"status": "error", "error": stderr.decode()}
```

## PostgreSQL Schema

```sql
-- Films table
CREATE TABLE films (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    idea TEXT NOT NULL,
    genre VARCHAR(100),
    style VARCHAR(100) DEFAULT 'cinematic',
    quality_mode VARCHAR(50) DEFAULT 'cinematic',
    status VARCHAR(50) DEFAULT 'initializing',
    story JSONB,
    scenes JSONB DEFAULT '[]',
    timeline JSONB,
    final_render_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Assets table
CREATE TABLE assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    film_id UUID REFERENCES films(id) ON DELETE CASCADE,
    scene_id VARCHAR(50),
    asset_type VARCHAR(50), -- image|video|audio|music
    model VARCHAR(100),
    prompt TEXT,
    path TEXT,
    url TEXT,
    quality_score DECIMAL(5,2),
    generation_time_ms INTEGER,
    retries INTEGER DEFAULT 0,
    fallback_used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Model decisions log
CREATE TABLE model_decisions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    film_id UUID REFERENCES films(id) ON DELETE CASCADE,
    scene_id VARCHAR(50),
    asset_id UUID REFERENCES assets(id),
    asset_type VARCHAR(50),
    primary_model VARCHAR(100),
    fallback_models JSONB,
    routing_reason TEXT,
    cost_usd DECIMAL(10,6) DEFAULT 0.0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Quality evaluations
CREATE TABLE quality_evaluations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_id UUID REFERENCES assets(id),
    composition_score DECIMAL(5,2),
    lighting_score DECIMAL(5,2),
    consistency_score DECIMAL(5,2),
    cinematic_score DECIMAL(5,2),
    emotional_score DECIMAL(5,2),
    technical_score DECIMAL(5,2),
    overall_score DECIMAL(5,2),
    improvement_notes JSONB,
    evaluator VARCHAR(50), -- AI critic model used
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_films_status ON films(status);
CREATE INDEX idx_assets_film_id ON assets(film_id);
CREATE INDEX idx_assets_scene_id ON assets(scene_id);
CREATE INDEX idx_assets_type ON assets(asset_type);
CREATE INDEX idx_model_decisions_film ON model_decisions(film_id);
```
