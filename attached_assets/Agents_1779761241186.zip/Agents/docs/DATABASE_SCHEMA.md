# From Storyboard To Vision — Database Schema & API Design

## Database Schema (PostgreSQL)

### Core Tables

```sql
-- Users and Authentication
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    avatar_url TEXT,
    subscription_tier VARCHAR(50) DEFAULT 'free',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Projects (Productions)
CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(500),
    logline TEXT,
    genre VARCHAR(100),
    tone VARCHAR(100),
    target_duration INTEGER, -- minutes
    status VARCHAR(50) DEFAULT 'draft',
    raw_idea TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    UNIQUE(user_id, title)
);

-- Production Structure (Three-Act, Scenes)
CREATE TABLE story_structure (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    act_number INTEGER NOT NULL, -- 1, 2A, 2B, 3
    act_title VARCHAR(255),
    act_summary TEXT,
    percentage_start INTEGER, -- 0, 25, 50, 75
    percentage_end INTEGER, -- 25, 50, 75, 100
    emotional_target VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE scenes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    scene_number VARCHAR(20) NOT NULL, -- "SC-01", "SC-02"
    scene_title VARCHAR(255),
    act_id UUID REFERENCES story_structure(id),
    location VARCHAR(255),
    time_of_day VARCHAR(100),
    duration_estimate INTEGER, -- seconds
    purpose VARCHAR(50), -- plot, emotion, theme, transition
    characters JSONB, -- ["character_id_1", "character_id_2"]
    dramatic_question TEXT,
    screenplay_text TEXT,
    emotional_beat VARCHAR(100),
    emotional_intensity INTEGER CHECK (emotional_intensity BETWEEN -10 AND 10),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Characters
CREATE TABLE characters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    character_name VARCHAR(255) NOT NULL,
    role VARCHAR(100), -- protagonist, antagonist, supporting
    age INTEGER,
    gender VARCHAR(50),
    physical_description TEXT,
    personality_traits JSONB,
    motivation TEXT,
    flaw TEXT,
    arc_description TEXT,
    wardrobe_description TEXT,
    ai_consistency_tokens JSONB, -- for prompt generation
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Shots (Cinematic Direction)
CREATE TABLE shots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    scene_id UUID REFERENCES scenes(id) ON DELETE CASCADE,
    shot_number VARCHAR(20) NOT NULL, -- "SC-01-SH-01"
    shot_type VARCHAR(100), -- wide, medium, close-up, etc.
    camera_angle VARCHAR(100), -- eye-level, low, high, dutch
    camera_movement VARCHAR(100), -- static, dolly, pan, etc.
    lens_mm INTEGER, -- 14, 24, 35, 50, 85, 135
    depth_of_field VARCHAR(100), -- deep, shallow, rack focus
    composition_rule VARCHAR(100),
    duration_estimate INTEGER, -- seconds
    purpose VARCHAR(255),
    lighting_mood VARCHAR(100),
    lighting_details JSONB,
    frame_description TEXT,
    emotional_purpose VARCHAR(255),
    transition_to VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Storyboard Frames
CREATE TABLE storyboard_frames (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    shot_id UUID REFERENCES shots(id) ON DELETE CASCADE,
    scene_id UUID REFERENCES scenes(id) ON DELETE CASCADE,
    frame_number VARCHAR(20) NOT NULL,
    frame_order INTEGER,
    visual_description TEXT NOT NULL,
    composition_notes TEXT,
    color_mood VARCHAR(100),
    character_actions JSONB,
    background_elements JSONB,
    lighting_direction VARCHAR(100),
    frame_duration INTEGER,
    generated_image_url TEXT, -- if AI image generated
    ai_prompt TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Emotional Arc Data
CREATE TABLE emotional_beats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    scene_id UUID REFERENCES scenes(id) ON DELETE CASCADE,
    beat_order INTEGER,
    beat_type VARCHAR(100), -- hope, fear, love, loss, triumph
    intensity INTEGER CHECK (intensity BETWEEN 1 AND 10),
    duration INTEGER, -- seconds
    description TEXT,
    setup_beat_id UUID REFERENCES emotional_beats(id), -- self-reference for setup/payoff
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Audio Design
CREATE TABLE audio_cues (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    scene_id UUID REFERENCES scenes(id) ON DELETE CASCADE,
    cue_number VARCHAR(20),
    cue_type VARCHAR(100), -- music, sfx, ambience, dialogue
    description TEXT,
    emotional_purpose VARCHAR(255),
    timing_in VARCHAR(20), -- timecode or "on cut"
    timing_out VARCHAR(20),
    duration INTEGER,
    instruments JSONB, -- for music cues
    sound_elements JSONB, -- for sfx cues
    reference_track TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AI Prompts Library
CREATE TABLE ai_prompts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    scene_id UUID REFERENCES scenes(id) ON DELETE CASCADE,
    shot_id UUID REFERENCES shots(id),
    frame_id UUID REFERENCES storyboard_frames(id),
    platform VARCHAR(100) NOT NULL, -- sora, veo, runway, kling, pika, midjourney, flux, sd
    prompt_text TEXT NOT NULL,
    negative_prompt TEXT,
    aspect_ratio VARCHAR(20),
    duration_seconds INTEGER,
    style_references JSONB,
    character_consistency_tags JSONB,
    platform_parameters JSONB, -- platform-specific params
    quality_score INTEGER,
    generated_media_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Production Exports
CREATE TABLE exports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    export_type VARCHAR(100) NOT NULL, -- html, screenplay, shotlist, storyboard, full_package
    file_url TEXT,
    file_size INTEGER,
    format VARCHAR(50),
    generated_by_agent VARCHAR(100), -- which agent generated it
    download_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Agent Execution Logs
CREATE TABLE agent_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    agent_name VARCHAR(100) NOT NULL,
    phase INTEGER NOT NULL, -- 1, 2, 3
    status VARCHAR(50) DEFAULT 'pending', -- pending, running, completed, failed
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    execution_time_ms INTEGER,
    output_summary TEXT,
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for Performance
CREATE INDEX idx_projects_user_id ON projects(user_id);
CREATE INDEX idx_scenes_project_id ON scenes(project_id);
CREATE INDEX idx_scenes_act_id ON scenes(act_id);
CREATE INDEX idx_shots_scene_id ON shots(scene_id);
CREATE INDEX idx_shots_project_id ON shots(project_id);
CREATE INDEX idx_storyboard_project_id ON storyboard_frames(project_id);
CREATE INDEX idx_emotional_project_id ON emotional_beats(project_id);
CREATE INDEX idx_audio_project_id ON audio_cues(project_id);
CREATE INDEX idx_prompts_project_id ON ai_prompts(project_id);
CREATE INDEX idx_prompts_platform ON ai_prompts(platform);
CREATE INDEX idx_agent_exec_project ON agent_executions(project_id);
CREATE INDEX idx_agent_exec_phase ON agent_executions(phase);
```

## Redis Data Structures

```
# Session Cache
session:{session_id} -> Hash { user_id, project_id, created_at, last_active }

# Agent Task Queue
agent:queue:{agent_name} -> List [task_json_1, task_json_2, ...]

# Project State
project:{project_id}:state -> Hash { 
    status, 
    current_phase, 
    completed_agents, 
    last_updated 
}

# Streaming Buffer (for WebSocket updates)
project:{project_id}:stream -> Stream { agent_update_events }

# Rate Limiting
rate_limit:{user_id}:{endpoint} -> String (counter with TTL)

# Prompt Templates Cache
prompt:template:{template_name} -> String

# Cinematic References Cache
reference:film:{film_slug} -> Hash { title, director, cinematographer, style_notes }
```

## Qdrant Vector Collections

```
Collection: story_concepts
- Vectors: 1536 dimensions (OpenAI embeddings)
- Payload: { project_id, concept_text, genre, tone, themes }
- Use case: Semantic search across all user story concepts

Collection: character_descriptions
- Vectors: 1536 dimensions
- Payload: { project_id, character_id, description, traits, visual_tokens }
- Use case: Character consistency matching, similar character search

Collection: visual_references
- Vectors: 1536 dimensions
- Payload: { project_id, frame_id, visual_description, style_tags }
- Use case: Visual style matching, mood board generation

Collection: prompt_embeddings
- Vectors: 1536 dimensions
- Payload: { project_id, prompt_id, platform, prompt_text, quality_score }
- Use case: Prompt similarity search, prompt optimization recommendations
```

## API Design (REST + WebSocket)

### REST Endpoints

```
POST /api/v1/projects
  Body: { raw_idea, title?, genre?, tone?, target_duration? }
  Response: { project_id, status, estimated_completion }

GET /api/v1/projects/{project_id}
  Response: { project metadata, status, completion_percentage }

GET /api/v1/projects/{project_id}/structure
  Response: { story_structure, acts, scenes }

GET /api/v1/projects/{project_id}/characters
  Response: { characters[] }

GET /api/v1/projects/{project_id}/shots
  Query: ?scene_id=xxx
  Response: { shots[], shot_count }

GET /api/v1/projects/{project_id}/storyboard
  Query: ?scene_id=xxx
  Response: { frames[], frame_count }

GET /api/v1/projects/{project_id}/emotional-arc
  Response: { emotional_beats[], arc_graph_data }

GET /api/v1/projects/{project_id}/audio-design
  Response: { audio_cues[], cue_sheet }

GET /api/v1/projects/{project_id}/ai-prompts
  Query: ?platform=sora&scene_id=xxx
  Response: { prompts[] }

GET /api/v1/projects/{project_id}/exports
  Response: { exports[] }

POST /api/v1/projects/{project_id}/exports
  Body: { export_type, formats[] }
  Response: { export_id, download_url, estimated_ready }

GET /api/v1/projects/{project_id}/html-experience
  Response: { html_content_url, preview_url }

GET /api/v1/projects/{project_id}/agent-status
  Response: { 
    phases: [
      { phase: 1, agents: [{ name, status, progress }] },
      { phase: 2, agents: [...] },
      { phase: 3, agents: [...] }
    ]
  }

DELETE /api/v1/projects/{project_id}
  Response: { deleted: true }

GET /api/v1/templates
  Response: { templates[] } -- story templates, genre templates

GET /api/v1/references/films
  Query: ?genre=xxx&director=xxx
  Response: { films[] } -- cinematic references for style matching
```

### WebSocket Events

```
# Client connects
ws://api/v1/stream/{project_id}

# Server → Client Events
{ type: "agent_started", agent: "story-architect", phase: 1, timestamp }
{ type: "agent_progress", agent: "story-architect", progress: 45, message: "Building character arcs..." }
{ type: "agent_completed", agent: "story-architect", phase: 1, output_summary: "3-act structure with 12 scenes" }
{ type: "agent_failed", agent: "visual-storyboard", error: "...", retry_attempt: 1 }
{ type: "phase_completed", phase: 1, completed_agents: [...] }
{ type: "scene_ready", scene_id: "...", scene_number: "SC-01", status: "complete" }
{ type: "html_experience_ready", download_url: "...", preview_url: "..." }
{ type: "production_complete", project_id: "...", total_time_ms, export_urls: {...} }

# Client → Server Messages
{ type: "ping" }
{ type: "request_update", agent: "cinematic-director" }
{ type: "cancel_production" }
```

## Data Flow Diagram

```
User Request
    │
    ▼
┌─────────────────────────────┐
│  API Gateway                  │
│  • Validate request           │
│  • Rate limit check           │
│  • Create project record        │
│  • Queue Phase 1 agents         │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│  Fleet Agent Orchestrator     │
│  • Dispatch Story Architect     │
│  • Dispatch Emotional Narrative│
│  • Parallel execution          │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│  PostgreSQL + Redis          │
│  • Store agent outputs         │
│  • Cache intermediate state     │
│  • Update project status        │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│  Phase 2 Dispatch             │
│  • Cinematic Director         │
│  • Visual Storyboard          │
│  • Sound & Music              │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│  PostgreSQL + Redis          │
│  • Store shot list             │
│  • Store storyboard frames      │
│  • Store audio cues             │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│  Phase 3 Dispatch             │
│  • AI Prompt Director          │
│  • Interactive Experience     │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│  Final Storage                │
│  • AI prompts in PostgreSQL    │
│  • HTML experience file        │
│  • Vector embeddings in Qdrant │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│  WebSocket Notification       │
│  • Production complete event   │
│  • Export URLs sent            │
│  • HTML experience ready         │
└─────────────────────────────┘
```

## Export Formats

### 1. Interactive HTML Experience
- Self-contained single HTML file
- Inline CSS and JavaScript
- No external dependencies
- Cinematic UI with timeline, scene cards, storyboard viewer

### 2. Screenplay (Markdown)
- Standard screenplay format
- Scene headings, action lines, dialogue
- Character names, parentheticals, transitions

### 3. Shot List (CSV)
- Spreadsheet format with all shot details
- Sortable and filterable
- Importable into production software

### 4. Storyboard (Markdown + Image References)
- Frame-by-frame descriptions
- Visual composition notes
- Camera and lighting details

### 5. Complete Production Package (ZIP)
- Contains all individual exports
- README with navigation guide
- Folder structure: /screenplay, /shots, /storyboard, /audio, /prompts, /html
