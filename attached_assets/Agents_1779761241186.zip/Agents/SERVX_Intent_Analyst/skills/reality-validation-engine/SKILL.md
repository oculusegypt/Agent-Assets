---
name: reality-validation-engine
description: Real-world validation layer that verifies libraries exist, APIs are real, packages are maintained, technologies are not deprecated, performance claims are benchmarked, and solutions are proven in production. Transforms the system from philosophical to truly engineering-grade.
---

# Reality Validation Engine (RVE)

## When to Use
- Before recommending ANY technology, library, or framework
- Before approving ANY dependency
- When an agent proposes a "new" solution
- When verifying performance claims
- Before production deployment
- During continuous validation audits

## Core Principle
> Theory without verification is hallucination. Every recommendation must be grounded in reality.

## Validation Domains

### 1. Technology Existence Validation (TECH-VAL)
For every technology mentioned:
```
VALIDATION CHECKLIST
Technology: [Name]
Validation Date: [Date]

□ EXISTS: Does this technology actually exist?
  Source: [Official website / Registry / Documentation]
  Verification: [Link / Search result]

□ MAINTAINED: Is it actively maintained?
  Last Commit: [Date]
  Commit Frequency: [Commits per month]
  Maintainers: [N active]
  Response Time: [Average issue response]

□ STABLE: Is it production-ready?
  Version: [Current stable]
  Breaking Changes (last 12mo): [N]
  Deprecation Warnings: [List or "None"]

□ DOCUMENTED: Is documentation adequate?
  API Docs: [YES/NO/INCOMPLETE]
  Examples: [YES/NO]
  Migration Guides: [YES/NO]
  Community: [Active / Moderate / Dormant]

□ COMPATIBLE: Does it work with our stack?
  Tested With: [Our stack versions]
  Known Conflicts: [List or "None found"]
  Integration Complexity: [LOW/MEDIUM/HIGH]

□ PROVEN: Is it used in production at scale?
  Known Users: [List or "Not documented"]
  Scale Testimonials: [List or "None"]
  Case Studies: [List or "None"]

VALIDATION RESULT: PASS / PASS_WITH_WARNINGS / FAIL / NEEDS_MORE_DATA
CONFIDENCE: [0-100]%
```

### 2. API Reality Check (API-VAL)
```
API VALIDATION
Endpoint/Service: [Name]

□ DOCUMENTED: Official docs exist?
  URL: [Link]
  Completeness: [Score 1-10]

□ ACCESSIBLE: Can we actually call it?
  Test Result: [SUCCESS/FAIL/PARTIAL]
  Response Time: [X]ms
  Rate Limits: [Documented?]

□ RELIABLE: Uptime SLA?
  SLA: [X]%
  Historical Uptime: [If available]
  Outage History: [If available]

□ COST: Pricing transparent?
  Free Tier: [YES/NO] | Limits: [...]
  Paid Tier: [Price] | Scaling: [...]
  Hidden Costs: [List or "None found"]

□ SECURITY: Auth mechanism documented?
  Auth Type: [OAuth/API Key/JWT/etc]
  Security Audit: [Available?]
  Compliance: [SOC2/GDPR/etc]

RESULT: REAL / UNVERIFIED / FAKE / RISKY
```

### 3. Performance Claim Verification (PERF-VAL)
```
PERFORMANCE CLAIM CHECK
Claim: "[Technology X handles 100K req/s]"

□ SOURCE: Where does this claim come from?
  - Benchmark Source: [Official / Third-party / Unverified]
  - Methodology: [Described?]
  - Hardware Used: [Specified?]

□ REPRODUCIBLE: Can we verify?
  - Our Test Environment: [Specs]
  - Our Test Result: [Result]
  - Deviation: [X]% from claimed

□ REALISTIC: Is the benchmark realistic?
  - Cached vs Real: [Difference]
  - Ideal vs Production: [Difference]
  - Best Case vs Average: [Difference]

VERDICT: VERIFIED / OVERSTATED / UNVERIFIABLE / MISLEADING
RECOMMENDED EXPECTATION: [Realistic number]
```

### 4. Market Reality Check (MKT-VAL)
```
MARKET VALIDATION
Technology: [Name]

□ ADOPTION: How widely used?
  GitHub Stars: [N]
  NPM Downloads (last month): [N]
  Stack Overflow Questions: [N]
  Job Postings Mentioning: [N]

□ TREND: Growing or declining?
  Google Trends: [Direction]
  GitHub Activity Trend: [Direction]
  New Projects Using: [Direction]

□ ECOSYSTEM: Support ecosystem healthy?
  IDE Support: [List]
  Testing Tools: [List]
  Deployment Tools: [List]
  Monitoring Tools: [List]

□ FUTURE: Is it future-proof?
  Roadmap Available: [YES/NO]
  Backing Organization: [Name / Community]
  Risk of Abandonment: [LOW/MEDIUM/HIGH]

MARKET HEALTH SCORE: [0-100]
```

## Validation Protocol
Every agent MUST pass through RVE before proposing:
1. **Self-Validation**: Agent runs internal reality check
2. **Peer-Validation**: Another agent cross-checks
3. **Registry-Validation**: Check against technology registries
4. **Historical-Validation**: Check if technology caused past failures
5. **Human-Override**: Human can override validation with documented justification

## Anti-Hallucination Weapons
- `tavily_web_search` → Search for technology existence and maturity
- `read_url_content` → Read official docs to verify claims
- Registry checks → npm, PyPI, crates.io, etc.
- Community checks → Stack Overflow, GitHub issues
- Benchmark skepticism → "If it sounds too good, it probably is"

## Validation Report Format
```
REALITY VALIDATION REPORT [ID: RVE-YYYY-MM-DD-NNN]
Target: [Technology/API/Claim]
Validator: [Agent Name]
Date: [Timestamp]

Checks Performed:
  □ Technology Existence
  □ Maintenance Status
  □ Documentation Quality
  □ Production Proven
  □ Performance Verified
  □ Market Health

Results:
  Technology Exists: [YES/NO]
  Actively Maintained: [YES/NO] | Last Update: [Date]
  Production Proven: [YES/NO/UNCERTAIN]
  Performance Claims: [VERIFIED/OVERSTATED/UNVERIFIABLE]
  Market Health: [Score]/100

Risks:
  - [Risk 1]
  - [Risk 2]

Confidence: [0-100]%
Recommendation: APPROVE / REJECT / NEEDS_MORE_DATA / APPROVE_WITH_WARNINGS
```
