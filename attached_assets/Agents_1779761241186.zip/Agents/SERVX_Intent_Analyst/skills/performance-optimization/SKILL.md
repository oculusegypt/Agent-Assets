---
name: performance-optimization
description: Skill for analyzing system performance, detecting bottlenecks, forecasting scalability, and recommending targeted optimizations. Prevents premature optimization while ensuring production readiness.
---

# Performance Optimization Skill

## When to Use
- During architecture design (PHASE 3)
- Before production deployment (PHASE 6)
- During continuous monitoring (PHASE 7)
- For long-term stability forecasting (PHASE 8)

## Core Principles
1. **Measure First**: No optimization without measurement
2. **Target Bottlenecks**: Focus on the 20% causing 80% of issues
3. **Avoid Premature Optimization**: Don't optimize what isn't broken
4. **Test After**: Verify improvement, not just change

## Performance Audit Checklist

### 1. Response Time Analysis
- [ ] API response times < 200ms (p50)
- [ ] API response times < 500ms (p95)
- [ ] Database queries < 100ms
- [ ] Frontend First Contentful Paint < 1.5s
- [ ] Frontend Time to Interactive < 3s

### 2. Throughput Analysis
- [ ] Can handle expected concurrent users?
- [ ] Database connection pool sufficient?
- [ ] Rate limiting appropriate?
- [ ] Queue depth manageable?

### 3. Resource Utilization
- [ ] CPU usage < 70% at peak
- [ ] Memory usage < 80% at peak
- [ ] Disk I/O not saturated
- [ ] Network bandwidth sufficient

### 4. Scalability Forecasting
For each component, estimate:
- Current capacity: [X] users/requests
- Scaling limit: [Y] users/requests
- Bottleneck at: [Component]
- Solution when reached: [Action]

## Scalability Patterns

| Scale | Pattern | When to Apply |
|-------|---------|---------------|
| < 1K users | Single instance | MVP, prototype |
| 1K-10K | Vertical scaling | Early growth |
| 10K-100K | Horizontal scaling + CDN | Product-market fit |
| 100K-1M | Microservices + caching | Rapid scaling |
| 1M+ | Event-driven + sharding | Enterprise |

## Performance Decision Framework
Before optimizing:
1. What is the current measurement?
2. What is the target?
3. What is the bottleneck?
4. What are 3 possible solutions?
5. Cost/benefit of each?
6. Recommendation?

## Reporting Format
```
PERFORMANCE REPORT [PHASE] [TIMESTAMP]
Component: [Name]
Current Metrics:
  - Response Time (p50): [X]ms
  - Response Time (p95): [Y]ms
  - Throughput: [Z] req/s
Bottlenecks Identified:
  1. [Description] | Severity: [X] | Fix: [Action]
Recommendations:
  1. [Action] | Expected Improvement: [X]%
Scalability Forecast:
  - Safe until: [N] users
  - Requires scaling at: [M] users
  - Recommended architecture change: [Action]
```
