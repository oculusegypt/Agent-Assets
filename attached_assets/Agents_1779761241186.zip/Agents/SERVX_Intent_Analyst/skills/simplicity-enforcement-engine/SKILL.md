---
name: simplicity-enforcement-engine
description: Simplicity Enforcement Engine that challenges unnecessary complexity, questions every abstraction, and enforces the principle that the best solution is often the simplest one. Prevents the AI's tendency toward beautiful but over-engineered solutions.
---

# Simplicity Enforcement Engine (SEE)

## When to Use
- Before approving ANY architecture decision
- When reviewing proposed solutions
- During code review (agent or human)
- When technical debt is introduced
- When evaluating refactoring proposals
- When an agent proposes an elegant but complex solution

## Core Principle
> Simplicity is the ultimate sophistication. Complexity is the enemy of execution. Every abstraction must earn its existence.

## The Simplicity Test

### 1. Necessity Test
For every proposed element, ask:
```
NECESSITY TEST
Element: [What is being proposed]

Question 1: What problem does this solve?
  Answer: [...]

Question 2: Can we solve this problem without this element?
  Answer: [YES/NO]
  If YES: [How?]
  If NO: [Why not?]

Question 3: Does this problem actually exist, or are we solving imaginary problems?
  Answer: [Real problem / Anticipated problem / Theoretical problem]

Question 4: If we remove this element 6 months from now, what breaks?
  Answer: [...]

Verdict:
  NECESSARY: [YES/NO]
  If NO → Remove or simplify
```

### 2. Complexity Budget
```
COMPLEXITY BUDGET
Project: [Name]
Module: [Name]

Complexity Budget (max allowed): [N] points
Current Complexity: [N] points
Remaining Budget: [N] points

Complexity Points:
  Abstraction Layer: +[N]
  Indirection: +[N]
  Configuration: +[N]
  Custom Framework: +[N]
  Microservice: +[N]
  Event-Driven: +[N]
  Distributed State: +[N]
  Custom DSL: +[N]

If adding new element exceeds budget:
  → Must remove existing complexity first
  → Or justify why budget should increase
  → Human must approve budget increase
```

### 3. The YAGNI Challenge
```
YAGNI (You Aren't Gonna Need It) CHECK
Feature/Abstraction: [Name]

Challenge Questions:
  1. Is this needed for MVP? [YES/NO]
     If NO → Postpone

  2. Is this needed for first 1000 users? [YES/NO]
     If NO → Postpone

  3. Is this needed for current known requirements? [YES/NO]
     If NO → Postpone

  4. Can we add this later without rewriting everything? [YES/NO]
     If YES → Postpone

  5. Are we solving a problem we don't have yet? [YES/NO]
     If YES → POSTPONE

YAGNI Verdict:
  BUILD NOW: [YES/NO]
  POSTPONE TO: [Phase/Date]
```

### 4. The "Explain to a Junior" Test
```
EXPLAINABILITY TEST
Component/Decision: [Name]

Can a junior developer with [6 months] experience:
  1. Understand what this does in < 5 minutes? [YES/NO]
  2. Explain why it exists? [YES/NO]
  3. Modify it safely? [YES/NO]
  4. Debug it when it breaks? [YES/NO]
  5. Write a test for it? [YES/NO]

If 3+ answers are NO:
  → Too complex. Simplify or add comprehensive documentation.
```

### 5. The Premature Abstraction Check
```
PREMATURE ABSTRACTION CHECK
Abstraction: [Name]

How many times is this abstraction used?
  - 1 time: It's not an abstraction, it's indirection. REMOVE.
  - 2 times: Maybe. Is the duplication coincidental or meaningful?
  - 3+ times: Probably justified. But still challenge it.

Is the abstraction solving:
  - [ ] Actual duplication (same thing in multiple places)
  - [ ] Anticipated duplication (might happen in future)
  - [ ] Theoretical elegance (looks cleaner)

If anticipated or theoretical:
  → YAGNI applies. Keep it concrete for now.
```

## Simplicity Metrics
```
SIMPLICITY SCORE
Component: [Name]

Lines of Code: [N]
Cyclomatic Complexity: [N] (target: < 10)
Cognitive Complexity: [N] (target: < 15)
Number of Abstractions: [N] (target: minimal)
Number of Dependencies: [N] (target: minimal)
Number of Configuration Points: [N] (target: minimal)
Time to Understand (new dev): [Minutes]

Simplicity Score: [0-100] (100 = simplest)
Target: > 70
```

## Simplicity Laws
1. **Law of Least Astonishment**: Code should do what a reasonable developer would expect
2. **Law of Parsimony**: Entities should not be multiplied unnecessarily
3. **Law of Concrete First**: Build concrete solutions first, abstract only after 3+ real uses
4. **Law of Readability**: Code is read 10× more than it's written. Optimize for reading.
5. **Law of Composition**: Prefer composing simple things over creating complex monoliths
6. **Law of No Magic**: No hidden behavior, no implicit assumptions, no "it just works"

## Anti-Complexity Patterns
```
PATTERNS TO CHALLENGE

❌ Microservices for < 10K users
❌ Event-driven for < 5 components
❌ Custom framework instead of existing solution
❌ Abstract base classes with 1 implementation
❌ Dependency injection for simple dependencies
❌ ORM for simple CRUD (if team knows SQL)
❌ GraphQL for simple REST API
❌ Kubernetes for single service
❌ Serverless for predictable load
❌ Multi-cloud for no reason
❌ Custom protocol when HTTP works
❌ Distributed transactions when local works
```

## Enforcement
```
SIMPLICITY ENFORCEMENT PROTOCOL

When agent proposes solution:
  1. Run Necessity Test
  2. Check Complexity Budget
  3. Run YAGNI Challenge
  4. Run Explainability Test
  5. Check Premature Abstraction
  6. Calculate Simplicity Score

If Score < 50:
  → REJECT with simplicity challenge
  → Request simpler alternative
  → Escalate to human if agent insists

If Score 50-70:
  → PASS_WITH_WARNING
  → Document why complexity is necessary
  → Set re-evaluation date

If Score > 70:
  → PASS
  → Note any remaining concerns
```

## Integration
- SEE challenges Architecture Advisor recommendations
- SEE reviews all agent outputs for unnecessary complexity
- SEE feeds into Quality Guardian (simplicity is a quality metric)
- SEE is consulted during every architecture decision
- SEE reports are part of quarterly architecture reviews
