---
name: token-economy
description: Skill for monitoring, optimizing, and controlling token consumption, context window health, and semantic compression across AI agent pipelines.
---

# Token Economy Skill

## When to Use
- Before delegating to sub-agents (check context budget)
- When conversation context approaches limits
- When planning multi-agent workflows
- During PHASE 7 continuous auditing

## Token Budgeting Rules

### 1. Semantic Compression
Instead of sending full files, send:
- **Diff only**: What changed, not the whole file
- **Affected parts only**: Relevant functions, not entire module
- **Decision only**: The conclusion, not the full reasoning chain
- **References**: "See FILE:X LINES:Y-Z" instead of quoting

### 2. Scoped Context
Each agent receives ONLY:
- Current task description
- Relevant files (affected + dependencies)
- Relevant constitutional laws
- Previous decisions (decision ID + conclusion, not full analysis)

### 3. Conversation Pruning
When context approaches 70%:
1. Summarize completed phases into decision digest
2. Remove detailed reasoning, keep only conclusions
3. Archive full analysis to external document (Google Doc)
4. Reference the archive, don't inline it

### 4. Agent Pipeline Budget
| Phase | Max Tokens | Notes |
|-------|------------|-------|
| 1 Intent | 2,000 | Lightweight extraction |
| 2 Interrogation | 4,000 | Decision tree building |
| 3 Blueprint | 6,000 | Architecture design |
| 4 Constitution | 3,000 | Law drafting |
| 5 Ratification | 2,000 | Human interaction |
| 6 Execution | 8,000 | Code generation |
| 7 Audit | 4,000 | Continuous checks |
| 8 Forecast | 2,000 | Long-term analysis |

## Context Health Monitoring
Report format:
```
CONTEXT HEALTH REPORT
Session ID: [ID]
Tokens Used: [X] / [Limit] ([%] %)
Agents Active: [N]
Phases Completed: [List]
Pruning Needed: YES / NO
Recommendations:
- [Action 1]
- [Action 2]
```

## Cost Optimization Strategies
1. **Batch independent calls**: Parallel tool calls where possible
2. **Cache repeated analysis**: Don't re-analyze same file
3. **Use skills for common patterns**: Load skill instead of explaining
4. **Compress historical context**: Summarize instead of quoting
5. **Limit agent depth**: 3 levels max (parent → child → grandchild)

## Warning Thresholds
- **60%**: Monitor closely, prepare pruning
- **70%**: Begin pruning, warn user
- **80%**: Emergency compression, pause new agents
- **90%**: Halt, archive, restart with fresh context
