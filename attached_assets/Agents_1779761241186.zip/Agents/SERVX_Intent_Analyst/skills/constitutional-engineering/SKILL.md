---
name: constitutional-engineering
description: Skill for drafting, enforcing, and managing project-specific constitutional laws for AI engineering governance. Covers Architecture Laws, Security Laws, AI Governance Laws, and Code Quality Laws.
---

# Constitutional Engineering Skill

## When to Use
- When you need to draft a project constitution (LAYER 4 of SOVEREIGN ARCHITECT pipeline)
- When you need to enforce existing constitutional laws on new decisions
- When you need to ratify or amend constitutional rules

## Constitutional Law Categories

### 1. Architecture Laws
Prohibitions and requirements for system architecture:
- `ARCH-001`: ممنوع Business Logic داخل UI Layer
- `ARCH-002`: ممنوع Direct DB Access من Frontend
- `ARCH-003`: ممنوع Circular Dependencies
- `ARCH-004`: ممنوع Shared Mutable State
- `ARCH-005`: ممنوع God Objects / Mega Classes
- `ARCH-006`: إلزامية Separation of Concerns
- `ARCH-007`: إلزامية Dependency Inversion
- `ARCH-008`: إلزامية Event-Driven Communication بين Agents

### 2. Security Laws
Mandatory security requirements:
- `SEC-001`: Mandatory Input Validation (all inputs)
- `SEC-002`: Mandatory Rate Limiting (all APIs)
- `SEC-003`: Mandatory Audit Logs (all actions)
- `SEC-004`: Mandatory Secret Isolation (no secrets in code)
- `SEC-005`: Mandatory Auth Flow Integrity Checks
- `SEC-006`: Mandatory Data Exposure Simulation (before production)
- `SEC-007`: Mandatory Dependency Security Reputation Check

### 3. AI Governance Laws
Rules governing AI agent behavior:
- `AI-GOV-001`: ممنوع إعادة كتابة ملف كامل لتعديل صغير (use Smart Patch only)
- `AI-GOV-002`: ممنوع إنشاء Dependency بدون موافقة صريحة
- `AI-GOV-003`: ممنوع Refactor شامل بدون تحليل Impact
- `AI-GOV-004`: ممنوع تغيير Business Logic دون Approval بشري
- `AI-GOV-005`: ممنوع أي Agent اتخاذ قرار معماري جذري بدون تصديق بشري
- `AI-GOV-006`: إلزامية Constitution Check قبل كل خطوة تنفيذ
- `AI-GOV-007`: إلزامية Decision Ledger logging لكل قرار

### 4. Code Quality Laws
Standards for code production:
- `QUAL-001`: Strict Typing Required (no `any`, no implicit types)
- `QUAL-002`: Modular Isolation (single responsibility per module)
- `QUAL-003`: Test Coverage Thresholds (min 70% for critical paths)
- `QUAL-004`: Live Documentation Enforcement (every public API documented)
- `QUAL-005`: No Dead Code (no unused imports, functions, variables)
- `QUAL-006`: Lint/Format Compliance (automated checks)

## Drafting Workflow
1. Analyze project intent extraction for sensitivity, scale, complexity
2. Select applicable laws from each category
3. Add project-specific amendments
4. Present draft constitution to human for ratification
5. Log ratified constitution to Decision Ledger
6. Share constitution with all project agents

## Enforcement
Before ANY execution step, verify:
- Does this step violate any constitutional law?
- If yes → block and escalate to human
- If unclear → mark as `REQUIRES_RATIFICATION` and pause

## Amendment Protocol
Constitution amendments require:
1. Written justification
2. Impact analysis on existing decisions
3. Human ratification
4. Version bump (e.g., v1.0 → v1.1)
5. Notification to all active agents
