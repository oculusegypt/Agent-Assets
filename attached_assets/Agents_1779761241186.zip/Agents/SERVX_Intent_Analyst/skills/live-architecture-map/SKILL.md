---
name: live-architecture-map
description: "Living Architecture Map showing relationships, flows, dependencies, services, state, and ownership in real-time. Prevents the most dangerous problem in projects: losing sight of the big picture."
---

# Live Architecture Map (LAM)

## When to Use
- During every architecture review
- When onboarding new team members or agents
- When making decisions that affect system structure
- When detecting architectural drift
- When explaining the system to stakeholders
- During any "where are we?" moment

## Core Principle
> A team that cannot see the whole cannot govern the whole. The architecture map is the shared visual cortex of the engineering organization.

## Map Components

### 1. Component Registry
```
COMPONENT [ID: COMP-XXX]
Name: [Name]
Layer: [Domain / Application / Infrastructure / UI]
Type: [Service / Library / Database / API / Queue / Cache]

Responsibilities:
  - [Responsibility 1]
  - [Responsibility 2]

Interfaces:
  - Provides: [APIs / Events / Data]
  - Consumes: [APIs / Events / Data]

State:
  - Owns: [Data types]
  - Mutable: [YES/NO]
  - Persistence: [Database / Memory / File / None]

Dependencies:
  - Direct: [List of COMP-XXX]
  - Indirect: [List of COMP-XXX]
  - External: [List of external services]

Owner:
  - Decision: [DEC-XXX]
  - Ratified By: [Human]
  - Maintained By: [Agent/Human]

Health:
  - Status: [HEALTHY / AT_RISK / DEGRADED / FAILED]
  - Quality Score: [0-100]
  - Test Coverage: [X]%
  - Last Updated: [Date]
```

### 2. Relationship Map
```
ARCHITECTURE RELATIONSHIP GRAPH

[Domain Layer]
  |-- UserDomain [COMP-001]
  |     |-- AuthService [COMP-002] --> depends on COMP-003
  |     |-- ProfileService [COMP-004] --> depends on COMP-005
  |
  |-- PaymentDomain [COMP-010]
  |     |-- PaymentProcessor [COMP-011] --> depends on COMP-012
  |     |-- FraudDetection [COMP-013] --> depends on COMP-014
  |
[Application Layer]
  |-- API Gateway [COMP-020]
  |     --> routes to COMP-002, COMP-004, COMP-011
  |
  |-- EventBus [COMP-030]
  |     --> subscribed by COMP-002, COMP-011, COMP-013
  |
[Infrastructure Layer]
  |-- PostgreSQL [COMP-040]
  |-- Redis [COMP-041]
  |-- S3 Storage [COMP-042]
  |-- Kafka [COMP-043]

[External]
  |-- Stripe API
  |-- SendGrid API
  |-- Monitoring (Datadog)
```

### 3. Data Flow Diagram
```
DATA FLOW MAP

User Request
  --> API Gateway [COMP-020]
    --> Auth Check [COMP-002] --> PostgreSQL [COMP-040]
    --> Rate Limit [COMP-021] --> Redis [COMP-041]
    --> Route Request
      --> User Service [COMP-004] --> PostgreSQL [COMP-040]
        --> Event: UserUpdated --> EventBus [COMP-030]
          --> Analytics Service [COMP-050] --> S3 [COMP-042]
          --> Notification Service [COMP-051] --> SendGrid API
      --> Payment Service [COMP-011] --> PostgreSQL [COMP-040]
        --> External: Stripe API
        --> Event: PaymentProcessed --> EventBus [COMP-030]
          --> Fraud Detection [COMP-013] --> Kafka [COMP-043]
```

### 4. State Ownership Map
```
STATE OWNERSHIP

Data Type          | Owner Component | Mutable By          | Persistence
-------------------|-----------------|---------------------|-------------
User Profiles      | COMP-004        | COMP-004 only       | PostgreSQL
Auth Tokens        | COMP-002        | COMP-002 only       | Redis
Payment Records    | COMP-011        | COMP-011 only       | PostgreSQL
Events             | COMP-030        | Append-only         | Kafka
Analytics Data     | COMP-050        | Append-only         | S3
Session Data       | COMP-021        | COMP-021, COMP-002  | Redis
```

### 5. Dependency Heat Map
```
DEPENDENCY HEALTH HEAT MAP

Component    | Dependencies | Outdated | Vulnerable | Risk Score
-------------|--------------|----------|------------|------------
COMP-002     | 12           | 2        | 0          | 65
COMP-004     | 8            | 1        | 0          | 80
COMP-011     | 15           | 5        | 1          | 45
COMP-013     | 6            | 0        | 0          | 90
COMP-020     | 4            | 0        | 0          | 95
```

## Map Generation Rules
1. **Auto-Update**: Map updates automatically when components change
2. **Version Control**: Every map version is snapshotted
3. **Drift Detection**: Compare current map to approved architecture
4. **Ownership**: Every component has a clear owner (decision + agent/human)
5. **Health Overlay**: Health scores displayed on components
6. **Zoom Levels**: High-level (domains) --> Mid-level (services) --> Low-level (functions)

## Drift Detection
```
ARCHITECTURE DRIFT REPORT
Approved Map Version: [V]
Current Map Version: [V+N]

Drift Detected:
  Component Added: [N] (not in approved architecture)
    - [COMP-XXX]: [Why was it added?]
  Component Removed: [N]
    - [COMP-XXX]: [Why was it removed?]
  Dependencies Changed: [N]
    - [COMP-XXX]: [Old deps --> New deps]
  Layers Violated: [N]
    - [Violation 1]: [Which law broken]

Drift Score: [0-100] (100 = perfect, 0 = complete divergence)
Trend: [IMPROVING / STABLE / DEGRADING]

Action Required:
  [YES / NO]
  If YES: [What needs to happen]
```

## Map Storage
Stored in /memories/architecture-map/:
- current.md -- current state (auto-updated)
- approved-vX.md -- approved architecture snapshots
- history/YYYY-MM-DD.md -- daily snapshots
- drift-reports/DRIFT-XXX.md -- drift detection reports

## Access Patterns
- Before any architecture change: read current map
- During quarterly review: compare to approved map
- When onboarding: read approved map + current map
- During crisis: read current map + health overlay
