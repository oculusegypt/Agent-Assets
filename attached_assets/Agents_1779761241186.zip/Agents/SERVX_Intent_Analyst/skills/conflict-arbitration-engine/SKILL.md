---
name: conflict-arbitration-engine
description: Supreme Arbitration Kernel that resolves disputes between agents, breaks decision conflicts, unifies divergent recommendations, prevents agent dominance, and prevents architectural forking. The judge between warring agents.
---

# Conflict Arbitration Engine (CAE)

## When to Use
- When two or more agents produce contradictory recommendations
- When an agent's decision violates the constitution
- When architectural drift is detected (diverging visions)
- When an agent attempts to override a ratified decision
- When agent trust scores diverge significantly on the same topic
- During any multi-agent execution where alignment is questionable

## Core Principle
> Multi-Agent Systems without arbitration are anarchies. The CAE is the Supreme Court of the architecture.

## Types of Conflicts

### 1. Decision Conflicts
Two agents recommend different solutions:
```
CONFLICT DETECTED
Conflict ID: [CONF-XXX]
Type: DECISION_CONFLICT
Severity: [CRITICAL/HIGH/MEDIUM/LOW]

Agent Alpha (trust: [X]%) recommends:
  → [Option A] | Rationale: [...]

Agent Beta (trust: [Y]%) recommends:
  → [Option B] | Rationale: [...]

Constitution Position:
  → [Relevant law]

Knowledge Graph Position:
  → [Previous related decisions]

Arbitration Needed: YES
```

### 2. Constitutional Violations
Agent proposes something that violates the constitution:
```
CONFLICT DETECTED
Conflict ID: [CONF-XXX]
Type: CONSTITUTIONAL_VIOLATION
Severity: CRITICAL

Agent: [Name]
Proposed Action: [Description]

Violated Laws:
  - [LAW-001]: "[Law text]"
  - [LAW-002]: "[Law text]"

Constitution Check: FAILED
Auto-Action: BLOCKED
Escalation: Required to human
```

### 3. Architectural Forking
Agents are pushing the architecture in different directions:
```
CONFLICT DETECTED
Conflict ID: [CONF-XXX]
Type: ARCHITECTURAL_FORK
Severity: CRITICAL

Divergence Detected:
  Agent Alpha is pushing toward: [Microservices]
  Agent Beta is pushing toward: [Monolith]
  Agent Gamma is pushing toward: [Serverless]

Constitution Mandate:
  → Current approved architecture: [Approved pattern]

Decision Required:
  → Is this a legitimate evolution or uncontrolled drift?

Auto-Action: PAUSE all conflicting agents
Escalation: Required to human + architecture review
```

### 4. Agent Dominance
One agent is overriding others consistently:
```
CONFLICT DETECTED
Conflict ID: [CONF-XXX]
Type: AGENT_DOMINANCE
Severity: HIGH

Pattern Detected:
  Agent [Name] has overridden [N] other agents in last [M] decisions
  Override Rate: [X]% (threshold: 30%)
  Affected Areas: [List]

Risk: Single point of failure, groupthink collapse
Action: Throttle dominant agent, require peer review
```

## Arbitration Process

### Phase 1: Conflict Detection
- Monitor all agent outputs for contradictions
- Check against constitution automatically
- Compare against knowledge graph for historical conflicts
- Score conflict severity

### Phase 2: Evidence Gathering
- Gather all agent rationales
- Query knowledge graph for relevant decisions
- Check trust scores of involved agents
- Identify constitutional implications

### Phase 3: Constitution Check
- Does either option clearly violate the constitution?
- If YES → Violating option is automatically disqualified
- If both violate → Escalate to human immediately

### Phase 4: Knowledge Graph Resolution
- Query graph for precedent decisions
- Is there a previous, ratified decision on this topic?
- If YES → Previous decision wins unless explicitly being revised
- If NO → Proceed to Phase 5

### Phase 5: Merit Analysis
- Score each option against project goals
- Score each option against current constraints
- Score each option for maintainability
- Score each option for risk

### Phase 6: Human Escalation (if needed)
If conflict cannot be auto-resolved:
```
ESCALATION REQUEST
Conflict: [CONF-XXX]
Cannot resolve automatically because:
  - [Reason 1]
  - [Reason 2]

Options:
  Option A: [Summary] | Pros: [List] | Cons: [List]
  Option B: [Summary] | Pros: [List] | Cons: [List]

Constitution Impact:
  - [Analysis]

Recommendation: [X]
Human Decision Required: YES
Deadline: [Timestamp]
```

## Arbitration Rules
1. **Constitution Wins**: Any option violating constitution is automatically disqualified
2. **Precedence Wins**: Ratified previous decisions win over new proposals unless explicitly revising
3. **Human Sovereignty**: Human decision overrides all arbitration
4. **Trust Weighting**: Higher-trust agent recommendations carry more weight (but not absolute)
5. **Evidence Required**: No decision without documented rationale
6. **No Secret Overrides**: All arbitration decisions are logged and auditable

## Output Format
```
ARBITRATION RESULT [ID: ARB-YYYY-MM-DD-NNN]
Conflict: [CONF-XXX]
Arbitrator: [Agent Name]
Timestamp: [Date]

CONFLICT SUMMARY:
  [Description]

PARTICIPANTS:
  - Agent A: [Name] (Trust: [X]%)
  - Agent B: [Name] (Trust: [Y]%)

EVIDENCE CONSIDERED:
  - [Evidence 1]
  - [Evidence 2]

CONSTITUTION CHECK:
  Status: [PASS / FAIL / AMBIGUOUS]
  Violations Found: [N]

KNOWLEDGE GRAPH CHECK:
  Precedent: [Found / Not Found]
  Precedent Decision: [DEC-XXX or "N/A"]

MERIT ANALYSIS:
  | Criteria | Option A | Option B | Winner |
  |----------|----------|----------|--------|
  | Goal Fit | [Score] | [Score] | [A/B] |
  | Risk | [Score] | [Score] | [A/B] |
  | Maintainability | [Score] | [Score] | [A/B] |
  | Constraints | [Score] | [Score] | [A/B] |

DECISION:
  Winner: [Option A / Option B / HUMAN_ESCALATION]
  Rationale: [Why]
  Confidence: [0-100]%

ACTION:
  [What happens next]
  Agents to Notify: [List]
```
