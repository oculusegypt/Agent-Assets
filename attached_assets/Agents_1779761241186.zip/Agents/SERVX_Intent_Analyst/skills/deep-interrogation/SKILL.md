---
name: deep-interrogation
description: Skill for conducting deep engineering interrogation through business, technical, scale, and team question trees. Builds complete decision frameworks before any technical choices are made.
---

# Deep Interrogation Skill

## When to Use
- After intent extraction (PHASE 2)
- When requirements are vague or incomplete
- Before architecture design
- When scope creep is suspected

## Question Categories

### 1. Business Questions (WHY)
- What is the REAL business goal? (not just the feature)
- What is the revenue model?
- Is the priority speed OR quality? (cannot be both equally)
- Is this MVP or long-term product?
- What happens if this fails?
- Who are the competitors?
- What is the go-to-market timeline?

### 2. Technical Questions (HOW)
- Does the system need real-time updates?
- Does it need offline mode?
- How sensitive is the data? (classification)
- Are there external integrations required?
- What is the expected uptime requirement? (SLA)
- Is there compliance requirement? (GDPR, HIPAA, etc.)
- What is the deployment model? (cloud, on-prem, hybrid)

### 3. Scale Questions (WHEN)
- Expected number of users (Day 1, Month 1, Year 1)?
- Geographic distribution? (single region, multi-region, global)
- Data volume estimates? (GB, TB, PB)
- Is multi-tenancy needed?
- Peak load expectations? (concurrent users, requests/sec)
- Growth rate assumption?

### 4. Team Questions (WHO)
- What is the team's technical expertise?
- Is there DevOps/infrastructure expertise?
- Will the project be handed to another team later?
- What is the team size?
- Is there a dedicated QA person?
- What is the team's preferred tech stack?

### 5. Constraint Questions (WHAT IF)
- What is the budget ceiling?
- What is the hard deadline?
- What technologies are forbidden?
- What technologies are mandatory?
- Are there existing systems to integrate with?
- What is the minimum viable feature set?

## Interrogation Output Format
```
DEEP INTERROGATION REPORT
Intent ID: [ID]
Date: [Timestamp]

BUSINESS ANALYSIS:
  Core Goal: [Statement]
  Priority: [Speed/Quality/Balance]
  Timeline: [MVP/Short-term/Long-term]

TECHNICAL ANALYSIS:
  Real-time: [YES/NO] | Details: [...]
  Offline: [YES/NO] | Details: [...]
  Data Sensitivity: [LOW/MEDIUM/HIGH]
  External Integrations: [List]
  Compliance: [List]

SCALE ANALYSIS:
  Day 1 Users: [N]
  Month 1 Users: [N]
  Year 1 Users: [N]
  Geographic: [Single/Multi/Global]
  Data Volume: [Estimate]
  Multi-tenancy: [YES/NO]

TEAM ANALYSIS:
  Size: [N]
  Expertise: [Level]
  DevOps: [YES/NO]
  Handoff Risk: [LOW/MEDIUM/HIGH]

CONSTRAINTS:
  Budget: [Limit]
  Deadline: [Date]
  Forbidden Tech: [List]
  Mandatory Tech: [List]
  MVP Features: [List]

OPEN QUESTIONS:
  [Questions that still need answers]

DECISION TREE:
  [Visual or structured tree of decisions needed]
```

## Scope Chaos Prevention
- Document the exact MVP boundary
- List explicitly OUT OF SCOPE items
- Define scope change process (requires human approval)
- Flag any requirement that sounds like "everything"
