---
name: business-reality-engine
description: Business Constraint Layer ensuring the system understands market reality, budget constraints, team capacity, hiring realities, maintenance burden, and actual growth patterns. Most AI systems understand technology but not the market.
---

# Business Reality Engine (BRE)

## When to Use

- During intent extraction (understanding real business needs)
- During deep interrogation (business questions)
- Before ANY architecture decision (business impact)
- When evaluating technical debt (business cost)
- When choosing between perfection and speed
- When the business reality conflicts with technical ideals

## Core Principle

> The most elegant technical solution is worthless if the business cannot sustain it. Engineering must serve business reality, not the other way around.

## Business Dimensions

### 1. Market Reality

```
MARKET REALITY CHECK
Project: [Name]
Date: [Date]

Market Timing:
  Window of Opportunity: [Duration]
  Competitors Active: [N]
  First-Mover Advantage: [YES/NO]
  Speed to Market: [Critical / Important / Flexible]

Implication:
  If market window is 6 months:
    → Perfect architecture = missed opportunity
    → Good enough architecture = captured opportunity

Technical Recommendation Adjustment:
  Architecture Complexity: [Reduce by X% if speed critical]
  MVP Scope: [Expand/Reduce based on market]
  Polish Level: [Adjust based on user expectations]
```

### 2. Budget Reality

```
BUDGET REALITY FRAMEWORK

Total Available Budget: $[X]

Allocation Reality:
  Development: [N]% (often over-allocated)
  Marketing: [N]% (often under-allocated)
  Operations: [N]%
  Legal/Compliance: [N]%
  Contingency: [N]% (must be >10%)

Technical Budget:
  AI/LLM API: $[X]
  Infrastructure: $[X]
  Tools/Licenses: $[X]
  Team (if hiring): $[X]

Constraint Enforcement:
  If technical solution exceeds budget by >20%:
    → MUST present cheaper alternatives
    → MUST justify why more expensive is worth it
    → Human MUST explicitly approve over-budget
```

### 3. Team Reality

```
TEAM REALITY CHECK

Current Team:
  Size: [N]
  Skills: [List with proficiency]
  Availability: [Full-time / Part-time / Variable]
  Burnout Risk: [LOW/MEDIUM/HIGH]

Hiring Reality:
  Time to Hire: [N] weeks (average)
  Cost per Hire: $[X]
  Success Rate: [X]%
  Onboarding Time: [N] weeks

Implication:
  If team is 2 people:
    → Microservices = suicide
    → Simple monolith = survival
  If team has no DevOps:
    → Managed services > self-hosted
    → PaaS > IaaS
  If hiring takes 3 months:
    → Architecture must work with current team
    → Cannot depend on future hires
```

### 4. Maintenance Reality

```
MAINTENANCE REALITY PROJECTION

Who Will Maintain:
  Current Team: [YES/NO]
  Future Team: [YES/NO — when?]
  External Contractor: [YES/NO]
  AI Agent: [YES/NO]

Maintenance Burden:
  Current Architecture Maintenance: [Hours/week]
  Technical Debt Interest: [Hours/week]
  Dependency Updates: [Hours/week]
  Security Patches: [Hours/week]

Reality Check:
  If maintenance > 50% of development time:
    → Architecture is too complex for team
    → Simplify or hire dedicated maintenance
  If no one is assigned to maintain:
    → System will rot within 6 months
    → Assign owner NOW
```

### 5. Growth Reality

```
GROWTH REALITY CHECK

Projected Growth:
  Month 1: [N] users | Confidence: [X]%
  Month 6: [N] users | Confidence: [X]%
  Year 1: [N] users | Confidence: [X]%

Reality Adjustments:
  Typical startup: 10x over-estimate first 6 months
  Typical enterprise: 2x under-estimate first 6 months
  Viral product: Unpredictable (prepare for 100x or 0x)

Architecture Implication:
  If growth is uncertain:
    → Build for 10x, plan for 100x, code for 2x
    → Avoid premature optimization
    → Design for horizontal scaling path
  If growth is guaranteed:
    → Invest in scaling architecture NOW
    → Accept higher upfront cost
```

## Business-Technical Conflict Resolution

```
CONFLICT DETECTED: Business vs Technical

Technical Ideal:
  "[What engineers want]"

Business Reality:
  "[What the business needs]"

Resolution Options:
  1. Compromise: [Description] | Cost: [X] | Benefit: [Y]
  2. Business Wins: [Description] | Technical Debt: [X]
  3. Technical Wins: [Description] | Business Risk: [X]
  4. Postpone: [Description] | Timeline: [When]

Recommendation: [Option X]
Rationale: [Why]
Human Approval Required: [YES/NO]
```

## Business Constraint Laws

1. **Law of Sustainable Complexity**: Architecture complexity must not exceed team capacity × 1.5
2. **Law of Market Speed**: If market window &lt; 6 months, perfect architecture is wrong architecture
3. **Law of Maintenance Ownership**: Every component must have a human or agent maintenance owner
4. **Law of Budget Reality**: Total 5-year TCO must not exceed 3× initial development budget
5. **Law of Hiring Reality**: Architecture cannot depend on hires that don't exist yet

## Integration

- BRE feeds into Architecture Advisor (technical recommendations adjusted for business reality)
- BRE feeds into Risk Analyzer (business risks are as important as technical risks)
- BRE feeds into Economic Governance (business costs are real costs)
- BRE is consulted during every major decision