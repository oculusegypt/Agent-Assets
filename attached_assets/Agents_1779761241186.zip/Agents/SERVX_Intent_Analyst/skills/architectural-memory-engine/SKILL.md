---
name: architectural-memory-engine
description: "Long-term architectural memory that records WHY decisions were made, WHY alternatives were rejected, accepted technical debt, and periodic architectural health checks. Prevents the root cause of system collapse: forgetting why."
---

# Architectural Memory Engine (AME)

## When to Use
- When making ANY architectural decision that affects the system structure
- When onboarding new developers or agents to the project
- When evaluating whether to change an existing architecture decision
- During architecture review meetings (quarterly recommended)
- When technical debt reaches a threshold requiring action

## Core Principle
> The most dangerous thing in software engineering is not bad code. It is forgetting WHY that code exists the way it does. AME ensures the "why" is never lost.

## Memory Structure

### 1. Decision Memory
Every architectural decision stored with:
```
DECISION MEMORY ENTRY
ID: [DEC-XXX]
Timestamp: [ISO date]
Decision Maker: [Human / Agent / Hybrid]

THE QUESTION:
  "[What was the decision about?]"

THE ANSWER (Chosen):
  "[What we decided]"

THE REJECTED:
  - Alternative A: "[Description]" | Why Rejected: "[Reason]"
  - Alternative B: "[Description]" | Why Rejected: "[Reason]"
  - Alternative C: "[Description]" | Why Rejected: "[Reason]"

THE REASONING:
  Primary Reason: "[Main justification]"
  Secondary Reasons: [List]
  Risks Accepted: [List]
  Trade-offs Made: [What we gained vs what we lost]

THE CONTEXT:
  Team Size: [N]
  Time Pressure: [HIGH/MEDIUM/LOW]
  Budget Constraints: [YES/NO]
  Market Pressure: [Description]
  Technical Constraints: [List]

THE FUTURE:
  Expected to Change By: [Date / "Unknown"]
  Change Trigger: [What would cause us to revisit this?]
  Migration Path: [How to change if needed]
  Estimated Migration Cost: [Time/Effort]

STATUS: ACTIVE / DEPRECATED / REVISED / UNDER_REVIEW
REVISIONS: [List of DEC-IDs that revised this]
```

### 2. Technical Debt Ledger
```
TECHNICAL DEBT ENTRY
ID: [DEBT-XXX]
Timestamp: [ISO date]

THE SHORTCUT:
  "[What we did instead of the right thing]"

WHY WE TOOK IT:
  - [Reason 1]
  - [Reason 2]

THE REAL COST:
  - Immediate: [Impact]
  - 3 Months: [Impact]
  - 6 Months: [Impact]
  - 1 Year: [Impact]

ACCEPTANCE CRITERIA:
  When to Pay: [Trigger condition]
  Max Acceptable Duration: [Time limit]
  Budget for Fix: [Effort estimate]

CURRENT STATUS:
  Accumulated Interest: [LOW/MEDIUM/HIGH/CRITICAL]
  Days Since Created: [N]
  Days Until Due: [N]
  Risk Level: [LOW/MEDIUM/HIGH/CRITICAL]
```

### 3. Architecture Health Journal
Quarterly reviews stored as:
```
ARCHITECTURE HEALTH REVIEW
Review Date: [Date]
Reviewer: [Agent/Human]

CURRENT STATE:
  Architecture Pattern: [Current pattern]
  Components: [N] | Healthy: [N] | At Risk: [N] | Failing: [N]
  Dependencies: [N] | Current: [N] | Outdated: [N] | Vulnerable: [N]
  Technical Debt Items: [N] | Critical: [N] | High: [N] | Medium: [N]

DECISION INTEGRITY:
  Active Decisions: [N]
  Deprecated Decisions: [N]
  Contradictions Found: [N]
  Unjustified Deviations: [N]

ARCHITECTURE DRIFT:
  Drift Score: [0-100] (100 = perfect alignment with original vision)
  Drift Areas: [List]
  Drift Velocity: [INCREASING / STABLE / DECREASING]

RECOMMENDATIONS:
  - [Action 1] | Priority: [P0/P1/P2]
  - [Action 2] | Priority: [P0/P1/P2]
```

## Why-First Documentation
Every component in the system MUST have a WHY file:
```
/component-name/WHY.md

Question: Why does this component exist?
Answer: [...]

Question: Why is it structured this way?
Answer: [...]

Question: What would make us change it?
Answer: [...]

Question: What are we accepting as technical debt?
Answer: [...]

Last Updated: [Date]
```

## Integration with Knowledge Graph
AME is the narrative layer on top of SKGE:
- SKGE stores the WHAT and WHO (structured graph)
- AME stores the WHY and WHY NOT (narrative memory)
- Together they form complete project intelligence

## Access Patterns
- Before changing ANY existing code --> read WHY.md
- Before proposing alternative architecture --> read Decision Memory
- During quarterly review --> read Health Journal
- When technical debt reaches threshold --> read Debt Ledger

## File Storage
Stored in /memories/architectural-memory/:
- decisions/DEC-XXX-WHY.md -- narrative decision memory
- debt/DEBT-XXX.md -- technical debt entries
- health/Q[1-4]-YYYY-review.md -- quarterly reviews
- whys/COMPONENT-XXX.md -- per-component why files
