---
name: quality-assurance
description: Skill for ensuring production-grade code quality through continuous metrics, maintainability audits, test coverage analysis, and regression detection.
---

# Quality Assurance Skill

## When to Use
- Before production deployment (PHASE 6)
- During continuous auditing (PHASE 7)
- After any code change
- For long-term stability forecasting (PHASE 8)

## Quality Immunity Metrics

The system continuously measures:

| Metric | Target | Critical Threshold |
|--------|--------|-------------------|
| Architecture Integrity | 90%+ | < 70% |
| Security Stability | 95%+ | < 80% |
| Maintainability | 85%+ | < 60% |
| Dependency Health | 90%+ | < 70% |
| Agent Alignment | 95%+ | < 80% |
| Production Readiness | 90%+ | < 75% |

## Quality Audit Checklist

### 1. Code Quality
- [ ] Strict typing enforced (no `any`)
- [ ] No circular dependencies
- [ ] Modular isolation respected
- [ ] Single responsibility per module
- [ ] No dead code
- [ ] Consistent naming conventions

### 2. Test Coverage
- [ ] Unit tests: > 70% for critical paths
- [ ] Integration tests: all API endpoints
- [ ] E2E tests: critical user journeys
- [ ] Error handling tested
- [ ] Edge cases covered

### 3. Documentation Quality
- [ ] README exists and is current
- [ ] API documentation complete
- [ ] Architecture diagrams current
- [ ] Decision log maintained
- [ ] Onboarding docs for new developers

### 4. Maintainability
- [ ] Average cyclomatic complexity < 10
- [ ] No files > 300 lines (without strong reason)
- [ ] Dependencies up to date
- [ ] No TODO comments older than 30 days
- [ ] Consistent code style (linting passes)

## Regression Detection
After every change, verify:
- [ ] Previous tests still pass
- [ ] Performance not degraded > 10%
- [ ] No new security vulnerabilities
- [ ] Constitution still respected
- [ ] Business logic unchanged (unless approved)

## Quality Score Calculation
```
Quality Score = weighted_average(
  code_quality * 0.25,
  test_coverage * 0.25,
  documentation * 0.20,
  maintainability * 0.20,
  security * 0.10
)
```

## Enforcement
- Score >= 90%: PASS → Proceed
- Score 75-89%: PASS_WITH_WARNINGS → Fix warnings before next phase
- Score 60-74%: CONDITIONAL → Human approval required
- Score < 60%: BLOCKED → Must improve before proceeding

## Quality Report Format
```
QUALITY REPORT [PHASE] [TIMESTAMP]
Overall Score: [X]/100
Status: PASS | PASS_WITH_WARNINGS | CONDITIONAL | BLOCKED

Breakdown:
  Code Quality: [X]/100
  Test Coverage: [X]/100
  Documentation: [X]/100
  Maintainability: [X]/100
  Security: [X]/100

Findings:
  [List of issues with severity]

Action Items:
  [Required fixes]
```
