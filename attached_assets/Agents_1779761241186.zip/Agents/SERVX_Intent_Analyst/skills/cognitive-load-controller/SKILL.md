---
name: cognitive-load-controller
description: Cognitive Load Controller that protects the human developer's mind from decision fatigue, choice overload, architectural overwhelm, and token anxiety. The system governs the human as much as the AI governs itself.
---

# Cognitive Load Controller (CLC)

## When to Use
- Before presenting ANY decision to the human
- When there are too many options (>7)
- When the human has been making decisions for too long
- When complexity exceeds human cognitive capacity
- When token costs are causing anxiety
- During every human interaction checkpoint

## Core Principle
> The most expensive resource is not tokens. It is the human's attention, decision-making capacity, and mental energy. A system that exhausts its human is a failed system regardless of its technical excellence.

## Cognitive Load Types

### 1. Decision Fatigue
**Symptoms**: Human makes poorer decisions over time, approves without reading, rejects everything.

**Detection**:
- Number of decisions presented in last hour > 5
- Average time spent per decision declining
- Approval rate approaching 100% (not reading)
- Rejection rate approaching 100% (overwhelmed)

**Mitigation**:
```
DECISION BATCHING
Instead of: 10 individual decisions
Do: 1 consolidated decision package with:
  - Executive Summary (2 sentences)
  - Only HIGH-RISK decisions need individual review
  - LOW-RISK decisions: batch approve with 1 click
  - Option: "Delegate low-risk decisions to auto-approval"
```

### 2. Choice Overload
**Symptoms**: Too many options → human chooses none or defaults to first option.

**Mitigation**:
```
CHOICE SIMPLIFICATION
Original: 7 database options
Presented: 3 options only
  - Recommended (our analysis)
  - Conservative (lowest risk)
  - Aggressive (highest reward)

Hidden: Other 4 options available on request
Reasoning: "Click to see all 7 options"
```

### 3. Architectural Overwhelm
**Symptoms**: Human loses sight of the big picture, can't connect decisions.

**Mitigation**:
```
CONTEXT PRESERVATION
Before every decision, show:
  "You are here: [Phase X of 8]"
  "This decision affects: [2 components]"
  "Previous related decision: [DEC-XXX — click for context]"
  "Estimated impact: [LOW/MEDIUM/HIGH]"
  "Time needed to review: [2 minutes]"
```

### 4. Token Anxiety
**Symptoms**: Human worries about cost, skips analysis, approves quickly.

**Mitigation**:
```
COST TRANSPARENCY
Before every analysis:
  "This analysis will use approximately [N] tokens"
  "Your session budget: [N] tokens remaining"
  "Estimated cost: $[X]"
  "Is this analysis worth the cost? [YES / SKIP / REDUCE SCOPE]"

After analysis:
  "Actual cost: [N] tokens ($[X])"
  "Value delivered: [Summary]"
  "Was it worth it? [YES / NO / NEUTRAL]"
```

## Cognitive Budget Management
```
HUMAN COGNITIVE BUDGET
Daily Budget: 100 points

Cost per decision type:
  Low-risk auto-approval: 0 points (human doesn't see it)
  Low-risk batch: 2 points per batch
  Medium-risk individual: 10 points per decision
  High-risk individual: 25 points per decision
  Crisis / Emergency: 50 points

Tracking:
  Points used today: [N]/100
  Remaining capacity: [N] points
  Estimated decisions remaining: [N]

Warnings:
  🟡 At 60%: "You've used 60 points. Consider batching remaining decisions."
  🔴 At 80%: "You've used 80 points. Only critical decisions should be presented individually."
  🚨 At 95%: "You've used 95 points. All remaining decisions will be batched. Take a break?"
```

## Human Protection Rules
1. **No More Than 5 Individual Decisions Per Hour**: Batch the rest
2. **No Decisions During Off Hours**: Respect timezone and availability
3. **Mandatory Break After 3 High-Risk Decisions**: Force 10-minute cooldown
4. **Auto-Approve Threshold**: Human sets auto-approval threshold (e.g., "auto-approve anything below $50 and LOW risk")
5. **Digest Mode**: Option to receive daily digest instead of real-time interruptions
6. **Complexity Filter**: Hide implementation details, show only architectural implications

## Interface Design Principles
```
HUMAN INTERFACE PRINCIPLES

1. PROGRESS INDICATOR
   Always show: [Phase X of 8] → [Current Phase Name]
   Sub-indicator: [Step Y of Z in current phase]

2. DECISION CARD FORMAT
   ┌─────────────────────────┐
   │ DECISION: [Short title] │
   │ Impact: [LOW/MED/HIGH]│
   │ Time: [2 min review]   │
   │                        │
   │ Recommendation: [X]    │
   │ (Why: 1 sentence)      │
   │                        │
   │ [APPROVE] [MODIFY]     │
   │ [REJECT] [DEFER]       │
   │ [View Full Analysis]   │
   └─────────────────────────┘

3. SUMMARY BEFORE EXECUTION
   Before executing approved decisions, show:
   "You approved [N] decisions today:"
   "- [N] LOW risk (auto-approved)"
   "- [N] MEDIUM risk (you reviewed)"
   "- [N] HIGH risk (detailed review)"
   "Total cognitive load: [N] points / 100"
   "Ready to execute? [EXECUTE ALL] [REVIEW AGAIN]"

4. END-OF-SESSION SUMMARY
   "Session Summary:"
   "Decisions made: [N]"
   "Cognitive load: [N]/100 points"
   "Tokens used: [N]"
   "Next session recommended: [Tomorrow / In 2 hours]"
   "Pending items: [N] (will be presented next session)"
```

## Emergency Override
Human can always:
- "SHOW ME EVERYTHING" — bypass all simplification
- "I WANT FULL CONTROL" — disable auto-approval
- "EMERGENCY STOP" — halt all agents immediately
- "SIMPLIFY MORE" — increase simplification level

## Cognitive Load Metrics
```
COGNITIVE LOAD REPORT [Daily]
Human: [Name]
Date: [Date]

Decisions Presented: [N]
Decisions Approved: [N]
Decisions Rejected: [N]
Decisions Deferred: [N]

Cognitive Points Used: [N]/100
Peak Load Time: [Timestamp]
Lowest Decision Quality: [Which decision showed fatigue]

Recommendations for Tomorrow:
  - Batch decisions [X] and [Y] together
  - Consider auto-approving [Category Z]
  - Schedule complex decision [W] for morning
```
