---
name: ai-trust-score-system
description: Dynamic Trust Scoring system that evaluates agent accuracy, hallucination rate, stability, decision quality, and regression rate. Not all agents should be trusted equally.
---

# AI Trust Score System (TSS)

## When to Use
- Before weighing an agent's recommendation
- When conflicts arise between agents
- When deciding delegation authority
- During quarterly agent performance review
- When an agent's trust score drops below threshold
- When promoting or demoting agent responsibilities

## Core Principle
> Trust must be earned, measured, and continuously validated. Blind trust in AI agents is as dangerous as blind trust in humans.

## Trust Dimensions

### 1. Accuracy Score (Weight: 25%)
```
ACCURACY METRICS
Agent: [Name]
Period: [Last 30 days]

Correct Decisions: [N] / Total: [M] = [X]%
Correct Predictions: [N] / Total: [M] = [X]%
Correct Technology Claims: [N] / Total: [M] = [X]%
Correct API Descriptions: [N] / Total: [M] = [X]%

Accuracy Score: [0-100]
Trend: [IMPROVING / STABLE / DECLINING]
```

### 2. Hallucination Rate (Weight: 25%)
```
HALLUCINATION METRICS
Agent: [Name]
Period: [Last 30 days]

Fake APIs Claimed: [N]
Fake Libraries Claimed: [N]
Non-existent Functions: [N]
Incorrect Documentation: [N]
Fabricated Benchmarks: [N]

Total Claims Checked: [N]
Hallucinations Found: [N]
Hallucination Rate: [X]%

Score: [100 - Hallucination Rate]
Trend: [IMPROVING / STABLE / DECLINING]
Severity Distribution:
  Critical (blocked execution): [N]
  High (caught in review): [N]
  Medium (minor inaccuracy): [N]
  Low (stylistic): [N]
```

### 3. Stability Score (Weight: 15%)
```
STABILITY METRICS
Agent: [Name]
Period: [Last 30 days]

Consistent Outputs: [N] / Total: [M] = [X]%
Template Compliance: [N] / Total: [M] = [X]%
Decision Consistency (same input → same output): [X]%
No Unexpected Behavior: [X]%

Score: [0-100]
Trend: [IMPROVING / STABLE / DECLINING]
```

### 4. Decision Quality (Weight: 20%)
```
DECISION QUALITY METRICS
Agent: [Name]
Period: [Last 30 days]

Human Override Rate: [X]% (lower is better, but 0% means human is rubber-stamping)
Optimal Decision Rate: [N] decisions were optimal / [M] total = [X]%
Risk Accurately Predicted: [N] / [M] = [X]%
Trade-off Quality: [Score 0-100]
Constitution Compliance: [N] / [M] = [X]%

Score: [0-100]
Trend: [IMPROVING / STABLE / DECLINING]
```

### 5. Regression Rate (Weight: 15%)
```
REGRESSION METRICS
Agent: [Name]
Period: [Last 30 days]

Changes Causing Regressions: [N]
Changes Requiring Rollback: [N]
Quality Score Impact (average): [X]%
Technical Debt Introduced: [N] items

Regression Rate: [X]%
Score: [100 - Regression Rate]
Trend: [IMPROVING / STABLE / DECLINING]
```

## Trust Score Calculation
```
TRUST SCORE FORMULA
Agent: [Name]
Period: [Last 30 days]

Accuracy (25%): [Score] × 0.25 = [Weighted]
Anti-Hallucination (25%): [Score] × 0.25 = [Weighted]
Stability (15%): [Score] × 0.15 = [Weighted]
Decision Quality (20%): [Score] × 0.20 = [Weighted]
Anti-Regression (15%): [Score] × 0.15 = [Weighted]

TOTAL TRUST SCORE: [0-100]

Classification:
  90-100: TRUSTED — Can auto-approve low-risk decisions
  75-89: RELIABLE — Requires peer review for medium+ risk
  50-74: MONITORED — All decisions require review
  25-49: RESTRICTED — Only executes with human approval
  0-24: QUARANTINED — Isolated, requires investigation
```

## Trust Score Actions
```
TRUST SCORE GOVERNANCE

For TRUSTED agents (90-100):
  ✓ Can auto-approve LOW risk decisions
  ✓ Can execute without human approval (within bounds)
  ✓ Can mentor newer agents
  ✓ Review frequency: Quarterly

For RELIABLE agents (75-89):
  ⚠️ Peer review required for MEDIUM+ risk
  ⚠️ Cannot auto-approve
  ⚠️ Review frequency: Monthly

For MONITORED agents (50-74):
  🔶 All decisions require human or peer review
  🔶 Cannot make architectural decisions
  🔶 Review frequency: Weekly
  🔶 Action plan required to improve

For RESTRICTED agents (25-49):
  🔴 All execution requires human approval
  🔴 Cannot propose new decisions
  🔴 Can only execute pre-approved tasks
  🔴 Immediate investigation required

For QUARANTINED agents (0-24):
  🚨 ISOLATED — All activity blocked
  🚨 Investigation initiated
  🚨 Past decisions re-evaluated
  🚨 Recovery plan required before reactivation
```

## Trust Dynamics
- **Positive Events**: Correct decision (+2), Caught own error (+5), Excellent quality (+3)
- **Negative Events**: Hallucination (-10), Constitution violation (-15), Regression (-8), Human override of good decision (-3)
- **Recovery**: Agent can recover trust through consistent good performance over time
- **Decay**: Trust scores slowly decay if agent is inactive (prevent stale trust)

## Trust Score History
```
TRUST SCORE HISTORY
Agent: [Name]

Date       | Score | Event
-----------|-------|---------------------------
2026-01-15 |  85   | Initial calibration
2026-02-01 |  88   | Excellent security audit
2026-02-15 |  72   | Hallucination detected (API fake)
2026-03-01 |  78   | Recovery period
2026-03-15 |  82   | Consistent good performance
2026-04-01 |  65   | Regression introduced
2026-04-15 |  71   | Improvement plan executed
```

## Integration
- TSS feeds into CAE (Conflict Arbitration) — higher trust = more weight
- TSS feeds into ESM (Execution State Machine) — restricted agents can't execute without approval
- TSS feeds into Security Audit — low trust agents get extra scrutiny
- TSS is displayed in Observability Layer dashboard
