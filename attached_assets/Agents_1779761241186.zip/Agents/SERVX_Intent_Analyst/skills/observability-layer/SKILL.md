---
name: observability-layer
description: Engineering Telemetry Layer providing Logs, Traces, Agent Activity monitoring, Decision History, and Architectural Violation detection. Complete observability for the sovereign engineering system.
---

# Observability Layer (OL)

## When to Use
- Continuously across ALL phases and ALL agents
- When debugging why a decision was made
- When investigating agent behavior anomalies
- When auditing constitution violations
- When measuring system health
- When reporting to human stakeholders

## Core Principle
> You cannot govern what you cannot observe. Observability is not logging — it is understanding.

## Telemetry Streams

### 1. Agent Activity Logs
```
AGENT_LOG [ID: ALOG-YYYY-MM-DD-NNN-SEQ]
Timestamp: [ISO]
Agent: [Name]
Phase: [1-8]
Action: [What the agent did]
Target: [What was affected]

Input:
  [Summary of what agent received]

Output:
  [Summary of what agent produced]

Constitution Check:
  Status: [PASS/FAIL/SKIPPED]
  Violations: [List or "None"]

Token Consumption:
  Input Tokens: [N]
  Output Tokens: [N]
  Total: [N]

Duration: [Seconds]
Result: [SUCCESS/FAILURE/ERROR/RETRY]
Error Details: [If applicable]
```

### 2. Decision History Stream
```
DECISION_LOG [ID: DLOG-YYYY-MM-DD-NNN]
Timestamp: [ISO]
Decision ID: [DEC-XXX]
Phase: [1-8]

What:
  [Description of decision]

Why:
  [Rationale]

Who Proposed:
  Agent: [Name]
  Human Input: [YES/NO]

Who Ratified:
  [Human name or "Auto-approved (low risk)"]

Alternatives Rejected:
  - [Alt 1]: [Why rejected]
  - [Alt 2]: [Why rejected]

Risks Accepted:
  - [Risk 1]
  - [Risk 2]

Impact:
  Components Affected: [List]
  Requirements Satisfied: [List]
  Risks Introduced: [List]
  Dependencies Added: [List]

Constitution Alignment:
  Status: [ALIGNED/DEVIATION/DEBATED]
  Deviations: [List or "None"]
```

### 3. Architecture Violation Detection
```
VIOLATION_ALERT [ID: VIO-YYYY-MM-DD-NNN]
Severity: [CRITICAL/HIGH/MEDIUM/LOW]
Timestamp: [ISO]

Violation Type:
  [Which constitutional law was violated]

Violator:
  Agent: [Name]
  Action: [What they tried to do]

Violation Details:
  [Specific description]

Constitution Reference:
  Law: [LAW-XXX]
  Text: "[Law text]"

Auto-Action Taken:
  [BLOCK/REVERT/WARN/LOG]

Required Response:
  [What needs to happen next]

Human Notification:
  Status: [SENT/PENDING/N/A]
```

### 4. System Health Metrics
```
SYSTEM_HEALTH [Timestamp]

CAEOS Health Score: [0-100]

Component Health:
  Intent Extraction: [Score]
  Deep Interrogation: [Score]
  Decision Intelligence: [Score]
  Constitution Builder: [Score]
  Execution Engine: [Score]
  Risk Analysis: [Score]
  Security Audit: [Score]
  Performance Monitor: [Score]
  Dependency Guardian: [Score]
  Quality Guardian: [Score]
  Token Auditor: [Score]
  Conflict Arbitrator: [Score]
  Knowledge Graph: [Score]
  Architectural Memory: [Score]

Agent Health:
  Active Agents: [N]
  Healthy: [N]
  At Risk: [N]
  Isolated: [N]

Constitution Compliance:
  Total Violations (24h): [N]
  Critical: [N]
  High: [N]
  Medium: [N]
  Low: [N]

Performance:
  Avg Decision Time: [Duration]
  Avg Execution Time: [Duration]
  Await Human Input Time: [Duration]
  Bottleneck: [Which phase]

Quality:
  Avg Quality Score: [Score]
  Regression Events (24h): [N]
  Technical Debt Growth Rate: [Trend]
```

## Observability Tools
1. **grep**: Search across all log files for patterns
2. **glob**: Discover log files and telemetry artifacts
3. **read_file**: Inspect detailed logs
4. **google_sheets_write_range**: Record metrics in dashboards

## Log Retention
- Agent activity logs: 30 days active, archived after
- Decision logs: Permanent (architectural memory)
- Violation alerts: Permanent (compliance record)
- System health snapshots: 90 days rolling

## Human-Facing Dashboard
Key metrics humans care about:
- Project health score (0-100)
- Is anything BLOCKED requiring my attention?
- Are there any CRITICAL violations?
- What's the current phase and estimated completion?
- How much have we spent (tokens/time)?
- Are we on track or drifting?

## Integration
- OL feeds into CAE (Conflict Arbitration) for violation detection
- OL feeds into Security Auditor for security event logging
- OL feeds into Token Auditor for consumption tracking
- OL feeds into Knowledge Graph for event persistence
- OL feeds into Quality Guardian for regression detection
