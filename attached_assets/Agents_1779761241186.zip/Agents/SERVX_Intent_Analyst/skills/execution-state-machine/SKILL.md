---
name: execution-state-machine
description: Strict execution lifecycle state machine that governs every task through DRAFT → REVIEW → VALIDATED → APPROVED → EXECUTING → VERIFIED → SEALED → ARCHIVED. Prevents Chaos Execution, Duplicate Tasks, and Conflicting Refactors.
---

# Execution State Machine (ESM)

## When to Use
- For EVERY task, decision, refactor, or code change
- When multiple agents might work on the same component
- When tracking progress across the 8 CAEOS phases
- When preventing duplicate or conflicting work
- When auditing what happened and when

## Core Principle
> Every piece of work has a lifecycle. Without tracking it, chaos reigns.

## State Definitions

| State | Description | Entry Condition | Exit Condition | Duration Limit |
|-------|-------------|----------------|----------------|----------------|
| **DRAFT** | Proposed, not yet reviewed | Task created | Assigned reviewer | 24 hours |
| **REVIEW** | Under peer/constitution review | Reviewer assigned | Review complete | 48 hours |
| **VALIDATED** | Passed constitution + reality checks | All checks passed | Approved for execution | 12 hours |
| **APPROVED** | Ratified by human or delegated authority | Human/agent approval | Execution begins | 72 hours |
| **EXECUTING** | Active work in progress | Execution started | Work submitted | Per task estimate |
| **VERIFIED** | Work complete, under verification | Execution complete | All checks pass | 24 hours |
| **SEALED** | Immutable, approved record | Verification passed | N/A | Permanent |
| **ARCHIVED** | Historical reference only | Task superseded | N/A | Permanent |

## State Transitions

```
DRAFT
  → REVIEW (auto after 24h or manual trigger)
  → CANCELLED (if task abandoned)

REVIEW
  → VALIDATED (all checks pass)
  → REJECTED → BACK_TO_DRAFT (issues found)
  → BLOCKED (constitution violation detected)

VALIDATED
  → APPROVED (human/agent ratification)
  → REJECTED → BACK_TO_DRAFT (ratification denied)

APPROVED
  → EXECUTING (execution starts)
  → EXPIRED (not started within 72h, returns to DRAFT)

EXECUTING
  → VERIFIED (execution complete)
  → FAILED → BACK_TO_DRAFT (execution failed)
  → CONFLICT_DETECTED → BLOCKED (CAE intervenes)

VERIFIED
  → SEALED (all verification checks pass)
  → FAILED → BACK_TO_DRAFT (verification failed)

SEALED
  → ARCHIVED (superseded by new revision)
  → UNDER_REVISION (explicit revision initiated)

ARCHIVED
  → [No exit] (read-only historical record)
```

## Task Registry Format
```
TASK REGISTRY ENTRY [ID: TASK-YYYY-MM-DD-NNN]

METADATA:
  Title: [Task description]
  Created By: [Agent/Human]
  Created At: [Timestamp]
  Priority: [P0/P1/P2/P3]
  Estimated Effort: [Tokens/Time]

STATE HISTORY:
  [DRAFT] → [Timestamp] → Created by [Agent]
  [REVIEW] → [Timestamp] → Assigned to [Reviewer]
  [VALIDATED] → [Timestamp] → Constitution check: PASS
  [APPROVED] → [Timestamp] → Ratified by [Approver]
  [EXECUTING] → [Timestamp] → Started by [Agent]
  [VERIFIED] → [Timestamp] → Verified by [Verifier]
  [SEALED] → [Timestamp] → Finalized

CURRENT STATE: [State]
State Entered: [Timestamp]
State Deadline: [Timestamp]
Time in Current State: [Duration]

BLOCKING:
  Blocked By: [TASK-XXX or "None"]
  Blocks: [List of TASK-XXX]

AGENTS INVOLVED:
  - [Agent Name]: [Role] | State: [Current agent state]

CONSTITUTION CHECKS:
  - [Check 1]: [PASS/FAIL/PENDING]
  - [Check 2]: [PASS/FAIL/PENDING]

VERIFICATION RESULTS:
  - [Test 1]: [PASS/FAIL]
  - [Review 1]: [PASS/FAIL]

ARTIFACTS:
  - [Artifact 1]: [Location]
  - [Artifact 2]: [Location]
```

## Prevention Rules
1. **No Parallel Execution on Same Component**: If TASK-A is EXECUTING on component X, TASK-B cannot enter EXECUTING on component X until TASK-A is SEALED or ARCHIVED
2. **No State Skipping**: Cannot jump from DRAFT to EXECUTING (must pass through REVIEW, VALIDATED, APPROVED)
3. **Expiration**: APPROVED tasks expire after 72h of inactivity → return to DRAFT
4. **Conflict Detection**: If two tasks target the same decision/component, CAE must arbitrate before either enters EXECUTING
5. **Audit Trail**: Every state change is logged with who/what/when/why

## Automation Rules
- DRAFT → REVIEW: Auto after 24h or when reviewer assigned
- REVIEW → VALIDATED: Auto when all automated checks pass
- VALIDATED → APPROVED: Auto for low-risk decisions (with threshold), human for high-risk
- APPROVED → EXPIRED: Auto after 72h of no execution start
- EXECUTING → CONFLICT_DETECTED: Auto when CAE detects conflict

## Dashboard Metrics
```
ESM DASHBOARD [Timestamp]

State Distribution:
  DRAFT: [N]
  REVIEW: [N]
  VALIDATED: [N]
  APPROVED: [N]
  EXECUTING: [N]
  VERIFIED: [N]
  SEALED: [N]
  ARCHIVED: [N]
  BLOCKED: [N]
  EXPIRED: [N]

Alerts:
  🚨 Tasks expired (>72h in APPROVED): [N]
  🚨 Tasks blocked (>48h): [N]
  🚨 Conflicts detected: [N]
  ⚠️  Tasks in REVIEW >48h: [N]
  ⚠️  Tasks in DRAFT >24h: [N]

Throughput:
  Tasks completed today: [N]
  Average cycle time: [Duration]
  Bottleneck state: [Which state has most tasks]
```
