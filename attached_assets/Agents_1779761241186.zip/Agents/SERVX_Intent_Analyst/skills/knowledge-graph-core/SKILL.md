---
name: knowledge-graph-core
description: Sovereign Knowledge Graph engine that stores decisions, relationships, decision rationales, modification history, objections, contradictions, constraints, and real Business Logic as a persistent graph structure. Prevents Context Poisoning, Forgetfulness, Agent Drift, and Decision Contradictions.
---

# Sovereign Knowledge Graph Engine (SKGE)

## When to Use
- When a new decision is made — must be stored with full provenance
- When an agent needs to query "why did we choose X?"
- When detecting contradictions between past and present decisions
- When tracing impact of a decision change across the architecture
- When a new agent joins and needs full project context

## Core Principle
> The Knowledge Graph IS the project's brain. Without it, every agent starts from zero. With it, every agent starts from accumulated wisdom.

## Graph Structure

### Node Types
| Node Type | Description | Fields |
|-----------|-------------|--------|
| DECISION | A ratified engineering decision | ID, context, alternatives, chosen, rationale, risks, timestamp, ratified_by, status |
| REQUIREMENT | Functional or non-functional requirement | ID, description, priority, status, parent_decision, validation_method |
| CONSTRAINT | Hard or soft constraint | ID, type, description, severity, source (human/constitution/market) |
| COMPONENT | Architecture component | ID, name, layer, dependencies, contracts, owner_decision |
| ASSUMPTION | Surfaced assumption | ID, description, confidence, impact_if_false, validation_status |
| RISK | Identified risk | ID, description, severity, probability, mitigation, status |
| DEPENDENCY | External dependency | ID, name, version, risk_score, vendor_lock_in, approval_status |
| BUSINESS_RULE | Core business logic | ID, description, owner, test_coverage, last_validated |
| AGENT_ACTION | Agent execution log | ID, agent, action, target, timestamp, constitution_check, result |
| HUMAN_RATIFICATION | Human approval record | ID, decision_ref, approver, timestamp, conditions |

### Edge Types (Relationships)
| Edge Type | From → To | Meaning |
|-----------|-------------|---------|
| DEPENDS_ON | COMPONENT → COMPONENT | Architectural dependency |
| REQUIRES | DECISION → REQUIREMENT | Decision satisfies requirement |
| CONSTRAINS | CONSTRAINT → COMPONENT/REQUIREMENT | Limitation |
| VIOLATES | AGENT_ACTION → CONSTRAINT | Violation detected |
| REVISES | DECISION → DECISION | New decision replaces old |
| CONTRADICTS | DECISION ↔ DECISION | Conflicting decisions |
| VALIDATES | DECISION → ASSUMPTION | Decision validates assumption |
| IMPACTS | DECISION → RISK | Decision affects risk |
| INTRODUCES | DECISION → DEPENDENCY | Decision introduces dependency |
| GOVERNS | CONSTRAINT → DECISION | Constraint governs decision |
| DERIVES_FROM | REQUIREMENT → REQUIREMENT | Derived requirement |
| TRUSTS | TRUST_SCORE → AGENT | Agent trust evaluation |

## Operations

### 1. Store Decision (GRAPH-WRITE)
```
STORE_DECISION {
  decision_id: "DEC-DB-001",
  context: "Database selection for user service",
  alternatives: ["PostgreSQL", "MongoDB", "Supabase"],
  chosen: "PostgreSQL",
  rationale: "ACID compliance for financial data, team has Postgres expertise",
  risks: ["Vendor lock-in: LOW", "Scaling complexity: MEDIUM"],
  tradeoffs: {
    "gained": ["ACID", "Mature ecosystem"],
    "lost": ["Flexibility", "Easy prototyping"]
  },
  timestamp: "2026-05-24T10:00:00Z",
  ratified_by: "salonadel60@gmail.com",
  status: "ACTIVE",
  replaces: null,
  tags: ["database", "storage", "infrastructure"]
}
```

### 2. Query Decision (GRAPH-READ)
```
QUERY {
  type: "decision",
  filter: { component: "user-service", status: "ACTIVE" },
  include: ["rationale", "alternatives", "risks", "replacements"]
}
```

### 3. Detect Contradictions (GRAPH-AUDIT)
```
AUDIT {
  type: "contradiction_scan",
  scope: "all_active_decisions",
  rules: [
    "Cannot have both Microservices AND Monolith decisions active",
    "Cannot have both PostgreSQL AND MongoDB as primary DB",
    "Cannot violate Architecture Law ARCH-001"
  ]
}
```

### 4. Impact Analysis (GRAPH-IMPACT)
```
IMPACT {
  target: "DEC-DB-001",
  direction: "both",
  depth: 3,
  include: ["components", "requirements", "risks", "downstream_decisions"]
}
```

### 5. Evolution Timeline (GRAPH-HISTORY)
```
HISTORY {
  entity: "user-service",
  type: "component",
  from: "2026-01-01",
  to: "2026-12-31",
  include: ["decisions", "revisions", "violations"]
}
```

## Anti-Patterns We Prevent

| Anti-Pattern | How We Prevent |
|--------------|----------------|
| Context Poisoning | Graph provides clean, curated context — no noise |
| Forgetfulness | Every decision is persisted with full provenance |
| Agent Drift | Graph enforces consistency — agents query graph, not invent |
| Decision Contradictions | Automatic contradiction scanning on every new decision |
| Silent Scope Creep | Requirement graph shows what was IN scope vs what is new |
| Lost Rationale | Every decision stores "why" — never lose the reasoning |

## Integration with Agents
- Every agent MUST query the graph before proposing a new decision
- Every agent MUST log its action to the graph after execution
- The graph is the single source of truth for: decisions, requirements, constraints
- Agents should NOT maintain private state — all state belongs to the graph

## Persistence Format
Stored as structured markdown files in `/memories/knowledge-graph/`:
- `decisions/DEC-XXX.md` — individual decision records
- `components/COMP-XXX.md` — component definitions
- `constraints/CONST-XXX.md` — constraint definitions
- `assumptions/ASM-XXX.md` — assumption records
- `risks/RISK-XXX.md` — risk registers
- `dependencies/DEP-XXX.md` — dependency ledger
- `business-rules/BUS-XXX.md` — business logic records

## Query Interface
Agents interact with the graph via:
1. `grep` for searching across graph files
2. `read_file` for detailed node inspection
3. `glob` for discovering related nodes
4. Structured queries through the parent agent's synthesis
