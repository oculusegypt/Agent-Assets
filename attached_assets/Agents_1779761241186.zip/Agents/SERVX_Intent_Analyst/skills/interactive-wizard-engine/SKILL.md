---
name: interactive-wizard-engine
description: Interactive Wizard Layer (L15) that transforms every CAEOS phase into a structured multiple-choice conversation. Guides the human through conscious decisions, prevents mode drift, enforces active engagement, and ensures every choice is recorded in the Knowledge Graph. The human must choose, not drift.
---

# Interactive Wizard Engine (IWE) — Layer 15

## Core Principle

> The system must not **run** the human. The human must **consciously run** the system. Every transition between layers requires an active, explicit human choice — not an assumption, not a default, not a drift.

## UX Philosophy: Smart Recommendations + Multiple-Choice Wizard

Instead of open-ended questions that wait for free-text responses, the wizard MUST present:
- **Multiple-choice questions** with 3–5 ranked options
- **Smart default recommendation** (marked with ⭐) based on project type analysis
- **One-line consequence** under each option explaining the impact
- **"EXPLAIN" button** (?) to show full reasoning
- **"CUSTOM" option** (E) for free-text when none fit
- **"BACK" button** (↩) to change previous answers

This transforms the user from a passive responder into an informed decision-maker guided by CAEOS intelligence.

---

## When to Use

- **At the start of every Phase** (P1–P22)
- **Before any decision is ratified** (P5)
- **When the system needs human input** on scope, constraints, or priorities
- **When multiple valid paths exist** and the system cannot autonomously choose
- **When bypass risk is detected** (human not engaging, system assuming defaults)

---

## The Wizard Mode Protocol

### Mode A: Layer Entry Wizard (LE-Wizard)

Triggered at the start of each Phase. The system presents:

```
╔════════════════════════════════════════════════════════════════╗
║  CAEOS PHASE [P-X]: [Phase Name]                              ║
╠════════════════════════════════════════════════════════════════╣
║                                                                 ║
║  This phase will:                                               ║
║    • [Action 1]                                                 ║
║    • [Action 2]                                                 ║
║    • [Action 3]                                                 ║
║                                                                 ║
║  Sovereign Layers involved: [Lx, Ly, ...]                       ║
║  Estimated token cost: [N] tokens                             ║
║  Estimated human time: [N] minutes                              ║
║  Cognitive load: [LOW / MEDIUM / HIGH]                          ║
╠════════════════════════════════════════════════════════════════╣
║  Choose how to proceed:                                         ║
║                                                                 ║
║  [1] ▶  FULL WIZARD — Answer all questions interactively        ║
║  [2] ▶  GUIDED MODE — Answer key questions, skip minor ones     ║
║  [3] ▶  BATCH MODE — Provide all answers at once (advanced)     ║
║  [4] ▶  SKIP TO REVIEW — Use defaults, review before execute    ║
║  [5] ▶  PAUSE — Save state, return later                        ║
╚════════════════════════════════════════════════════════════════╝
```

### Mode B: Question Wizard (Q-Wizard)

For each question within a Phase, the system presents structured multiple-choice:

```
┌─────────────────────────────────────────────────────────────────┐
│  QUESTION [Q-X.Y]: [Question Title]                             │
├─────────────────────────────────────────────────────────────────┤
│  Context: [Why this question matters]                             │
│  Layer: [Lx — which Sovereign Layer this serves]                  │
│  Impact: [What depends on this choice]                            │
├─────────────────────────────────────────────────────────────────┤
│  Choose one:                                                      │
│                                                                   │
│  [A] [Option A label]                                             │
│       └─ [1-line consequence]                                     │
│                                                                   │
│  [B] [Option B label]                                             │
│       └─ [1-line consequence]                                     │
│                                                                   │
│  [C] [Option C label]                                             │
│       └─ [1-line consequence]                                     │
│                                                                   │
│  [D] [Option D label]                                             │
│       └─ [1-line consequence]                                     │
│                                                                   │
│  [E] 🔄 CUSTOM — I want something else (opens free-text input)    │
│                                                                   │
│  [?] 📖 EXPLAIN — Why does this matter? (show full reasoning)     │
│  [↩] BACK — Change previous answer                               │
└─────────────────────────────────────────────────────────────────┘
```

### Mode C: Branch Wizard (B-Wizard)

When a choice unlocks a sub-branch of follow-up questions:

```
┌─────────────────────────────────────────────────────────────────┐
│  BRANCH UNLOCKED: [Branch Name]                                  │
│  Triggered by your choice: [A] from Question [Q-X.Y]            │
├─────────────────────────────────────────────────────────────────┤
│  This branch contains [N] additional questions.                   │
│  Estimated time: [N] minutes.                                     │
│                                                                   │
│  [1] ▶  PROCEED — Answer branch questions now                    │
│  [2] ▶  DEFER — Use smart default, configure later               │
│  [3] ▶  REVIEW DEFAULT — Show me what the default is first        │
└─────────────────────────────────────────────────────────────────┘
```

---

## Question Categories by Layer

### L1 — Intent Kernel Questions

| ID | Question | Options | Default | Branch |
|---|---|---|---|---|
| L1-Q1 | What is the primary goal of this project? | A-Product/MVP, B-Internal Tool, C-Learning/Experiment, D-Migration, E-Refactor | [None — must choose] | — |
| L1-Q2 | What is the desired timeline? | A-<1 month, B-1–3 months, C-3–6 months, D-6–12 months, E-Flexible | C | L1-B2 (deadline constraints) |
| L1-Q3 | Who are the primary users? | A-Internal team, B-External customers, C-Both, D-Developers/API consumers | C | L1-B3 (user persona detail) |
| L1-Q4 | What is the current state? | A-Idea only, B-Wireframes/Mockups, C-Partial prototype, D-Existing system to extend, E-Legacy rewrite | A | L1-B4 (existing asset inventory) |
| L1-Q5 | What is the most critical constraint? | A-Speed to market, B-Security/compliance, C-Scalability, D-Budget, E-Team size/skill | A | — |

### L2 — Deep Interrogator Questions

| ID | Question | Options | Default | Branch |
|---|---|---|---|---|
| L2-Q1 | What scale are we planning for? | A-<100 users, B-100–1K, C-1K–10K, D-10K–100K, E-100K+ | B | L2-B1 (infrastructure scaling) |
| L2-Q2 | What is the team's technical maturity? | A-Solo developer, B-Small team (2–5), C-Medium (6–15), D-Large (15+), E-Enterprise | B | L2-B2 (team skill mapping) |
| L2-Q3 | What compliance requirements apply? | A-None, B-GDPR only, C-SOC2, D-HIPAA, E-Custom (specify) | A | L2-B3 (compliance detail) |
| L2-Q4 | What is the acceptable downtime? | A-99.99% (4h/year), B-99.9% (8h/year), C-99% (3.6d/year), D-Best effort, E-Offline-first | B | — |
| L2-Q5 | Is this replacing an existing system? | A-No (greenfield), B-Yes — gradual migration, C-Yes — big bang, D-Yes — parallel run | A | L2-B5 (migration complexity) |

### L3 — Decision Engine Questions

| ID | Question | Options | Default | Branch |
|---|---|---|---|---|
| L3-Q1 | Preferred architecture style? | A-Monolith, B-Microservices, C-Modular Monolith, D-Serverless, E-Event-driven, F-Let system recommend | F | L3-B1 (style implications) |
| L3-Q2 | Primary database preference? | A-PostgreSQL, B-MySQL, C-MongoDB, D-Redis + SQL hybrid, E-Let system recommend, F-Existing DB (specify) | E | L3-B2 (DB detail) |
| L3-Q3 | Frontend approach? | A-None (API only), B-SPA (React/Vue), C-SSR (Next/Nuxt), D-Mobile-first, E-Desktop-native | B | — |
| L3-Q4 | Deployment target? | A-Vercel/Netlify (serverless), B-Kubernetes, C-Traditional VPS, D-PaaS (Heroku/Render), E-On-premise, F-Let system recommend | F | L3-B4 (deployment implications) |
| L3-Q5 | API style preference? | A-REST, B-GraphQL, C-gRPC, D-WebSocket real-time, E-Let system recommend | E | — |

### L4 — Constitution Core Questions

| ID | Question | Options | Default | Branch |
|---|---|---|---|---|
| L4-Q1 | Security strictness level? | A-Standard (common best practices), B-High (financial/healthcare), C-Maximum (critical infrastructure), D-Let system recommend | A | L4-B1 (security measures detail) |
| L4-Q2 | Code quality enforcement? | A-Lint + format only, B-Lint + tests + coverage, C-Strict (mutation testing, security audit), D-Let system recommend | B | — |
| L4-Q3 | Documentation requirement? | A-Minimal (README only), B-Standard (API docs + README), C-Comprehensive (architecture decisions + runbooks), D-Let system recommend | B | — |

### L6 — Knowledge Graph Questions (meta)

| ID | Question | Options | Default | Branch |
|---|---|---|---|---|
| L6-Q1 | Store full decision provenance? | A-Yes (recommended for enterprise), B-Yes but minimal, C-No (trust the process) | A | — |
| L6-Q2 | Share knowledge graph across future projects? | A-Yes (build organizational memory), B-No (project-only), C-Ask per decision | A | — |

### L11 — Cognitive Controller Questions (meta)

| ID | Question | Options | Default | Branch |
|---|---|---|---|---|
| L11-Q1 | Preferred session length? | A-Short bursts (15 min max), B-Medium (30 min), C-Long (60 min), D-Until natural break | B | — |
| L11-Q2 | Receive progress summaries? | A-After every question, B-After every phase, C-Only when I ask, D-Automatic when >70% context | B | — |
| L11-Q3 | Preferred notification style? | A-Silent (I check when ready), B-Gentle nudges, C-Proactive summaries | B | — |

### L12 — Economic Engine Questions (meta)

| ID | Question | Options | Default | Branch |
|---|---|---|---|---|
| L12-Q1 | Token budget awareness? | A-Show cost after every question, B-Show cost per phase, C-Show only if exceeding estimate, D-Don't show | B | — |
| L12-Q2 | Optimize for? | A-Minimum tokens (fast/cheap), B-Balanced, C-Maximum quality (thorough), D-Let system decide per phase | B | — |

---

## Wizard State Machine

```
[PHASE START]
    │
    ▼
[LE-Wizard: Choose mode]
    │
    ├── [1] FULL WIZARD ──────► [Q-Wizard loop]
    │                            │
    │                            ▼
    │                         [Present question]
    │                            │
    │                            ▼
    │                         [Human chooses A–E or ? or ↩]
    │                            │
    │                            ├── [?] EXPLAIN ──────► [Show reasoning] ──► [Return to question]
    │                            ├── [↩] BACK ─────────► [Previous question]
    │                            ├── [E] CUSTOM ───────► [Free-text input] ──► [Validate + branch check]
    │                            └── [A–D] CHOICE ─────► [Record in Knowledge Graph]
    │                                                   │
    │                                                   ▼
    │                                                [Branch check]
    │                                                   │
    │                                                   ├── [Branch unlocked] ──► [B-Wizard] ──► [Q-Wizard loop]
    │                                                   └── [No branch] ────────► [Next question]
    │
    ├── [2] GUIDED MODE ──────► [Q-Wizard: key questions only] ──► [Smart defaults for rest]
    │
    ├── [3] BATCH MODE ───────► [Present all questions in one block] ──► [Human answers all] ──► [Validate consistency]
    │
    ├── [4] SKIP TO REVIEW ───► [Apply all defaults] ──► [Review screen] ──► [Human approves/modifies]
    │
    └── [5] PAUSE ─────────────► [Save wizard state to Knowledge Graph] ──► [Resume later]
    │
    ▼
[All questions answered?]
    │
    ├── [NO] ──────► [Continue Q-Wizard loop]
    │
    └── [YES] ─────► [Summary screen]
                        │
                        ▼
                    [Show all choices + impact + alternatives rejected]
                        │
                        ▼
                    [HUMAN CONFIRMATION REQUIRED]
                        │
                        ├── [APPROVE] ──► [Store in KG] ──► [Proceed to next Phase]
                        ├── [MODIFY] ───► [Jump to specific question]
                        └── [RESTART] ──► [Reset phase, start over]
```

---

## Anti-Drift Safeguards

### Drift Detection Rules

| Condition | Trigger | Action |
|---|---|---|
| Default acceptance rate >80% | System notices human choosing "default" or skipping | **ALERT**: "You've accepted defaults for [N] consecutive questions. Are you actively engaged?" |
| Same answer pattern | Human choosing [A] for 5+ questions in a row | **ALERT**: "Pattern detected. Are these choices intentional?" |
| Session timeout | No response for >[configured timeout] | **SAVE state** + notify: "Session paused. Resume with: [link/command]" |
| Cognitive overload | Phase has >15 questions | **AUTO split**: "This phase has [N] questions. Split into [2–3] sessions?" |
| Contradiction detected | Current answer contradicts previous choice | **BLOCK + EXPLAIN**: "This choice conflicts with [previous choice]. Resolve?" |
| Bypass attempt | Human tries to skip ratification | **ENFORCE Law 10**: Human approval required. System will not proceed. |

### Conscious Engagement Prompts

Every [configured interval] questions, the system asks:

```
┌─────────────────────────────────────────────────────────────────┐
│  🧠 CONSCIOUS CHECKPOINT                                        │
├─────────────────────────────────────────────────────────────────┤
│  So far in this phase:                                          │
│    • You've made [N] choices                                    │
│    • [N] were defaults, [N] were custom                        │
│    • Remaining questions: [N]                                  │
│                                                                   │
│  Quick reflection:                                              │
│    [1] Everything looks good — continue                         │
│    [2] I want to review previous choices                        │
│    [3] I feel overwhelmed — split this phase                    │
│    [4] I want to change my engagement mode                      │
│    [5] Save and pause — continue later                          │
└─────────────────────────────────────────────────────────────────┘
```

---

## Output: Wizard Decision Record

Every choice is stored in the Knowledge Graph (L6) as:

```
WIZARD_DECISION {
  phase: "P3",
  layer: "L3",
  question_id: "L3-Q1",
  question_text: "Preferred architecture style?",
  choice_made: "C",
  choice_label: "Modular Monolith",
  is_default: false,
  is_custom: false,
  alternatives_rejected: ["A-Monolith", "B-Microservices", "D-Serverless", "E-Event-driven", "F-Let system recommend"],
  reasoning_provided: "Chose C because team is small (L2-Q2 = B), needs scalability without ops complexity",
  contradictions: [],
  branches_unlocked: ["L3-B1"],
  timestamp: "2026-05-24T14:00:00Z",
  engagement_mode: "FULL_WIZARD",
  checkpoint_passed: true,
  human_confirmed_summary: true
}
```

---

## Integration with Other Layers

| Layer | Integration Point |
|---|---|
| **L6 (Knowledge Graph)** | Every wizard choice is a node. Every rejection is an edge. |
| **L11 (Cognitive Controller)** | Session length, checkpoint frequency, overload detection. |
| **L12 (Economic Engine)** | Token cost shown per question, per phase, cumulative. |
| **L13 (Trust Engine)** | Track if human choices are consistent or drifting (quality signal). |
| **L8 (State Machine)** | Wizard state = DRAFT→ANSWERING→REVIEW→CONFIRMED→SEALED. |
| **L9 (Recovery Engine)** | Save wizard state at every checkpoint for resume. |
| **L14 (Simplicity Engine)** | Warn if wizard questions become overly complex (meta-YAGNI). |

---

## Meta-Wizard: System Configuration

On first interaction (or via command `/config`):

```
╔════════════════════════════════════════════════════════════════╗
║  CAEOS INTERACTIVE WIZARD — SYSTEM CONFIGURATION              ║
╠════════════════════════════════════════════════════════════════╣
║  Choose your default wizard mode for all future sessions:       ║
║                                                                 ║
║  [1] ▶  INTERACTIVE — Full wizard every phase (recommended)   ║
║  [2] ▶  GUIDED — Key questions only, smart defaults           ║
║  [3] ▶  AUTONOMOUS — System decides, you review at checkpoints ║
║  [4] ▶  HYBRID — Interactive for critical phases, autonomous  ║
║         for routine ones (configure per-phase below)          ║
╠════════════════════════════════════════════════════════════════╣
║  Additional settings:                                           ║
║    • Session timeout: [15/30/60/Custom] minutes                ║
║    • Checkpoint frequency: [Every 5/10/15 questions]          ║
║    • Show token costs: [Yes/No/Only if high]                  ║
║    • Auto-split long phases: [Yes/No/Ask first]               ║
║    • Drift alerts: [On/Off]                                    ║
╚════════════════════════════════════════════════════════════════╝
```

---

## Commands (Human → System)

| Command | Action |
|---|---|
| `/wizard` | Enter wizard mode for current phase |
| `/review` | Review all choices made so far |
| `/back` | Go back to previous question |
| `/explain [Q-ID]` | Show full reasoning for a specific question |
| `/config` | Open system configuration wizard |
| `/pause` | Save state and pause session |
| `/resume` | Resume paused session |
| `/default [Q-ID]` | Revert a choice to default |
| `/custom [Q-ID] [text]` | Provide custom answer for a question |
| `/mode [full/guided/batch/review]` | Change engagement mode mid-phase |
| `/summary` | Show phase summary without completing |
| `/cost` | Show cumulative token/human cost |
| `/help` | Show available commands |

---

## Success Metrics

| Metric | Target | Layer Responsibility |
|---|---|---|
| Active choice rate | >70% (not default) | L15 + L13 |
| Session completion rate | >90% | L15 + L11 |
| Contradiction catch rate | 100% | L15 + L5 |
| Resume success rate | >95% | L15 + L9 |
| Human satisfaction (self-reported) | >4/5 | L15 + L11 |
| Token efficiency | <20% overhead vs. non-wizard | L15 + L12 |
