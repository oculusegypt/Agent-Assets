---
name: deterministic-mode
description: Deterministic Governance Mode that ensures the same inputs produce approximately the same outputs across all agents. Prevents Prompt Fragility, Agent Personality Drift, and Random Architectural Decisions through structured templates, decision templates, and controlled creativity boundaries.
---

# Deterministic Governance Mode (DGM)

## When to Use
- For ALL constitutional-level decisions
- When multiple agents must evaluate the same problem
- When consistency is more important than creativity
- When building the project constitution
- When ratifying architectural decisions
- When any agent's output needs to be reproducible

## Core Principle
> LLMs are stochastic by nature. Governance systems must be deterministic by design. We bridge the gap through structure, templates, and controlled boundaries.

## Deterministic Mechanisms

### 1. Structured Output Templates
Every agent MUST use strict output templates. No free-form creativity.

Example: Architecture Decision Template
```
=== DECISION TEMPLATE ===
DECISION_ID: [Format: DEC-{DOMAIN}-{NNN}]
TIMESTAMP: [ISO 8601]
AGENT: [Agent Name]

CONTEXT:
  [Exactly 2-3 sentences describing the problem]

OPTIONS:
  OPTION_A:
    Name: [Technology/Approach]
    Pros: [Max 3 bullet points]
    Cons: [Max 3 bullet points]
    Risk: [LOW/MEDIUM/HIGH]
    Score: [0-10]

  OPTION_B:
    Name: [Technology/Approach]
    Pros: [Max 3 bullet points]
    Cons: [Max 3 bullet points]
    Risk: [LOW/MEDIUM/HIGH]
    Score: [0-10]

  OPTION_C:
    Name: [Technology/Approach]
    Pros: [Max 3 bullet points]
    Cons: [Max 3 bullet points]
    Risk: [LOW/MEDIUM/HIGH]
    Score: [0-10]

RECOMMENDATION:
  Chosen: [OPTION_A/B/C]
  Confidence: [0-100]%
  Primary Reason: [1 sentence]

CONSTITUTION_CHECK:
  Violations: [YES/NO]
  If YES: [List]

RATIFICATION_NEEDED:
  [YES/NO] | Reason: [...]
=== END TEMPLATE ===
```

### 2. Decision Templates Library
Pre-defined templates for common decisions:
- `template_database_selection.md`
- `template_framework_selection.md`
- `template_deployment_model.md`
- `template_api_design.md`
- `template_security_mechanism.md`
- `template_scaling_strategy.md`

### 3. Controlled Temperature
For governance decisions:
- Temperature: 0.0 (maximum determinism)
- Top-p: 0.1 (minimal variation)
- For creative phases (exploration only): Temperature up to 0.3 with explicit boundaries

### 4. Multi-Agent Consensus
For critical decisions, require N agents to evaluate independently:
```
CONSENSUS PROTOCOL
Topic: [Decision topic]
Required Agreement: [X] out of [Y] agents

Agent 1 (Trust: [X]%): [Decision]
Agent 2 (Trust: [Y]%): [Decision]
Agent 3 (Trust: [Z]%): [Decision]

Consensus: [REACHED/NOT_REACHED]
Agreement Level: [X]%
Dissent: [List any disagreements]

If NOT_REACHED → Escalate to CAE (Conflict Arbitration)
```

### 5. Seed Values for Reproducibility
When comparing agent outputs:
- Use same random seed across evaluations
- Document seed in decision record
- Enable reproducible benchmarking

### 6. Versioned Prompts
All agent prompts are versioned:
```
AGENT PROMPT VERSION
Agent: [Name]
Version: [X.Y.Z]
Date: [Date]
Hash: [SHA256]

Changes from v[X.Y.Z-1]:
  - [Change 1]
  - [Change 2]

Compatibility:
  Compatible with CAEOS: [Version range]
  Breaking Changes: [YES/NO]
```

## Anti-Drift Measures

| Drift Type | Detection | Prevention |
|------------|-----------|------------|
| Personality Drift | Output style inconsistency | Enforce templates |
| Decision Drift | Same input → different output | Multi-agent consensus |
| Scope Drift | Expanding requirements | ESM state machine locks |
| Technical Drift | Unapproved tech changes | Constitution checks |
| Quality Drift | Declining output quality | Quality thresholds |

## Deterministic Checklist
Before any agent produces output:
- [ ] Is the output template correct?
- [ ] Is the temperature set to 0.0 for decisions?
- [ ] Are all fields in the template filled?
- [ ] Is the reasoning documented (not implied)?
- [ ] Can another agent reproduce this conclusion?

## Human Override
Humans can request creative mode for specific tasks:
```
CREATIVE MODE REQUEST
Task: [Description]
Requested By: [Human]
Duration: [Time limit]
Boundaries:
  - Must not violate: [List of constitutional laws]
  - Must stay within: [Scope boundaries]
  - Must return to deterministic mode by: [Date]

Approval: [Human signature]
```
