---
name: security-audit
description: Skill for performing comprehensive security audits on AI-generated code, architecture decisions, and system designs. Covers vulnerability scanning, auth flow integrity, data exposure simulation, and AI red-team analysis.
---

# Security Audit Skill

## When to Use
- Before ANY code execution (PHASE 6)
- After any code generation or modification (PHASE 7)
- When adding new dependencies (PHASE 3, 6)
- During continuous auditing (PHASE 7)

## Audit Checklist

### 1. Input Validation Audit
- [ ] All user inputs validated?
- [ ] SQL injection prevention?
- [ ] XSS prevention?
- [ ] File upload validation?
- [ ] Content-Type validation?

### 2. Authentication & Authorization Audit
- [ ] Auth flow integrity maintained?
- [ ] Role-based access control?
- [ ] JWT/session security?
- [ ] Password hashing (bcrypt/argon2)?
- [ ] MFA support considered?

### 3. Data Protection Audit
- [ ] PII handling compliant?
- [ ] Encryption at rest?
- [ ] Encryption in transit (TLS)?
- [ ] Data minimization applied?
- [ ] GDPR/CCPA considerations?

### 4. Dependency Security Audit
- [ ] No known vulnerabilities (check CVE database)?
- [ ] Reputable source?
- [ ] Actively maintained?
- [ ] License compatibility?
- [ ] Minimal attack surface?

### 5. API Security Audit
- [ ] Rate limiting configured?
- [ ] CORS properly set?
- [ ] API versioning?
- [ ] Error messages don't leak info?
- [ ] Request size limits?

### 6. Infrastructure Security Audit
- [ ] Secrets management (no hardcoded secrets)?
- [ ] Environment isolation?
- [ ] Logging and monitoring?
- [ ] Backup and recovery?

## AI Red-Team Analysis
Simulate an attacker trying to:
1. Exploit AI hallucinations (fake APIs, fake libraries)
2. Bypass input validation
3. Extract secrets from generated code
4. Find race conditions in multi-agent coordination
5. Exploit token economy to cause context leaks

## Audit Report Format
```
AUDIT ID: SEC-AUDIT-[PHASE]-[TIMESTAMP]
TARGET: [What is being audited]
SEVERITY: CRITICAL | HIGH | MEDIUM | LOW
FINDINGS:
- [ ] Finding 1: [Description] | Severity: [X] | Fix: [Action]
- [ ] Finding 2: ...
STATUS: PASS | PASS_WITH_WARNINGS | BLOCKED
RECOMMENDATIONS:
- [Action 1]
- [Action 2]
```

## Enforcement
- CRITICAL findings → BLOCK execution immediately
- HIGH findings → Require human approval
- MEDIUM findings → Log warning, schedule fix
- LOW findings → Note for next iteration
