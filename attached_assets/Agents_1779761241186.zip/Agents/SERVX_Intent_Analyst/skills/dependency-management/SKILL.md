---
name: dependency-management
description: Skill for managing, evaluating, and approving software dependencies. Prevents dependency explosion, vendor lock-in, and insecure library usage through systematic evaluation.
---

# Dependency Management Skill

## When to Use
- When proposing new libraries/frameworks (PHASE 3)
- Before installing any dependency (PHASE 6)
- During dependency audits (PHASE 7)

## Dependency Approval Workflow

### Step 1: Justification
Every new dependency MUST answer:
- What problem does it solve?
- Can we solve it without this dependency?
- What is the cost (bundle size, complexity, learning curve)?

### Step 2: Evaluation Matrix

| Criterion | Weight | Score (1-10) |
|-----------|--------|--------------|
| Maturity (stars, age, usage) | 20% | |
| Maintenance (last commit, issues) | 20% | |
| Security (CVEs, audit) | 25% | |
| Size (bundle impact) | 10% | |
| License (compatibility) | 10% | |
| Vendor Lock-in Risk | 15% | |

Minimum passing score: 7.0/10

### Step 3: Alternatives Check
Always compare at least 2 alternatives:
- Alternative A: [name] | Score: [X]
- Alternative B: [name] | Score: [X]
- Recommended: [name] | Score: [X]

### Step 4: Human Approval
- Present evaluation matrix
- Present recommendation
- Wait for ratification
- Log to Dependency Ledger

## Dependency Ledger Format
```
DEP-[ID]: [Library Name]@[Version]
  Approved By: [Human Name]
  Date: [Timestamp]
  Purpose: [What it solves]
  Score: [X]/10
  Risk Level: LOW | MEDIUM | HIGH
  Replacement Plan: [If needed later]
```

## Dependency Explosion Prevention Rules
1. Maximum 5 new dependencies per approval cycle
2. Prefer standard library over external package
3. Prefer small focused libraries over mega-frameworks
4. Re-evaluate every 30 days: still needed? still secure?
5. Remove unused dependencies immediately

## Vendor Lock-in Assessment
For each dependency, classify:
- **GREEN**: Easy to replace (e.g., lodash → native JS)
- **YELLOW**: Moderate effort (e.g., ORM → another ORM)
- **RED**: Very difficult (e.g., Firebase → self-hosted)
RED dependencies require extra justification and exit strategy.
