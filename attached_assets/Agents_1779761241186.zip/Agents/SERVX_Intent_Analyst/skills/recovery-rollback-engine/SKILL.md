---
name: recovery-rollback-engine
description: Sovereign Recovery Engine providing Snapshots, Architectural Rollbacks, Decision Rewinds, and Semantic Diffs. The safety net when agents corrupt architecture, dependencies cause collapse, or refactors destroy the system.
---

# Sovereign Recovery Engine (SRE)

## When to Use
- When an agent corrupts architecture
- When a dependency causes system collapse
- When a refactor breaks the system
- When a constitutional violation is detected post-execution
- When human orders a rollback
- During any disaster recovery scenario

## Core Principle
> Every system will fail. The question is: can you recover? Without a recovery engine, every failure is a catastrophe. With it, every failure is a learning opportunity.

## Recovery Mechanisms

### 1. Architectural Snapshots
```
SNAPSHOT [ID: SNAP-YYYY-MM-DD-NNN]
Timestamp: [ISO]
Trigger: [AUTO/MANUAL/SCHEDULED]

Contents:
  □ Constitution State
  □ Knowledge Graph State
  □ Decision Ledger (all active decisions)
  □ Component Definitions
  □ Dependency Graph
  □ Agent Trust Scores
  □ Quality Metrics
  □ ESM State (all tasks)

Integrity Check:
  Hash: [SHA256]
  Verification: [PASS/FAIL]

Storage Location: /memories/snapshots/SNAP-XXX/
Retention: [Duration / Permanent]
```

Scheduled snapshots:
- Before every phase transition (PHASE X → PHASE X+1)
- After every ratified decision
- Before any major refactor
- Daily automatic snapshots during active development
- Manual snapshots on demand

### 2. Decision Rewind
```
DECISION REWIND [ID: REWIND-YYYY-MM-DD-NNN]
Target Decision: [DEC-XXX]
Timestamp: [ISO]
Requested By: [Human/Agent/Auto-trigger]

Reason for Rewind:
  [Description]

Impact Analysis:
  Components Affected: [N]
  Downstream Decisions: [N]
  Dependencies Introduced: [N]
  Risks Introduced: [N]

Rewind Plan:
  1. [Step 1]
  2. [Step 2]
  3. [Step 3]

Rollback Targets:
  Restore Snapshot: [SNAP-XXX]
  Re-validate Decisions: [List of DEC-XXX to re-evaluate]
  Notify Agents: [List]

Safety Checks:
  □ Constitution still valid after rewind?
  □ No orphaned components?
  □ No dangling dependencies?
  □ Knowledge graph consistent?

Execution Status: [PENDING/APPROVED/EXECUTING/COMPLETE/FAILED]
```

### 3. Semantic Diffs
```
SEMANTIC DIFF [ID: DIFF-YYYY-MM-DD-NNN]
From: [SNAP-XXX or DECISION-XXX]
To: [SNAP-YYY or CURRENT]

Semantic Changes:
  Architecture Changes:
    - [What changed and why]

  Decision Changes:
    - [DEC-XXX]: [Changed from X to Y]

  Dependency Changes:
    + Added: [List]
    - Removed: [List]
    ~ Updated: [List]

  Constitution Changes:
    + New Laws: [List]
    - Removed Laws: [List]
    ~ Amended Laws: [List]

  Impact Summary:
    Risk Level Change: [INCREASED/DECREASED/STABLE]
    Complexity Change: [INCREASED/DECREASED/STABLE]
    Maintainability Change: [INCREASED/DECREASED/STABLE]
```

### 4. Agent Corruption Recovery
```
AGENT CORRUPTION DETECTED
Agent: [Name]
Detection Time: [ISO]
Detection Method: [Constitution Check / Quality Audit / Human Report / Anomaly Detection]

Corruption Type:
  [Hallucination / Constitutional Violation / Scope Creep / Quality Degradation / Trust Collapse]

Evidence:
  - [Evidence 1]
  - [Evidence 2]

Impact:
  Decisions Corrupted: [List]
  Components Affected: [List]
  Quality Score Impact: [X]%

Recovery Actions:
  1. ISOLATE agent: [Status]
  2. REVERT agent decisions: [List]
  3. RESTORE from snapshot: [SNAP-XXX]
  4. RE-EVALUATE affected decisions: [List]
  5. RE-TRAIN / RE-CONFIGURE agent: [Plan]

Post-Recovery:
  Root Cause Analysis: [...]
  Prevention Measure: [...]
  Agent Trust Score After Recovery: [X]%
```

### 5. Dependency Collapse Recovery
```
DEPENDENCY COLLAPSE DETECTED
Dependency: [Name]@[Version]
Detection Time: [ISO]

Failure Type:
  [Security Vulnerability / Breaking Change / Abandonment / License Change / Version Conflict]

Impact:
  Components Affected: [N]
  Downstream Dependencies: [N]
  Security Risk: [CRITICAL/HIGH/MEDIUM/LOW]

Recovery Plan:
  1. ISOLATE affected components
  2. REPLACE dependency with alternative: [Name]
  3. OR REVERT to previous working version: [Version]
  4. UPDATE all downstream components
  5. RE-RUN full test suite
  6. RE-AUDIT security

Prevention:
  Dependency Pinning: [Should we pin versions?]
  Monitoring: [Add to watch list]
```

## Recovery Protocol
```
RECOVERY PROTOCOL (5 Steps)

1. DETECT
   - Constitution violation detected
   - Quality threshold breached
   - Human reports issue
   - Automated anomaly detection

2. ISOLATE
   - Stop affected agent(s)
   - Block affected components
   - Prevent further damage

3. ASSESS
   - Determine scope of damage
   - Identify root cause
   - Choose recovery strategy:
     a) Rollback to snapshot
     b) Revert specific decisions
     c) Patch and continue

4. RECOVER
   - Execute chosen strategy
   - Verify recovery completeness
   - Re-run all validation checks

5. PREVENT
   - Document root cause
   - Update prevention rules
   - Adjust agent configuration
   - Update monitoring thresholds
```

## Rollback Granularity
- **Full System**: Restore entire snapshot
- **Phase Level**: Rollback to start of a specific phase
- **Decision Level**: Revert specific decisions and their impacts
- **Component Level**: Restore specific components
- **Agent Level**: Reset agent state and re-validate its decisions
