---
name: decision-intelligence
description: Skill for building engineering decision trees with trade-off analysis, risk scoring, cost/impact forecasting, and alternatives comparison for every architectural choice.
---

# Decision Intelligence Skill

## When to Use
- When making ANY technical decision (database, framework, architecture pattern, deployment model)
- When comparing alternatives for a technology choice
- When forecasting long-term impact of a decision

## Decision Framework

Every technical decision MUST contain:

| Element | Required | Description |
|---------|----------|-------------|
| Decision ID | YES | Unique identifier (e.g., DEC-DB-001) |
| Context | YES | What problem does this solve? |
| Options | YES | Minimum 3 alternatives |
| Recommendation | YES | Which option is recommended and why |
| Reasoning | YES | Engineering justification |
| Trade-offs | YES | What do we gain vs what do we lose? |
| Risks | YES | What could go wrong? |
| Cost Impact | YES | Time, money, tokens, expertise |
| Performance Impact | YES | Speed, throughput, latency |
| Maintenance Impact | YES | Complexity, documentation, team skill required |
| Scalability | YES | Will this decision scale? |
| Security Implications | YES | Any security concerns? |
| Human Ratification | YES | Required before execution |

## Decision Tree Building
1. Start with the core question (e.g., "Which database?")
2. Branch into categories (SQL vs NoSQL vs Managed)
3. For each branch, list specific technologies
4. For each technology, fill the full framework above
5. Score each option (1-10) across dimensions
6. Calculate weighted score
7. Present to human with recommendation

## Example: Database Selection

| Option | Pros | Cons | Fits | Score |
|--------|------|------|------|-------|
| PostgreSQL | Powerful, ACID, mature | Complex, needs expertise | Complex systems | 9/10 |
| MongoDB | Flexible, fast start | Future chaos, no schema | Prototype | 6/10 |
| Supabase | Fast dev, managed | Vendor lock-in | MVP | 7/10 |
| Firebase | Realtime excellent | Costly later, Google lock | Chat apps | 5/10 |

## Scoring Dimensions
- **Maturity** (1-10): How proven is this in production?
- **Team Fit** (1-10): Does the team know this?
- **Scalability** (1-10): Can it grow with the project?
- **Security** (1-10): Security posture out of the box?
- **Cost** (1-10): 10 = cheapest, 1 = most expensive
- **Maintainability** (1-10): How easy to maintain long-term?

## Human Ratification Protocol
- Present options table
- Present recommendation with reasoning
- Wait for explicit confirmation
- Log to Decision Ledger
- Only then proceed to execution
